/* assets.js — 스프라이트/배경 이미지 로딩과 그리기 */
(() => {
  const MD = window.MD, C = MD.C;
  const BGN = ['castle', 'crypt', 'ember', 'hall', 'throne'];
  const NAMES = ['hahoe', 'dokkaebi', 'fox', 'dosa', 'lion', 'maltugi', 'gaksi', 'reaper', 'soldier', 'archer', 'wisp', 'brute', 'boss'];
  const UI = ["boss_fill.png", "boss_frame.png", "btn_pri.png", "btn_pri_d.png", "btn_pri_h.png", "btn_pri_p.png", "btn_sec.png", "btn_sec_d.png", "btn_sec_h.png", "btn_sec_p.png", "card.png", "card_head.png", "card_sel.png", "card_sel_head.png", "chip.png", "divider.png", "dpad.png", "dpad_p.png", "fill.png", "gem.png", "gem_on.png", "keycap.png", "knob.png", "knob_h.png", "mark0.png", "mark1.png", "mark2.png", "menu_sel.png", "panel_main.png", "panel_sub.png", "pip.png", "pip_on.png", "ribbon.png", "slot.png", "slot_on.png", "tab.png", "tab_h.png", "tab_on.png", "tb_big.png", "tb_big_p.png", "tb_med.png", "tb_med_p.png", "tb_sm.png", "tb_sm_p.png", "tg_off.png", "tg_on.png", "toast.png", "track.png"];
  const imgs = {}, sils = {};

  const A = MD.Assets = {
    imgs, ready: false, bg: null,

    load(cb) {
      /* 레이어 배경: assets/bg/<구역>_<레이어>.png (하늘만 jpg). 목록은 MD.BG 메타에서 만든다 */
      const BGL = [];
      BGN.forEach((k) => { const m = MD.BG && MD.BG[k]; if (m) { BGL.push([k, 'sky']); ['clouds', 'far', 'mid', 'near', 'front'].forEach((l) => { if (m[l]) BGL.push([k, l]); }); } });
      let n = NAMES.length + 3 + 4 + BGN.length + UI.length + 1 + BGL.length;
      const done = () => { if (--n === 0) { A.ready = true; if (cb) cb(); } };
      /* UI 테두리 이미지를 미리 받아 둠 (처음 열 때 늦게 뜨는 것 방지) */
      A.ui = [];
      UI.forEach((f) => {
        const im = new Image();
        im.onload = () => { (im.decode ? im.decode() : Promise.resolve()).catch(() => {}).then(done); };
        im.onerror = done;
        im.src = 'assets/ui/' + f;
        A.ui.push(im);
      });
      /* 글꼴 */
      Promise.all([document.fonts.load('700 16px Galmuri11', '가나다'), document.fonts.load('400 16px Galmuri11', '가나다')])
        .catch(() => {}).then(done);
      const hp = new Image();
      hp.onload = () => { A.hp = hp; done(); };
      hp.onerror = done;
      hp.src = 'assets/hp.png';
      const ic = new Image();
      ic.onload = () => { A.icons = ic; done(); };
      ic.onerror = done;
      ic.src = 'assets/icons.png';
      NAMES.forEach((nm) => {
        const im = new Image();
        im.onload = () => { imgs[nm] = im; done(); };
        im.onerror = done;                       // boss 시트처럼 없는 파일은 조용히 건너뜀
        im.src = 'assets/sprites/' + nm + '.png';
      });
      const b = new Image();
      b.onload = () => { A.bg = b; done(); };
      b.onerror = done;
      b.src = 'assets/bg.svg';
      [['fx', 'fx.png'], ['beam', 'bossbeam.png'], ['obj', 'obj.png'], ['props', 'props.png']].forEach((a) => {
        const im = new Image();
        im.onload = () => { A[a[0]] = im; done(); };
        im.onerror = done;
        im.src = 'assets/' + a[1];
      });
      BGL.forEach((e) => {
        const im = new Image();
        im.onload = () => { (A.bgl[e[0]] = A.bgl[e[0]] || {})[e[1]] = im; done(); };
        im.onerror = done;
        im.src = 'assets/bg/' + e[0] + '_' + e[1] + (e[1] === 'sky' ? '.jpg' : '.png');
      });
      BGN.forEach((k) => {
        const im = new Image();
        im.onload = () => { A.bgs[k] = A.coverBg(im); done(); };
        im.onerror = done;
        im.src = 'assets/bg_' + k + '.jpg';
      });
    },

    bgs: {}, bgl: {},
    /* 배경을 1360x720 으로 꽉 채워 잘라 둠 (좌우 살짝 움직이는 시차용) */
    coverBg(im) {
      const W = C.CW + 80, H = C.CH, c = document.createElement('canvas');
      c.width = W; c.height = H;
      const x = c.getContext('2d'), s = Math.max(W / im.width, H / im.height);
      const w = im.width * s, h = im.height * s;
      x.drawImage(im, (W - w) / 2, (H - h) / 2, w, h);
      return c;
    },

    /* 이펙트 시트 한 칸. anchor: 'c' 중심, 'b' 바닥 중앙. scale 은 캔버스 픽셀 배율 */
    drawFx(ctx, key, frame, x, y, o) {
      const m = MD.FX_META, d = m && m.map[key];
      if (!A.fx || !d) return false;
      o = o || {};
      const t = ctx.getTransform(), s = o.scale || 1, cell = m.cell;
      const f = Math.max(0, Math.min(d.n - 1, frame | 0));
      ctx.save();
      ctx.setTransform(1, 0, 0, 1, t.e, t.f);
      ctx.imageSmoothingEnabled = false;
      ctx.globalAlpha = o.alpha == null ? 1 : o.alpha;
      if (o.add) ctx.globalCompositeOperation = 'lighter';
      ctx.translate(Math.round(x * C.K), Math.round(y * C.K));
      if (o.rot) ctx.rotate(o.rot);
      ctx.scale(o.flip ? -s : s, s);
      const ax = cell / 2, ay = o.anchor === 'b' ? d.by1 : cell / 2;
      ctx.drawImage(A.fx, (d.col + f) * cell, d.row * cell, cell, cell, -ax, -ay, cell, cell);
      ctx.restore();
      return true;
    },

    /* 보스 시트 (칸 크기·발 기준점은 BOSS_META: cw,ch,ax) */
    drawBoss(ctx, row, frame, cx, feet, flip, alpha, silColor, scale) {
      const m = MD.BOSS_META, src = imgs.boss;
      if (!src || !m) return false;
      const t = ctx.getTransform(), s = scale || 1;
      ctx.save();
      ctx.setTransform(1, 0, 0, 1, t.e, t.f);
      ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
      if (alpha != null) ctx.globalAlpha = alpha;
      ctx.translate(Math.round(cx * C.K), Math.round(feet * C.K));
      ctx.scale(flip ? -s : s, s);
      const ax = m.ax != null ? m.ax : m.cw / 2;
      const cols = m.cols || 8, nf = m.nf || 16, fi = Math.max(0, Math.min(nf - 1, Math.floor(frame))), srow = row * Math.ceil(nf / cols) + Math.floor(fi / cols);
      let img = src, sx = (fi % cols) * m.cw, sy = srow * m.ch;
      if (silColor) {                       /* 칸 하나짜리 실루엣만 만들어 캐시 (시트 전체 캔버스는 만들지 않음) */
        const key = 'B' + srow + '_' + fi + silColor;
        let c = sils[key];
        if (!c) {
          c = document.createElement('canvas'); c.width = m.cw; c.height = m.ch;
          const x = c.getContext('2d');
          x.drawImage(src, sx, sy, m.cw, m.ch, 0, 0, m.cw, m.ch);
          x.globalCompositeOperation = 'source-in'; x.fillStyle = silColor; x.fillRect(0, 0, m.cw, m.ch);
          sils[key] = c;
        }
        img = c; sx = 0; sy = 0;
      }
      ctx.drawImage(img, sx, sy, m.cw, m.ch, -ax, -(m.fy != null ? m.fy : m.ch - 6), m.cw, m.ch);
      ctx.restore();
      return true;
    },

    /* 오브젝트 시트 조각을 캔버스 픽셀 좌표(shake 오프셋만 반영)로 그림 */
    objDraw(ctx, key, px, py, w, h) {
      const d = MD.OBJ_META && MD.OBJ_META[key];
      if (!A.obj || !d) return false;
      ctx.drawImage(A.obj, d[0], d[1], d[2], d[3], px, py, w || d[2], h || d[3]);
      return true;
    },

    /* 소품 시트: 가로 중심 x, 발 높이 feet (로직 좌표), s: 배율 */
    prop(ctx, key, x, feet, s, alpha, flip) {
      const d = MD.PROPS_META && MD.PROPS_META[key];
      if (!A.props || !d) return false;
      const t = ctx.getTransform();
      ctx.save();
      ctx.setTransform(1, 0, 0, 1, t.e, t.f);
      ctx.imageSmoothingEnabled = false;
      if (alpha != null) ctx.globalAlpha = alpha;
      ctx.translate(Math.round(x * C.K), Math.round(feet * C.K));
      ctx.scale(flip ? -(s || 1) : (s || 1), s || 1);
      ctx.drawImage(A.props, d[0], d[1], d[2], d[3], -d[2] / 2, -d[3], d[2], d[3]);
      ctx.restore();
      return true;
    },

    has(nm) { return !!(imgs[nm] && MD.SPRITE_META[nm]); },

    /* 단색 실루엣 (피격 번쩍임, 대시 잔상용) */
    silhouette(nm, color) {
      const key = nm + color;
      if (sils[key]) return sils[key];
      const im = imgs[nm];
      if (!im) return null;
      const c = document.createElement('canvas');
      c.width = im.width; c.height = im.height;
      const x = c.getContext('2d');
      x.drawImage(im, 0, 0);
      x.globalCompositeOperation = 'source-in';
      x.fillStyle = color;
      x.fillRect(0, 0, c.width, c.height);
      return (sils[key] = c);
    },

    /* 색 변형 시트 (구역별 적 변종용) — 원본 위에 반투명 색을 덧씌움 */
    tinted(nm, color) {
      const key = 'T' + nm + color;
      if (sils[key]) return sils[key];
      const im = imgs[nm];
      if (!im) return null;
      const c = document.createElement('canvas');
      c.width = im.width; c.height = im.height;
      const x = c.getContext('2d');
      x.drawImage(im, 0, 0);
      x.globalCompositeOperation = 'source-atop';
      x.fillStyle = color;
      x.fillRect(0, 0, c.width, c.height);
      return (sils[key] = c);
    },

    /* cx: 가로 중심, feet: 발 높이 (로직 좌표). 캔버스 픽셀과 1:1로 찍어 선명하게 유지.
       silColor 가 'T'로 시작하면 색 변형 시트, 아니면 단색 실루엣. scale: 크기 배율 */
    draw(ctx, nm, row, frame, cx, feet, flip, alpha, silColor, scale, scaleY) {
      const m = MD.SPRITE_META[nm];
      const src = silColor ? (silColor.charAt(0) === 'T' ? A.tinted(nm, silColor.slice(1)) : A.silhouette(nm, silColor)) : imgs[nm];
      if (!src || !m) return false;
      ctx.save();
      ctx.setTransform(1, 0, 0, 1, ctx.getTransform().e, ctx.getTransform().f);
      const g = MD.SPR_SCALE || 1, sc = (scale || 1) * g, sy = scaleY ? scaleY * g : sc;
      ctx.imageSmoothingEnabled = g < 1; ctx.imageSmoothingQuality = 'high';
      if (alpha != null) ctx.globalAlpha = alpha;
      ctx.translate(Math.round(cx * C.K), Math.round(feet * C.K));
      if (flip || sc !== 1 || sy !== 1) ctx.scale(flip ? -sc : sc, sy);
      const nf = m.nf || 4, fi = Math.max(0, Math.min(nf - 1, Math.floor(frame / 4 * nf + 1e-6)));
      ctx.drawImage(src, fi * m.cw, row * m.ch, m.cw, m.ch, -m.cw / 2, -m.ch, m.cw, m.ch);
      ctx.restore();
      return true;
    },

    /* 아이콘 시트(icons.png)의 한 칸을 캔버스에 채움 */
    iconKey(canvas, key) {
      const m = MD.ICON_META;
      if (m && !m.map[key] && key.indexOf('skill_') === 0) key = 'mask_' + key.slice(6);
      if (!A.icons || !m || !m.map[key]) return false;
      const c = m.map[key], x = canvas.getContext('2d');
      x.clearRect(0, 0, canvas.width, canvas.height);
      x.imageSmoothingEnabled = true; x.imageSmoothingQuality = 'high';
      x.drawImage(A.icons, c[0] * m.cell, c[1] * m.cell, m.cell, m.cell, 0, 0, canvas.width, canvas.height);
      return true;
    },

    /* 월드(게임 화면)에 아이콘을 그림. cx, cy는 중심, size는 로직 좌표 크기 */
    drawIcon(ctx, key, cx, cy, size, alpha) {
      const m = MD.ICON_META;
      if (!A.icons || !m || !m.map[key]) return;
      const c = m.map[key], t = ctx.getTransform(), s = size * C.K;
      ctx.save();
      ctx.setTransform(1, 0, 0, 1, t.e, t.f);
      ctx.imageSmoothingEnabled = true;
      if (alpha != null) ctx.globalAlpha = alpha;
      ctx.drawImage(A.icons, c[0] * m.cell, c[1] * m.cell, m.cell, m.cell, Math.round(cx * C.K - s / 2), Math.round(cy * C.K - s / 2), s, s);
      ctx.restore();
    },

    /* 초상화: 가면 아이콘이 있으면 그것을, 없으면 걷기 첫 프레임의 머리 부분을 사용 */
    icon(canvas, nm) {
      if (A.iconKey(canvas, 'mask_' + nm)) return;
      const im = imgs[nm], m = MD.SPRITE_META[nm];
      const x = canvas.getContext('2d');
      x.imageSmoothingEnabled = false;
      x.clearRect(0, 0, canvas.width, canvas.height);
      if (!im || !m) return;
      const side = Math.min(m.bw, Math.round(m.bh * .52));
      const sx = Math.round(m.cw / 2 - side / 2), sy = m.ch - m.bh;
      x.drawImage(im, sx, sy, side, side, 0, 0, canvas.width, canvas.height);
    }
  };
})();
