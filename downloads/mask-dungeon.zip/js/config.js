/* config.js — 상수, 폰트, 색상, 게임 데이터 테이블 */
window.MD = window.MD || {};

MD.C = {
  W: 960, H: 540,          // 게임 로직 좌표계
  CW: 1280, CH: 720,       // 실제 캔버스 픽셀
  K: 4 / 3,                // 로직 -> 캔버스 배율
  FLOOR: 480,
  GRAV: 2300,
  MAXROOM: 8,
  TAU: Math.PI * 2,
  SPR: 0.75,               // 스프라이트 배율 (로직 좌표 기준, 캔버스에서는 1:1 픽셀)
  PW: 28, PH: 54           // 플레이어 판정 크기
};

MD.FONT = {
  T: '"Galmuri11","Apple SD Gothic Neo","Malgun Gothic",sans-serif',
  D: '"Galmuri11","Apple SD Gothic Neo","Malgun Gothic",sans-serif',
  B: '"Galmuri11","Apple SD Gothic Neo","Malgun Gothic",sans-serif'
};

MD.COL = {
  ember: '#ff9a3c', bone: '#f3ebd2', line: '#2f5566', panel: '#0b1626', panel2: '#14233a',
  ink: '#05080f', muted: '#8fa6ad', mint: '#6fe0c0', blood: '#c3303b', gold: '#e9bf5b'
};

MD.BASE_MASKS = ['hahoe', 'dokkaebi', 'fox', 'dosa'];
MD.MASK_ORDER = ['hahoe', 'dokkaebi', 'fox', 'dosa', 'lion', 'maltugi', 'gaksi', 'reaper'];
/* 보상·상점에 나올 수 있는 가면 (저승사자탈은 숨은 결말을 본 뒤에만) */
MD.maskPool = () => MD.MASK_ORDER.filter((id) => id !== 'reaper' || (MD.Meta && MD.Meta.endings && MD.Meta.endings.hidden > 0));

MD.MASKS = {
  hahoe: {
    id: 'hahoe', name: '하회탈', tier: '일반', role: '균형형', tierColor: '#e9bf5b',
    desc: '균형 잡힌 3연격 검술. 스킬은 회전 베기.',
    col: '#f0b955', dark: '#8a5a22', line: '#2b1a0c',
    dmg: 12, rate: .28, reach: 70, kb: 170, speed: 1, airJumps: 1, melee: true,
    skill: { name: '회전 베기', cd: 7 }
  },
  dokkaebi: {
    id: 'dokkaebi', name: '도깨비', tier: '희귀', role: '파워형', tierColor: '#6fe0c0',
    desc: '느리지만 묵직한 한 방. 스킬은 대지 강타.',
    col: '#d9473f', dark: '#5e1712', line: '#2a0b0b',
    dmg: 24, rate: .58, reach: 92, kb: 330, speed: .88, airJumps: 1, melee: true,
    skill: { name: '대지 강타', cd: 9 }
  },
  fox: {
    id: 'fox', name: '여우', tier: '희귀', role: '속도형', tierColor: '#6fe0c0',
    desc: '빠른 연타와 공중 점프 2회. 스킬은 여우불.',
    col: '#8fe3d2', dark: '#2f7f78', line: '#123a3a',
    dmg: 7, rate: .15, reach: 58, kb: 90, speed: 1.18, airJumps: 2, melee: true,
    skill: { name: '여우불', cd: 6 }
  },
  dosa: {
    id: 'dosa', name: '도사', tier: '유니크', role: '원거리형', tierColor: '#b78cff',
    desc: '부적을 날려 멀리서 공격. 스킬은 부적 비.',
    col: '#9fb4ff', dark: '#394a9c', line: '#141a3d',
    dmg: 11, rate: .36, reach: 0, kb: 110, speed: 1, airJumps: 1, melee: false,
    skill: { name: '부적 비', cd: 9 }
  },
  lion: {
    id: 'lion', name: '사자탈', tier: '희귀', role: '수비형', tierColor: '#6fe0c0',
    desc: '방패와 철퇴의 묵직한 연타. 스킬은 반격 방패.',
    col: '#e0a43a', dark: '#6b3b14', line: '#2a1608',
    dmg: 15, rate: .46, reach: 80, kb: 230, speed: .9, airJumps: 1, melee: true,
    skill: { name: '반격 방패', cd: 8 }
  },
  maltugi: {
    id: 'maltugi', name: '말뚝이탈', tier: '희귀', role: '교란형', tierColor: '#6fe0c0',
    desc: '말뚝과 폭죽을 던지는 재빠른 원거리 교란. 스킬은 폭죽 탄.',
    col: '#ff8a4a', dark: '#7a2e12', line: '#2d0f06',
    dmg: 8, rate: .22, reach: 0, kb: 80, speed: 1.1, airJumps: 1, melee: false,
    skill: { name: '폭죽 탄', cd: 8 }
  },
  gaksi: {
    id: 'gaksi', name: '각시탈', tier: '유니크', role: '보조형', tierColor: '#b78cff',
    desc: '부채로 꽃잎을 날려 베고 상처를 어루만진다. 스킬은 꽃비 치유.',
    col: '#ff9fb8', dark: '#8a2d4c', line: '#3a0f1f',
    dmg: 10, rate: .3, reach: 66, kb: 120, speed: 1.02, airJumps: 1, melee: true,
    skill: { name: '꽃비 치유', cd: 12 }
  },
  reaper: {
    id: 'reaper', name: '저승사자탈', tier: '전설', role: '처형형', tierColor: '#ff9a3c',
    desc: '사슬로 베고 혼을 거둔다. 스킬은 혼 거두기.',
    col: '#b58cff', dark: '#3b1f6b', line: '#120a24',
    dmg: 18, rate: .4, reach: 104, kb: 150, speed: 1.05, airJumps: 1, melee: true,
    skill: { name: '혼 거두기', cd: 10 }
  }
};

MD.ITEMS = [
  { id: 'armor', glyph: '갑', name: '단단한 갑옷', desc: '최대 체력 +25, 즉시 25 회복',
    apply(P) { P.maxHp += 25; P.hp = Math.min(P.maxHp, P.hp + 25); } },
  { id: 'blade', glyph: '검', name: '벼린 칼날', desc: '공격력 +15%', apply(P) { P.st.dmgB += .15; } },
  { id: 'boots', glyph: '신', name: '바람의 신발', desc: '이동 속도 +10%', apply(P) { P.st.spd += .1; } },
  { id: 'dashr', glyph: '질', name: '번개 같은 발', desc: '대시 재충전이 25% 빨라짐', apply(P) { P.st.dashRech *= .75; } },
  { id: 'steal', glyph: '혈', name: '흡혈 부적', desc: '적 처치 시 체력 +4', apply(P) { P.st.steal += 4; } },
  { id: 'eye', glyph: '눈', name: '급소를 보는 눈', desc: '치명타 확률 +12%', apply(P) { P.st.crit += .12; } },
  { id: 'echo', glyph: '울', name: '가면의 공명', desc: '가면 교체 대기시간 30% 감소', apply(P) { P.st.swapCd *= .7; } },
  { id: 'soul', glyph: '혼', name: '영혼의 불꽃', desc: '스킬 대기시간 20% 감소', apply(P) { P.st.skCd *= .8; } }
];

MD.ETYPES = {
  soldier: { name: '그림자 병정', w: 30, h: 54, hp: 42, speed: 92, dmg: 10 },
  archer:  { name: '먹물 궁수',   w: 28, h: 54, hp: 30, speed: 80, dmg: 9 },
  wisp:    { name: '도깨비불',    w: 40, h: 56, hp: 26, speed: 0,  dmg: 10, fly: true },
  brute:   { name: '돌 장승',     w: 52, h: 76, hp: 150, speed: 52, dmg: 18, armor: true },
  boss:    { name: '탈의 군주',   w: 90, h: 132, hp: 1000, speed: 70, dmg: 14, armor: true, boss: true }
};

/* 처치 시 떨어뜨리는 영혼 조각 */
MD.SOUL = { soldier: 5, archer: 5, wisp: 5, brute: 14, boss: 0 };

MD.LAYOUTS = [
  [],
  [{ x: 170, y: 370, w: 170 }, { x: 620, y: 370, w: 170 }],
  [{ x: 60, y: 360, w: 180 }, { x: 390, y: 285, w: 180 }, { x: 720, y: 360, w: 180 }],
  [{ x: 250, y: 380, w: 140 }, { x: 570, y: 380, w: 140 }, { x: 410, y: 280, w: 140 }],
  [{ x: 90, y: 360, w: 150 }, { x: 720, y: 360, w: 150 }]
];

window.MD = window.MD || {}; MD.SPR_SCALE = 0.78;
