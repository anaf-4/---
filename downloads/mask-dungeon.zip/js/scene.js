/* scene.js — 캐릭터가 걷고 말풍선이 뜨는 연출 장면 (인트로 / 엔딩).
   장면 대본은 MD.SCENES 에 있고, 한 줄이 한 동작이다. 기본은 앞 동작이 끝나야 다음으로 넘어간다. */
(() => {
  const MD = window.MD, G = MD.G, C = MD.C, A = MD.Audio;
  const K = C.K, FLOOR = C.FLOOR, SC = 1.55;   // 연출용 확대 배율
  const Sc = MD.Scene = { cur: null };

  const NAMES = { narrator: '말뚝이', hero: '', mask: '하회탈', guard: '무명병' };

  /* ---------- 대본 ----------
     [op, ...] 형식.
       wait s                 잠깐 멈춤
       move id x [speed]      걸어서 이동 (끝나면 다음)  /  moveGo 는 기다리지 않고 동시에 진행
       face id ±1             방향
       pose id 이름            idle | lie | wake | hit | hurt | rise
       say id 글 [이름]        말풍선 (타자 연출). 이름 생략 시 NAMES 기본값
       show id | hide id      등장 / 퇴장 (서서히)
       title 제목 부제          제목 카드
       shake n | flash 색      화면 연출
       sfx 이름                 효과음
  */
  MD.SCENES = {
    intro: {
      bg: 'castle', music: 'menu',
      actors: {
        hero: { spr: 'hahoe', x: 560, pose: 'lie', face: 1 },
        narrator: { spr: 'maltugi', x: -70, face: 1, hidden: true },
        guard: { spr: 'soldier', x: 1030, face: -1, hidden: true }
      },
      steps: [
        ['title', '마스크 던전', '', 1.6],
        ['wait', .5],
        ['show', 'narrator'],
        ['move', 'narrator', 250, 150],
        ['say', 'narrator', '쉬이— 놀이판이 열렸것다!'],
        ['say', 'narrator', '탈성의 보름달은 백 년째 지지 않고, 웃음소리는 백 년째 그치지 않는구나.'],
        ['say', 'narrator', '이 성의 군주가 슬픔을 탈에 가두더니, 백성들 얼굴까지 몽땅 잃었다 하오.'],
        ['move', 'narrator', 380, 130],
        ['say', 'narrator', '저기 누워 있는 놈이 오늘의 주인공이라. 이름도, 낯짝도 기억에 없는 놈이지.'],
        ['pose', 'hero', 'rise'],
        ['say', 'mask', '이보게, 깨어났나. 얼굴은 없어도 웃음은 남아 있구먼.'],
        ['say', 'hero', '…'],
        ['say', 'narrator', '아는 것이라곤 하나뿐. 왕좌의 방에 얼굴들이 모여 있고, 그중에 제 것이 있다는 것.'],
        ['move', 'hero', 500, 110],
        ['face', 'hero', 1],
        ['say', 'narrator', '쓰러진 자들의 탈을 빌려 쓰며 성을 오르는 길, 구경하는 양반들은 웃지 마시오.'],
        ['show', 'guard'],
        ['move', 'guard', 760, 90],
        ['say', 'guard', '여기서 얼굴을 보여 주면 통과한다… 얼굴이 있다면.'],
        ['pose', 'hero', 'hit'],
        ['shake', 5], ['flash', 'rgba(255,240,230,.5)'], ['sfx', 'boom'],
        ['wait', .5]
      ]
    },
    face: {
      bg: 'throne', music: 'reward',
      actors: {
        hero: { spr: 'hahoe', x: 400, face: 1 },
        narrator: { spr: 'maltugi', x: 1040, face: -1, hidden: true },
        s1: { spr: 'dokkaebi', x: 560, face: -1, ghost: true, hidden: true, name: '도깨비' },
        s2: { spr: 'fox', x: 650, face: -1, ghost: true, hidden: true, name: '여우' },
        s3: { spr: 'dosa', x: 740, face: -1, ghost: true, hidden: true, name: '도사' },
        s4: { spr: 'hahoe', x: 830, face: -1, ghost: true, hidden: true, name: '하회탈' }
      },
      steps: [
        ['wait', .8],
        ['flash', 'rgba(255,240,230,.7)'],
        ['show', 'narrator'], ['move', 'narrator', 860, 150],
        ['say', 'narrator', '탈이 하나둘 벗겨지고, 놀이판은 파했다.'],
        ['show', 'ghost'],
        ['say', 's1', '문은 열렸다. 이제 지킬 것이 없구나.'],
        ['say', 's2', '전하려던 진실 한 줄을, 이제야 전했소.'],
        ['say', 's3', '저주는 풀렸으나 부적 값은 못 받았구려.'],
        ['say', 's4', '웃지 않아도 되는 날이 오다니.'],
        ['hide', 'ghost'],
        ['say', 'narrator', '웃던 놈도 울던 놈도 제 얼굴로 돌아가는구나.'],
        ['say', 'narrator', '당신도 물웅덩이에서 얼굴 하나를 본다. 낯익은데, 이름은 끝내 떠오르지 않는다.'],
        ['say', 'narrator', '이름이 없으면 어떠하랴. 얼굴이 있으니 내일은 놀러 갈 만하다.'],
        ['say', 'narrator', '쉬이— 이 판은 이만 파하오!'],
        ['title', '파장', '탈이 벗겨지고, 놀이판이 끝난다.']
      ]
    },
    lord: {
      bg: 'throne', music: 'boss',
      actors: {
        hero: { spr: 'hahoe', x: 520, face: 1 },
        narrator: { spr: 'maltugi', x: 1040, face: -1, hidden: true }
      },
      steps: [
        ['wait', .8],
        ['say', 'mask', '그건 집지 말게. 꼭 맞는다는 게 가장 무서운 거야.', '하회탈'],
        ['say', 'hero', '…'],
        ['flash', 'rgba(150,60,200,.55)'], ['shake', 7], ['sfx', 'boom'],
        ['show', 'narrator'], ['move', 'narrator', 800, 150],
        ['say', 'narrator', '당신은 바닥의 가면을 집어 쓴다. 꼭 맞는다. 이상하리만치.'],
        ['say', 'narrator', '성이 다시 웃기 시작한다. 이번엔 새 군주를 모시고.'],
        ['say', 'narrator', '달은 여전히 지지 않고, 말뚝이는 혀를 찬다.'],
        ['say', 'narrator', '"양반은 바뀌어도 판은 안 바뀌는구먼."'],
        ['title', '새 군주', '성은 다시 웃기 시작한다. 이번엔 새 군주를 모시고.']
      ]
    },
    hidden: {
      bg: 'throne', music: 'reward',
      actors: {
        hero: { spr: 'hahoe', x: 440, face: 1 },
        narrator: { spr: 'maltugi', x: 1040, face: -1, hidden: true },
        reaper: { spr: 'reaper', x: 700, face: -1, hidden: true, ghost: true, name: '저승사자' }
      },
      steps: [
        ['wait', .8],
        ['say', 'hero', '…'],
        ['flash', 'rgba(180,140,255,.45)'],
        ['show', 'reaper'],
        ['say', 'reaper', '명부에 이름은 없으나, 얼굴은 인정하지.'],
        ['say', 'reaper', '데려갈 자는 군주 하나였다. 너는 두고 가마.'],
        ['hide', 'reaper'],
        ['show', 'narrator'], ['move', 'narrator', 800, 150],
        ['say', 'narrator', '당신은 군주의 가면도, 제 얼굴도 집지 않았다.'],
        ['say', 'narrator', '대신 모든 가면을 제단에 내려놓고, 빈 얼굴로 웃는다. 웃음이 어색하지 않다.'],
        ['say', 'narrator', '"얼굴 없는 놈이 판을 뒤집는 법이외다. 말뚝이가 보증하오."'],
        ['title', '무면(無面)', '빈 얼굴로, 판을 뒤집는다.']
      ]
    }
  };

  /* ---------- 상태 ---------- */
  let S = null, ctx = null;
  const FONT = '"Galmuri11","Apple SD Gothic Neo","Malgun Gothic",sans-serif';

  function actorList() { return Object.keys(S.actors).map((k) => S.actors[k]); }
  function targets(id) { return id === 'ghost' ? actorList().filter((a) => a.ghost && a.id !== 'reaper') : [S.actors[id]]; }

  Sc.active = () => !!S;

  Sc.play = (kind, cb) => {
    const def = MD.SCENES[kind];
    if (!def) { if (cb) cb(); return; }
    G.cine = null;
    S = { def, cb, t: 0, i: 0, step: null, actors: {}, bubble: null, title: null, flash: null, bars: 0, fadeIn: 1, leaving: false, hint: 0 };
    for (const id in def.actors) {
      const d = def.actors[id];
      S.actors[id] = { id, spr: d.spr, x: d.x, face: d.face || 1, pose: d.pose || 'idle', pt: 0, walk: false, alpha: d.hidden ? 0 : 1, ghost: !!d.ghost, name: d.name, tx: null, speed: 0 };
    }
    G.state = 'scene'; G.sceneBg = def.bg; G.paused = false;
    MD.UI.show(null); MD.UI.cur = 'scene';
    MD.UI.hudVisible(false); MD.UI.sayClear();
    document.getElementById('hud').classList.add('hide');
    if (def.music) A.music(def.music);
    next();
  };

  function finish() {
    if (!S || S.leaving) return;
    S.leaving = true;
    const cb = S.cb; S = null; G.sceneBg = null;
    MD.UI.cur = null; G.fade = .6;
    if (cb) cb();
  }

  /* ---------- 진행 ---------- */
  function next() {
    if (!S) return;
    const st = S.def.steps[S.i++];
    if (!st) { finish(); return; }
    const op = st[0];
    S.step = { op, t: 0, a: st };
    if (op === 'say') {
      const who = S.actors[st[1]] || S.actors.hero;
      const speaker = st[3] != null ? st[3] : (who.name != null ? who.name : NAMES[st[1]]);
      S.bubble = { actor: who, name: speaker, text: st[2], n: 0, acc: 0, done: false, hold: 0, wait: false };
      S.step.bubble = S.bubble;
    } else if (op === 'move') {
      const a = S.actors[st[1]]; a.tx = st[2]; a.speed = st[3] || 120; a.walk = true;
      a.face = st[2] >= a.x ? 1 : -1;
    } else if (op === 'show' || op === 'hide') {
      targets(st[1]).forEach((a) => { a.fadeTo = op === 'show' ? 1 : 0; });
    } else if (op === 'pose') {
      const a = S.actors[st[1]]; a.pose = st[2]; a.pt = 0;
    } else if (op === 'face') {
      S.actors[st[1]].face = st[2]; next();
    } else if (op === 'title') {
      S.title = { text: st[1], sub: st[2], t: 0, hold: st[3] || 0, end: !st[3] };
    } else if (op === 'shake') { MD.Combat.shake(st[1]); next();
    } else if (op === 'flash') { S.flash = { col: st[1], t: 0 }; next();
    } else if (op === 'sfx') { if (A.sfx[st[1]]) A.sfx[st[1]](); next(); }
  }

  /* 입력: 타이핑 중이면 한 번에, 대기 중이면 다음 대사 */
  Sc.advance = () => {
    if (!S) return;
    A.ensure();
    const b = S.bubble;
    if (S.step && S.step.op === 'say' && b) {
      if (!b.done) { b.n = Array.from(b.text).length; b.done = true; b.hold = 0; }
      else { S.bubble = null; next(); }
    } else if (S.step && S.step.op === 'title' && S.title && S.title.end && S.title.t > 1.6) {
      finish();
    }
  };
  Sc.skip = () => { if (S) finish(); };
  Sc.key = (code) => {
    if (code === 'Escape') Sc.skip();
    else if (code === 'Enter' || code === 'Space' || code === 'KeyZ' || code === 'KeyJ' || code === 'ArrowRight') Sc.advance();
  };

  /* ---------- 갱신 ---------- */
  Sc.update = (dt) => {
    if (!S) return;
    S.t += dt; S.hint = Math.min(1, S.hint + dt * .5);
    S.fadeIn = Math.max(0, S.fadeIn - dt * 1.5);
    S.bars = Math.min(1, S.bars + dt * 2);
    if (S.flash) { S.flash.t += dt; if (S.flash.t > .6) S.flash = null; }
    for (const id in S.actors) {
      const a = S.actors[id];
      a.pt += dt;
      if (a.fadeTo != null) {
        a.alpha += (a.fadeTo - a.alpha) * Math.min(1, dt * 3.2);
        if (Math.abs(a.alpha - a.fadeTo) < .02) { a.alpha = a.fadeTo; a.fadeTo = null; }
      }
      if (a.tx != null) {
        const d = a.tx - a.x, stp = a.speed * dt;
        if (Math.abs(d) <= stp) { a.x = a.tx; a.tx = null; a.walk = false; }
        else a.x += Math.sign(d) * stp;
      }
      if (a.pose === 'rise' && a.pt > .9) { a.pose = 'idle'; a.pt = 0; }
      if (a.pose === 'hit' && a.pt > .5) { a.pose = 'idle'; a.pt = 0; }
    }
    if (S.title) S.title.t += dt;
    const st = S.step;
    if (!st) return;
    st.t += dt;
    const op = st.op;
    if (op === 'wait') { if (st.t >= st.a[1]) next(); }
    else if (op === 'move') { if (S.actors[st.a[1]].tx == null) next(); }
    else if (op === 'show' || op === 'hide') {
      if (targets(st.a[1]).every((a) => a.fadeTo == null)) next();
    } else if (op === 'pose') {
      if (st.t > (st.a[2] === 'rise' ? .9 : .5)) next();
    } else if (op === 'say') {
      const b = S.bubble;
      if (!b) return;
      const total = Array.from(b.text).length;
      if (!b.done) {
        b.acc += dt * 30;
        while (b.acc >= 1 && b.n < total) {
          b.acc -= 1; b.n++;
          const ch = Array.from(b.text)[b.n - 1];
          if (ch !== ' ' && (b.n & 1)) A.sfx.type();
          if (/[.,?!…—]/.test(ch)) b.acc -= 3;
        }
        if (b.n >= total) { b.done = true; b.hold = 0; }
      } else {
        b.hold += dt;
        if (b.hold > 1.2 + total * .045) { S.bubble = null; next(); }
      }
    } else if (op === 'title') {
      const t = S.title;
      if (!t.end && t.t > t.hold) { S.title = null; next(); }
    }
  };

  /* ---------- 그리기 (월드 좌표 변환이 걸린 상태에서 호출) ---------- */
  function shadow(x, fy, w, alpha) {
    ctx.save(); ctx.globalAlpha = .35 * alpha; ctx.fillStyle = '#02040a';
    ctx.beginPath(); ctx.ellipse(x, fy, w / 2, 5, 0, 0, C.TAU); ctx.fill(); ctx.restore();
  }

  function drawActor(a) {
    if (a.alpha <= .01) return;
    const m = MD.SPRITE_META[a.spr];
    if (!m) return;
    let row = 0, fr = 0, y = FLOOR - 2;
    const t = a.pt;
    if (a.walk) { row = 0; fr = (S.t / .24) % 4; }
    else if (a.pose === 'lie') { row = 3; fr = 3.99; y += 2; }
    else if (a.pose === 'rise') { row = 3; fr = Math.max(0, 3.99 - t / .9 * 4); }
    else if (a.pose === 'hit') { row = 1; fr = Math.min(3.99, t / .5 * 4); }
    else if (a.pose === 'hurt') { row = 2; fr = Math.min(3.99, t / .4 * 4); }
    else { row = 0; fr = 0; y += Math.sin(S.t * 2.2 + a.x) * 1.2; }
    const alpha = a.alpha * (a.ghost ? .78 : 1);
    if (a.pose !== 'lie') shadow(a.x, FLOOR + 8, 46 * SC, a.alpha);
    if (a.ghost) {
      /* 혼 같은 푸른 기운 */
      ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = .18 * a.alpha;
      MD.Assets.draw(ctx, a.spr, row, fr, a.x, y - 2 + Math.sin(S.t * 3 + a.x) * 3, a.face < 0, 1, '#9fe8ff', 1.06 * SC);
      ctx.restore();
      y += Math.sin(S.t * 3 + a.x) * 3 - 6;
    }
    MD.Assets.draw(ctx, a.spr, row, fr, a.x, y, a.face < 0, alpha, null, SC);
  }

  function wrap(text, maxW) {
    const out = []; let line = '';
    const words = text.split(' ');
    const push = (w) => {
      const test = line ? line + ' ' + w : w;
      if (ctx.measureText(test).width <= maxW) { line = test; return; }
      if (line) out.push(line);
      /* 한 단어가 너무 길면 글자 단위로 자름 */
      if (ctx.measureText(w).width > maxW) {
        line = '';
        for (const ch of Array.from(w)) {
          if (ctx.measureText(line + ch).width > maxW) { out.push(line); line = ch; } else line += ch;
        }
      } else line = w;
    };
    words.forEach(push);
    if (line) out.push(line);
    return out;
  }

  function roundRect(x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
  }

  /* 말풍선은 캔버스 픽셀 좌표로 그려 글자를 선명하게 */
  function drawBubble(b) {
    const a = b.actor, m = MD.SPRITE_META[a.spr] || { bh: 80 };
    const px = Math.round(a.x * K), headY = Math.round((FLOOR - 2) * K - m.bh * SC * (a.pose === 'lie' ? .3 : 1)) - 12;
    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.font = '22px ' + FONT; ctx.textBaseline = 'top'; ctx.textAlign = 'left';
    const full = wrap(b.text, 460);
    const shown = Array.from(b.text).slice(0, b.n).join('');
    const lines = wrap(shown, 460);
    const lh = 30, padX = 18, padY = 12, hasName = !!b.name;
    let w = 0; full.forEach((l) => { w = Math.max(w, ctx.measureText(l).width); });
    if (hasName) w = Math.max(w, ctx.measureText(b.name).width + 8);
    w = Math.ceil(w) + padX * 2;
    const h = full.length * lh + padY * 2 + (hasName ? 28 : 0);
    let bx = Math.round(px - w / 2); bx = Math.max(24, Math.min(C.CW - 24 - w, bx));
    const by = Math.max(96, headY - h - 14);
    /* 본체 */
    ctx.fillStyle = 'rgba(8,16,30,.94)'; roundRect(bx, by, w, h, 6); ctx.fill();
    ctx.lineWidth = 3; ctx.strokeStyle = '#e9bf5b'; ctx.stroke();
    ctx.lineWidth = 1; ctx.strokeStyle = 'rgba(255,230,160,.25)'; roundRect(bx + 4, by + 4, w - 8, h - 8, 4); ctx.stroke();
    /* 꼬리 */
    const tx = Math.max(bx + 20, Math.min(bx + w - 20, px));
    ctx.fillStyle = 'rgba(8,16,30,.96)';
    ctx.beginPath(); ctx.moveTo(tx - 10, by + h - 1); ctx.lineTo(tx + 10, by + h - 1); ctx.lineTo(tx, by + h + 13); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = '#e9bf5b'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(tx - 10, by + h); ctx.lineTo(tx, by + h + 13); ctx.lineTo(tx + 10, by + h); ctx.stroke();
    ctx.fillStyle = 'rgba(8,16,30,.96)'; ctx.fillRect(tx - 8, by + h - 3, 16, 5);
    /* 글 */
    let ty = by + padY;
    if (hasName) { ctx.fillStyle = '#ff9a3c'; ctx.fillText(b.name, bx + padX, ty); ty += 28; }
    ctx.fillStyle = '#f3ebd2';
    lines.forEach((l, i) => ctx.fillText(l, bx + padX, ty + i * lh));
    if (b.done && Math.floor(S.t * 2.5) % 2 === 0) {
      ctx.fillStyle = '#e9bf5b'; ctx.fillText('▾', bx + w - padX - 12, by + h - lh - 2);
    }
    ctx.restore();
  }

  Sc.draw = (c) => {
    ctx = c;
    if (!S) return;
    /* 캐릭터: 아래쪽 y 정렬을 위해 x 순서가 아닌 등록 순서대로 */
    actorList().forEach(drawActor);
    /* 월드 변환 밖(캔버스 픽셀)에서 연출 요소 */
    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    /* 영화 같은 상하 띠 */
    const h = Math.round(70 * S.bars);
    ctx.fillStyle = '#02040a'; ctx.fillRect(0, 0, C.CW, h); ctx.fillRect(0, C.CH - h, C.CW, h);
    if (S.flash) { ctx.globalAlpha = Math.max(0, 1 - S.flash.t / .6); ctx.fillStyle = S.flash.col; ctx.fillRect(0, 0, C.CW, C.CH); ctx.globalAlpha = 1; }
    ctx.restore();
    if (S.bubble) drawBubble(S.bubble);
    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    if (S.title) {
      const t = S.title, k = Math.min(1, t.t / 1.0);
      const out = t.end ? 1 : Math.min(1, Math.max(0, (t.hold - t.t) / .5));
      ctx.fillStyle = 'rgba(2,4,10,' + (.72 * k * out) + ')'; ctx.fillRect(0, 0, C.CW, C.CH);
      ctx.globalAlpha = k * out; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.font = '700 88px ' + FONT; ctx.fillStyle = '#e9bf5b'; ctx.strokeStyle = '#05080f'; ctx.lineWidth = 8; ctx.lineJoin = 'round';
      ctx.strokeText(t.text, C.CW / 2, C.CH / 2 - 20); ctx.fillText(t.text, C.CW / 2, C.CH / 2 - 20);
      if (t.sub) { ctx.font = '22px ' + FONT; ctx.fillStyle = '#d7cfb4'; ctx.fillText(t.sub, C.CW / 2, C.CH / 2 + 50); }
      if (t.end && t.t > 1.6) { ctx.globalAlpha = .5 + .5 * Math.sin(S.t * 3); ctx.font = '18px ' + FONT; ctx.fillStyle = '#8fa6ad'; ctx.fillText('계속하려면 아무 키나 누르세요', C.CW / 2, C.CH - 110); }
    }
    ctx.globalAlpha = S.hint * .7; ctx.textAlign = 'right'; ctx.textBaseline = 'alphabetic';
    ctx.font = '16px ' + FONT; ctx.fillStyle = '#8fa6ad';
    ctx.fillText('클릭 · Enter 넘기기   |   Esc 건너뛰기', C.CW - 28, C.CH - 22);
    if (S.fadeIn > 0) { ctx.globalAlpha = S.fadeIn; ctx.fillStyle = '#02040a'; ctx.fillRect(0, 0, C.CW, C.CH); }
    ctx.restore();
  };

  /* 화면 클릭/터치로 넘기기 */
  addEventListener('pointerdown', (e) => {
    if (!S) return;
    if (e.target && e.target.closest && e.target.closest('#touch')) return;
    Sc.advance();
  });
})();
