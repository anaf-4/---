/* input.js — 키보드, 터치(버튼/가상 스틱), 게임패드 입력과 키 재설정 */
(() => {
  const MD = window.MD;
  const ACTIONS = ['left', 'right', 'down', 'jump', 'atk', 'skill', 'dash', 'swap'];
  const DEFAULT_KEYS = {
    left: ['KeyA', 'ArrowLeft'], right: ['KeyD', 'ArrowRight'], down: ['KeyS', 'ArrowDown'],
    jump: ['KeyW', 'ArrowUp', 'Space'], atk: ['KeyJ', 'KeyZ'], skill: ['KeyK', 'KeyX'],
    dash: ['ShiftLeft', 'ShiftRight', 'KeyL', 'KeyC'], swap: ['KeyQ', 'KeyE']
  };
  const KEYMAP = {};
  const NOSCROLL = new Set(['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight']);
  const keys = {}, just = {};

  function resetMap() {
    ACTIONS.forEach((a) => { KEYMAP[a] = DEFAULT_KEYS[a].concat(['Touch:' + a, 'Pad:' + a]); });
  }
  resetMap();

  const Input = {
    keys, just, KEYMAP, ACTIONS, DEFAULT_KEYS,
    isHeld: (a) => KEYMAP[a].some((k) => keys[k]),
    isPressed: (a) => KEYMAP[a].some((k) => just[k]),
    clearJust() { for (const k in just) delete just[k]; },
    clear() { for (const k in keys) keys[k] = false; for (const k in just) delete just[k]; },

    /* 저장된 사용자 키 설정 불러오기 */
    loadMap() {
      resetMap();
      try {
        const o = JSON.parse(MD.Settings.data.keymap || 'null');
        if (o) ACTIONS.forEach((a) => { if (o[a] && o[a].length) KEYMAP[a] = o[a].concat(['Touch:' + a, 'Pad:' + a]); });
      } catch (e) { /* 무시 */ }
    },
    saveMap() {
      const o = {};
      ACTIONS.forEach((a) => { o[a] = KEYMAP[a].filter((k) => k.indexOf(':') < 0); });
      MD.Settings.set('keymap', JSON.stringify(o));
    },
    /* action 의 키보드 키를 code 하나로 바꿈 (다른 동작과 겹치면 그쪽에서 제거) */
    rebind(action, code) {
      ACTIONS.forEach((a) => { KEYMAP[a] = KEYMAP[a].filter((k) => k !== code || a === action); });
      KEYMAP[action] = [code, 'Touch:' + action, 'Pad:' + action];
      ACTIONS.forEach((a) => { if (KEYMAP[a].filter((k) => k.indexOf(':') < 0).length === 0) KEYMAP[a] = DEFAULT_KEYS[a].filter((k) => k !== code).slice(0, 1).concat(['Touch:' + a, 'Pad:' + a]); });
      Input.saveMap();
    },
    resetKeys() { resetMap(); MD.Settings.set('keymap', ''); },
    keyLabel(code) {
      const m = { ArrowLeft: '←', ArrowRight: '→', ArrowUp: '↑', ArrowDown: '↓', ShiftLeft: 'Shift', ShiftRight: 'Shift', Space: 'Space', Escape: 'Esc', Enter: 'Enter', Tab: 'Tab', Backspace: 'Bksp' };
      if (m[code]) return m[code];
      return code.replace(/^Key/, '').replace(/^Digit/, '').replace(/^Numpad/, 'N');
    },

    bindTouch() {
      document.querySelectorAll('.tb').forEach((b) => {
        const code = 'Touch:' + b.dataset.a;
        const on = (e) => {
          e.preventDefault();
          MD.Audio.ensure();
          try { b.setPointerCapture(e.pointerId); } catch (_) { /* 무시 */ }
          if (!keys[code]) just[code] = true;
          keys[code] = true; b.classList.add('on');
          MD.Haptic(6);
        };
        const off = () => { keys[code] = false; b.classList.remove('on'); };
        b.addEventListener('pointerdown', on);
        b.addEventListener('pointerup', off);
        b.addEventListener('pointercancel', off);
        b.addEventListener('lostpointercapture', off);
        b.addEventListener('contextmenu', (e) => e.preventDefault());
      });
      bindStick();
    }
  };
  MD.Input = Input;

  MD.Haptic = (ms) => {
    try { if (MD.Settings.data.vib && MD.UI && MD.UI.touch && navigator.vibrate) navigator.vibrate(ms); } catch (e) { /* 무시 */ }
  };

  /* ---------- 가상 스틱 (화면 왼쪽을 누르고 끌기) ---------- */
  function bindStick() {
    const zone = document.getElementById('stick');
    if (!zone) return;
    const base = document.getElementById('stk-base'), knob = document.getElementById('stk-knob');
    let pid = null, ox = 0, oy = 0, jumped = false, dropped = false;
    const set = (a, v) => {
      const c = 'Touch:' + a;
      if (v && !keys[c]) just[c] = true;
      keys[c] = v;
    };
    const release = () => { ['left', 'right', 'jump', 'down'].forEach((a) => set(a, false)); base.classList.remove('on'); pid = null; };
    zone.addEventListener('pointerdown', (e) => {
      if (pid !== null) return;
      e.preventDefault(); MD.Audio.ensure();
      pid = e.pointerId; try { zone.setPointerCapture(pid); } catch (_) { /* 무시 */ }
      ox = e.clientX; oy = e.clientY; jumped = dropped = false;
      const r = zone.getBoundingClientRect();
      base.style.left = (ox - r.left) + 'px'; base.style.top = (oy - r.top) + 'px';
      knob.style.transform = 'translate(0,0)'; base.classList.add('on');
    });
    zone.addEventListener('pointermove', (e) => {
      if (e.pointerId !== pid) return;
      const dx = e.clientX - ox, dy = e.clientY - oy, R = 46;
      const m = Math.hypot(dx, dy) || 1, k = Math.min(1, R / m);
      knob.style.transform = 'translate(' + (dx * k) + 'px,' + (dy * k) + 'px)';
      set('left', dx < -14); set('right', dx > 14);
      if (dy < -34) { set('jump', true); if (!jumped) { jumped = true; MD.Haptic(8); } } else { set('jump', false); jumped = false; }
      if (dy > 34) { if (!dropped) { dropped = true; set('down', true); } } else { set('down', false); dropped = false; }
    });
    ['pointerup', 'pointercancel', 'lostpointercapture'].forEach((ev) => zone.addEventListener(ev, release));
    zone.addEventListener('contextmenu', (e) => e.preventDefault());
  }

  /* ---------- 게임패드 ---------- */
  const pad = { prev: {} };
  const PAD_UI = { up: 'ArrowUp', down: 'ArrowDown', left: 'ArrowLeft', right: 'ArrowRight' };
  Input.pollPad = () => {
    let gp = null;
    try { const l = navigator.getGamepads ? navigator.getGamepads() : []; for (const g of l) if (g && g.connected) { gp = g; break; } } catch (e) { /* 무시 */ }
    if (!gp) { if (pad.on) { pad.on = false; ACTIONS.forEach((a) => { keys['Pad:' + a] = false; }); } return; }
    pad.on = true;
    const b = (i) => !!(gp.buttons[i] && gp.buttons[i].pressed);
    const ax = gp.axes[0] || 0, ay = gp.axes[1] || 0;
    const st = {
      left: b(14) || ax < -.45, right: b(15) || ax > .45, down: b(13) || ay > .65,
      jump: b(0) || b(12) || ay < -.7, atk: b(2) || b(7), skill: b(3), dash: b(1) || b(5), swap: b(4) || b(6),
      ok: b(0), back: b(1), start: b(9), up: b(12) || ay < -.7
    };
    ACTIONS.forEach((a) => {
      const c = 'Pad:' + a;
      if (st[a] && !pad.prev[a]) just[c] = true;
      keys[c] = st[a];
    });
    if (MD.UI && MD.UI.cur) {
      const fake = (code) => { MD.UI.key({ code, preventDefault() {} }); };
      ['up', 'down', 'left', 'right'].forEach((a) => { if (st[a] && !pad.prev[a]) fake(PAD_UI[a]); });
      if (st.ok && !pad.prev.ok) fake('Enter');
      if (st.back && !pad.prev.back) fake('Escape');
    }
    if (st.start && !pad.prev.start && MD.G.state === 'play') MD.onKeyDown({ code: 'KeyP', preventDefault() {} });
    pad.prev = st;
  };

  addEventListener('keydown', (e) => {
    MD.Audio.ensure();
    if (MD.onKeyDown && MD.onKeyDown(e)) return;
    if (MD.G.state === 'play' && !MD.G.paused && NOSCROLL.has(e.code)) e.preventDefault();
    if (e.repeat) return;
    if (!keys[e.code]) just[e.code] = true;
    keys[e.code] = true;
  });
  addEventListener('keyup', (e) => { keys[e.code] = false; });
})();
