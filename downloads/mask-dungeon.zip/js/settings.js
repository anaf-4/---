/* settings.js — 설정 값 저장/불러오기 (브라우저 localStorage) */
(() => {
  const MD = window.MD;
  const KEY = 'maskdungeon.settings.v2';
  const DEF = {
    master: 80, bgm: 55, sfx: 85, mute: false,
    shake: 'normal', flash: true, dmg: true, full: false, hpstyle: 1,
    diff: 'normal', autopause: true,
    quality: 'auto', showfps: false, fpscap: 60, vsync: true, vib: true, ctl: 'pad', tbs: 'm', keymap: ''
  };
  const data = Object.assign({}, DEF);

  function load() {
    try {
      const s = localStorage.getItem(KEY);
      if (!s) return;
      const o = JSON.parse(s);
      for (const k in DEF) if (k in o && typeof o[k] === typeof DEF[k]) data[k] = o[k];
    } catch (e) { /* 저장소를 못 쓰는 환경이면 기본값 사용 */ }
    data.full = false;
  }
  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(data)); } catch (e) { /* 무시 */ }
  }

  MD.Settings = {
    data, DEF, load, save, onChange: null,
    set(k, v) { data[k] = v; save(); if (MD.Settings.onChange) MD.Settings.onChange(k, v); },
    reset() { Object.assign(data, DEF); save(); if (MD.Settings.onChange) MD.Settings.onChange('*'); },
    shakeMul() { return data.shake === 'off' ? 0 : data.shake === 'low' ? .5 : 1; },
    diff() {
      return ({ story: { hp: .8, dmg: .6 }, normal: { hp: 1, dmg: 1 }, hell: { hp: 1.3, dmg: 1.5 } })[data.diff] || { hp: 1, dmg: 1 };
    }
  };
})();
