/* combat.js — 피해 처리, 투사체, 장판, 이펙트 생성 */
(() => {
  const MD = window.MD, G = MD.G, U = MD.U, C = MD.C, S = MD.Settings;
  const Cb = MD.Combat = {};
  const cx = (b) => b.x + b.w / 2;
  const cy = (b) => b.y + b.h / 2;

  Cb.burst = (x, y, n, col, spd, life, size) => {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * C.TAU, v = U.rnd(.3, 1) * (spd || 200);
      G.parts.push({
        x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 40, t: 0,
        life: U.rnd(.5, 1) * (life || .5), size: size || 3, col: col || '#ffd9a0', g: 600
      });
    }
  };
  Cb.num = (x, y, text, col, size) => {
    if (!S.data.dmg) return;
    G.nums.push({ x: x + U.rnd(-8, 8), y, t: 0, life: .8, text: String(text), col: col || '#fff', size: size || 20 });
  };
  /* 영혼 조각 흩뿌리기 */
  Cb.drop = (x, y, total) => {
    total = Math.max(1, Math.round(total));
    const n = Math.min(8, Math.ceil(total / 3));
    let left = total;
    for (let i = 0; i < n; i++) {
      const v = i === n - 1 ? left : Math.max(1, Math.round(total / n)); left -= v;
      G.pickups.push({ x, y, vx: U.rnd(-160, 160), vy: U.rnd(-420, -200), v, t: 0 });
    }
  };
  Cb.fx = (o) => { G.fxs.push(Object.assign({ t: 0, life: .25 }, o)); };
  Cb.shake = (v) => { G.shake = Math.max(G.shake, v * S.shakeMul()); };
  Cb.stop = (t) => { G.hitstop = Math.max(G.hitstop, t); };

  Cb.hurtEnemy = (e, dmg, dir, kb, o) => {
    o = o || {};
    if (e.dead || e.spawnT > 0) return false;
    const P = G.P;
    const crit = !o.noCrit && Math.random() < P.st.crit;
    let d = dmg * (crit ? 1.8 : 1) * (e.armor ? .85 : 1);
    let blocked = false;
    if (e.shield && !o.light && e.face === -dir) { d *= .25; blocked = true; }
    d = Math.max(1, Math.round(d));
    e.hp -= d; e.flash = .09; e.sq = blocked ? .05 : .16;
    if (blocked) {
      Cb.num(cx(e) + e.face * 14, e.y + 10, '막힘', '#9fb4ff', 16);
      MD.Audio.sfx.deny();
      Cb.fx({ type: 'sprite', key: 'spark', x: cx(e) + e.face * 22, y: cy(e), scale: .6, life: .2, add: true });
    }
    if (!o.light) {
      if (!e.armor) {
        e.hurtT = .3; e.hurtV = .5; e.stun = Math.max(e.stun, o.stun || .3);
        if (blocked) kb *= .25;
        e.vx = dir * kb * (o.fin ? 1.35 : 1); e.vy = e.fly ? -40 : -(o.pop || 110) * (blocked ? .2 : 1);
        e.state = 'move'; e.st = 0; e.atkT = 0; e.tele = null; e.hitP = false;
        e.cd = Math.max(e.cd, .5);
      } else {
        e.vx += dir * kb * .08;
      }
    }
    if (!blocked) Cb.fx({ type: 'sprite', key: 'spark', x: cx(e), y: cy(e), scale: crit ? 1.1 : (o.fin ? .95 : .75), life: .22, add: true });
    if (crit) { G.slow = Math.max(G.slow, .07); MD.Haptic(12); }
    Cb.num(cx(e), e.y - 4, d, crit ? '#ffd24a' : '#fff', crit ? 28 : 20);
    Cb.burst(cx(e), cy(e), crit ? 10 : 6, crit ? '#ffe08a' : '#fff1d0', 220, .35, 3);
    MD.Audio.sfx[crit ? 'crit' : 'hit']();
    if (!o.light) Cb.stop(crit ? .06 : .035);
    if (e.hp <= 0) Cb.kill(e);
    return true;
  };

  Cb.kill = (e) => {
    if (e.dead) return;
    e.dead = true;
    G.kills++;
    if (G.P) MD.Meta.memAdd(G.P.masks[G.P.cur], 'k');
    G.corpses.push({
      name: e.type, x: e.x, y: e.y, w: e.w, h: e.h, face: e.face, t: 0,
      vx: e.vx * .5, vy: 0, fly: e.fly, boss: e.boss
    });
    Cb.burst(cx(e), cy(e), e.elite ? 26 : 14, '#ffb870', 260, .6, 3);
    MD.Audio.sfx[e.boss ? 'bossDie' : 'kill']();
    if (!e.boss) Cb.drop(cx(e), cy(e), MD.SOUL[e.type] * (e.elite ? 4 : 1));
    if (e.mod === 'volatile' || e.variant === 'ember' && e.type === 'soldier') {
      G.ezones.push({ x: cx(e) - 48, y: C.FLOOR - 84, w: 96, h: 90, delay: .6, t: 0, dmg: 8 * (e.elite ? 1.5 : 1), done: false, type: 'boom' });
    }
    Cb.stop(e.boss ? .25 : .05);
    const P = G.P;
    if (G.tut && G.tut.kills != null) G.tut.kills++;
    if (P.st.steal && !P.dead) {
      P.hp = Math.min(P.maxHp, P.hp + P.st.steal);
      Cb.num(cx(P), P.y - 14, '+' + P.st.steal, '#7dffb0', 18);
      Cb.fx({ type: 'icon', key: 'heal_orb', x: cx(P), y: P.y - 26, rise: 34, life: .7, size: 24 });
    }
    if (e.boss) MD.Rooms.onBossDead();
  };

  /* 플레이어 피격. 맞았으면 true */
  Cb.hurtPlayer = (dmg, fromX, src) => {
    const P = G.P;
    if (P.dead || P.inv > 0 || P.dashT > 0) return false;
    if (P.skill && P.skill.id === 'hahoe') return false;     // 회전 베기 중에는 무적
    if (P.skill && P.skill.id === 'lion' && P.skill.t < .5) { P.skill.blocked = (P.skill.blocked | 0) + 1; Cb.fx(MD.FX_META.map.lion_block ? { type: 'sprite', key: 'lion_block', x: cx(P) + P.face * 30, y: cy(P), scale: 1.0, life: .25, add: true } : { type: 'ring', x: cx(P) + P.face * 20, y: cy(P), r0: 8, r1: 48, life: .2, col: '#e0a43a' }); MD.Audio.sfx.deny(); return false; }
    if (P.skill && P.skill.id === 'reaper') return false;
    const d = Math.max(1, Math.round(dmg * S.diff().dmg));
    P.hp -= d; P.inv = 1.0; P.hurtT = .35; P.hurtV = .55; P.vis = null; P.atk = null;
    P.vx = U.sgn(cx(P) - fromX) * 260; P.vy = -260;
    if (S.data.flash) G.redFlash = .4;
    Cb.shake(8); Cb.stop(.08);
    MD.Audio.sfx.hurt();
    Cb.burst(cx(P), cy(P), 10, '#c3303b', 240, .5, 3);
    Cb.num(cx(P), P.y - 10, d, '#ff6a6a', 24);
    MD.Haptic(40);
    if (src && src.mod === 'vamp' && !src.dead) { src.hp = Math.min(src.maxHp, src.hp + src.maxHp * .06); Cb.num(src.x + src.w / 2, src.y - 6, '+', '#ff6a8a', 16); }
    if (P.hp <= 0) { P.hp = 0; MD.Player.die(); }
    return true;
  };

  Cb.update = (dt) => {
    const P = G.P;

    for (const p of G.projs) {
      p.life -= dt; p.t = (p.t || 0) + dt;
      p.x += p.vx * dt; p.y += p.vy * dt;
      if (p.x < -60 || p.x > C.W + 60 || p.y > C.H) p.life = 0;
      for (const e of G.enemies) {
        if (e.dead || e.spawnT > 0 || p.hit.indexOf(e) >= 0) continue;
        if (U.overlap(p, e)) {
          p.hit.push(e);
          Cb.hurtEnemy(e, p.dmg, U.sgn(p.vx), p.kb || 100);
          if (p.type === 'fire') Cb.fx({ type: 'sprite', key: 'foxhit', x: p.x + p.w / 2, y: p.y + p.h / 2, scale: .7, life: .3 });
          if (!p.pierce) { p.life = 0; break; }
        }
      }
    }
    G.projs = G.projs.filter((p) => p.life > 0);

    for (const p of G.eprojs) {
      p.life -= dt; p.t = (p.t || 0) + dt;
      p.x += p.vx * dt; p.y += p.vy * dt;
      if (!P.dead && U.overlap(p, P)) {
        if (Cb.hurtPlayer(p.dmg, p.x + p.w / 2, p.src) && !p.pierce) p.life = 0;
      }
      if (p.x < -90 || p.x > C.W + 90 || p.y > C.H + 40 || p.y < -80) p.life = 0;
    }
    G.eprojs = G.eprojs.filter((p) => p.life > 0);

    for (const z of G.zones) {
      z.t += dt; z.tick -= dt;
      if (z.tick <= 0) {
        z.tick = z.every;
        for (const e of G.enemies) {
          if (!e.dead && U.overlap(z, e)) Cb.hurtEnemy(e, z.dmg, U.sgn(cx(e) - z.cx), 60, { light: true });
        }
      }
    }
    G.zones = G.zones.filter((z) => z.t < z.life);

    for (const z of G.ezones) {
      z.t += dt;
      if (!z.done && z.t >= z.delay) {
        z.done = true;
        if (z.type === 'boom') {
          Cb.fx({ type: 'sprite', key: 'slam', x: z.x + z.w / 2, y: C.FLOOR + 2, anchor: 'b', scale: 1.1, life: .45 });
          Cb.shake(5); MD.Audio.sfx.skill('dokkaebi'); Cb.burst(z.x + z.w / 2, C.FLOOR - 10, 14, '#ff9a3c', 260, .5, 3);
        }
        if (!P.dead && U.overlap(z, P)) Cb.hurtPlayer(z.dmg, z.x + z.w / 2);
      }
    }
    G.ezones = G.ezones.filter((z) => z.t < z.delay + .3);

    /* 영혼 조각(재화) 줍기 */
    for (const o of G.pickups) {
      o.t += dt;
      const dx = cx(P) - o.x, dy = cy(P) - o.y, d = Math.hypot(dx, dy);
      if (o.t > .4 && d < 150 && !P.dead) { const a = 1100 * dt * (1 + (150 - d) / 60); o.vx += dx / (d || 1) * a; o.vy += dy / (d || 1) * a; o.mag = true; }
      else if (!o.mag) { o.vy += 1500 * dt; }
      o.vx -= o.vx * Math.min(1, dt * (o.mag ? 2 : 3));
      if (o.mag) o.vy -= o.vy * Math.min(1, dt * 2);
      o.x += o.vx * dt; o.y += o.vy * dt;
      if (!o.mag && o.y > C.FLOOR - 6) { o.y = C.FLOOR - 6; o.vy *= -.45; if (Math.abs(o.vy) < 40) o.vy = 0; }
      if (d < 20 && o.t > .25 && !P.dead) {
        o.dead = true; P.gold += o.v; G.runGold += o.v;
        Cb.num(cx(P) + U.rnd(-10, 10), P.y - 6, '+' + o.v, '#8fe3d2', 16);
        if (G.clock - (Cb.lastPick || 0) > .06) { MD.Audio.sfx.pickup(); Cb.lastPick = G.clock; }
      }
    }
    G.pickups = G.pickups.filter((o) => !o.dead && o.t < 25);
  };
})();
