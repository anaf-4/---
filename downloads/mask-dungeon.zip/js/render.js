/* render.js — 캔버스 그리기 (배경, 바닥, 캐릭터, 이펙트) */
(() => {
  const MD = window.MD, G = MD.G, C = MD.C, K = C.K, U = MD.U, A = MD.Assets, TAU = C.TAU;
  const R = MD.Render = {};
  let ctx, vig, fog, floorImg;
  const cx = (b) => b.x + b.w / 2;

  function mk(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }

  function buildVignette() {
    vig = mk(C.CW, C.CH);
    const x = vig.getContext('2d');
    const g = x.createRadialGradient(C.CW / 2, C.CH * .52, C.CH * .35, C.CW / 2, C.CH * .52, C.CW * .72);
    g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(2,4,10,.78)');
    x.fillStyle = g; x.fillRect(0, 0, C.CW, C.CH);
  }

  function buildFog() {
    fog = mk(C.CW, 180);
    const x = fog.getContext('2d');
    for (let i = 0; i < 16; i++) {
      const px = (i / 16) * C.CW + U.rnd(-30, 30), py = U.rnd(60, 150), r = U.rnd(90, 200);
      const g = x.createRadialGradient(px, py, 0, px, py, r);
      g.addColorStop(0, 'rgba(120,160,180,.20)'); g.addColorStop(1, 'rgba(120,160,180,0)');
      x.fillStyle = g; x.fillRect(px - r, py - r, r * 2, r * 2);
    }
  }

  function buildFloor() {
    const h = C.CH - C.FLOOR * K;
    floorImg = mk(C.CW, h);
    const x = floorImg.getContext('2d');
    const g = x.createLinearGradient(0, 0, 0, h);
    g.addColorStop(0, '#22394b'); g.addColorStop(.12, '#172a3a'); g.addColorStop(1, '#070d15');
    x.fillStyle = g; x.fillRect(0, 0, C.CW, h);
    x.strokeStyle = 'rgba(3,6,12,.75)'; x.lineWidth = 2;
    const rows = [14, 40, 66];
    rows.forEach((y, ri) => {
      x.beginPath(); x.moveTo(0, y); x.lineTo(C.CW, y); x.stroke();
      for (let px = (ri % 2) * 56; px < C.CW; px += 112) { x.beginPath(); x.moveTo(px, y); x.lineTo(px, y + 26); x.stroke(); }
    });
    for (let i = 0; i < 160; i++) {
      x.fillStyle = 'rgba(' + (i % 3 ? '90,140,160' : '0,0,0') + ',' + U.rnd(.05, .14) + ')';
      x.fillRect(U.rnd(0, C.CW), U.rnd(4, h), U.rnd(3, 12), 2);
    }
    x.fillStyle = '#5a8da0'; x.fillRect(0, 0, C.CW, 3);
    x.fillStyle = '#2f5566'; x.fillRect(0, 3, C.CW, 3);
    x.fillStyle = 'rgba(255,154,60,.10)'; x.fillRect(0, 6, C.CW, 4);
  }

  /* 수직동기화: 브라우저는 화면 주사율에 맞춰 그리는 것이 기본이다.
     끄면 '저지연 캔버스(desynchronized)'를 써서 입력 지연을 줄이는 대신 화면 찢김이 생길 수 있다. */
  function makeCtx(vsync) {
    const old = document.getElementById('cv');
    let cv = old, c = null;
    const opt = vsync ? { alpha: false } : { alpha: false, desynchronized: true };
    if (R.ctx) {   // 이미 컨텍스트가 있으면 새 캔버스로 교체해야 옵션이 바뀐다
      cv = old.cloneNode(false);
      old.parentNode.replaceChild(cv, old);
    }
    try { c = cv.getContext('2d', opt); } catch (e) { c = null; }
    if (!c) c = cv.getContext('2d');
    c.imageSmoothingEnabled = false;
    ctx = c; R.ctx = c;
  }
  R.setSync = (vsync) => { if (R.vs === !!vsync) return; R.vs = !!vsync; makeCtx(R.vs); };

  R.init = () => {
    R.vs = MD.Settings.data.vsync !== false;
    makeCtx(R.vs);
    buildVignette(); buildFog(); buildFloor();
  };

  function inPx(fn) {
    const t = ctx.getTransform();
    ctx.save(); ctx.setTransform(1, 0, 0, 1, t.e, t.f); ctx.imageSmoothingEnabled = false;
    fn();
    ctx.restore();
  }
  function bgKey() {
    const r = G.room, s = G.state;
    if (s === 'scene') return G.sceneBg || 'castle';
    if (s === 'menu' || s === 'boot' || !G.P) return 'castle';
    return r <= 2 ? 'castle' : r <= 4 ? 'crypt' : r <= 6 ? 'ember' : r === 7 ? 'hall' : 'throne';
  }
  /* 레이어 배경: 하늘(고정) → 구름(천천히 흐름) → 먼 배경 → 중간 구조물 → 가까운 오브젝트. 전경은 drawFront 에서 */
  const BG_SPD = { far: .06, mid: .16, near: .34, front: .6 };
  const BG_Y = { far: 612, mid: 650, near: 654 };
  function bgPar() {
    if (G.qual < 1) return 0;
    return G.P && G.state !== 'menu' ? (G.P.x / C.W - .5) : Math.sin(G.clock * .15) * .5;
  }
  /* zoom: 가로 확대 배율. 세로는 구역별 ky 를 더 곱해 구조물을 키운다 */
  function layerDraw(img, m, key, par, spd, y, anchorTop, ky, zoom) {
    zoom = zoom || 1;
    const sx = (C.CW + 180) / m[0] * zoom, dw = m[0] * sx, dh = m[1] * sx * ky * zoom;
    const x = Math.round((C.CW - dw) / 2 - par * 260 * spd);
    ctx.drawImage(img, x, Math.round(anchorTop ? y : y - dh), Math.round(dw), Math.round(dh));
  }
  function drawBgLayers(L, M, key) {
    ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(L.sky, 0, 0, C.CW, C.CH);
    const par = bgPar();
    if (L.clouds) {
      const m = M.clouds, sx = (C.CW + 180) / m[0], dw = Math.round(m[0] * sx), dh = Math.round(m[1] * sx * M.ky);
      /* 멀리 있는 작은 구름(느림) → 가까운 큰 구름(빠름) */
      const dw2 = Math.round(dw * .75), dh2 = Math.round(dh * .75);
      const off2 = ((G.clock * 3.5 + dw2 * .5) % dw2 + dw2) % dw2;
      ctx.globalAlpha = .55;
      for (let k = -1; k <= 1; k++) ctx.drawImage(L.clouds, Math.round(-90 + off2 + k * dw2), 190, dw2, dh2);
      ctx.globalAlpha = 1;
      const off = ((G.clock * 7 + par * -260 * .02) % dw + dw) % dw;
      for (let k = -1; k <= 1; k++) ctx.drawImage(L.clouds, Math.round(-90 + off + k * dw), 36, dw, dh);
    }
    if (L.far) layerDraw(L.far, M.far, key, par, BG_SPD.far, BG_Y.far, false, M.ky, 1.3);
    if (L.mid) layerDraw(L.mid, M.mid, key, par, BG_SPD.mid, BG_Y.mid, false, M.ky, 1.15);
    if (L.near) layerDraw(L.near, M.near, key, par, BG_SPD.near, key === 'throne' ? 0 : BG_Y.near, key === 'throne', M.ky, 1.15);
    ctx.imageSmoothingEnabled = false;
  }
  /* 보스 단계 전환 연출: 화면이 어두워지고 눈이 반짝이다가 붉게 폭발 */
  function glint(x, y, s, a) {
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    const g = ctx.createRadialGradient(x, y, 0, x, y, s);
    g.addColorStop(0, 'rgba(255,240,200,' + a + ')'); g.addColorStop(.35, 'rgba(255,60,50,' + a * .7 + ')'); g.addColorStop(1, 'rgba(255,40,40,0)');
    ctx.fillStyle = g; ctx.fillRect(x - s, y - s, s * 2, s * 2);
    ctx.fillStyle = 'rgba(255,230,190,' + a + ')';
    ctx.fillRect(x - s * 1.6, y - 1.2, s * 3.2, 2.4); ctx.fillRect(x - 1.2, y - s * 1.6, 2.4, s * 3.2);
    ctx.restore();
  }
  function drawPhaseCine() {
    const cn = G.cine; if (!cn || cn.type !== 'phase') return;
    const b = G.enemies.find((e) => e.boss); if (!b) return;
    const t = cn.t, p3 = cn.data.ph === 3;
    const dim = t < 1.75 ? Math.min(.55, t * .9) : Math.max(0, .55 - (t - 1.75) * .8);
    ctx.fillStyle = 'rgba(2,2,10,' + dim + ')'; ctx.fillRect(0, 0, C.W, C.H);
    const bx = cx(b), hy = b.y + 18, ex = b.face < 0 ? -7 : 7;
    // 눈 반짝임: 두 번 깜빡이다 마지막에 크게
    const pulse = (t0, d) => t < t0 ? 0 : Math.max(0, 1 - Math.abs(t - t0 - d / 2) / (d / 2));
    const a = Math.max(pulse(.5, .5) * .6, pulse(1.1, .5) * .85, t >= 1.6 && t < 2.6 ? Math.min(1, (t - 1.6) * 3) * (1 - Math.max(0, t - 2.2) / .4) : 0);
    if (a > 0) {
      const s = 6 + a * (t > 1.6 ? 20 : 9);
      glint(bx + ex - 9, hy, s, a); glint(bx + ex + 9, hy, s, a);
    }
    if (t > 1.75) {
      ctx.save(); ctx.globalCompositeOperation = 'lighter';
      const k = Math.max(0, 1 - (t - 1.75) / 1.2), fy = b.y + b.h;
      const g = ctx.createRadialGradient(bx, fy - 90, 10, bx, fy - 90, 190);
      g.addColorStop(0, 'rgba(255,70,50,' + (.55 * k) + ')'); g.addColorStop(1, 'rgba(255,40,40,0)');
      ctx.fillStyle = g; ctx.fillRect(bx - 200, fy - 290, 400, 320);
      ctx.restore();
      if (Math.random() < .6) MD.Combat.burst(bx + (Math.random() - .5) * 70, fy - 10, 1, p3 ? '#ff3c3c' : '#ff8a3c', 140, 1, 3);
    }
  }
  function drawFront() {
    const key = bgKey(), L = A.bgl && A.bgl[key], M = MD.BG && MD.BG[key];
    if (!L || !L.front || !M || !M.front) return;
    const save = ctx.getTransform();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
    ctx.globalAlpha = .92;
    layerDraw(L.front, M.front, key, bgPar(), BG_SPD.front, C.CH, false, 1.5);
    ctx.globalAlpha = 1; ctx.imageSmoothingEnabled = false;
    ctx.setTransform(save);
  }
  function drawBg(tint) {
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    const key = bgKey(), L = A.bgl && A.bgl[key], M = MD.BG && MD.BG[key];
    const bg = A.bgs && A.bgs[key];
    if (L && L.sky && M) {
      drawBgLayers(L, M, key);
    } else if (bg) {
      const px = G.qual < 1 ? 0 : G.P && G.state !== 'menu' ? (G.P.x / C.W - .5) * -50 : Math.sin(G.clock * .15) * 18;
      ctx.drawImage(bg, Math.round(-40 + px), 0);
    } else if (A.bg) ctx.drawImage(A.bg, 0, 0, C.CW, C.CH);
    else { ctx.fillStyle = '#0a1422'; ctx.fillRect(0, 0, C.CW, C.CH); }
    if (tint) { ctx.fillStyle = tint; ctx.fillRect(0, 0, C.CW, C.CH); }
    if (G.qual >= 1) {
      const off = (G.clock * 14) % C.CW;
      ctx.globalAlpha = .55;
      ctx.drawImage(fog, -off, C.CH - 260);
      ctx.drawImage(fog, C.CW - off, C.CH - 260);
      ctx.globalAlpha = 1;
    }
  }

  const TOPS = ['tile_top_a', 'tile_top_c', 'tile_top_a', 'tile_top_c', 'tile_top_b'];
  const BODS = ['tile_body_a', 'tile_body_b', 'tile_body_a', 'tile_body_crack', 'tile_body_moss', 'tile_body_b'];
  function drawFloor() {
    if (!A.obj) { ctx.drawImage(floorImg, -24, C.FLOOR, C.W + 48, floorImg.height / K); return; }
    inPx(() => {
      const fy = Math.round(C.FLOOR * K);
      ctx.fillStyle = '#0b1220'; ctx.fillRect(-40, fy, C.CW + 80, C.CH - fy + 40);
      for (let i = -1, x = -32; x < C.CW + 40; i++, x += 64) {
        const k = ((i * 7 + 3) % 5 + 5) % 5;
        A.objDraw(ctx, BODS[((i * 5 + 1) % 6 + 6) % 6], x, fy + 40);
        A.objDraw(ctx, TOPS[k], x, fy - 4);
      }
      const g = ctx.createLinearGradient(0, fy + 10, 0, C.CH);
      g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(2,4,10,.55)');
      ctx.fillStyle = g; ctx.fillRect(-40, fy + 10, C.CW + 80, C.CH - fy);
    });
  }

  function strip(key, x, y, w) {
    const d = MD.OBJ_META[key];
    ctx.drawImage(A.obj, d[0], d[1], Math.min(d[2], w), d[3], x, y, Math.min(d[2], w), d[3]);
  }
  function drawPlats() {
    for (const p of G.plats) {
      if (!A.obj) {
        const h = 18;
        ctx.fillStyle = '#05080f'; ctx.fillRect(p.x - 2, p.y - 2, p.w + 4, h + 4);
        ctx.fillStyle = '#2d4b5d'; ctx.fillRect(p.x, p.y, p.w, h);
        continue;
      }
      inPx(() => {
        const x = Math.round(p.x * K), y = Math.round(p.y * K) - 6, tw = Math.round(p.w * K);
        ctx.fillStyle = 'rgba(0,0,0,.28)'; ctx.fillRect(x + 8, y + 36, tw - 16, 16);
        for (let px = 64; px < tw - 64; px += 64) strip('plat_um', x + px, y, tw - 64 - px);
        strip('plat_ul', x, y, 64);
        strip('plat_ur', x + tw - 64, y, 64);
      });
    }
  }

  /* 배경 소품: 방마다 고정된 위치 (횃불 / 깃발 / 해골) */
  function rng(seed) { let a = seed * 9301 + 49297; return () => { a = (a * 9301 + 49297) % 233280; return a / 233280; }; }
  function drawDecor() {
    if (!A.obj) return;
    const rn = rng((G.room || 1) + 3);
    const fy = Math.round(C.FLOOR * K) + 3;
    const t = G.clock;
    const pool = [60, 130, 260, 330, 430, 520, 600, 700, 800].filter((x) => !G.plats.some((q) => x > q.x - 40 && x < q.x + q.w + 40) && x < 820);
    const xs = [pool[Math.floor(rn() * pool.length)] || 40, pool[Math.floor(pool.length / 2 + rn() * pool.length / 2)] || 760].map((v) => Math.round(v * K));
    const sk = Math.round((300 + rn() * 200) * K);
    inPx(() => {
      A.objDraw(ctx, 'decor_skulls', sk, fy - 43);
      xs.forEach((cxp, i) => {
        ctx.save(); ctx.globalAlpha = .92;
        const yb = fy - 53, ym = yb - 87, yt = ym - 84;
        A.objDraw(ctx, 'decor_pillar_mid', cxp - 14, ym + 0);
        A.objDraw(ctx, 'decor_pillar_mid', cxp - 14, ym + 0);
        A.objDraw(ctx, 'decor_pillar_top', cxp - 18, yt);
        A.objDraw(ctx, 'decor_pillar_base', cxp - 26, yb);
        ctx.restore();
        if (i === 0) A.objDraw(ctx, 'decor_banner', cxp - 17, yt + 46);
        else {
          const tx = cxp - 11, ty = ym + 14;
          A.objDraw(ctx, 'decor_torch' + (i % 2 ? '1' : '2'), tx, ty);
          const fl = .8 + Math.sin(t * 9 + i * 2) * .12 + Math.sin(t * 23 + i) * .06;
          ctx.save(); ctx.globalCompositeOperation = 'lighter';
          const g = ctx.createRadialGradient(tx + 10, ty + 10, 2, tx + 10, ty + 10, 130 * fl);
          g.addColorStop(0, 'rgba(255,170,70,.38)'); g.addColorStop(1, 'rgba(255,120,30,0)');
          ctx.fillStyle = g; ctx.fillRect(tx - 130, ty - 130, 270, 270);
          ctx.restore();
        }
      });
      A.objDraw(ctx, 'decor_chain', Math.round((60 + rn() * 80) * K), 0);
    });
  }

  let doorT0 = -1, doorWas = false;
  function drawDoor() {
    const d = G.door;
    const boss = G.room === C.MAXROOM;
    if (!d && !doorWas) { /* 닫힘 */ } 
    if (d && !doorWas) doorT0 = G.clock;
    doorWas = !!d;
    if (!A.obj) {
      const x = d ? d.x : C.W - 120, y = C.FLOOR - 110, w = 70, h = 110;
      ctx.fillStyle = '#05080f'; ctx.fillRect(x - 10, y - 10, w + 20, h + 10);
      ctx.fillStyle = '#0a1018'; ctx.fillRect(x, y, w, h);
      return;
    }
    inPx(() => {
      const fy = Math.round(C.FLOOR * K) + 3;
      if (boss) {
        const op = G.state === 'ending' || G.state === 'end' ? 1 : Math.min(1, G.doorOpenT / .9);
        const bx = Math.round((C.W - 100) * K);
        const m = MD.OBJ_META.bossdoor_closed, m2 = MD.OBJ_META.bossdoor_open;
        ctx.drawImage(A.obj, m[0], m[1], m[2], m[3], bx - m[2] / 2, fy - m[3], m[2], m[3]);
        if (op > 0) {
          ctx.globalAlpha = op;
          ctx.drawImage(A.obj, m2[0], m2[1], m2[2], m2[3], bx - m2[2] / 2, fy - m2[3], m2[2], m2[3]);
          ctx.globalAlpha = 1;
          ctx.save(); ctx.globalCompositeOperation = 'lighter';
          const g = ctx.createRadialGradient(bx, fy - 100, 10, bx, fy - 100, 220);
          g.addColorStop(0, 'rgba(255,230,160,' + (.5 * op) + ')'); g.addColorStop(1, 'rgba(255,200,100,0)');
          ctx.fillStyle = g; ctx.fillRect(bx - 240, fy - 340, 480, 360);
          ctx.restore();
        }
        return;
      }
      const x = Math.round((C.W - 85) * K);
      let key = 'door_closed';
      if (d) {
        const dt = G.clock - doorT0;
        key = dt < .45 ? 'door_burst' : 'door_open' + (Math.floor(G.clock * 6) % 3);
        const g = ctx.createRadialGradient(x, fy - 80, 6, x, fy - 80, 150);
        ctx.save(); ctx.globalCompositeOperation = 'lighter';
        g.addColorStop(0, 'rgba(255,170,70,.35)'); g.addColorStop(1, 'rgba(255,120,30,0)');
        ctx.fillStyle = g; ctx.fillRect(x - 160, fy - 240, 320, 260);
        ctx.restore();
      }
      const m = MD.OBJ_META[key];
      ctx.drawImage(A.obj, m[0], m[1], m[2], m[3], x - Math.round(m[2] / 2), fy - m[3], m[2], m[3]);
    });
    if (d) {
      const t = G.clock;
      ctx.fillStyle = 'rgba(255,240,200,.95)';
      ctx.font = '700 15px ' + MD.FONT.D; ctx.textAlign = 'center';
      ctx.fillText('▶ 다음 방', C.W - 85, C.FLOOR - 128 + Math.sin(t * 4) * 3);
    }
  }

  function shadow(x, fy, w) {
    ctx.fillStyle = 'rgba(0,0,0,.4)';
    ctx.beginPath(); ctx.ellipse(x, fy + 1, w * .5, 5, 0, 0, TAU); ctx.fill();
  }

  /* ---- 보스 (절차적 그리기, 스프라이트가 있으면 그쪽을 사용) ---- */
  function drawBoss(e) {
    const f = e.face, t = G.clock;
    const x = cx(e), fy = e.y + e.h;
    let sw = .55;
    if (e.state === 'windup' && e.atk === 'swing') sw = .55 - 2.8 * Math.min(1, e.atkT / e.atkTotal);
    else if (e.state === 'act' && e.atk === 'swing') sw = 1.3;
    else if (e.state === 'windup' && e.atk === 'slam') sw = -.6;
    else if (e.state === 'air') sw = -2.2;
    const lift = e.state === 'air' ? 0 : Math.sin(t * 3) * 3;
    ctx.save();
    if (e.flash > 0) { try { ctx.filter = 'brightness(2.6)'; } catch (_) { /* 무시 */ } }
    if (e.spawnT > 0) ctx.globalAlpha = 1 - e.spawnT / .8;
    ctx.translate(x, fy); ctx.scale(f, 1);
    ctx.fillStyle = '#17112b';
    ctx.beginPath(); ctx.moveTo(-34, -112 + lift); ctx.lineTo(34, -112 + lift); ctx.lineTo(54, 0); ctx.lineTo(-54, 0); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#2a1d4d';
    ctx.beginPath(); ctx.moveTo(-20, -108 + lift); ctx.lineTo(20, -108 + lift); ctx.lineTo(30, 0); ctx.lineTo(-30, 0); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#e9bf5b'; ctx.fillRect(-54, -4, 108, 4);
    ctx.fillStyle = '#3a2c66'; ctx.fillRect(-40, -118 + lift, 80, 22);
    ctx.fillStyle = '#e9bf5b'; ctx.fillRect(-40, -98 + lift, 80, 3);
    ctx.fillStyle = '#d8d0b8';
    ctx.beginPath(); ctx.ellipse(0, -142 + lift, 26, 30, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = '#b52b34';
    ctx.beginPath(); ctx.moveTo(-26, -150 + lift); ctx.lineTo(-40, -176 + lift); ctx.lineTo(-12, -164 + lift); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.moveTo(26, -150 + lift); ctx.lineTo(40, -176 + lift); ctx.lineTo(12, -164 + lift); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#b52b34'; ctx.fillRect(-18, -128 + lift, 36, 5);
    ctx.fillStyle = '#ffcf5a';
    ctx.fillRect(-14, -150 + lift, 9, 8); ctx.fillRect(5, -150 + lift, 9, 8);
    ctx.fillStyle = '#05080f'; ctx.fillRect(-9, -149 + lift, 3, 6); ctx.fillRect(10, -149 + lift, 3, 6);
    ctx.fillRect(-12, -134 + lift, 24, 3);
    ctx.save();
    ctx.translate(26, -86 + lift); ctx.rotate(sw);
    ctx.fillStyle = '#3a2c66'; ctx.fillRect(-6, -8, 12, 38);
    ctx.fillStyle = '#c9d6dc'; ctx.fillRect(-5, 28, 10, 96);
    ctx.fillStyle = '#ffffff'; ctx.fillRect(-1, 30, 2, 92);
    ctx.fillStyle = '#e9bf5b'; ctx.fillRect(-14, 24, 28, 6);
    ctx.restore();
    ctx.restore();
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    const g = ctx.createRadialGradient(x, fy - 100, 10, x, fy - 100, 110);
    g.addColorStop(0, 'rgba(181,43,52,.22)'); g.addColorStop(1, 'rgba(181,43,52,0)');
    ctx.fillStyle = g; ctx.fillRect(x - 120, fy - 220, 240, 240);
    ctx.restore();
  }

  const BSC = 0.66;
  function drawEnemy(e) {
    shadow(cx(e), e.fly ? C.FLOOR : e.y + e.h, e.w + 10);
    if (e.boss && !A.has('boss')) { drawBoss(e); return; }
    if (e.boss) {
      const ba = MD.Enemies.bossAnim(e), fy = e.y + e.h + 2;
      if (e.ph >= 2) {
        ctx.save(); ctx.globalCompositeOperation = 'lighter';
        const gl = e.ph >= 3 ? .5 : .3, pl = gl + Math.sin(G.clock * 6) * .08;
        const g = ctx.createRadialGradient(cx(e), fy - 100, 10, cx(e), fy - 100, 150);
        g.addColorStop(0, 'rgba(255,60,50,' + pl + ')'); g.addColorStop(1, 'rgba(255,60,50,0)');
        ctx.fillStyle = g; ctx.fillRect(cx(e) - 160, fy - 260, 320, 280);
        ctx.restore();
      }
      A.drawBoss(ctx, ba.row, ba.frame, cx(e), fy, e.face < 0, 1, null, BSC);
      if (e.flash > 0) A.drawBoss(ctx, ba.row, ba.frame, cx(e), fy, e.face < 0, .7, '#ffffff', BSC);
      if (e.tele) {
        const p = .3 + Math.sin(G.clock * 22) * .13;
        ctx.fillStyle = 'rgba(220,40,50,' + p + ')';
        ctx.fillRect(e.tele.x, e.tele.y, e.tele.w, e.tele.h);
      }
      return;
    }
    const an = MD.Enemies.anim(e);
    const alpha = e.spawnT > 0 ? 1 - e.spawnT / .35 : 1;
    const bob = e.fly ? Math.sin(e.anim * 4) * 3 : 0;
    const sc = e.scale || 1, sq = e.sq > 0 ? Math.min(1, e.sq / .16) : 0;
    const sx = sc * (1 + .14 * sq), sy = sc * (1 - .12 * sq);
    const fy = e.y + e.h + bob;
    if (e.elite) {
      ctx.save(); ctx.globalCompositeOperation = 'lighter';
      const pr = .5 + Math.sin(G.clock * 5) * .15;
      const g = ctx.createRadialGradient(cx(e), fy - e.h * .5, 6, cx(e), fy - e.h * .5, e.h * .9);
      g.addColorStop(0, e.modCol + '66'); g.addColorStop(1, e.modCol + '00');
      ctx.globalAlpha = pr + .3; ctx.fillStyle = g; ctx.fillRect(cx(e) - e.h, fy - e.h * 1.6, e.h * 2, e.h * 2);
      ctx.restore();
    }
    A.draw(ctx, e.type, an.row, an.frame, cx(e), fy, e.face < 0, alpha, e.tint ? 'T' + e.tint : null, sx, sy);
    if (e.flash > 0) A.draw(ctx, e.type, an.row, an.frame, cx(e), fy, e.face < 0, .75, '#ffffff', sx, sy);
    if (e.shield && A.props) A.prop(ctx, 'shield', cx(e) + e.face * (e.w * .5 + 6), e.y + e.h * .72, .3);
    else if (e.shield) {
      const sxp = cx(e) + e.face * (e.w * .5 + 4);
      ctx.fillStyle = '#05080f'; ctx.fillRect(sxp - 5, e.y + e.h * .18, 10, e.h * .56);
      ctx.fillStyle = '#9fb4ff'; ctx.fillRect(sxp - 3, e.y + e.h * .18 + 2, 6, e.h * .56 - 4);
      ctx.fillStyle = '#e8eeff'; ctx.fillRect(sxp - 1, e.y + e.h * .2 + 4, 2, e.h * .56 - 10);
    }
    if (e.tele) {
      const p = .35 + Math.sin(G.clock * 22) * .15;
      ctx.fillStyle = 'rgba(220,40,50,' + p + ')';
      ctx.fillRect(e.tele.x, e.tele.y, e.tele.w, e.tele.h);
    }
    if (e.state === 'windup' && !e.boss) {
      ctx.fillStyle = '#ff5050'; ctx.font = '700 22px ' + MD.FONT.T; ctx.textAlign = 'center';
      ctx.fillText('!', cx(e), e.y - 14);
    }
    if (!e.boss && (e.hp < e.maxHp || e.elite)) {
      const w = e.elite ? 56 : 34, x = cx(e) - w / 2, y = e.y - 8;
      ctx.fillStyle = '#05080f'; ctx.fillRect(x - 1, y - 1, w + 2, 6);
      ctx.fillStyle = e.elite ? e.modCol : '#c3303b'; ctx.fillRect(x, y, w * Math.max(0, e.hp / e.maxHp), 4);
      if (e.elite) {
        ctx.font = '700 14px ' + MD.FONT.D; ctx.textAlign = 'center';
        ctx.lineWidth = 3; ctx.strokeStyle = '#05080f'; ctx.strokeText(e.name, cx(e), y - 5);
        ctx.fillStyle = e.modCol; ctx.fillText(e.name, cx(e), y - 5);
        if (A.props) A.prop(ctx, 'elite', cx(e), y - 18, .2);
      }
    }
  }

  function drawPlayer() {
    const P = G.P, M = MD.Player.mask(P);
    shadow(cx(P), P.y + P.h, P.w + 14);
    const an = MD.Player.anim(P);
    let alpha = 1;
    if (P.dashT > 0) alpha = .55;
    else if (P.inv > 0 && P.hurtT <= 0) alpha = Math.floor(G.clock * 16) % 2 ? .45 : 1;
    A.draw(ctx, M.id, an.row, an.frame, cx(P), P.y + P.h, P.face < 0, alpha);
    if (P.hurtT > .26) A.draw(ctx, M.id, an.row, an.frame, cx(P), P.y + P.h, P.face < 0, .6, '#ffffff');
    if (!A.has(M.id)) { ctx.fillStyle = M.col; ctx.fillRect(P.x, P.y, P.w, P.h); }
  }

  function drawCorpses() {
    for (const c of G.corpses) {
      const frame = Math.min(3.99, c.t / .3);
      let alpha = c.t > 1.6 ? Math.max(0, 1 - (c.t - 1.6) / 1) : 1;
      if (c.boss && A.has('boss')) {
        alpha = c.t > 2.1 ? Math.max(0, 1 - (c.t - 2.1) / .6) : 1;
        A.drawBoss(ctx, 5, Math.min(15, Math.floor(c.t / .13)), cx(c), c.y + c.h + 2, c.face < 0, alpha, null, BSC);
        if (c.t < .1) A.drawBoss(ctx, 5, 0, cx(c), c.y + c.h + 2, c.face < 0, .8, '#ffffff', BSC);
        continue;
      }
      if (c.boss && A.has('boss') === false) {
        ctx.save(); ctx.globalAlpha = alpha * .8; ctx.fillStyle = '#2a1d4d';
        const k = Math.min(1, c.t / .6);
        ctx.fillRect(cx(c) - 50, c.y + c.h - 40 * (1 - k * .6), 100, 40 * (1 - k * .6));
        ctx.restore();
        continue;
      }
      A.draw(ctx, c.name, 3, frame, cx(c), c.y + c.h, c.face < 0, alpha);
      if (c.t < .1) A.draw(ctx, c.name, 3, 0, cx(c), c.y + c.h, c.face < 0, .8, '#ffffff');
    }
  }

  function drawProjs() {
    for (const p of G.projs) {
      const mx = p.x + p.w / 2, my = p.y + p.h / 2;
      if (p.type === 'fire' && A.fx) {
        A.drawFx(ctx, 'fox', Math.floor(p.t * 12) % 3, mx, my, { scale: .55, flip: p.vx < 0 });
      } else if (p.type === 'tal' && A.fx) {
        const dr = p.vx < 0 ? -1 : 1;
        A.drawFx(ctx, 'tal', Math.floor(p.t * 16) % 4, mx, my, { scale: .4, flip: dr < 0, rot: Math.atan2(p.vy, Math.abs(p.vx)) * dr });
      } else if (p.type === 'peg' && A.fx && MD.FX_META.map.mal_peg) {
        const dr = p.vx < 0 ? -1 : 1;
        A.drawFx(ctx, 'mal_peg', Math.floor(p.t * 14) % 5, mx, my, { scale: .55, flip: dr < 0, rot: Math.atan2(p.vy, Math.abs(p.vx)) * dr });
      } else if (p.type === 'peg') {
        ctx.save(); ctx.translate(mx, my); ctx.rotate(Math.atan2(p.vy, p.vx));
        ctx.fillStyle = '#2d0f06'; ctx.fillRect(-12, -4, 24, 8); ctx.fillRect(12, -2, 6, 4);
        ctx.fillStyle = '#b9824a'; ctx.fillRect(-10, -2, 20, 4);
        ctx.fillStyle = '#e8d6a8'; ctx.fillRect(10, -1, 6, 2);
        ctx.fillStyle = '#ff8a4a'; ctx.fillRect(-12, -3, 4, 6);
        ctx.restore();
      } else if (p.type === 'fire') {
        ctx.save(); ctx.globalCompositeOperation = 'lighter';
        const g = ctx.createRadialGradient(mx, my, 2, mx, my, 24);
        g.addColorStop(0, 'rgba(220,255,250,1)'); g.addColorStop(.4, 'rgba(111,224,192,.8)'); g.addColorStop(1, 'rgba(111,224,192,0)');
        ctx.fillStyle = g; ctx.fillRect(mx - 26, my - 26, 52, 52);
        ctx.restore();
      } else {
        ctx.save(); ctx.translate(mx, my); ctx.rotate(Math.atan2(p.vy, p.vx) + Math.sin(p.t * 30) * .1);
        ctx.fillStyle = '#05080f'; ctx.fillRect(-14, -8, 28, 16);
        ctx.fillStyle = '#f3ebd2'; ctx.fillRect(-12, -6, 24, 12);
        ctx.fillStyle = '#c3303b'; ctx.fillRect(-7, -4, 3, 8); ctx.fillRect(-2, -2, 8, 3);
        ctx.restore();
      }
    }
    for (const p of G.eprojs) {
      const mx = p.x + p.w / 2, my = p.y + p.h / 2;
      if (p.type === 'arrow' && A.fx) {
        A.drawFx(ctx, 'arrow', 0, mx, my, { scale: .32, rot: Math.atan2(p.vy, p.vx) });
      } else if (p.type === 'lance' && A.beam) {
        const bm = MD.BOSS_META.beam, t = ctx.getTransform();
        ctx.save(); ctx.setTransform(1, 0, 0, 1, t.e, t.f); ctx.imageSmoothingEnabled = false;
        ctx.translate(Math.round(mx * K), Math.round(my * K)); ctx.rotate(Math.atan2(p.vy, p.vx));
        const sc = .34, f = Math.floor(p.t * 14) % bm.n;
        ctx.drawImage(A.beam, f * bm.w, 0, bm.w, bm.h, -bm.w * sc * .7, -bm.h * sc / 2, bm.w * sc, bm.h * sc);
        ctx.restore();
      } else if (p.type === 'arrow') {
        ctx.save(); ctx.translate(mx, my); ctx.rotate(Math.atan2(p.vy, p.vx));
        ctx.fillStyle = '#05080f'; ctx.fillRect(-14, -3, 26, 6);
        ctx.fillStyle = '#d8d0b8'; ctx.fillRect(-13, -1, 22, 2);
        ctx.fillStyle = '#c3303b'; ctx.beginPath(); ctx.moveTo(14, 0); ctx.lineTo(7, -5); ctx.lineTo(7, 5); ctx.closePath(); ctx.fill();
        ctx.restore();
      } else if (p.type === 'orb' && A.fx) {
        A.drawFx(ctx, 'orb', 0, mx, my, { scale: .3 });
      } else if (p.type === 'wave' && A.fx) {
        A.drawFx(ctx, 'firewave', Math.floor(p.t * 10) % 2, mx, p.y + p.h + 4, { scale: .8, anchor: 'b', flip: p.vx < 0 });
      } else if (p.type === 'orb') {
        ctx.save(); ctx.globalCompositeOperation = 'lighter';
        const g = ctx.createRadialGradient(mx, my, 1, mx, my, 18);
        g.addColorStop(0, 'rgba(255,230,230,1)'); g.addColorStop(.4, 'rgba(210,60,90,.85)'); g.addColorStop(1, 'rgba(210,60,90,0)');
        ctx.fillStyle = g; ctx.fillRect(mx - 20, my - 20, 40, 40);
        ctx.restore();
      } else {
        const dir = U.sgn(p.vx);
        ctx.save(); ctx.translate(mx, p.y + p.h);
        ctx.fillStyle = 'rgba(255,110,60,.85)';
        ctx.beginPath(); ctx.moveTo(-dir * 24, 0); ctx.quadraticCurveTo(-dir * 6, -p.h * 1.1, dir * 22, -p.h * .2); ctx.lineTo(dir * 22, 0); ctx.closePath(); ctx.fill();
        ctx.fillStyle = 'rgba(255,230,160,.9)';
        ctx.beginPath(); ctx.moveTo(-dir * 12, 0); ctx.quadraticCurveTo(-dir * 2, -p.h * .6, dir * 14, -p.h * .1); ctx.lineTo(dir * 14, 0); ctx.closePath(); ctx.fill();
        ctx.restore();
      }
    }
    for (const z of G.zones) {
      const k = Math.min(1, z.t / .2) * Math.min(1, (z.life - z.t) / .4);
      if (A.fx) {
        const f = Math.floor(z.t * 10);
        A.drawFx(ctx, 'rain', f % 6, z.cx - 85, C.FLOOR + 8, { scale: 1.6, anchor: 'b', alpha: k });
        A.drawFx(ctx, 'rain', (f + 3) % 6, z.cx + 85, C.FLOOR + 8, { scale: 1.6, anchor: 'b', alpha: k });
        continue;
      }
      ctx.save(); ctx.globalAlpha = k;
      const g = ctx.createLinearGradient(0, z.y, 0, z.y + z.h);
      g.addColorStop(0, 'rgba(159,180,255,0)'); g.addColorStop(1, 'rgba(159,180,255,.28)');
      ctx.fillStyle = g; ctx.fillRect(z.x, z.y, z.w, z.h);
      ctx.fillStyle = '#f3ebd2';
      for (let i = 0; i < 9; i++) {
        const px = z.x + ((i * 53 + 17) % z.w);
        const py = z.y + ((G.clock * 380 + i * 71) % z.h);
        ctx.fillRect(px, py, 5, 9);
        ctx.fillStyle = i % 2 ? '#f3ebd2' : '#c3303b';
      }
      ctx.restore();
    }
  }

  function drawFx() {
    for (const f of G.fxs) {
      const p = f.t / f.life;
      if (f.type === 'icon') {
        A.drawIcon(ctx, f.key, f.x, f.y - f.rise * (1 - (1 - p) * (1 - p)), f.size, Math.min(1, (1 - p) * 2));
      } else if (f.type === 'ghost') {
        if (G.qual < 1) continue;
        A.draw(ctx, f.name, 0, f.frame, f.x, f.feet, f.face < 0, .38 * (1 - p), f.col);
      } else if (f.type === 'sprite') {
        const n = MD.FX_META.map[f.key].n;
        A.drawFx(ctx, f.key, Math.floor(p * n), f.x, f.y, { scale: f.scale, anchor: f.anchor, flip: f.flip, rot: f.rot, add: f.add, alpha: f.alpha });
      } else if (f.type === 'ring') {
        const r = f.r0 + (f.r1 - f.r0) * (1 - (1 - p) * (1 - p));
        ctx.save(); ctx.globalAlpha = 1 - p; ctx.strokeStyle = f.col; ctx.lineWidth = 4 * (1 - p) + 1;
        ctx.beginPath();
        if (f.flat) ctx.ellipse(f.x, f.y, r, r * .22, 0, 0, TAU); else ctx.arc(f.x, f.y, r, 0, TAU);
        ctx.stroke(); ctx.restore();
      } else if (f.type === 'slash' && A.fx) {
        if (f.spin) A.drawFx(ctx, 'spin', Math.floor(p * 6), f.x, f.y, { scale: f.r * 2 * K / 155 * 1.05, alpha: 1 - p * p * .6 });
        else {
          const key = f.big ? 'slash_big' : 'slash_small', n = MD.FX_META.map[key].n;
          A.drawFx(ctx, key, Math.floor(p * n), f.x, f.y, { scale: f.r * K * 1.5 / 134 * (f.big ? 1.15 : 1), flip: f.dir < 0 });
        }
      } else if (f.type === 'slash') {
        const r = f.r * (.8 + .4 * p), d = f.dir;
        ctx.save(); ctx.globalAlpha = (1 - p) * .95; ctx.translate(f.x, f.y);
        if (f.spin) ctx.rotate(p * 3 * d);
        ctx.scale(d, 1);
        ctx.fillStyle = f.big ? '#ffffff' : f.col;
        ctx.beginPath();
        ctx.arc(0, 0, r, -1.1, 1.1, false);
        ctx.arc(-r * .22, 0, r * .86, 1.1, -1.1, true);
        ctx.closePath(); ctx.fill();
        ctx.restore();
      }
    }
    for (const q of G.parts) {
      ctx.globalAlpha = Math.max(0, 1 - q.t / q.life);
      ctx.fillStyle = q.col; ctx.fillRect(q.x - q.size / 2, q.y - q.size / 2, q.size, q.size);
    }
    ctx.globalAlpha = 1;
  }

  /* ---- 함정: 떨어지는 돌 / 불꽃 분출 / 가시 ---- */
  function drawHazards() {
    for (const h of G.hazards) {
      if (h.kind === 'geyser' && A.props) {
        const c = h.t % h.cyc;
        if (h.ph === 2) A.prop(ctx, 'jet' + Math.min(4, Math.floor((c - 3.0) / 1.2 * 5)), h.x, C.FLOOR + 6, .8);
        else A.prop(ctx, h.ph === 1 ? 'vent_warm' + (Math.floor(G.clock * 10) % 2) : 'vent_cold', h.x, C.FLOOR + 6, .8);
        if (h.ph === 2) { ctx.save(); ctx.globalCompositeOperation = 'lighter'; const g = ctx.createRadialGradient(h.x, C.FLOOR - 50, 5, h.x, C.FLOOR - 50, 110); g.addColorStop(0, 'rgba(255,150,60,.3)'); g.addColorStop(1, 'rgba(255,120,30,0)'); ctx.fillStyle = g; ctx.fillRect(h.x - 120, C.FLOOR - 170, 240, 200); ctx.restore(); }
      } else if (h.kind === 'spikes' && A.props) {
        A.prop(ctx, 'spikes' + h.ph, h.x, C.FLOOR + 3, .8);
      } else if (h.kind === 'geyser') {
        const x = h.x, fy = C.FLOOR;
        ctx.fillStyle = '#05080f'; ctx.fillRect(x - 17, fy - 4, 34, 6);
        ctx.fillStyle = h.ph === 0 ? '#3a2418' : '#a8381d'; ctx.fillRect(x - 14, fy - 3, 28, 4);
        if (h.ph === 1) {
          const a = .35 + Math.sin(G.clock * 30) * .25;
          ctx.fillStyle = 'rgba(255,120,40,' + a + ')'; ctx.fillRect(x - 16, fy - 14, 32, 12);
        } else if (h.ph === 2) {
          ctx.save(); ctx.globalCompositeOperation = 'lighter';
          const hh = 130 + Math.sin(G.clock * 40) * 8;
          const g = ctx.createLinearGradient(0, fy - hh, 0, fy);
          g.addColorStop(0, 'rgba(255,200,80,0)'); g.addColorStop(.4, 'rgba(255,140,40,.7)'); g.addColorStop(1, 'rgba(255,90,30,.95)');
          ctx.fillStyle = g; ctx.fillRect(x - 18, fy - hh, 36, hh);
          ctx.fillStyle = 'rgba(255,240,200,.85)'; ctx.fillRect(x - 6, fy - hh * .8, 12, hh * .8);
          ctx.restore();
        }
      } else if (h.kind === 'spikes') {
        const x0 = h.x - h.w / 2, fy = C.FLOOR, n = 6, sw = h.w / n;
        const up = h.ph === 2 ? 26 : h.ph === 1 ? 7 + Math.sin(G.clock * 35) * 2 : 3;
        ctx.fillStyle = '#05080f'; ctx.fillRect(x0 - 2, fy - 3, h.w + 4, 5);
        for (let i = 0; i < n; i++) {
          const bx = x0 + i * sw;
          ctx.fillStyle = h.ph === 1 ? '#d96a4a' : '#bcc7cc';
          ctx.beginPath(); ctx.moveTo(bx + 1, fy - 2); ctx.lineTo(bx + sw / 2, fy - 2 - up); ctx.lineTo(bx + sw - 1, fy - 2); ctx.closePath(); ctx.fill();
          if (h.ph === 2) { ctx.fillStyle = '#fff'; ctx.fillRect(bx + sw / 2 - 1, fy - up, 2, up - 4); }
        }
        if (h.ph === 1) { ctx.fillStyle = 'rgba(220,40,50,' + (.15 + Math.sin(G.clock * 30) * .08) + ')'; ctx.fillRect(x0, fy - 30, h.w, 30); }
      }
    }
  }
  function drawRocks() {
    for (const z of G.ezones) {
      if (z.type !== 'rock') continue;
      const p = Math.min(1, z.t / z.delay), cxp = z.x + z.w / 2;
      if (z.done && A.props) { A.prop(ctx, 'rockb' + Math.min(3, Math.floor((z.t - z.delay) / .3 * 4)), cxp, C.FLOOR + 2, .62); continue; }
      if (!z.done) {
        ctx.fillStyle = 'rgba(220,40,50,' + (.2 + p * .25) + ')';
        ctx.beginPath(); ctx.ellipse(cxp, C.FLOOR, z.w * .55, 7, 0, 0, TAU); ctx.fill();
        const y = -50 + (C.FLOOR - 40 + 50) * p * p;
        if (A.props) { const t0 = ctx.getTransform(); ctx.save(); ctx.translate(0, 0); A.prop(ctx, 'rock', cxp, y + 28, .6); ctx.restore(); continue; }
        ctx.save(); ctx.translate(cxp, y); ctx.rotate(p * 3);
        ctx.fillStyle = '#05080f'; ctx.beginPath(); ctx.moveTo(-24, 4); ctx.lineTo(-10, -26); ctx.lineTo(16, -22); ctx.lineTo(26, 6); ctx.lineTo(4, 24); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#6b7480'; ctx.beginPath(); ctx.moveTo(-20, 3); ctx.lineTo(-8, -22); ctx.lineTo(14, -18); ctx.lineTo(22, 5); ctx.lineTo(3, 20); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#8f99a3'; ctx.fillRect(-6, -14, 10, 5);
        ctx.restore();
      }
    }
  }

  /* ---- 영혼 조각 ---- */
  function drawPickups() {
    if (!G.pickups.length) return;
    if (A.props) {
      for (const o of G.pickups) {
        const big = o.v >= 8, f = Math.floor(G.clock * 10 + o.x) ;
        A.prop(ctx, big ? 'soul_l' + (f % 2) : 'soul_s' + (f % 4), o.x, o.y + (big ? 10 : 8), big ? .5 : .55);
      }
      return;
    }
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    for (const o of G.pickups) {
      const r = o.v >= 8 ? 7 : 5, fl = .75 + Math.sin(G.clock * 12 + o.x) * .25;
      const g = ctx.createRadialGradient(o.x, o.y, 1, o.x, o.y, r * 3);
      g.addColorStop(0, 'rgba(143,227,210,' + (fl * .55) + ')'); g.addColorStop(1, 'rgba(111,224,192,0)');
      ctx.fillStyle = g; ctx.fillRect(o.x - r * 3, o.y - r * 3, r * 6, r * 6);
      ctx.fillStyle = 'rgba(230,255,248,.95)'; ctx.fillRect(o.x - 2, o.y - 3, 4, 6);
    }
    ctx.restore();
  }

  /* ---- 상점 / 쉼터 / 사건 소품 ---- */
  function drawProps() {
    const p = G.props;
    if (!p) return;
    const x = p.x, fy = C.FLOOR, t = G.clock;
    if (A.props) {
      if (p.kind === 'rest') {
        if (p.used) A.prop(ctx, 'fire_dead', x, fy + 4, .85);
        else {
          A.prop(ctx, 'fire' + (Math.floor(t * 8) % 4), x, fy + 4, .85);
          ctx.save(); ctx.globalCompositeOperation = 'lighter';
          const g = ctx.createRadialGradient(x, fy - 30, 6, x, fy - 30, 190 + Math.sin(t * 9) * 12);
          g.addColorStop(0, 'rgba(255,160,60,.38)'); g.addColorStop(1, 'rgba(255,110,30,0)');
          ctx.fillStyle = g; ctx.fillRect(x - 220, fy - 250, 440, 270); ctx.restore();
          if (Math.random() < .25 && G.qual > 0) G.parts.push({ x: x + U_rnd(-12, 12), y: fy - 40, vx: U_rnd(-20, 20), vy: -U_rnd(60, 120), g: -20, t: 0, life: 1, col: '#ffb060', size: 2 });
        }
      } else if (p.kind === 'shop') {
        A.prop(ctx, 'stall1', x - 34, fy + 2, .85);
        A.prop(ctx, 'merch' + (Math.floor(t * 2.5) % 4), x + 70, fy + 2, .7);
        ctx.save(); ctx.globalCompositeOperation = 'lighter';
        const g = ctx.createRadialGradient(x, fy - 70, 6, x, fy - 70, 150);
        g.addColorStop(0, 'rgba(255,200,100,.25)'); g.addColorStop(1, 'rgba(255,160,60,0)');
        ctx.fillStyle = g; ctx.fillRect(x - 160, fy - 230, 320, 240); ctx.restore();
      } else {
        const nm = p.ev && p.ev.name;
        if (nm === '고요한 샘') A.prop(ctx, 'fountain', x, fy + 3, .8);
        else if (p.used) A.prop(ctx, nm === '피의 제단' ? 'altar_off1' : 'altar_off0', x, fy + 3, .8);
        else A.prop(ctx, nm === '피의 제단' ? 'altar_blood' : 'altar_on' + (Math.floor(t * 6) % 4), x, fy + 3, .8);
      }
    } else if (p.kind === 'rest') {
      const on = !p.used;
      ctx.fillStyle = 'rgba(0,0,0,.4)'; ctx.beginPath(); ctx.ellipse(x, fy + 1, 46, 7, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = '#3a2414'; ctx.save(); ctx.translate(x, fy - 7); ctx.rotate(.35); ctx.fillRect(-34, -5, 68, 10); ctx.rotate(-.7); ctx.fillRect(-34, -5, 68, 10); ctx.restore();
      ctx.fillStyle = '#5a3a1e'; ctx.save(); ctx.translate(x, fy - 7); ctx.rotate(.35); ctx.fillRect(-34, -5, 68, 4); ctx.rotate(-.7); ctx.fillRect(-34, -5, 68, 4); ctx.restore();
      if (on) {
        for (let i = 0; i < 3; i++) {
          const fh = 46 - i * 12 + Math.sin(t * 11 + i * 2) * 5, fw = 22 - i * 6;
          ctx.fillStyle = ['#e0501c', '#ff9a2c', '#ffe27a'][i];
          ctx.beginPath(); ctx.moveTo(x - fw, fy - 8); ctx.quadraticCurveTo(x - fw * .5 + Math.sin(t * 8 + i) * 3, fy - fh * .6, x + Math.sin(t * 13 + i) * 4, fy - 8 - fh); ctx.quadraticCurveTo(x + fw * .5, fy - fh * .6, x + fw, fy - 8); ctx.closePath(); ctx.fill();
        }
        ctx.save(); ctx.globalCompositeOperation = 'lighter';
        const g = ctx.createRadialGradient(x, fy - 30, 6, x, fy - 30, 190 + Math.sin(t * 9) * 12);
        g.addColorStop(0, 'rgba(255,160,60,.42)'); g.addColorStop(1, 'rgba(255,110,30,0)');
        ctx.fillStyle = g; ctx.fillRect(x - 220, fy - 250, 440, 270); ctx.restore();
        if (Math.random() < .25 && G.qual > 0) G.parts.push({ x: x + U_rnd(-12, 12), y: fy - 30, vx: U_rnd(-20, 20), vy: -U_rnd(60, 120), g: -20, t: 0, life: 1, col: '#ffb060', size: 2 });
      } else {
        ctx.fillStyle = 'rgba(255,120,50,.5)'; ctx.fillRect(x - 12, fy - 10, 24, 3);
      }
    } else if (p.kind === 'shop') {
      ctx.fillStyle = 'rgba(0,0,0,.4)'; ctx.beginPath(); ctx.ellipse(x, fy + 1, 90, 8, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = '#05080f'; ctx.fillRect(x - 78, fy - 52, 156, 52);
      ctx.fillStyle = '#4a3220'; ctx.fillRect(x - 74, fy - 48, 148, 44);
      ctx.fillStyle = '#6a4a2e'; ctx.fillRect(x - 78, fy - 56, 156, 8);
      for (let i = 0; i < 7; i++) { ctx.fillStyle = i % 2 ? '#e8dcb8' : '#b83a3a'; ctx.beginPath(); ctx.moveTo(x - 84 + i * 24, fy - 106); ctx.lineTo(x - 60 + i * 24, fy - 106); ctx.lineTo(x - 66 + i * 24, fy - 84); ctx.lineTo(x - 78 + i * 24, fy - 84); ctx.closePath(); ctx.fill(); }
      ctx.fillStyle = '#05080f'; ctx.fillRect(x - 80, fy - 108, 4, 54); ctx.fillRect(x + 76, fy - 108, 4, 54);
      const gc = ['#6fe0c0', '#e9bf5b', '#b78cff', '#e0494f'];
      for (let i = 0; i < 4; i++) { ctx.fillStyle = gc[i]; ctx.fillRect(x - 58 + i * 30, fy - 70 + Math.sin(t * 2 + i) * 2, 14, 14); }
      ctx.fillStyle = '#15101c'; ctx.beginPath(); ctx.ellipse(x, fy - 76, 16, 20, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = '#ffcf5a'; ctx.fillRect(x - 7, fy - 80, 4, 4); ctx.fillRect(x + 3, fy - 80, 4, 4);
      ctx.save(); ctx.globalCompositeOperation = 'lighter';
      const g = ctx.createRadialGradient(x, fy - 70, 6, x, fy - 70, 150);
      g.addColorStop(0, 'rgba(255,200,100,.28)'); g.addColorStop(1, 'rgba(255,160,60,0)');
      ctx.fillStyle = g; ctx.fillRect(x - 160, fy - 230, 320, 240); ctx.restore();
    } else {
      const on = !p.used;
      ctx.fillStyle = 'rgba(0,0,0,.4)'; ctx.beginPath(); ctx.ellipse(x, fy + 1, 50, 7, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = '#05080f'; ctx.fillRect(x - 34, fy - 24, 68, 24); ctx.fillRect(x - 24, fy - 52, 48, 30);
      ctx.fillStyle = '#4a5260'; ctx.fillRect(x - 31, fy - 21, 62, 21); ctx.fillRect(x - 21, fy - 49, 42, 27);
      ctx.fillStyle = '#6a7484'; ctx.fillRect(x - 31, fy - 21, 62, 4); ctx.fillRect(x - 21, fy - 49, 42, 4);
      if (on) {
        const oy = fy - 84 + Math.sin(t * 2.4) * 6;
        ctx.save(); ctx.globalCompositeOperation = 'lighter';
        const g = ctx.createRadialGradient(x, oy, 3, x, oy, 90);
        g.addColorStop(0, 'rgba(190,150,255,.7)'); g.addColorStop(1, 'rgba(150,100,255,0)');
        ctx.fillStyle = g; ctx.fillRect(x - 100, oy - 100, 200, 200);
        ctx.restore();
        ctx.fillStyle = '#e6d8ff'; ctx.beginPath(); ctx.arc(x, oy, 9, 0, TAU); ctx.fill();
        ctx.strokeStyle = 'rgba(200,170,255,.7)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(x, oy, 22, 8, t * 2, 0, TAU); ctx.stroke();
      }
    }
    /* 안내 */
    const P = G.P, near = Math.abs(P.x + P.w / 2 - x) < 52;
    if (!(p.used && p.kind !== 'shop')) {
      ctx.textAlign = 'center'; ctx.font = '700 15px ' + MD.FONT.D;
      ctx.fillStyle = 'rgba(255,240,200,.95)';
      ctx.fillText(p.kind === 'shop' ? '▼ 머물러서 물건 보기' : p.kind === 'rest' ? '▼ 머물러서 쉬기' : '▼ 머물러서 살펴보기', x, fy - 126 + Math.sin(t * 4) * 3);
      if (near && p.hold > 0) {
        ctx.strokeStyle = '#ffd24a'; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(x, fy - 150, 14, -Math.PI / 2, -Math.PI / 2 + TAU * Math.min(1, p.hold / .45)); ctx.stroke();
      }
    } else {
      ctx.textAlign = 'center'; ctx.font = '700 15px ' + MD.FONT.D; ctx.fillStyle = 'rgba(160,180,190,.8)';
      ctx.fillText('이미 사용했다', x, fy - 126);
    }
  }
  const U_rnd = (a, b) => a + Math.random() * (b - a);

  function drawNums() {
    ctx.textAlign = 'center';
    for (const n of G.nums) {
      const p = n.t / n.life;
      ctx.globalAlpha = 1 - p * p;
      ctx.font = '700 ' + n.size + 'px ' + MD.FONT.T;
      ctx.lineWidth = 4; ctx.strokeStyle = '#05080f';
      const y = n.y - p * 36;
      ctx.strokeText(n.text, n.x, y);
      ctx.fillStyle = n.col; ctx.fillText(n.text, n.x, y);
    }
    ctx.globalAlpha = 1;
  }

  function drawEmbers() {
    if (G.qual < 1) return;
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    for (let i = 0; i < G.embers.length; i += (G.qual < 2 ? 2 : 1)) {
      const m = G.embers[i];
      ctx.globalAlpha = .4 + Math.sin(G.clock * 3 + m.ph) * .3;
      ctx.fillStyle = '#ff9a3c';
      ctx.fillRect(m.x, m.y, m.s, m.s);
    }
    ctx.restore();
  }

  function drawMenuScene() {
    drawFloor();
    const t = G.clock;
    const fy = C.FLOOR;
    const cast = [
      { n: 'hahoe', x: 640, f: false, row: 0, fr: 0 },
      { n: 'soldier', x: 770, f: true, row: 0, fr: 0 },
      { n: 'brute', x: 870, f: true, row: 0, fr: 0 }
    ];
    cast.forEach((c, i) => {
      shadow(c.x, fy, 60);
      A.draw(ctx, c.n, c.row, c.fr, c.x, fy + Math.sin(t * 1.6 + i) * 1.2, c.f, 1);
    });
  }

  R.frame = () => {
    const s = G.state;
    const room = G.room;
    const tint = (s === 'menu' || s === 'boot') ? 'rgba(5,8,15,.08)' : (room === C.MAXROOM ? 'rgba(90,10,30,.10)' : 'rgba(5,8,15,' + Math.min(.14, (room - 1) * .018) + ')');
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalAlpha = 1;
    drawBg(tint);

    let sx = 0, sy = 0;
    if (G.shake > 0.3) { sx = (Math.random() * 2 - 1) * G.shake; sy = (Math.random() * 2 - 1) * G.shake; }
    ctx.setTransform(K, 0, 0, K, sx, sy);
    ctx.imageSmoothingEnabled = false;

    if (s === 'menu' || s === 'boot') {
      drawMenuScene();
      drawEmbers();
      ctx.setTransform(1, 0, 0, 1, 0, 0); drawFront(); ctx.setTransform(K, 0, 0, K, sx, sy);
    } else if (s === 'scene') {
      drawFloor(); drawEmbers(); drawFront(); MD.Scene.draw(ctx);
    } else if (G.P) {
      drawDecor(); drawFloor(); drawPlats(); drawDoor(); drawProps(); drawHazards();
      for (const z of G.ezones) {
        if (!z.done && z.type !== 'rock') {
          ctx.fillStyle = 'rgba(220,40,50,' + (.25 + Math.sin(G.clock * 22) * .12) + ')';
          ctx.fillRect(z.x, z.y, z.w, z.h);
        }
      }
      drawRocks(); drawCorpses(); drawPickups(); drawFront();
      for (const e of G.enemies) if (!e.dead) drawEnemy(e);
      drawPlayer();
      drawProjs(); drawFx(); drawEmbers(); drawNums(); drawPhaseCine();
    }

    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.drawImage(vig, 0, 0);
    if (G.redFlash > 0) {
      ctx.fillStyle = 'rgba(195,30,40,' + Math.min(.45, G.redFlash) + ')';
      ctx.fillRect(0, 0, C.CW, C.CH);
    }
    if (G.whiteFlash > 0) {
      ctx.fillStyle = 'rgba(255,240,230,' + Math.min(.8, G.whiteFlash) + ')';
      ctx.fillRect(0, 0, C.CW, C.CH);
    }
    const cn = G.cine;
    if (cn) {
      let k = Math.min(1, cn.t / .5);
      if (cn.type === 'intro' || cn.type === 'phase') k = Math.min(k, Math.max(0, (cn.dur - cn.t) / .5));
      const h = 86 * (k * k * (3 - 2 * k));
      ctx.fillStyle = '#02040a';
      ctx.fillRect(0, 0, C.CW, h); ctx.fillRect(0, C.CH - h, C.CW, h);
    }
    if (G.fade > 0) {
      ctx.fillStyle = 'rgba(2,4,10,' + Math.min(1, G.fade) + ')';
      ctx.fillRect(0, 0, C.CW, C.CH);
    }
  };
})();
