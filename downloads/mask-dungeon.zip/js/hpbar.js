/* hpbar.js — 체력바: 빈 막대 위에 채워진 막대를 체력 비율만큼 잘라 겹쳐 그림 */
(() => {
  const MD = window.MD, A = MD.Assets;
  const B = MD.HpBar = {};

  /* style: 0 하트 / 1 가시 하트 / 2 물약 / 3 영혼. frac: 0~1. crack: 체력이 위험할 때 금 간 심장 */
  B.draw = (canvas, style, frac, crack) => {
    const m = MD.HP_META, r = m && m.rows[style];
    if (!A.hp || !r) return false;
    if (canvas.width !== r.w || canvas.height !== r.h) { canvas.width = r.w; canvas.height = r.h; }
    const x = canvas.getContext('2d'), sy = style * m.ch;
    x.clearRect(0, 0, r.w, r.h);
    x.drawImage(A.hp, 0, sy, r.w, r.h, 0, 0, r.w, r.h);
    if (frac > 0) {
      x.save();
      x.beginPath(); x.rect(r.fx0, 0, (r.fx1 - r.fx0) * Math.min(1, frac), r.h); x.clip();
      x.drawImage(A.hp, m.cw, sy, r.w, r.h, 0, 0, r.w, r.h);
      x.restore();
    }
    if (crack) {
      x.clearRect(0, 0, r.fx0, r.h);
      x.drawImage(A.hp, m.cw * 2, sy, r.fx0, r.h, 0, 0, r.fx0, r.h);
    }
    return true;
  };
})();
