/* player.js — 플레이어 이동, 공격, 스킬, 대시, 가면 교체 */
(() => {
  const MD = window.MD, G = MD.G, U = MD.U, C = MD.C, Cb = MD.Combat, I = MD.Input, A = MD.Audio;
  const Pl = MD.Player = {};
  const cx = (b) => b.x + b.w / 2;
  const cy = (b) => b.y + b.h / 2;
  const SKILL_DUR = { hahoe: .5, dokkaebi: .75, fox: .4, dosa: .5, lion: .8, maltugi: .5, gaksi: .7, reaper: .45 };

  Pl.create = () => ({
    x: 80, y: C.FLOOR - C.PH, w: C.PW, h: C.PH, vx: 0, vy: 0, face: 1,
    hp: 100, maxHp: 100, onGround: true, onPlat: null,
    masks: ['hahoe', null], cur: 0, air: 1,
    dashCharges: 2, dashTimer: 0, dashT: 0, ghostT: 0,
    inv: 0, hurtT: 0, atkCd: 0, atk: null, combo: 0, comboT: 0,
    skill: null, skcd: {}, swapCd: 0, dropT: 0, anim: 0, dead: false, deathT: 0,
    items: [], gold: 0, mlv: { hahoe: 1 },
    st: { dmg: 1, dmgB: 1, altar: 1, spd: 1, dashRech: 1, steal: 0, crit: .05, swapCd: 1, skCd: 1, heal: 0, shield: 0 }
  });

  /* 영구 강화(영혼의 제단)를 새 런에 적용 */
  Pl.applyMeta = (P) => {
    const M = MD.Meta;
    P.maxHp += 8 * M.lv('hp'); P.hp = P.maxHp;
    P.st.dmgB *= 1 + .04 * M.lv('atk');
    P.gold += 15 * M.lv('soul');
    P.st.heal += .03 * M.lv('heal');
    P.st.dashRech *= 1 - .06 * M.lv('dash');
  };

  Pl.level = (P, id) => (P.mlv && P.mlv[id]) || 1;
  Pl.levelUp = (id) => {
    const P = G.P;
    P.mlv[id] = Math.min(5, Pl.level(P, id) + 1);
    Cb.fx({ type: 'ring', x: cx(P), y: cy(P), r0: 10, r1: 90, life: .5, col: '#ffd24a' });
    Cb.burst(cx(P), cy(P), 18, '#ffd24a', 260, .7, 3);
    Cb.num(cx(P), P.y - 16, 'Lv.' + P.mlv[id], '#ffd24a', 24);
  };

  Pl.mask = (P) => { P = P || G.P; return MD.MASKS[P.masks[P.cur]]; };

  Pl.giveMask = (id) => {
    const P = G.P;
    if (P.masks.indexOf(id) >= 0) { Pl.levelUp(id); return; }
    if (!P.masks[1]) P.masks[1] = id; else P.masks[P.cur] = id;
    P.atk = null; P.skill = null; if (!P.mlv[id]) P.mlv[id] = 1;
    MD.Meta.unlock(id);
  };

  Pl.die = () => {
    const P = G.P;
    P.dead = true; P.deathT = 0; P.atk = null; P.skill = null;
    G.state = 'dying'; G.deathT = 0;
    A.sfx.boom();
  };

  function shoot(x, y, vx, vy, dmg, o) {
    G.projs.push(Object.assign({ x: x - 13, y: y - 7, w: 26, h: 14, vx, vy, dmg, life: .9, hit: [], kb: 100 }, o));
  }

  function startDash(dir) {
    const P = G.P;
    P.vis = null;
    P.dashCharges--;
    P.dashT = .17; P.ghostT = 0;
    if (dir) P.face = dir;
    P.vx = P.face * 760; P.vy = 0;
    P.atk = null; P.skill = null;
    A.sfx.dash();
  }

  function swapMask() {
    const P = G.P;
    P.cur = 1 - P.cur;
    P.swapCd = 6 * P.st.swapCd;
    P.inv = Math.max(P.inv, .4);
    P.atk = null; P.skill = null; P.vis = null; P.combo = 0;
    const M = Pl.mask(P);
    A.sfx.swap();
    { const w = MD.LORE.whisper[P.masks[P.cur]]; if (w) MD.UI.say(M.name, w[(Math.random() * w.length) | 0], { hold: 700, cps: 34 }); }
    Cb.fx({ type: 'ring', x: cx(P), y: cy(P), r0: 10, r1: 110, life: .35, col: M.col });
    Cb.burst(cx(P), cy(P), 14, M.col, 240, .5, 3);
    for (const e of G.enemies) {
      if (e.dead || e.spawnT > 0) continue;
      const dx = cx(e) - cx(P), dy = cy(e) - cy(P);
      if (dx * dx + dy * dy < 120 * 120) Cb.hurtEnemy(e, M.dmg * 1.5 * P.st.dmg, U.sgn(dx), 240);
    }
  }

  function startAttack() {
    const P = G.P, M = Pl.mask(P);
    P.combo = (P.comboT > 0 ? P.combo : 0) % 3 + 1;
    P.atk = { t: 0, dur: M.rate, n: P.combo, hit: false };
    P.vis = { t: 0, dur: Math.max(M.rate * 1.5, .5), hitT: M.rate * .4 };
  }

  function doAttack(a) {
    const P = G.P, M = Pl.mask(P);
    const big = a.n === 3;
    if (M.melee) {
      const reach = M.reach * (big ? 1.2 : 1);
      const r = { x: P.face > 0 ? P.x + P.w - 6 : P.x - reach + 6, y: P.y - 8, w: reach, h: P.h + 16 };
      const dmg = M.dmg * P.st.dmg * (big ? 1.5 : 1);
      let any = false;
      for (const e of G.enemies) {
        if (!e.dead && e.spawnT <= 0 && U.overlap(r, e)) {
          Cb.hurtEnemy(e, dmg, P.face, M.kb * (big ? 1.6 : 1), { pop: big ? 260 : 100, fin: big });
          any = true;
        }
      }
      if (M.id === 'gaksi' && MD.FX_META.map.gak_fan) {
        Cb.fx({ type: 'sprite', key: 'gak_fan', x: cx(P) + P.face * (P.w / 2 + reach * .5), y: P.y + P.h * .5, scale: big ? .95 : .78, flip: P.face < 0, life: .28 });
      } else if (M.id === 'reaper' && MD.FX_META.map.rea_slash) {
        Cb.fx({ type: 'sprite', key: 'rea_slash', x: cx(P) + P.face * (P.w / 2 + reach * .42), y: P.y + P.h * .45, scale: big ? 1.15 : .95, flip: P.face < 0, life: .26, add: true });
      } else Cb.fx({
        type: 'slash', x: cx(P) + P.face * (P.w / 2 + reach * .38), y: P.y + P.h * .45,
        dir: P.face, r: reach * .75, life: .2, col: M.col, big
      });
      P.vx += P.face * (M.id === 'dokkaebi' ? 60 : 120);
      A.sfx.swing(a.n);
      if (any) { Cb.shake(big ? 7 : 2); if (big) { Cb.stop(.05); MD.Haptic(14); } }
    } else {
      const n = big ? 3 : 1;
      for (let i = 0; i < n; i++) {
        const ang = (i - (n - 1) / 2) * .16;
        shoot(cx(P) + P.face * 22, P.y + 22, P.face * Math.cos(ang) * 640, Math.sin(ang) * 640,
          M.dmg * P.st.dmg * (big ? .9 : 1), { type: M.id === 'maltugi' ? 'peg' : 'tal', kb: M.kb });
      }
      A.sfx.shoot();
    }
  }

  function updateAttack(dt) {
    const a = G.P.atk;
    a.t += dt;
    if (!a.hit && a.t >= a.dur * .4) { a.hit = true; doAttack(a); }
    if (a.t >= a.dur) {
      G.P.atk = null; G.P.comboT = .45;
      G.P.atkCd = a.n === 3 ? .16 : 0;
    }
  }

  function trySkill() {
    const P = G.P, M = Pl.mask(P);
    if ((P.skcd[M.id] || 0) > 0) return false;
    P.skcd[M.id] = M.skill.cd * P.st.skCd;
    P.skill = { id: M.id, t: 0, dur: SKILL_DUR[M.id], step: 0 };
    P.vis = { t: 0, dur: Math.max(SKILL_DUR[M.id] * 1.2, .65) };
    if (M.id !== 'dokkaebi') A.sfx.skill(M.id);
    return true;
  }

  function updateSkill(dt) {
    const P = G.P, M = Pl.mask(P), s = P.skill, D = M.dmg * P.st.dmg;
    s.t += dt;
    if (s.id === 'hahoe') {
      const marks = [.08, .26];
      if (s.step < 2 && s.t >= marks[s.step]) {
        s.step++;
        Cb.fx({ type: 'ring', x: cx(P), y: cy(P), r0: 20, r1: 110, life: .25, col: M.col });
        Cb.fx({ type: 'slash', x: cx(P), y: cy(P), dir: s.step % 2 ? 1 : -1, r: 95, life: .22, col: M.col, big: true, spin: true });
        for (const e of G.enemies) {
          if (e.dead || e.spawnT > 0) continue;
          const dx = cx(e) - cx(P), dy = cy(e) - cy(P);
          if (dx * dx + dy * dy < (105 + e.w / 2) * (105 + e.w / 2)) Cb.hurtEnemy(e, D * 1.5, U.sgn(dx), 260, { pop: 200 });
        }
        Cb.shake(3); A.sfx.swing(2);
      }
    } else if (s.id === 'dokkaebi') {
      if (s.step === 0 && s.t >= .4) {
        s.step = 1;
        const r = { x: cx(P) - 170, y: C.FLOOR - 110, w: 340, h: 130 };
        Cb.fx({ type: 'sprite', key: 'slam', x: cx(P), y: C.FLOOR + 2, anchor: 'b', scale: 2.4, life: .55 });
        Cb.burst(cx(P), C.FLOOR - 6, 22, '#c9b08a', 320, .6, 4);
        for (const e of G.enemies) {
          if (!e.dead && e.spawnT <= 0 && U.overlap(r, e)) Cb.hurtEnemy(e, D * 3.2, U.sgn(cx(e) - cx(P)), 360, { pop: 380, stun: .9 });
        }
        Cb.shake(11); Cb.stop(.08); A.sfx.skill('dokkaebi'); MD.Haptic(40);
      }
    } else if (s.id === 'fox') {
      if (s.step === 0 && s.t >= .15) {
        s.step = 1;
        [-.2, 0, .2].forEach((ang) => {
          shoot(cx(P) + P.face * 20, P.y + 22, P.face * Math.cos(ang) * 560, Math.sin(ang) * 560, M.dmg * 2.2 * P.st.dmg,
            { w: 30, h: 30, y: P.y + 8, x: cx(P) + P.face * 20 - 15, life: 1.1, pierce: true, type: 'fire', kb: 120 });
        });
        A.sfx.shoot();
      }
    } else if (s.id === 'dosa') {
      if (s.step === 0 && s.t >= .2) {
        s.step = 1;
        let tx = cx(P) + P.face * 220, best = 1e9;
        for (const e of G.enemies) {
          const d = Math.abs(cx(e) - cx(P));
          if (!e.dead && d < best) { best = d; tx = cx(e); }
        }
        tx = U.clamp(tx, 150, C.W - 150);
        G.zones.push({ x: tx - 150, y: C.FLOOR - 240, w: 300, h: 260, cx: tx, t: 0, life: 2.6, every: .28, tick: .05, dmg: D * 1.0, type: 'rain' });
      }
    } else if (s.id === 'lion') {
      /* 0~.5초 방패 자세(무적, 막은 만큼 반격 강화) → 충격파 */
      if (!s.fxo && MD.FX_META.map.lion_shield) { Cb.fx({ type: 'sprite', key: 'lion_shield', x: cx(P) + P.face * 30, y: cy(P) + 4, scale: .8, flip: P.face < 0, life: .5 }); s.fxo = G.fxs[G.fxs.length - 1]; }
      if (s.fxo) { s.fxo.x = cx(P) + P.face * 30; s.fxo.y = cy(P) + 4; }
      if (s.step === 0 && s.t < .5 && Math.random() < dt * 14) Cb.burst(cx(P) + P.face * 24, cy(P), 1, M.col, 90, .3, 2);
      if (s.step === 0 && s.t >= .5) {
        s.step = 1;
        const boost = 1 + Math.min(3, s.blocked | 0) * .35;
        const r = { x: P.face > 0 ? P.x + P.w - 10 : P.x - 170, y: C.FLOOR - 110, w: 180, h: 130 };
        Cb.fx({ type: 'ring', x: cx(P) + P.face * 60, y: cy(P) + 8, r0: 12, r1: 120, life: .35, col: M.col });
        Cb.fx({ type: 'sprite', key: MD.FX_META.map.lion_shock ? 'lion_shock' : 'dust', x: cx(P) + P.face * 80, y: C.FLOOR + 4, anchor: 'b', scale: 1.5, flip: P.face < 0, life: .5 });
        Cb.burst(cx(P) + P.face * 60, C.FLOOR - 10, 16, '#e0a43a', 300, .5, 3);
        for (const e of G.enemies) {
          if (!e.dead && e.spawnT <= 0 && U.overlap(r, e)) Cb.hurtEnemy(e, D * 2.2 * boost, P.face, 420 * boost, { pop: 300, stun: .8 });
        }
        Cb.shake(9); Cb.stop(.07); A.sfx.skill('dokkaebi'); MD.Haptic(30);
      }
    } else if (s.id === 'maltugi') {
      if (s.step === 0 && s.t >= .18) {
        s.step = 1;
        let tx = cx(P) + P.face * 210, best = 1e9;
        for (const e of G.enemies) {
          const d = Math.abs(cx(e) - cx(P));
          if (!e.dead && d < best && d < 420) { best = d; tx = cx(e); }
        }
        s.tx = U.clamp(tx, 80, C.W - 80);
        Cb.fx({ type: 'sprite', key: MD.FX_META.map.mal_mark ? 'mal_mark' : 'spark', x: s.tx, y: C.FLOOR + 4, anchor: 'b', scale: 1.0, life: .3 });
        A.sfx.shoot();
      }
      if (s.step === 1 && s.t >= .42) {
        s.step = 2;
        const r = { x: s.tx - 80, y: C.FLOOR - 120, w: 160, h: 140 };
        Cb.fx({ type: 'sprite', key: MD.FX_META.map.mal_boom ? 'mal_boom' : 'slam', x: s.tx, y: C.FLOOR + 6, anchor: 'b', scale: 1.7, life: .5 });
        Cb.burst(s.tx, C.FLOOR - 20, 22, '#ffb24a', 320, .6, 3);
        for (const e of G.enemies) {
          if (!e.dead && e.spawnT <= 0 && U.overlap(r, e)) Cb.hurtEnemy(e, D * 3, U.sgn(cx(e) - s.tx), 300, { pop: 330, stun: .7 });
        }
        Cb.shake(7); A.sfx.skill('dokkaebi');
      }
    } else if (s.id === 'gaksi') {
      if (s.step === 0 && s.t >= .2) {
        s.step = 1;
        const heal = Math.round(P.maxHp * (.16 + .02 * (Pl.level(P, 'gaksi') - 1)));
        P.hp = Math.min(P.maxHp, P.hp + heal);
        Cb.num(cx(P), P.y - 14, '+' + heal, '#7dffb0', 22);
        if (MD.FX_META.map.gak_heal) {
          Cb.fx({ type: 'sprite', key: 'gak_heal', x: cx(P), y: C.FLOOR + 6, anchor: 'b', scale: 1.6, life: .7 });
          Cb.fx({ type: 'sprite', key: 'gak_petal', x: cx(P), y: cy(P), scale: 1.9, life: .7 });
        } else Cb.fx({ type: 'ring', x: cx(P), y: cy(P), r0: 14, r1: 130, life: .5, col: '#ff9fb8' });
        Cb.fx({ type: 'icon', key: 'heal_orb', x: cx(P), y: P.y - 26, rise: 40, life: .8, size: 26 });
        Cb.burst(cx(P), cy(P), 26, '#ffc4d2', 260, .9, 3);
        for (const e of G.enemies) {
          const dx = cx(e) - cx(P), dy = cy(e) - cy(P);
          if (!e.dead && e.spawnT <= 0 && dx * dx + dy * dy < 130 * 130) Cb.hurtEnemy(e, D * 1.3, U.sgn(dx), 200, { pop: 200 });
        }
        A.sfx.heal();
      }
    } else if (s.id === 'reaper') {
      if (s.step === 0) {
        s.step = 1; s.hit = [];
        P.vx = P.face * 900; P.vy = 0; P.inv = Math.max(P.inv, s.dur);
        Cb.fx({ type: 'ring', x: cx(P), y: cy(P), r0: 10, r1: 90, life: .3, col: M.col });
        A.sfx.dash();
      }
      P.vy = 0; P.vx = P.face * 900 * Math.max(.25, 1 - s.t / s.dur);
      Cb.burst(cx(P), cy(P), 2, M.col, 80, .4, 3);
      s.trail = (s.trail || 0) - dt;
      if (s.trail <= 0 && MD.FX_META.map.rea_dash) { s.trail = .07; Cb.fx({ type: 'sprite', key: 'rea_dash', x: cx(P) - P.face * 26, y: cy(P) + 4, scale: .85, flip: P.face < 0, life: .3, add: true }); }
      for (const e of G.enemies) {
        if (e.dead || e.spawnT > 0 || s.hit.indexOf(e) >= 0 || !U.overlap(P, { x: e.x - 18, y: e.y - 10, w: e.w + 36, h: e.h + 20 })) continue;
        s.hit.push(e);
        const low = !e.boss && e.hp <= e.maxHp * .28;
        Cb.hurtEnemy(e, low ? e.hp + 999 : D * 2.6, P.face, 260, { pop: 240, noCrit: true });
        if (MD.FX_META.map.rea_cross) {
          Cb.fx({ type: 'sprite', key: 'rea_cross', x: cx(e), y: cy(e), scale: 1.1, life: .32, add: true });
          if (low) Cb.fx({ type: 'sprite', key: 'rea_soul', x: cx(e), y: cy(e) - 12, scale: 1.2, life: .6, add: true });
        } else Cb.fx({ type: 'slash', x: cx(e), y: cy(e), dir: P.face, r: 80, life: .22, col: M.col, big: true });
        Cb.shake(5);
      }
    }
    if (s.t >= s.dur) P.skill = null;
  }

  Pl.update = (dt) => {
    const P = G.P, M = Pl.mask(P);
    P.anim += dt;
    P.st.dmg = P.st.dmgB * (1 + .18 * (Pl.level(P, M.id) - 1)) * P.st.altar;
    if (P.dead) {
      P.deathT += dt;
      P.vx -= P.vx * Math.min(1, dt * 6);
      P.vy += C.GRAV * dt;
      U.moveBody(P, dt);
      return;
    }
    if (P.inv > 0) P.inv -= dt;
    if (P.hurtT > 0) P.hurtT -= dt;
    if (P.hurtV > 0) P.hurtV -= dt;
    if (P.vis) { P.vis.t += dt; if (P.vis.t >= P.vis.dur) P.vis = null; }
    if (P.atkCd > 0) P.atkCd -= dt;
    if (P.swapCd > 0) P.swapCd -= dt;
    if (P.dropT > 0) P.dropT -= dt;
    if (P.comboT > 0) { P.comboT -= dt; if (P.comboT <= 0) P.combo = 0; }
    for (const k in P.skcd) if (P.skcd[k] > 0) P.skcd[k] -= dt;
    if (P.dashCharges < 2) {
      P.dashTimer += dt;
      if (P.dashTimer >= 2.2 * P.st.dashRech) { P.dashCharges++; P.dashTimer = 0; }
    }

    const dir = (I.isHeld('right') ? 1 : 0) - (I.isHeld('left') ? 1 : 0);

    if (P.dashT > 0) {
      P.dashT -= dt; P.vy = 0;
      P.ghostT -= dt;
      if (P.ghostT <= 0) {
        P.ghostT = .035;
        Cb.fx({ type: 'ghost', name: M.id, x: cx(P), feet: P.y + P.h, face: P.face, life: .3, col: M.col, frame: ((P.anim / .24) % 4 + 4) % 4 });
      }
      U.moveBody(P, dt, true);
      if (P.dashT <= 0) P.vx *= .3;
      return;
    }

    if (P.hurtT > 0) {
      P.vx -= P.vx * Math.min(1, dt * 6);
      P.vy += C.GRAV * dt;
      U.moveBody(P, dt);
      return;
    }

    if (I.isPressed('dash') && P.dashCharges > 0) { startDash(dir); return; }
    if (I.isPressed('swap') && P.masks[1] && P.swapCd <= 0) swapMask();

    const busy = P.atk || P.skill;
    const spd = 250 * P.st.spd * M.speed * (busy ? .4 : 1);
    if (dir && !busy) P.face = dir;
    P.vx += (dir * spd - P.vx) * Math.min(1, dt * (P.onGround ? 16 : 9));

    if (I.isPressed('down') && P.onPlat && !busy) { P.dropT = .22; P.y += 3; P.onGround = false; }
    if (I.isPressed('jump')) {
      if (I.isHeld('down') && P.onPlat) { P.dropT = .22; P.y += 3; P.onGround = false; }
      else if (P.onGround) { P.vy = -800; P.onGround = false; A.sfx.jump(); Cb.burst(cx(P), P.y + P.h, 5, '#8fa6ad', 90, .3, 2); }
      else if (P.air > 0) {
        P.air--; P.vy = -740; A.sfx.jump();
        Cb.fx({ type: 'ring', x: cx(P), y: P.y + P.h, r0: 6, r1: 36, life: .25, col: '#cfe8ee', flat: true });
      }
    }
    if (!I.isHeld('jump') && P.vy < -300) P.vy += C.GRAV * .8 * dt;
    P.vy += C.GRAV * dt;
    const wasAir = !P.onGround, pvy = P.vy;
    U.moveBody(P, dt, P.dropT > 0);
    if (P.onGround && wasAir && pvy > 520) { A.sfx.land(); Cb.burst(cx(P), P.y + P.h, 5, '#8fa6ad', 80, .3, 2); }
    if (P.onGround) P.air = M.airJumps;

    if (P.atk) updateAttack(dt);
    else if (P.skill) updateSkill(dt);
    else if (I.isPressed('skill') && trySkill()) { /* 스킬 시작 */ }
    else if (I.isHeld('atk') && P.atkCd <= 0) startAttack();
  };

  /* 공격 모션 진행도: 타격 시점에 타격 프레임(40%)이 오도록 보정 */
  function visP(v) {
    if (!v.hitT) return v.t / v.dur;
    if (v.t < v.hitT) return .4 * v.t / v.hitT;
    return .4 + .6 * Math.min(1, (v.t - v.hitT) / Math.max(.01, v.dur - v.hitT));
  }

  /* 현재 상태에 맞는 스프라이트 행/프레임 */
  Pl.anim = (P) => {
    const M = Pl.mask(P);
    if (P.dead) return { row: 3, frame: Math.min(3.99, P.deathT / .32) };
    if (P.hurtV > 0) return { row: 2, frame: Math.min(3.99, Math.max(0, (1 - Math.max(0, P.hurtV || 0) / .55) * 4)) };
    if (P.vis && (P.atk || P.skill || Math.abs(P.vx) < 60 || P.vis.t < P.vis.dur * .55)) return { row: 1, frame: Math.min(3.99, visP(P.vis) * 4) };
    if (P.skill) return { row: 1, frame: Math.min(3.99, P.skill.t / P.skill.dur * 4) };
    if (P.atk) return { row: 1, frame: Math.min(3.99, P.atk.t / Math.max(P.atk.dur, .22) * 4) };
    if (!P.onGround) return { row: 0, frame: P.vy < 0 ? 1.3 : 2.3 };
    if (Math.abs(P.vx) > 30) return { row: 0, frame: ((P.anim / (.24 / M.speed)) % 4 + 4) % 4 };
    return { row: 0, frame: 0 };
  };
})();
