/* game.js — 메인 루프, 상태 전환, 초기화 */
(() => {
  const MD = window.MD, G = MD.G, U = MD.U, C = MD.C, S = MD.Settings, A = MD.Audio, I = MD.Input;
  const Game = MD.Game = {};
  let last = 0, started = false;

  function fit() {
    const vv = window.visualViewport;
    const w = vv ? vv.width : window.innerWidth, h = vv ? vv.height : window.innerHeight;
    const sc = Math.min(w / C.CW, h / C.CH);
    document.getElementById('stage').style.transform = 'scale(' + sc + ')';
    /* 작은 화면(휴대폰)에서는 HUD를 키우고 터치 버튼은 줄여 화면을 덜 가리게 함 */
    const r = document.documentElement.style;
    r.setProperty('--hs', Math.max(1, Math.min(1.7, .64 / sc)).toFixed(3));
    const tbm = ({ s: .8, m: 1, l: 1.2 })[S.data.tbs] || 1;
    r.setProperty('--k', (Math.max(.52, Math.min(1, sc * 1.25)) * tbm).toFixed(3));
    document.body.classList.toggle('stick', S.data.ctl === 'stick');
    document.body.classList.toggle('touch', !!MD.UI.touch);
  }

  function resetWorld() {
    G.enemies = []; G.projs = []; G.eprojs = []; G.zones = []; G.ezones = [];
    G.fxs = []; G.parts = []; G.nums = []; G.corpses = []; G.plats = []; G.door = null;
    G.shake = 0; G.hitstop = 0; G.redFlash = 0; G.fade = 0; G.slow = 0; G.victoryT = 0;
    G.kills = 0; G.runT = 0; G.cleared = false;
    G.pickups = []; G.hazards = []; G.cine = null; G.props = null; G.runGold = 0; G.whiteFlash = 0; G.doorOpenT = 0; G.tut = null; G.zoneSeen = {};
    MD.UI.tutShow(-1); MD.UI.sayClear();
  }

  Game.startRun = (resume) => {
    resetWorld();
    const sv = resume ? MD.Meta.loadRun() : null;
    G.P = MD.Player.create();
    if (sv && sv.P) {
      Object.assign(G.P, sv.P);
      G.P.dashCharges = 2;
      G.path = sv.path; G.kills = sv.kills | 0; G.runT = sv.runT || 0; G.runGold = sv.runGold | 0;
    } else {
      MD.Player.applyMeta(G.P);
      G.path = MD.Rooms.genPath();
      MD.Meta.runs++; MD.Meta.save();
    }
    G.state = 'play'; G.paused = false;
    MD.UI.show(null);
    MD.UI.hudVisible(true);
    MD.Rooms.start(sv && sv.room ? sv.room : 1, { noSave: !!sv });
    I.clear();
    if (!sv && !MD.Meta.tut) MD.Rooms.tutStart();
  };

  Game.toMenu = () => {
    G.state = 'menu'; G.paused = false; G.P = null;
    resetWorld();
    A.music('menu');
    MD.UI.hudVisible(false);
    MD.UI.updateBest();
    MD.UI.show('menu');
  };

  Game.pause = () => {
    if (G.state !== 'play' || G.paused) return;
    G.paused = true; I.clear();
    MD.UI.show('pause');
  };
  Game.resume = () => {
    if (!G.paused) return;
    G.paused = false; I.clear();
    MD.UI.show(null);
  };

  Game.end = (win, kind) => {
    const M = MD.Meta;
    const reached = win ? C.MAXROOM + 1 : G.room;
    if (reached > M.best) M.best = reached;
    if (win) M.wins++;
    const shards = Math.round((reached - 1) * 5 + G.kills * .6 + G.runGold * .15 + (win ? 60 : 0));
    M.shards += shards;
    M.save(); M.clearRun();
    const secs = Math.floor(G.runT);
    const time = Math.floor(secs / 60) + ':' + ('0' + (secs % 60)).slice(-2);
    G.state = 'end';
    A.musicStop(.5); A.jingle(win ? 'victory' : 'defeat');
    MD.UI.showEnd(win, { room: G.room, kills: G.kills, time, shards }, kind);
  };

  /* 키 입력 가로채기: 화면이 열려 있으면 UI가, 플레이 중이면 일시정지/음소거 */
  MD.onKeyDown = (e) => {
    if (!started) { started = true; A.music('menu'); }
    if (MD.UI.cur && MD.UI.key(e)) return true;
    if (G.state === 'play' || G.state === 'shop') {
      if (G.state === 'shop') return false;
      if (e.code === 'Escape' || e.code === 'KeyP') { e.preventDefault(); if (G.paused) Game.resume(); else Game.pause(); return true; }
      if (e.code === 'KeyM' && !e.repeat) { S.set('mute', !S.data.mute); MD.UI.toast(S.data.mute ? '소리 끔' : '소리 켬', 1.2); return true; }
    }
    return false;
  };

  function updateFx(dt) {
    for (const f of G.fxs) f.t += dt;
    G.fxs = G.fxs.filter((f) => f.t < f.life);
    for (const q of G.parts) { q.t += dt; q.vy += q.g * dt; q.x += q.vx * dt; q.y += q.vy * dt; }
    G.parts = G.parts.filter((q) => q.t < q.life);
    for (const n of G.nums) n.t += dt;
    G.nums = G.nums.filter((n) => n.t < n.life);
    for (const c of G.corpses) {
      c.t += dt;
      c.vx -= c.vx * Math.min(1, dt * 5);
      c.x = U.clamp(c.x + c.vx * dt, 0, C.W - c.w);
      if (c.fly) { c.vy += C.GRAV * .5 * dt; c.y = Math.min(C.FLOOR - c.h, c.y + c.vy * dt); }
    }
    G.corpses = G.corpses.filter((c) => c.t < 2.7);
  }

  function step(dt) {
    if (G.cine) {
      I.clear();
      MD.Rooms.cineUpdate(dt);
      updateFx(dt);
      return;
    }
    G.runT += dt;
    MD.Player.update(dt);
    if (G.state === 'play') {
      MD.Enemies.update(dt);
      MD.Combat.update(dt);
      MD.Rooms.update(dt);
    } else if (G.state === 'dying') {
      G.deathT += dt;
      if (G.deathT > 1.8) Game.end(false);
    }
    updateFx(dt);
  }

  function ambient(raw) {
    for (const m of G.embers) {
      m.y -= m.vy * raw; m.x += Math.sin(G.clock + m.ph) * 10 * raw;
      if (m.y < -10) { m.y = C.H + 10; m.x = Math.random() * C.W; }
    }
  }

  /* 프레임 측정: 화질 자동 조절과 FPS 표시 */
  let fAcc = 0, fN = 0, fLow = 0;
  function fpsMon(raw) {
    fAcc += raw; fN++;
    if (fAcc < 1) return;
    const fps = fN / fAcc;
    fAcc = 0; fN = 0;
    if (S.data.showfps) { const el = document.getElementById('fps'); if (el) { el.style.display = 'block'; el.textContent = Math.round(fps) + ' FPS · ' + ['낮음', '보통', '높음'][G.qual]; } }
    if (S.data.quality === 'auto' && (G.state === 'play') && !G.paused) {
      fLow = fps < Math.min(40, (S.data.fpscap || 999) * .72) ? fLow + 1 : Math.max(0, fLow - 1);
      if (fLow >= 3 && G.qual > 0) { G.qual--; fLow = 0; MD.UI.toast('프레임이 낮아 화질을 낮췄습니다', 2.5); }
    }
  }
  Game.applyQuality = () => {
    const q = S.data.quality;
    G.qual = q === 'low' ? 0 : q === 'mid' ? 1 : 2;
    const el = document.getElementById('fps');
    if (el && !S.data.showfps) el.style.display = 'none';
  };

  let lastRun = 0;
  function loop(ts) {
    const cap = S.data.fpscap;
    if (cap > 0 && ts - lastRun < 1000 / cap - 2) { requestAnimationFrame(loop); return; }
    lastRun = ts;
    const raw = Math.min(.05, ((ts - last) / 1000) || 0);
    last = ts;
    G.clock += raw;
    I.pollPad();
    fpsMon(raw);
    ambient(raw);
    if (G.whiteFlash > 0) G.whiteFlash = Math.max(0, G.whiteFlash - raw * 1.6);
    if (G.fade > 0) G.fade = Math.max(0, G.fade - raw * 1.6);
    if (G.redFlash > 0) G.redFlash -= raw;
    if (G.shake > 0) G.shake = Math.max(0, G.shake - raw * 30);

    if ((G.state === 'play' || G.state === 'dying') && !G.paused) {
      if (G.hitstop > 0) G.hitstop -= raw;
      else {
        let dt = raw;
        if (G.slow > 0) { G.slow -= raw; dt *= .35; }
        step(dt);
      }
    }
    if (G.state === 'scene') MD.Scene.update(raw);
    MD.Render.frame();
    MD.UI.hud();
    I.clearJust();
    requestAnimationFrame(loop);
  }

  function setFull(on) {
    try {
      if (on) {
        const p = document.documentElement.requestFullscreen && document.documentElement.requestFullscreen();
        if (p && p.catch) p.catch(() => { S.data.full = false; });
      } else if (document.fullscreenElement) {
        document.exitFullscreen();
      }
    } catch (e) { S.data.full = false; }
  }

  Game.init = () => {
    S.load(); MD.Meta.load();
    I.loadMap();
    Game.applyQuality();
    S.onChange = (k) => {
      A.applyVolumes();
      if (k === 'full') setFull(S.data.full);
      if (k === 'quality' || k === 'showfps' || k === '*') Game.applyQuality();
      if (k === 'vsync' || k === '*') MD.Render.setSync(S.data.vsync !== false);
      if (k === 'tbs' || k === 'ctl' || k === '*') fit();
    };
    for (let i = 0; i < 46; i++) {
      G.embers.push({ x: Math.random() * C.W, y: Math.random() * C.H, vy: U.rnd(10, 40), ph: Math.random() * 6, s: Math.random() < .3 ? 3 : 2 });
    }
    MD.Render.init();
    MD.UI.init();
    I.bindTouch();
    UI_touchDetect();
    fit();
    addEventListener('resize', fit);
    addEventListener('orientationchange', () => setTimeout(fit, 120));
    if (window.visualViewport) window.visualViewport.addEventListener('resize', fit);
    document.addEventListener('fullscreenchange', () => { S.data.full = !!document.fullscreenElement; });
    addEventListener('pointerdown', () => { A.ensure(); if (!started) { started = true; if (G.state === 'menu') A.music('menu'); } });
    document.addEventListener('visibilitychange', () => { if (document.hidden && S.data.autopause) Game.pause(); });
    addEventListener('blur', () => { if (S.data.autopause) Game.pause(); });

    MD.Assets.load(() => {
      document.getElementById('loading').classList.add('hide');
      MD.UI.paintStatic();
      G.state = 'menu';
      MD.UI.updateBest();
      MD.UI.show('menu');
      if (started) A.music('menu');
    });
    requestAnimationFrame(loop);
  };

  function UI_touchDetect() {
    let coarse = false;
    try { coarse = window.matchMedia('(pointer: coarse)').matches; } catch (e) { /* 무시 */ }
    MD.UI.touch = coarse;
    addEventListener('touchstart', () => { MD.UI.touch = true; fit(); if (G.state === 'play') MD.UI.hudVisible(true); }, { once: true, passive: true });
  }

  Game.init();
})();
