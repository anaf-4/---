/* enemies.js — 적 생성과 AI (병정/궁수/불꽃/장승/보스) */
(() => {
  const MD = window.MD, G = MD.G, U = MD.U, C = MD.C, Cb = MD.Combat;
  const E = MD.Enemies = {};
  const cx = (b) => b.x + b.w / 2;
  const cy = (b) => b.y + b.h / 2;

  E.zone = (n) => { n = n || G.room; return n <= 2 ? 'castle' : n <= 4 ? 'crypt' : n <= 6 ? 'ember' : n === 7 ? 'hall' : 'throne'; };
  const TINT = { crypt: 'rgba(70,230,140,.34)', ember: 'rgba(255,70,40,.36)', hall: 'rgba(150,120,255,.32)' };
  const MODS = [
    { id: 'swift', name: '질주하는', col: '#6fe0c0' },
    { id: 'vamp', name: '흡혈하는', col: '#ff6a8a' },
    { id: 'volatile', name: '폭발하는', col: '#ff9a3c' },
    { id: 'frenzy', name: '광란의', col: '#ffd24a' }
  ];
  E.MODS = MODS;

  E.spawn = (type, x, y, o) => {
    o = o || {};
    const d = MD.ETYPES[type], df = MD.Settings.diff();
    const lvl = d.boss ? 0 : G.room - 1;
    const el = !!o.elite && !d.boss, sc = el ? 1.25 : 1;
    const w = Math.round(d.w * sc), h = Math.round(d.h * sc);
    const hp = Math.round(d.hp * (1 + lvl * .1) * df.hp * (el ? 3 : 1));
    const z = d.boss ? 'throne' : E.zone();
    const e = {
      type, name: d.name, x, y: y != null ? y - (el ? h - d.h : 0) : C.FLOOR - h, w, h, vx: 0, vy: 0, face: -1,
      hp, maxHp: hp, speed: d.speed * (1 + lvl * .02), dmg: d.dmg * (1 + lvl * .06) * (el ? 1.25 : 1),
      armor: !!d.armor, fly: !!d.fly, boss: !!d.boss, elite: el, scale: sc, cdm: 1,
      variant: d.boss ? null : (z === 'castle' ? null : z), tint: null, shield: false, mod: null,
      state: 'move', st: 0, atkT: 0, atkTotal: 0, cd: U.rnd(.5, 1.3),
      hurtT: 0, stun: 0, flash: 0, anim: Math.random() * 2, onGround: false, dead: false,
      spawnT: d.boss ? 1.4 : .35, hitP: false, tele: null, contactCd: 0, sq: 0, ph: 1
    };
    if (e.variant) {
      e.tint = TINT[e.variant];
      if (e.variant === 'crypt') e.speed *= 1.14;
      if (e.variant === 'ember') e.dmg *= 1.08;
      if (e.variant === 'hall' && type === 'soldier' && (el || Math.random() < .55)) e.shield = true;
    }
    if (el) {
      const m = MODS[(Math.random() * MODS.length) | 0];
      e.mod = m.id; e.modName = m.name; e.modCol = m.col;
      if (m.id === 'swift') e.speed *= 1.35;
      if (m.id === 'frenzy') e.cdm = .5;
      e.name = m.name + ' ' + d.name;
      if (type === 'soldier') e.shield = e.shield || Math.random() < .4;
    }
    G.enemies.push(e);
    Cb.fx({ type: 'ring', x: cx(e), y: e.y + e.h, r0: 8, r1: d.boss ? 120 : 50, life: .4, col: '#ff9a3c', flat: true });
    Cb.burst(cx(e), e.y + e.h * .6, d.boss ? 24 : 8, '#ff9a3c', 160, .5, 3);
    return e;
  };

  function front(e, w, h, y) {
    return { x: e.face > 0 ? e.x + e.w : e.x - w, y: y != null ? y : e.y, w, h };
  }

  const AI = {
    soldier(e, dt, dx, dist, P) {
      if (e.state === 'move') {
        e.face = U.sgn(dx);
        e.vx = dist > 44 ? e.face * e.speed : 0;
        if (dist < 70 && Math.abs(cy(P) - cy(e)) < 70 && e.cd <= 0 && !P.dead) {
          e.state = 'windup'; e.st = .4; e.atkT = 0; e.atkTotal = .58; e.vx = 0;
          e.tele = front(e, 56, e.h);
        }
      } else if (e.state === 'windup') {
        e.vx = 0; e.st -= dt; e.atkT += dt;
        if (e.st <= 0) {
          e.state = 'strike'; e.st = .18; e.tele = null; e.vx = e.face * 190;
          if (U.overlap(front(e, 58, e.h), P)) Cb.hurtPlayer(e.dmg, cx(e), e);
        }
      } else if (e.state === 'strike') {
        e.atkT += dt; e.st -= dt; e.vx -= e.vx * Math.min(1, dt * 8);
        if (e.st <= 0) { e.state = 'recover'; e.st = .45; e.cd = 1.1 * e.cdm; }
      } else {
        e.atkT = e.atkTotal; e.st -= dt; e.vx -= e.vx * Math.min(1, dt * 8);
        if (e.st <= 0) e.state = 'move';
      }
    },

    archer(e, dt, dx, dist, P) {
      if (e.state === 'move') {
        e.face = U.sgn(dx);
        if (dist < 230) e.vx = -e.face * e.speed * 1.3;
        else if (dist > 400) e.vx = e.face * e.speed;
        else e.vx = 0;
        if (e.cd <= 0 && dist < 560 && !P.dead) { e.state = 'windup'; e.st = .55; e.atkT = 0; e.atkTotal = .62; e.vx = 0; }
      } else if (e.state === 'windup') {
        e.vx = 0; e.st -= dt; e.atkT += dt; e.face = U.sgn(dx);
        if (e.st <= 0) {
          const sx = cx(e) + e.face * 24, sy = e.y + 22;
          const ang = Math.atan2(cy(P) - sy, cx(P) - sx);
          const spread = e.variant === 'crypt' || e.elite ? [-.13, .13] : [0];
          spread.forEach((da) => {
            const a2 = ang + da;
            G.eprojs.push({ x: sx - 13, y: sy - 4, w: 26, h: 8, vx: Math.cos(a2) * 430, vy: Math.sin(a2) * 430, dmg: e.dmg, life: 2.5, type: 'arrow', src: e });
          });
          MD.Audio.sfx.shoot();
          e.state = 'recover'; e.st = .35; e.cd = U.rnd(1.6, 2.4) * e.cdm;
        }
      } else {
        e.atkT = e.atkTotal; e.st -= dt; e.vx = 0;
        if (e.st <= 0) e.state = 'move';
      }
    },

    wisp(e, dt, dx, dist, P) {
      e.face = U.sgn(dx);
      if (e.state === 'move') {
        const ty = P.y - 70 + Math.sin(e.anim * 2.2) * 26;
        e.vy = U.clamp((ty - e.y) * 2.2, -140, 140);
        const want = dist > 200 ? e.face * 80 : -e.face * 40;
        e.vx += (want - e.vx) * Math.min(1, dt * 3);
        if (e.cd <= 0 && dist < 420 && !P.dead) { e.state = 'windup'; e.st = .6; e.atkT = 0; e.atkTotal = .6; }
      } else if (e.state === 'windup') {
        e.vx -= e.vx * Math.min(1, dt * 8); e.vy -= e.vy * Math.min(1, dt * 8);
        e.st -= dt; e.atkT += dt;
        if (e.st <= 0) {
          e.state = 'dash'; e.st = .6; e.hitP = false;
          const ang = Math.atan2(cy(P) - cy(e), cx(P) - cx(e));
          e.vx = Math.cos(ang) * 380; e.vy = Math.sin(ang) * 380;
        }
      } else if (e.state === 'dash') {
        e.atkT = e.atkTotal; e.st -= dt;
        if (!e.hitP && !P.dead && U.overlap(e, P)) { e.hitP = true; Cb.hurtPlayer(e.dmg, cx(e), e); }
        if (e.st <= 0) { e.state = 'recover'; e.st = .5; e.cd = U.rnd(2, 3) * e.cdm; }
      } else {
        e.atkT = e.atkTotal; e.vx -= e.vx * Math.min(1, dt * 5); e.vy -= e.vy * Math.min(1, dt * 5);
        e.st -= dt;
        if (e.st <= 0) e.state = 'move';
      }
    },

    brute(e, dt, dx, dist, P) {
      if (e.state === 'move') {
        e.face = U.sgn(dx);
        e.vx = dist > 70 ? e.face * e.speed : 0;
        if (dist < 100 && Math.abs(cy(P) - cy(e)) < 80 && e.cd <= 0 && !P.dead) {
          e.state = 'windup'; e.st = .75; e.atkT = 0; e.atkTotal = .95; e.vx = 0;
          e.tele = { x: e.face > 0 ? cx(e) - 10 : cx(e) + 10 - 140, y: C.FLOOR - 80, w: 140, h: 80 };
        }
      } else if (e.state === 'windup') {
        e.vx = 0; e.st -= dt; e.atkT += dt;
        if (e.st <= 0) {
          const z = e.tele;
          e.tele = null; e.state = 'strike'; e.st = .2;
          G.ezones.push({ x: z.x, y: z.y, w: z.w, h: z.h, delay: 0, t: 0, dmg: e.dmg, done: false, type: 'slam' });
          Cb.fx({ type: 'sprite', key: 'dust', x: z.x + z.w / 2, y: C.FLOOR + 2, anchor: 'b', scale: 1.1, life: .5 });
          Cb.burst(z.x + z.w / 2, C.FLOOR - 4, 12, '#a99677', 220, .5, 3);
          Cb.shake(5); MD.Audio.sfx.boom();
        }
      } else if (e.state === 'strike') {
        e.atkT += dt; e.st -= dt;
        if (e.st <= 0) { e.state = 'recover'; e.st = .8; e.cd = 1.4 * e.cdm; }
      } else {
        e.atkT = e.atkTotal; e.st -= dt; e.vx = 0;
        if (e.st <= 0) e.state = 'move';
      }
    },

    boss(e, dt, dx, dist, P) {
      const hpP = e.hp / e.maxHp;
      const ph = hpP < .25 ? 3 : hpP < .55 ? 2 : 1;
      const rate = ph === 3 ? .6 : ph === 2 ? .8 : 1;
      if (ph > e.ph && !G.cine) {
        e.ph = ph;
        MD.Rooms.cine('phase', 3.2, { boss: e, ph });
        e.state = 'move'; e.st = 0; e.tele = null; e.cd = 1.2; e.vx = 0;
        if (ph >= 2 && !e.summoned) {
          e.summoned = true;
          E.spawn('soldier', 50); E.spawn('soldier', C.W - 90);
        }
        return;
      }
      if (e.contactCd > 0) e.contactCd -= dt;
      if (e.contactCd <= 0 && !P.dead && U.overlap(e, P)) { e.contactCd = 1; Cb.hurtPlayer(e.dmg * .6, cx(e), e); }

      if (e.state === 'move') {
        e.face = U.sgn(dx);
        e.vx = dist > 140 ? e.face * e.speed * (ph === 3 ? 1.4 : 1) : 0;
        if (e.cd <= 0 && !P.dead) {
          const r = Math.random();
          let pick = dist < 180 && r < .6 ? 'swing' : r < .5 ? 'slam' : 'volley';
          if (pick === e.last && Math.random() < .6) pick = pick === 'swing' ? 'volley' : 'swing';
          e.atk = e.last = pick;
          e.state = 'windup';
          e.st = ({ swing: .6, slam: .6, volley: .75 })[pick] * rate + .1;
          e.atkT = 0; e.atkTotal = e.st; e.vx = 0;
          if (pick === 'swing') e.tele = front(e, 150, 120, e.y + 8);
        }
      } else if (e.state === 'windup') {
        e.vx = 0; e.st -= dt; e.atkT += dt;
        if (e.atkT < e.atkTotal * .5) e.face = U.sgn(dx);
        if (e.st <= 0) {
          e.tele = null;
          if (e.atk === 'swing') {
            e.state = 'act'; e.st = .25; e.vx = e.face * 260;
            if (U.overlap(front(e, 150, 120, e.y + 8), P)) Cb.hurtPlayer(e.dmg * 1.2, cx(e), e);
            MD.Audio.sfx.bossSwing(); Cb.shake(5);
          } else if (e.atk === 'slam') {
            e.state = 'air'; e.st = .2; e.vy = -880; e.onGround = false;
            e.vx = U.clamp(dx / .76, -420, 420);
          } else {
            e.state = 'act'; e.st = .3;
            const n = ph >= 2 ? 9 : 5, sx = cx(e) + e.face * 40, sy = e.y + 40;
            const aim = Math.atan2(cy(P) - sy, cx(P) - sx);
            for (let i = 0; i < n; i++) {
              const a = aim + (i - (n - 1) / 2) * .22;
              G.eprojs.push({ x: sx - 10, y: sy - 10, w: 20, h: 20, vx: Math.cos(a) * 290, vy: Math.sin(a) * 290, dmg: e.dmg * .8, life: 4, type: 'lance' });
            }
            MD.Audio.sfx.bossVolley(); Cb.shake(3);
          }
        }
      } else if (e.state === 'act') {
        e.atkT = e.atkTotal; e.st -= dt; e.vx -= e.vx * Math.min(1, dt * 7);
        if (e.st <= 0) { e.state = 'recover'; e.st = .7 * rate; e.rtot = e.st; }
      } else if (e.state === 'air') {
        e.atkT = e.atkTotal; e.st -= dt;
        if (e.st <= 0 && e.onGround) {
          for (const s of [-1, 1]) {
            G.eprojs.push({ x: cx(e) + s * 40 - 22, y: C.FLOOR - 56, w: 44, h: 56, vx: s * 330, vy: 0, dmg: e.dmg, life: 2.6, type: 'wave', pierce: true });
          }
          Cb.fx({ type: 'sprite', key: 'slam', x: cx(e), y: C.FLOOR + 2, anchor: 'b', scale: 2.6, life: .6 });
          Cb.shake(12); Cb.stop(.06); MD.Audio.sfx.bossSlam(); MD.Haptic(30);
          Cb.burst(cx(e), C.FLOOR - 4, 20, '#b09070', 300, .6, 4);
          e.vx = 0; e.state = 'recover'; e.st = .85 * rate; e.rtot = e.st;
        }
      } else {
        e.atkT = e.atkTotal; e.st -= dt; e.vx = 0;
        if (e.st <= 0) { e.state = 'move'; e.cd = U.rnd(.5, 1) * rate; }
      }
    }
  };

  function step(e, dt) {
    const P = G.P;
    e.anim += dt;
    if (e.flash > 0) e.flash -= dt;
    if (e.sq > 0) e.sq -= dt;
    if (e.hurtT > 0) e.hurtT -= dt;
    if (e.hurtV > 0) e.hurtV -= dt;
    if (e.cd > 0) e.cd -= dt;
    if (e.spawnT > 0) { e.spawnT -= dt; return; }
    if (e.stun > 0) {
      e.stun -= dt;
      e.vx -= e.vx * Math.min(1, dt * 5);
      if (e.fly) e.vy -= e.vy * Math.min(1, dt * 4); else e.vy += C.GRAV * dt;
      U.moveBody(e, dt, e.fly || e.boss);
      return;
    }
    const dx = cx(P) - cx(e), dist = Math.abs(dx);
    AI[e.type](e, dt, dx, dist, P);
    if (!e.fly) e.vy += C.GRAV * dt;
    U.moveBody(e, dt, e.fly || e.boss);
  }

  /* 연출 중에는 등장 애니메이션만 진행 */
  E.cineTick = (dt) => {
    for (const e of G.enemies) { e.anim += dt; if (e.spawnT > 0) e.spawnT -= dt; if (e.flash > 0) e.flash -= dt; }
  };

  E.update = (dt) => {
    for (const e of G.enemies) if (!e.dead) step(e, dt);
    /* 지상 적끼리 너무 겹치지 않도록 살짝 밀어냄 */
    const L = G.enemies;
    for (let i = 0; i < L.length; i++) {
      for (let j = i + 1; j < L.length; j++) {
        const a = L[i], b = L[j];
        if (a.dead || b.dead || a.fly || b.fly || a.boss || b.boss) continue;
        if (Math.abs(a.y - b.y) > 30) continue;
        const d = cx(a) - cx(b), min = (a.w + b.w) * .45;
        if (Math.abs(d) < min) {
          const push = (min - Math.abs(d)) * .5 * U.sgn(d || (Math.random() - .5));
          a.x = U.clamp(a.x + push, 0, C.W - a.w);
          b.x = U.clamp(b.x - push, 0, C.W - b.w);
        }
      }
    }
    G.enemies = G.enemies.filter((e) => !e.dead);
  };

  /* 보스 시트 행/프레임: 0 대기, 1 이동, 2 휘두르기 준비, 3 회전 베기, 4 시전/도약, 5 사망, 6 등장, 7 창 발사 */
  E.bossAnim = (e) => {
    if (e.spawnT > 0) return { row: 6, frame: Math.min(15, Math.floor((1 - e.spawnT / 1.4) * 16)) };
    const pr = e.atkTotal > 0 ? Math.min(.999, e.atkT / e.atkTotal) : 0;
    if (e.state === 'windup') {
      if (e.atk === 'swing') return { row: 2, frame: Math.floor(pr * 16) };
      if (e.atk === 'slam') return { row: 4, frame: 4 + Math.floor(pr * 4) };
      return { row: 7, frame: Math.floor(pr * 5) };
    }
    if (e.state === 'act') {
      const p = Math.max(0, Math.min(.999, 1 - e.st / (e.atk === 'swing' ? .25 : .3)));
      if (e.atk === 'swing') return { row: 3, frame: Math.floor(p * 10) };
      return { row: 7, frame: 5 + Math.floor(p * 5) };
    }
    if (e.state === 'air') return { row: 4, frame: 9 };
    if (e.state === 'recover') {
      const p = Math.max(0, Math.min(.999, 1 - e.st / (e.rtot || .7))), f = 10 + Math.floor(p * 6);
      return { row: e.atk === 'slam' ? 4 : e.atk === 'swing' ? 3 : 7, frame: f };
    }
    return { row: Math.abs(e.vx) > 20 ? 1 : 0, frame: Math.floor(e.anim / .1) % 16 };
  };

  /* 스프라이트 행/프레임 */
  E.anim = (e) => {
    if (e.hurtV > 0 && !e.armor && (e.stun > 0 || e.state === 'move')) return { row: 2, frame: Math.min(3.99, Math.max(0, (1 - e.hurtV / .5) * 4)) };
    if (e.state !== 'move' && e.atkTotal > 0) return { row: 1, frame: Math.min(3.99, e.atkT / e.atkTotal * 4) };
    if (Math.abs(e.vx) > 20 || e.fly) return { row: 0, frame: ((e.anim / .24) % 4 + 4) % 4 };
    return { row: 0, frame: 0 };
  };
})();
