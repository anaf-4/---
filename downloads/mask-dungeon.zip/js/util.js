/* util.js — 수학 보조 함수, 충돌, 물리 */
(() => {
  const MD = window.MD, C = MD.C;

  const U = {
    rnd: (a, b) => a + Math.random() * (b - a),
    clamp: (v, a, b) => (v < a ? a : v > b ? b : v),
    sgn: (v) => (v < 0 ? -1 : 1),
    overlap: (a, b) => a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y,
    circRect(cx, cy, r, b) {
      const nx = U.clamp(cx, b.x, b.x + b.w), ny = U.clamp(cy, b.y, b.y + b.h);
      const dx = cx - nx, dy = cy - ny;
      return dx * dx + dy * dy <= r * r;
    },
    shuffle(a) {
      for (let i = a.length - 1; i > 0; i--) {
        const j = (Math.random() * (i + 1)) | 0;
        const t = a[i]; a[i] = a[j]; a[j] = t;
      }
      return a;
    },
    el(tag, cls, text) {
      const e = document.createElement(tag);
      if (cls) e.className = cls;
      if (text !== undefined) e.textContent = text;
      return e;
    },
    /* 바닥/한쪽 통과 발판과 충돌하며 이동 */
    moveBody(b, dt, ignorePlat) {
      b.x = U.clamp(b.x + b.vx * dt, 0, C.W - b.w);
      const prevBottom = b.y + b.h;
      b.y += b.vy * dt;
      b.onGround = false; b.onPlat = null;
      const bottom = b.y + b.h;
      if (b.vy >= 0) {
        if (bottom >= C.FLOOR) { b.y = C.FLOOR - b.h; b.vy = 0; b.onGround = true; }
        else if (!ignorePlat) {
          for (const p of MD.G.plats) {
            if (b.x + b.w > p.x + 2 && b.x < p.x + p.w - 2 && prevBottom <= p.y + 1 && bottom >= p.y) {
              b.y = p.y - b.h; b.vy = 0; b.onGround = true; b.onPlat = p; break;
            }
          }
        }
      }
      if (b.y < 0) { b.y = 0; if (b.vy < 0) b.vy = 0; }
    }
  };
  MD.U = U;
})();
