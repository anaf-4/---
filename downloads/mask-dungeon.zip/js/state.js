/* state.js — 게임 전역 상태 (모든 모듈이 공유) */
window.MD = window.MD || {};

MD.G = {
  state: 'boot',          // boot | menu | play | reward | dying | end
  paused: false,
  room: 1,
  P: null,
  enemies: [], projs: [], eprojs: [], zones: [], ezones: [],
  fxs: [], parts: [], nums: [], corpses: [], embers: [],
  plats: [], door: null,
  waves: [], waveIdx: 0, waveDelay: 0,
  cleared: false, clearT: 0, bossT: 0, bossSpawned: false,
  hitstop: 0, shake: 0, redFlash: 0, fade: 0,
  banner: null, toast: { t: 0, text: '' },
  deathT: 0, clock: 0, best: 0,
  kills: 0, runT: 0, doorT: 0, victoryT: 0, slow: 0,
  qual: 2, whiteFlash: 0, doorOpenT: 0, pickups: [], hazards: [], cine: null, path: [], tut: null, runGold: 0, props: null, zoneSeen: {}
};
