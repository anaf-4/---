/* ui.js — 메뉴, 설정, 도감, 보상, 일시정지, 결과 화면과 HUD (DOM) */
(() => {
  const MD = window.MD, G = MD.G, U = MD.U, A = MD.Audio, S = MD.Settings;
  const UI = MD.UI = {};
  const $ = (id) => document.getElementById(id);
  const SCREENS = ['menu', 'settings', 'codex', 'reward', 'pause', 'end', 'choice', 'altar', 'ending', 'memo'];
  const I = () => MD.Input;

  UI.cur = null;
  let navItems = [], navIdx = 0, settingsBack = 'menu', stTab = 'sound', rwChoices = [], rwSel = 0, rebinding = null;

  /* ---------- 화면 전환 ---------- */
  UI.show = (name) => {
    SCREENS.forEach((s) => $(s).classList.toggle('on', s === name));
    UI.cur = name;
    const st = MD.G.state;
    $('touch').classList.toggle('hide', !!name || !UI.touch || !MD.G.P || st === 'menu' || st === 'end' || st === 'boot');
    navItems = []; navIdx = 0;
    if (name === 'menu') { $('mi-continue').classList.toggle('hide', !MD.Meta.hasRun()); setNav($('menu-list')); }
    else if (name === 'pause') setNav($('pause-list'));
    else if (name === 'end') setNav($('end-list'));
  };

  function setNav(list) {
    navItems = Array.prototype.slice.call(list.querySelectorAll('.mi:not(.hide)'));
    navIdx = 0;
    navItems.forEach((el, i) => {
      el.onmouseenter = () => { if (navIdx !== i) { navIdx = i; paintNav(); A.sfx.select(); } };
      el.onclick = () => { A.ensure(); A.sfx.click(); action(el.dataset.a); };
    });
    paintNav();
  }
  function paintNav() { navItems.forEach((el, i) => el.classList.toggle('sel', i === navIdx)); const cur = navItems[navIdx]; if (cur && cur.scrollIntoView && cur.closest && cur.closest('.st-body')) cur.scrollIntoView({ block: 'nearest' }); }

  function action(a) {
    if (a === 'start') UI.showStory('intro', () => { MD.Meta.intro = true; MD.Meta.save(); MD.Game.startRun(); });
    else if (a === 'start' || a === 'retry') MD.Game.startRun();
    else if (a === 'continue') MD.Game.startRun(true);
    else if (a === 'altar') { buildAltar(); UI.show('altar'); }
    else if (a === 'codex') { buildCodex(); UI.show('codex'); }
    else if (a === 'settings') { settingsBack = UI.cur === 'pause' ? 'pause' : 'menu'; openSettings('sound'); }
    else if (a === 'keys') { settingsBack = 'menu'; openSettings('keys'); }
    else if (a === 'resume') MD.Game.resume();
    else if (a === 'menu') MD.Game.toMenu();
  }

  /* ---------- 키보드 ---------- */
  UI.key = (e) => {
    const c = e.code, s = UI.cur;
    if (!s) return false;
    const stop = () => { e.preventDefault(); return true; };
    if (rebinding) {
      if (c !== 'Escape' && c !== 'KeyP' && c !== 'KeyM' && c !== 'Enter') { I().rebind(rebinding, c); A.sfx.select(); }
      rebinding = null; openSettings('keys');
      return stop();
    }
    if (s === 'scene') { MD.Scene.key(c); return stop(); }
    if (s === 'ending') { endingKey(); return stop(); }
    if (s === 'memo') { if (c === 'Escape' || c === 'Backspace' || c === 'Enter' || c === 'Space') { A.sfx.back(); UI.show('codex'); } return stop(); }
    if (s === 'choice') return choiceKey(c) ? stop() : stop();
    if (s === 'altar') {
      if (c === 'Escape' || c === 'Backspace') { A.sfx.back(); UI.show('menu'); return stop(); }
      const n = parseInt(c.replace('Digit', ''), 10);
      if (n >= 1 && n <= MD.UPG.length) { altarBuy(MD.UPG[n - 1].id); }
      return stop();
    }
    if (s === 'reward') {
      const n = rwChoices.length;
      if (c === 'Digit1' || c === 'Numpad1') return rwPick(0), stop();
      if (c === 'Digit2' || c === 'Numpad2') return rwPick(1), stop();
      if (c === 'Digit3' || c === 'Numpad3') return rwPick(2), stop();
      if (c === 'ArrowLeft' || c === 'KeyA') return rwPick((rwSel + n - 1) % n), stop();
      if (c === 'ArrowRight' || c === 'KeyD') return rwPick((rwSel + 1) % n), stop();
      if (c === 'Enter' || c === 'Space') return rwConfirm(), stop();
      return stop();
    }
    if (s === 'settings' || s === 'codex') {
      if (c === 'Escape' || c === 'Backspace') { A.sfx.back(); UI.show(s === 'codex' ? 'menu' : settingsBack); return stop(); }
      if (s === 'settings' && (c === 'ArrowLeft' || c === 'ArrowRight')) {
        const ids = ['sound', 'screen', 'keys', 'game'];
        const i = ids.indexOf(stTab) + (c === 'ArrowRight' ? 1 : -1);
        openSettings(ids[(i + ids.length) % ids.length]);
        return stop();
      }
      return stop();
    }
    if (s === 'pause' && (c === 'Escape' || c === 'KeyP')) { MD.Game.resume(); return stop(); }
    if (c === 'ArrowUp' || c === 'KeyW') { navIdx = (navIdx + navItems.length - 1) % navItems.length; paintNav(); A.sfx.select(); return stop(); }
    if (c === 'ArrowDown' || c === 'KeyS') { navIdx = (navIdx + 1) % navItems.length; paintNav(); A.sfx.select(); return stop(); }
    if (c === 'Enter' || c === 'Space') { if (navItems[navIdx]) { A.sfx.click(); action(navItems[navIdx].dataset.a); } return stop(); }
    return stop();
  };

  /* ---------- 설정 ---------- */
  const TABS = [['sound', '소리'], ['screen', '화면'], ['keys', '조작'], ['game', '게임']];
  const DEFS = {
    sound: [
      { t: 'slider', k: 'master', label: '전체 음량' },
      { t: 'slider', k: 'bgm', label: '배경음' },
      { t: 'slider', k: 'sfx', label: '효과음' },
      { t: 'toggle', k: 'mute', label: '음소거 (M)' }
    ],
    screen: [
      { t: 'seg', k: 'shake', label: '화면 흔들림', opts: [['off', '끔'], ['low', '약하게'], ['normal', '보통']] },
      { t: 'seg', k: 'hpstyle', label: '체력바 모양', opts: [[0, '하트'], [1, '가시'], [2, '물약'], [3, '영혼']] },
      { t: 'seg', k: 'quality', label: '그래픽 품질', opts: [['auto', '자동'], ['high', '높음'], ['mid', '보통'], ['low', '낮음']] },
      { t: 'seg', k: 'fpscap', label: '최대 FPS', opts: [[30, '30'], [60, '60'], [90, '90'], [120, '120'], [144, '144'], [0, '무제한']] },
      { t: 'toggle', k: 'vsync', label: '수직 동기화' },
      { t: 'note', text: '끄면 입력 지연은 줄지만 화면이 찢어질 수 있습니다 (저지연 모드).' },
      { t: 'toggle', k: 'showfps', label: 'FPS 표시' },
      { t: 'toggle', k: 'flash', label: '피격 시 붉은 화면' },
      { t: 'toggle', k: 'dmg', label: '피해량 숫자 표시' },
      { t: 'toggle', k: 'full', label: '전체 화면' }
    ],
    game: [
      { t: 'seg', k: 'diff', label: '난이도', opts: [['story', '쉬움'], ['normal', '보통'], ['hell', '지옥']] },
      { t: 'toggle', k: 'autopause', label: '창을 벗어나면 일시정지' },
      { t: 'seg', k: 'ctl', label: '터치 이동 방식', opts: [['pad', '방향 버튼'], ['stick', '가상 스틱']] },
      { t: 'seg', k: 'tbs', label: '터치 버튼 크기', opts: [['s', '작게'], ['m', '보통'], ['l', '크게']] },
      { t: 'toggle', k: 'vib', label: '진동 (모바일)' },
      { t: 'btn', label: '튜토리얼 다시 보기', text: '다시 보기', act() { MD.Meta.tut = false; MD.Meta.save(); UI.toast('다음 새 게임에서 튜토리얼이 표시됩니다', 2.4); } }
    ]
  };
  const ACT_NAME = { left: '왼쪽 이동', right: '오른쪽 이동', down: '아래 (발판 통과)', jump: '점프', atk: '공격', skill: '스킬', dash: '대시', swap: '가면 교체' };
  const KEYS = [['일시정지', ['P', 'Esc']], ['음소거', ['M']], ['선택 / 확인', ['1 2 3', 'Enter']]];

  function openSettings(tab) {
    stTab = tab;
    const tabs = $('st-tabs');
    tabs.innerHTML = '';
    TABS.forEach(([id, name]) => {
      const b = U.el('button', 'tab' + (id === tab ? ' on' : ''), name);
      b.type = 'button'; b.tabIndex = -1;
      b.onclick = () => { A.sfx.click(); openSettings(id); };
      tabs.appendChild(b);
    });
    const body = $('st-body');
    body.innerHTML = '';
    if (tab === 'keys') {
      const g = U.el('div', 'keys');
      const inp = I();
      inp.ACTIONS.forEach((a) => {
        const r = U.el('div', 'krow'); r.appendChild(U.el('span', '', ACT_NAME[a]));
        const sp = U.el('span', 'ks');
        const seen = {};
        inp.KEYMAP[a].filter((k) => k.indexOf(':') < 0).forEach((k) => { const l = inp.keyLabel(k); if (!seen[l] && Object.keys(seen).length < 3) { seen[l] = 1; sp.appendChild(U.el('span', 'kc', l)); } });
        const b = U.el('button', 'btn kb' + (rebinding === a ? ' on' : ''), rebinding === a ? '키를 누르세요…' : '변경');
        b.type = 'button'; b.tabIndex = -1;
        b.onclick = () => { A.sfx.click(); rebinding = rebinding === a ? null : a; openSettings('keys'); };
        r.appendChild(sp); r.appendChild(b); g.appendChild(r);
      });
      KEYS.forEach(([n, ks]) => {
        const r = U.el('div', 'krow fixed'); r.appendChild(U.el('span', '', n));
        const sp = U.el('span', 'ks'); ks.forEach((k) => sp.appendChild(U.el('span', 'kc', k)));
        r.appendChild(sp); g.appendChild(r);
      });
      body.appendChild(g);
      body.appendChild(U.el('div', 'note', '게임패드: A 점프 · X/RT 공격 · Y 스킬 · B/RB 대시 · LB 가면 교체 · Start 일시정지'));
    } else {
      DEFS[tab].forEach((d) => body.appendChild(d.t === 'note' ? U.el('div', 'note', d.text) : settingRow(d)));
    }
    UI.show('settings');
  }

  function settingRow(d) {
    const row = U.el('div', 'row');
    row.appendChild(U.el('span', 'lab', d.label));
    if (d.t === 'slider') {
      const inp = document.createElement('input');
      inp.type = 'range'; inp.min = 0; inp.max = 100; inp.value = S.data[d.k];
      const val = U.el('span', 'val', S.data[d.k] + '%');
      inp.style.setProperty('--p', inp.value + '%');
      inp.oninput = () => { S.set(d.k, +inp.value); val.textContent = inp.value + '%'; inp.style.setProperty('--p', inp.value + '%'); };
      inp.onchange = () => A.sfx.click();
      row.appendChild(inp); row.appendChild(val);
    } else if (d.t === 'btn') {
      const b = U.el('button', 'btn', d.text);
      b.type = 'button'; b.tabIndex = -1;
      b.onclick = () => { A.sfx.click(); d.act(); };
      row.appendChild(b);
    } else if (d.t === 'toggle') {
      const b = U.el('button', 'tg' + (S.data[d.k] ? ' on' : ''), S.data[d.k] ? '켜짐' : '꺼짐');
      b.type = 'button'; b.tabIndex = -1;
      b.onclick = () => {
        S.set(d.k, !S.data[d.k]);
        b.classList.toggle('on', S.data[d.k]); b.textContent = S.data[d.k] ? '켜짐' : '꺼짐';
        A.sfx.click();
      };
      row.appendChild(b);
    } else {
      const seg = U.el('div', 'seg');
      d.opts.forEach(([v, name]) => {
        const b = U.el('button', S.data[d.k] === v ? 'on' : '', name);
        b.type = 'button'; b.tabIndex = -1;
        b.onclick = () => {
          S.set(d.k, v);
          Array.prototype.forEach.call(seg.children, (c) => c.classList.remove('on'));
          b.classList.add('on'); A.sfx.click();
        };
        seg.appendChild(b);
      });
      row.appendChild(seg);
    }
    return row;
  }

  /* 아이콘 시트 한 칸을 담은 캔버스 (size는 화면에 보이는 크기) */
  function ico(key, size) {
    const c = document.createElement('canvas');
    c.width = c.height = size * 2; c.className = 'ico';
    c.style.width = c.style.height = size + 'px';
    MD.Assets.iconKey(c, key);
    return c;
  }
  function skillRow(m, extra) {
    const r = U.el('div', 'sk');
    r.appendChild(ico('skill_' + m.id, 30));
    r.appendChild(document.createTextNode('스킬 · ' + m.skill.name + (extra || '')));
    return r;
  }

  /* ---------- 도감 ---------- */
  const HINT = {
    dokkaebi: '묵직한 일격을 아끼는 가면. 전투 보상이나 장터에서 만날 수 있다.',
    fox: '재빠른 발을 가진 가면. 전투 보상이나 장터에서 만날 수 있다.',
    dosa: '부적을 다루는 가면. 전투 보상이나 장터에서 만날 수 있다.',
    lion: '무대를 지키던 가면. 전투 보상이나 장터에서 만날 수 있다.',
    maltugi: '왕을 조롱하던 하인의 가면. 전투 보상이나 장터에서 만날 수 있다.',
    gaksi: '죽은 왕녀의 시녀가 쓰던 가면. 전투 보상이나 장터에서 만날 수 있다.',
    reaper: '숨은 결말을 본 자에게만 모습을 드러낸다.'
  };
  function buildCodex() {
    const g = $('cx-grid');
    g.innerHTML = '';
    MD.MASK_ORDER.forEach((id) => {
      const m = MD.MASKS[id], open = !!MD.Meta.unlocked[id];
      const c = U.el('div', 'cc' + (open ? '' : ' lock'));
      const cv = document.createElement('canvas'); cv.width = 128; cv.height = 128;
      MD.Assets.icon(cv, id);
      if (!open) {
        const x = cv.getContext('2d');
        x.globalCompositeOperation = 'source-in'; x.fillStyle = '#2c4358'; x.fillRect(0, 0, cv.width, cv.height);
        x.globalCompositeOperation = 'source-over'; x.fillStyle = '#6f8da3'; x.font = '700 54px sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText('?', 64, 68);
      }
      c.appendChild(cv);
      c.appendChild(U.el('div', 'nm', open ? m.name : '???'));
      const tr = U.el('div', 'tr', open ? m.tier + ' · ' + m.role : '미획득'); tr.style.color = open ? m.tierColor : '#3a4c58';
      c.appendChild(tr);
      c.appendChild(U.el('div', 'ds', open ? m.desc : HINT[id] || '던전에서 보상으로 얻으면 기록됩니다.'));
      if (open) {
        c.appendChild(skillRow(m));
        c.appendChild(U.el('div', 'st2', '재사용 ' + m.skill.cd + '초 · 공격력 ' + m.dmg));
        const n = MD.Meta.memOpen(id).filter(Boolean).length;
        c.appendChild(U.el('div', 'memb', '기억 ' + n + ' / 4 · 눌러서 읽기'));
        c.classList.add('hasmem'); c.onclick = () => { A.ensure(); A.sfx.click(); openMemo(id); };
      }
      g.appendChild(c);
    });
  }

  function openMemo(id) {
    const m = MD.MASKS[id], L = MD.LORE.memo[id], open = MD.Meta.memOpen(id), st = MD.Meta.memOf(id), g = MD.LORE.memoGoal;
    $('mm-title').textContent = m.name + ' · ' + L.who;
    $('mm-sub').textContent = '쓰러진 자의 기억 ' + open.filter(Boolean).length + ' / 4';
    const box = $('mm-list'); box.innerHTML = '';
    const prog = [null, st.k + ' / ' + g[1], st.c + ' / ' + g[2], st.l + ' / ' + g[3]];
    L.m.forEach((t, i) => {
      const r = U.el('div', 'mmr' + (open[i] ? ' ok' : ' lock'));
      r.appendChild(U.el('b', '', '기억 ' + (i + 1)));
      r.appendChild(U.el('span', '', open[i] ? t : '??? — ' + MD.LORE.memoNeed[i] + (prog[i] ? ' (' + prog[i] + ')' : '')));
      box.appendChild(r);
    });
    UI.show('memo');
  }

  /* ---------- 보상 ---------- */
  function rwPick(i) {
    if (i === rwSel && arguments.length === 0) return;
    rwSel = i;
    Array.prototype.forEach.call($('rw-cards').children, (c, j) => c.classList.toggle('sel', j === i));
    A.sfx.select();
  }
  function rwConfirm() {
    const c = rwChoices[rwSel];
    if (!c) return;
    UI.show(null);
    MD.Rooms.pick(c);
  }
  UI.showReward = (choices) => {
    rwChoices = choices; rwSel = 0;
    $('banner').classList.remove('show');
    const box = $('rw-cards');
    box.innerHTML = '';
    choices.forEach((c, i) => {
      const card = U.el('div', 'rc' + (i === 0 ? ' sel' : ''));
      card.appendChild(U.el('span', 'kc num', String(i + 1)));
      const ic = U.el('div', 'ic');
      let tag, name, desc, col;
      if (c.kind === 'lv') {
        const m = MD.MASKS[c.id], lv = MD.Player.level(G.P, c.id);
        const cv = document.createElement('canvas'); cv.width = 128; cv.height = 128;
        MD.Assets.icon(cv, c.id); ic.appendChild(cv);
        card.appendChild(U.el('div', 'tagc', '가면 단련')).style.color = '#ffd24a';
        card.appendChild(ic);
        card.appendChild(U.el('div', 'nm', m.name + ' Lv.' + (lv + 1)));
        card.appendChild(U.el('div', 'ds', '공격력이 18% 오른다. (현재 Lv.' + lv + ')'));
      } else if (c.kind === 'mask') {
        const m = MD.MASKS[c.id];
        const cv = document.createElement('canvas'); cv.width = 128; cv.height = 128;
        MD.Assets.icon(cv, c.id); ic.appendChild(cv);
        tag = '가면 · ' + m.tier; name = m.name; desc = m.desc; col = m.tierColor;
        card.appendChild(U.el('div', 'tagc', tag)).style.color = col;
        card.appendChild(ic);
        card.appendChild(U.el('div', 'nm', name));
        card.appendChild(U.el('div', 'ds', desc));
        card.appendChild(skillRow(m));
      } else {
        const it = MD.ITEMS.find((x) => x.id === c.id);
        const icv = document.createElement('canvas'); icv.width = 128; icv.height = 128;
        if (MD.Assets.iconKey(icv, 'item_' + c.id)) ic.appendChild(icv); else ic.textContent = it.glyph;
        card.appendChild(U.el('div', 'tagc', '아이템')).style.color = '#8fa6ad';
        card.appendChild(ic);
        card.appendChild(U.el('div', 'nm', it.name));
        card.appendChild(U.el('div', 'ds', it.desc));
      }
      card.onclick = () => { A.ensure(); if (rwSel === i) rwConfirm(); else rwPick(i); };
      box.appendChild(card);
    });
    UI.show('reward');
  };

  /* ---------- 일시정지 / 결과 ---------- */
  UI.showEnd = (win, stats, kind) => {
    const t = $('en-title');
    t.textContent = win ? '승리' : '쓰러졌다';
    t.className = 'en-title ' + (win ? 'win' : 'lose');
    $('en-sub').textContent = win ? ((MD.LORE.story[kind] || MD.LORE.story.face).sub) : '가면이 깨지고 어둠이 다시 성을 덮는다.';
    const box = $('en-stats');
    box.innerHTML = '';
    [['도달한 방', stats.room + ' / ' + MD.C.MAXROOM], ['처치한 적', String(stats.kills)], ['걸린 시간', stats.time], ['얻은 영혼 파편', '+' + stats.shards]].forEach(([k, v]) => {
      const d = U.el('div', 'sc'); d.appendChild(U.el('b', '', v)); d.appendChild(U.el('span', '', k)); box.appendChild(d);
    });
    UI.show('end');
  };

  UI.updateBest = () => {
    const b = MD.Meta.best;
    const sh = $('shardl'); if (sh) sh.textContent = '영혼 파편 ' + MD.Meta.shards;
    $('bestl').textContent = b ? '최고 기록 · 제 ' + Math.min(b, MD.C.MAXROOM) + ' 방' + (MD.Meta.wins ? ' · 클리어 ' + MD.Meta.wins + '회' : '') : '최고 기록 —';
  };

  /* ---------- 선택 화면 (상점 / 휴식 / 사건) ---------- */
  let chOpt = null, chSel = 0, chCards = [], chPicked = false;
  UI.showChoice = (o) => { chOpt = o; chSel = 0; chPicked = false; renderChoice(); UI.show('choice'); };
  function renderChoice() {
    const P = G.P;
    chCards = chOpt.cards();
    $('ch-title').textContent = chOpt.title;
    $('ch-sub').textContent = chOpt.sub || '';
    $('ch-gold').textContent = String(P.gold);
    if (chSel >= chCards.length) chSel = 0;
    const box = $('ch-cards');
    box.innerHTML = ''; box.className = 'rw-cards n' + chCards.length;
    chCards.forEach((c, i) => {
      const card = U.el('div', 'rc' + (i === chSel ? ' sel' : '') + (c.sold ? ' sold' : '') + (c.dis ? ' dis' : '') + (c.price && P.gold < c.price && !c.sold ? ' poor' : ''));
      card.appendChild(U.el('span', 'kc num', String(i + 1)));
      const tg = U.el('div', 'tagc', c.tag || ''); tg.style.color = c.tagCol || '#8fa6ad'; card.appendChild(tg);
      const ic = U.el('div', 'ic');
      const cv = document.createElement('canvas'); cv.width = 128; cv.height = 128;
      if (c.mask) { MD.Assets.icon(cv, c.mask); ic.appendChild(cv); }
      else if (c.icon && MD.Assets.iconKey(cv, c.icon)) ic.appendChild(cv);
      else ic.textContent = c.glyph || '·';
      card.appendChild(ic);
      card.appendChild(U.el('div', 'nm', c.name));
      card.appendChild(U.el('div', 'ds', c.desc));
      const pr = c.sold ? '품절' : c.dis ? c.dis : c.price ? '혼 ' + c.price : '';
      if (pr) card.appendChild(U.el('div', 'pr', pr));
      card.onclick = () => { A.ensure(); if (chSel === i) choiceConfirm(); else { chSel = i; A.sfx.select(); renderChoice(); } };
      box.appendChild(card);
    });
    $('ch-ok').textContent = chOpt.closeOnPick ? '선택하기' : '구매하기';
    $('ch-leave').textContent = chOpt.closeOnPick ? '고르지 않고 떠나기' : '나가기';
    $('ch-leave').style.display = chOpt.noLeave ? 'none' : '';
  }
  function choiceConfirm() {
    const P = G.P, c = chCards[chSel];
    if (!c) return;
    if (c.sold || c.dis) { A.sfx.deny(); return; }
    if (c.price && P.gold < c.price) { A.sfx.deny(); UI.toast('혼이 부족합니다', 1.3); return; }
    P.gold -= c.price || 0;
    c.act();
    chPicked = true;
    A.sfx.buy();
    if (chOpt.closeOnPick) choiceClose(); else renderChoice();
  }
  function choiceClose() {
    const f = chOpt && chOpt.onClose, picked = chPicked;
    chOpt = null;
    UI.show(null);
    I().clear();
    if (f) f(picked);
  }
  function choiceKey(c) {
    const n = chCards.length;
    const d = parseInt(c.replace('Digit', '').replace('Numpad', ''), 10);
    if (d >= 1 && d <= n) { chSel = d - 1; A.sfx.select(); renderChoice(); return true; }
    if (c === 'ArrowLeft' || c === 'KeyA') { chSel = (chSel + n - 1) % n; A.sfx.select(); renderChoice(); return true; }
    if (c === 'ArrowRight' || c === 'KeyD') { chSel = (chSel + 1) % n; A.sfx.select(); renderChoice(); return true; }
    if (c === 'Enter' || c === 'Space') { choiceConfirm(); return true; }
    if (c === 'Escape') { if (chOpt && chOpt.noLeave) return true; A.sfx.back(); choiceClose(); return true; }
    return true;
  }

  /* ---------- 영혼의 제단 (영구 강화) ---------- */
  function buildAltar() {
    const M = MD.Meta, box = $('al-list');
    $('al-shards').textContent = String(M.shards);
    box.innerHTML = '';
    MD.UPG.forEach((u, i) => {
      const lv = M.lv(u.id), cost = M.cost(u), max = lv >= u.max;
      const r = U.el('div', 'arow');
      r.appendChild(U.el('span', 'kc num', String(i + 1)));
      const t = U.el('div', 'at'); t.appendChild(U.el('b', '', u.name)); t.appendChild(U.el('span', '', u.desc)); r.appendChild(t);
      const pips = U.el('div', 'pips');
      for (let k = 0; k < u.max; k++) pips.appendChild(U.el('i', k < lv ? 'on' : ''));
      r.appendChild(pips);
      const b = U.el('button', 'btn' + (!max && M.shards >= cost ? ' pri' : ''), max ? '최대' : '파편 ' + cost);
      b.type = 'button'; b.tabIndex = -1; b.disabled = max;
      b.onclick = () => altarBuy(u.id);
      r.appendChild(b);
      box.appendChild(r);
    });
  }
  function altarBuy(id) {
    if (MD.Meta.buy(id)) A.sfx.buy(); else A.sfx.deny();
    buildAltar();
  }

  /* ---------- 튜토리얼 안내 ---------- */
  const TUT = [['move', '이동', ['left', 'right']], ['jump', '점프', ['jump']], ['atk', '공격 4번', ['atk']], ['dash', '대시', ['dash']], ['skill', '스킬 사용', ['skill']]];
  const TOUCH_NAME = { left: '◀', right: '▶', jump: '점프', atk: '공격', dash: '대시', skill: '스킬' };
  UI.tutShow = (step) => {
    const el = $('tut');
    if (step < 0) { el.classList.add('hide'); return; }
    el.classList.remove('hide');
    const box = $('tut-l');
    box.innerHTML = '';
    TUT.forEach((t, i) => {
      const r = U.el('div', 'tr' + (i < step ? ' ok' : i === step ? ' cur' : ''));
      r.appendChild(U.el('b', '', i < step ? '✔' : String(i + 1)));
      r.appendChild(U.el('span', '', t[1]));
      if (i === step) {
        const ks = U.el('span', 'ks');
        t[2].forEach((a) => {
          const code = I().KEYMAP[a].filter((k) => k.indexOf(':') < 0)[0];
          ks.appendChild(U.el('span', 'kc', UI.touch ? TOUCH_NAME[a] : I().keyLabel(code)));
        });
        r.appendChild(ks);
      }
      box.appendChild(r);
    });
  };

  /* ---------- 타자기 연출 ---------- */
  /* el 에 text 를 한 글자씩 찍는다. 글자마다 짧은 소리가 난다. o = { cps, onDone } */
  UI.type = (el, text, o) => {
    o = o || {};
    const chars = Array.from(text), cps = o.cps || 28;
    let i = 0, timer = 0, finished = false;
    el.textContent = '';
    const done = () => { if (finished) return; finished = true; clearTimeout(timer); el.textContent = text; if (o.onDone) o.onDone(); };
    const tick = () => {
      if (finished) return;
      const ch = chars[i++];
      el.textContent += ch;
      if (ch !== ' ' && (i & 1)) A.sfx.type();
      if (i >= chars.length) { finished = true; if (o.onDone) o.onDone(); return; }
      timer = setTimeout(tick, 1000 / cps + (/[.,?!…—]/.test(ch) ? 150 : 0));
    };
    tick();
    return { skip: done, get done() { return finished; }, stop() { finished = true; clearTimeout(timer); } };
  };

  /* ---------- 말풍선 (게임 중 짧은 대사) ---------- */
  let sayQ = [], sayBusy = false, sayHandle = null, sayTimer = 0;
  const SAY_ICON = { '말뚝이': 'mask_maltugi', '탈의 군주': 'item_eye', '모닥불': 'heal_orb' };
  function sayIcon(who) {
    if (!who) return null;
    if (SAY_ICON[who]) return SAY_ICON[who];
    const m = Object.values(MD.MASKS || {}).find((x) => x.name === who);
    return m ? 'mask_' + m.id : null;
  }
  function sayNext() {
    const el = $('talk');
    if (!sayQ.length) { sayBusy = false; el.classList.remove('on'); return; }
    sayBusy = true;
    const it = sayQ.shift();
    $('tk-who').textContent = it.who || '';
    $('tk-who').style.display = it.who ? '' : 'none';
    { const ic = $('tk-ic'), key = sayIcon(it.who); ic.classList.toggle('hide', !key); if (key) MD.Assets.iconKey(ic, key); }
    el.classList.add('on');
    sayHandle = UI.type($('tk-tx'), it.text, { cps: it.cps || 30, onDone: () => { sayTimer = setTimeout(sayNext, it.hold || 1700); } });
  }
  /* UI.say('말뚝이', '대사') 또는 UI.say([[who, text], ...]) */
  UI.say = (a, b, o) => {
    const list = Array.isArray(a) ? a : [[a, b]];
    list.forEach((x) => sayQ.push({ who: x[0], text: x[1], cps: o && o.cps, hold: o && o.hold }));
    if (!sayBusy) sayNext();
  };
  UI.sayClear = () => {
    sayQ = []; sayBusy = false; clearTimeout(sayTimer);
    if (sayHandle) sayHandle.stop();
    const el = $('talk'); if (el) el.classList.remove('on');
  };

  /* ---------- 전체 화면 이야기 (인트로 / 엔딩) ---------- */
  let edTimers = [], edDone = false, edLines = [], edI = 0, edHandle = null, edCb = null, edTitle = '';
  function edClear() { edTimers.forEach(clearTimeout); edTimers = []; if (edHandle) edHandle.stop(); edHandle = null; }
  function edFinish() {
    $('ed-title').classList.add('on');
    edTimers.push(setTimeout(() => { edDone = true; $('ed-hint').classList.add('on'); }, 1200));
  }
  function edNext() {
    if (edI >= edLines.length) { edFinish(); return; }
    const l = U.el('div', 'edl on', ''); $('ed-lines').appendChild(l);
    const t = edLines[edI++];
    edHandle = UI.type(l, t, { cps: 22, onDone: () => { edTimers.push(setTimeout(edNext, 750)); } });
  }
  UI.showStory = (kind, cb) => {
    if (MD.SCENES && MD.SCENES[kind] && MD.Assets.ready) { MD.Scene.play(kind, cb); return; }
    const st = MD.LORE.story[kind];
    edClear(); edDone = false; edCb = cb || null; edI = 0; edLines = st.lines.slice(); edTitle = st.title;
    $('ed-lines').innerHTML = '';
    $('ed-hint').classList.remove('on'); $('ed-title').classList.remove('on');
    $('ed-title').textContent = st.title;
    UI.show('ending');
    $('hud').classList.add('hide');
    edTimers.push(setTimeout(edNext, 700));
  };
  function endingKey() {
    if (!edDone) {
      /* 첫 입력: 남은 글을 한 번에 보여 준다 */
      edClear();
      const box = $('ed-lines'); box.innerHTML = '';
      edLines.forEach((t) => { box.appendChild(U.el('div', 'edl on', t)); });
      edI = edLines.length; edFinish(); edTimers.forEach(clearTimeout); edTimers = [];
      $('ed-title').classList.add('on'); $('ed-hint').classList.add('on'); edDone = true;
      return;
    }
    edDone = false;
    const f = edCb; edCb = null;
    if (f) f();
  }

  /* 군주를 쓰러뜨린 뒤: 결말 선택(2개 이상일 때) → 이야기 → 결과 화면 */
  UI.showVictory = () => {
    const M = MD.Meta, kinds = ['face'];
    if (M.wins >= 1) kinds.push('lord');
    if (M.wins >= 2 && MD.BASE_MASKS.every((id) => M.memOf(id).l >= 1)) kinds.push('hidden');
    const go = (kind) => { M.endings[kind] = (M.endings[kind] | 0) + 1; UI.showStory(kind, () => MD.Game.end(true, kind)); };
    if (kinds.length === 1) { go('face'); return; }
    const META = {
      face: { tag: '결말', col: '#7dffb0', glyph: '☺', name: '얼굴을 되찾는다', desc: '탈을 벗고 판을 파한다. 이름은 끝내 떠오르지 않는다.' },
      lord: { tag: '결말', col: '#ff9a3c', glyph: '♛', name: '군주의 가면을 쓴다', desc: '바닥에 떨어진 가면을 집어 쓴다. 판은 계속된다.' },
      hidden: { tag: '숨은 결말', col: '#b58cff', glyph: '∅', name: '빈 얼굴로 남는다', desc: '모든 가면을 내려놓는다. 얼굴 없는 놈이 판을 뒤집는다.' }
    };
    let pick = 'face';
    UI.showChoice({
      title: '마지막 선택', sub: '군주의 가면이 바닥에 떨어져 있다', closeOnPick: true, noLeave: true,
      cards: () => kinds.map((k) => ({ tag: META[k].tag, tagCol: META[k].col, glyph: META[k].glyph, name: META[k].name, desc: META[k].desc, act() { pick = k; } })),
      onClose: () => go(pick)
    });
  };

  /* ---------- 배너 / 토스트 ---------- */
  UI.banner = (t1, t2) => {
    const b = $('banner');
    $('bn1').textContent = t1; $('bn2').textContent = t2 || '';
    b.classList.remove('show'); void b.offsetWidth; b.classList.add('show');
  };
  let toastTimer = 0;
  UI.toast = (text, sec) => {
    const t = $('toast');
    t.textContent = text; t.classList.add('on');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove('on'), (sec || 2.5) * 1000);
  };

  /* ---------- HUD ---------- */
  const last = {};
  let hpDisp = 1;
  function setText(el, key, v) { if (last[key] !== v) { last[key] = v; el.textContent = v; } }
  function setCss(el, key, prop, v) { if (last[key] !== v) { last[key] = v; el.style[prop] = v; } }

  UI.hudVisible = (on) => { $('hud').classList.toggle('hide', !on); $('touch').classList.toggle('hide', !(on && UI.touch)); };

  UI.hud = () => {
    const P = G.P;
    if (!P || $('hud').classList.contains('hide')) return;
    const M = MD.Player.mask(P);
    const hpStyle = S.data.hpstyle, hpTarget = Math.max(0, P.hp / P.maxHp);
    if (last.hpP !== P) { last.hpP = P; hpDisp = hpTarget; }
    hpDisp += (hpTarget - hpDisp) * .18;
    if (Math.abs(hpTarget - hpDisp) < .002) hpDisp = hpTarget;
    const crack = hpTarget < .25;
    const hk = hpStyle + '|' + hpDisp.toFixed(3) + '|' + crack;
    if (last.hpc !== hk) {
      last.hpc = hk;
      MD.HpBar.draw($('hpc'), hpStyle, hpDisp, crack);
      $('hpw').classList.toggle('low', crack);
    }
    if (last.hps !== hpStyle) {
      last.hps = hpStyle;
      const r = MD.HP_META && MD.HP_META.rows[hpStyle], t = $('hpt').style;
      if (r) { t.left = r.fx0 + 'px'; t.width = (r.fx1 - r.fx0) + 'px'; t.top = r.fy0 + 'px'; t.height = (r.fy1 - r.fy0) + 'px'; }
    }
    setText($('hpt'), 'hpt', Math.ceil(P.hp) + ' / ' + P.maxHp);
    setText($('roomt'), 'room', '제 ' + G.room + ' 방');
    setText($('goldt'), 'gold', String(P.gold));
    $('hud').classList.toggle('cine', !!G.cine);
    document.body.classList.toggle('incine', !!G.cine);
    const pk = (G.path || []).join(',') + '|' + G.room;
    if (last.path !== pk) {
      last.path = pk;
      const box = $('path'); box.innerHTML = '';
      (G.path || []).forEach((t, i) => {
        const m = MD.Rooms.PATH_META[t];
        const d = U.el('i', 'pn' + (i + 1 < G.room ? ' done' : i + 1 === G.room ? ' cur' : '') + (t === 'boss' ? ' boss' : ''));
        d.style.setProperty('--c', m.c); d.title = m.n;
        box.appendChild(d);
      });
    }

    for (let i = 0; i < 2; i++) {
      const id = P.masks[i], el = $('pt' + i);
      if (last['pt' + i] !== id) { last['pt' + i] = id; el.classList.toggle('empty', !id); if (id) MD.Assets.icon(el, id); else el.getContext('2d').clearRect(0, 0, el.width, el.height); }
      el.classList.toggle('on', i === P.cur);
      setText($('lv' + i), 'lv' + i + (id || ''), id ? 'Lv.' + MD.Player.level(P, id) : '');
    }

    const sk = P.skcd[M.id] || 0, skMax = M.skill.cd * P.st.skCd;
    setText($('skn'), 'skn', M.skill.name);
    if (last.ski !== M.id) { last.ski = M.id; MD.Assets.iconKey($('ski'), 'skill_' + M.id); }
    setCss($('skm'), 'skm', 'height', sk > 0 ? (sk / skMax * 100).toFixed(0) + '%' : '0%');
    setText($('skt'), 'skt', sk > 0 ? Math.ceil(sk) : '');
    $('skc').classList.toggle('off', sk > 0);

    const has2 = !!P.masks[1];
    const sw = has2 ? Math.max(0, P.swapCd) : 0, swMax = 6 * P.st.swapCd;
    setCss($('swm'), 'swm', 'height', sw > 0 ? (sw / swMax * 100).toFixed(0) + '%' : '0%');
    setText($('swt'), 'swt', sw > 0 ? Math.ceil(sw) : '');
    $('swc').classList.toggle('off', !has2 || sw > 0);

    const need = 2.2 * P.st.dashRech;
    for (let i = 0; i < 2; i++) {
      const w = P.dashCharges > i ? 100 : (P.dashCharges === i ? P.dashTimer / need * 100 : 0);
      setCss($('d' + i).firstChild, 'd' + i, 'width', w.toFixed(0) + '%');
    }

    const key = P.items.join(',');
    if (last.items !== key) {
      last.items = key;
      const box = $('items'); box.innerHTML = '';
      const cnt = {};
      P.items.forEach((id) => { cnt[id] = (cnt[id] || 0) + 1; });
      Object.keys(cnt).forEach((id) => {
        const it = MD.ITEMS.find((x) => x.id === id);
        const d = U.el('div', 'it'); d.title = it.name;
        const icv = ico('item_' + id, 26);
        if (MD.Assets.icons) d.appendChild(icv); else d.textContent = it.glyph;
        if (cnt[id] > 1) d.appendChild(U.el('b', '', 'x' + cnt[id]));
        box.appendChild(d);
      });
    }

    const boss = G.enemies.find((e) => e.boss && !e.dead);
    $('bossb').classList.toggle('hide', !boss);
    if (boss) setCss($('bossf'), 'bossf', 'width', Math.max(0, boss.hp / boss.maxHp * 100).toFixed(1) + '%');
  };

  UI.init = () => {
    $('st-back').onclick = () => { A.sfx.back(); rebinding = null; UI.show(settingsBack); };
    $('mm-back').onclick = () => { A.sfx.back(); UI.show('codex'); };
    $('cx-back').onclick = () => { A.sfx.back(); UI.show('menu'); };
    $('st-reset').onclick = () => { if (stTab === 'keys') I().resetKeys(); else S.reset(); A.sfx.click(); openSettings(stTab); };
    $('rw-ok').onclick = () => { A.ensure(); rwConfirm(); };
    $('ch-ok').onclick = () => { A.ensure(); choiceConfirm(); };
    $('ch-leave').onclick = () => { A.sfx.back(); choiceClose(); };
    $('al-back').onclick = () => { A.sfx.back(); UI.show('menu'); };
    $('ed-go').onclick = () => { A.ensure(); endingKey(); };
    $('tut-skip').onclick = () => { MD.Rooms.tutSkip(); };
    $('btn-pause').onclick = () => { A.ensure(); MD.Game.pause(); };
    UI.updateBest();
  };

  /* 로딩이 끝난 뒤 data-ic 로 지정된 고정 아이콘을 채움 */
  UI.paintStatic = () => {
    document.querySelectorAll('canvas[data-ic]').forEach((c) => MD.Assets.iconKey(c, c.dataset.ic));
  };
})();
