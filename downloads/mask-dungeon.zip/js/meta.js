/* meta.js — 최고 기록, 도감 해금, 영구 강화(영혼 파편), 튜토리얼, 이어하기 저장 (브라우저 localStorage) */
(() => {
  const MD = window.MD;
  const KEY = 'maskdungeon.meta.v2', RUNKEY = 'maskdungeon.run.v1';
  const M = MD.Meta = { best: 0, wins: 0, unlocked: { hahoe: true }, shards: 0, up: {}, tut: false, runs: 0, intro: false, mem: {}, endings: {} };

  /* 영구 강화 목록 */
  MD.UPG = [
    { id: 'hp', name: '강인한 육체', desc: '시작 체력 +8', max: 5, cost: [20, 35, 55, 80, 110] },
    { id: 'atk', name: '날카로운 의지', desc: '공격력 +4%', max: 5, cost: [25, 40, 60, 85, 120] },
    { id: 'soul', name: '넉넉한 주머니', desc: '시작 혼 +15', max: 4, cost: [15, 30, 50, 75] },
    { id: 'heal', name: '치유의 숨결', desc: '방을 정리할 때 회복 +3%', max: 4, cost: [20, 35, 55, 80] },
    { id: 'dash', name: '가벼운 발걸음', desc: '대시 재충전 6% 빨라짐', max: 4, cost: [25, 40, 60, 90] }
  ];

  M.lv = (id) => M.up[id] | 0;
  M.cost = (u) => { const l = M.lv(u.id); return l >= u.max ? 0 : u.cost[l]; };
  M.buy = (id) => {
    const u = MD.UPG.find((x) => x.id === id), c = u ? M.cost(u) : 0;
    if (!u || !c || M.shards < c) return false;
    M.shards -= c; M.up[id] = M.lv(id) + 1; M.save();
    return true;
  };

  M.load = () => {
    try {
      const o = JSON.parse(localStorage.getItem(KEY) || 'null');
      if (o) {
        M.best = o.best | 0; M.wins = o.wins | 0; M.shards = o.shards | 0; M.runs = o.runs | 0;
        M.tut = !!o.tut; M.up = o.up || {}; M.intro = !!o.intro; M.mem = o.mem || {}; M.endings = o.endings || {};
        M.unlocked = Object.assign({ hahoe: true }, o.unlocked || {});
      }
    } catch (e) { /* 저장소를 못 쓰면 이번 접속 동안만 유지 */ }
  };
  M.save = () => {
    try {
      localStorage.setItem(KEY, JSON.stringify({ best: M.best, wins: M.wins, unlocked: M.unlocked, shards: M.shards, up: M.up, tut: M.tut, runs: M.runs, intro: M.intro, mem: M.mem, endings: M.endings }));
    } catch (e) { /* 무시 */ }
  };
  /* 가면별 기록: k 처치, c 방 정리, l 군주 처치 */
  M.memAdd = (id, key, n) => { const m = M.mem[id] || (M.mem[id] = { k: 0, c: 0, l: 0 }); m[key] = (m[key] | 0) + (n || 1); };
  M.memOf = (id) => M.mem[id] || { k: 0, c: 0, l: 0 };
  /* 기억 해금 단계(0~4) 목록 */
  M.memOpen = (id) => {
    const m = M.memOf(id), g = MD.LORE ? MD.LORE.memoGoal : [0, 100, 10, 1];
    return [!!M.unlocked[id], m.k >= g[1], m.c >= g[2], m.l >= g[3]];
  };
  M.unlock = (id) => { if (!M.unlocked[id]) { M.unlocked[id] = true; M.save(); } };

  /* 진행 중인 런 저장 / 불러오기 */
  M.saveRun = (o) => { try { localStorage.setItem(RUNKEY, JSON.stringify(o)); } catch (e) { /* 무시 */ } };
  M.loadRun = () => { try { return JSON.parse(localStorage.getItem(RUNKEY) || 'null'); } catch (e) { return null; } };
  M.clearRun = () => { try { localStorage.removeItem(RUNKEY); } catch (e) { /* 무시 */ } };
  M.hasRun = () => { const r = M.loadRun(); return !!(r && r.room >= 1 && r.P); };
})();
