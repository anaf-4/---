/* rooms.js — 방 경로·종류(전투/정예/상점/휴식/사건), 웨이브, 함정, 보스 연출, 저장, 엔딩 */
(() => {
  const MD = window.MD, G = MD.G, U = MD.U, C = MD.C, Cb = MD.Combat, A = MD.Audio, I = MD.Input;
  const R = MD.Rooms = {};

  const WAVES = {
    1: [['soldier', 'soldier'], ['soldier', 'soldier', 'soldier']],
    2: [['soldier', 'soldier', 'archer'], ['soldier', 'soldier', 'wisp']],
    3: [['soldier', 'soldier', 'soldier', 'archer'], ['archer', 'archer', 'wisp', 'wisp']],
    4: [['brute'], ['soldier', 'soldier', 'soldier', 'archer', 'archer']],
    5: [['brute', 'wisp', 'wisp'], ['soldier', 'soldier', 'archer', 'archer', 'wisp']],
    6: [['brute', 'brute'], ['soldier', 'soldier', 'soldier', 'archer', 'archer', 'wisp', 'wisp']],
    7: [['brute', 'brute', 'archer', 'archer'], ['soldier', 'soldier', 'soldier', 'soldier', 'wisp', 'wisp', 'wisp'], ['brute', 'archer', 'archer', 'wisp', 'wisp']],
    8: [['boss']]
  };
  R.PATH_META = {
    combat: { n: '전투', c: '#8fa6ad' }, elite: { n: '정예', c: '#e0494f' }, shop: { n: '상점', c: '#e9bf5b' },
    rest: { n: '휴식', c: '#6fe0a0' }, event: { n: '사건', c: '#b78cff' }, boss: { n: '보스', c: '#ff5a3c' }
  };

  /* ---------- 경로 (런마다 무작위) ---------- */
  R.genPath = () => {
    const mid = U.shuffle(['shop', 'rest', 'elite', 'event', 'combat']);
    if (mid[0] === 'elite') { const t = mid[0]; mid[0] = mid[1]; mid[1] = t; }
    return ['combat', 'combat'].concat(mid, ['boss']);
  };
  R.roomType = (n) => (G.path && G.path[(n || G.room) - 1]) || (n === C.MAXROOM ? 'boss' : 'combat');

  R.zoneMusic = () => {
    const t = R.roomType();
    if (t === 'shop' || t === 'rest' || t === 'event') return 'reward';
    if (t === 'boss') return null;
    return ({ castle: 'castle', crypt: 'crypt', ember: 'ember', hall: 'hall' })[MD.Enemies.zone()];
  };

  /* ---------- 방 시작 ---------- */
  R.start = (n, opt) => {
    opt = opt || {};
    const P = G.P;
    G.room = n;
    G.enemies = []; G.projs = []; G.eprojs = []; G.zones = []; G.ezones = [];
    G.fxs = []; G.parts = []; G.nums = []; G.corpses = []; G.pickups = []; G.hazards = []; G.props = null;
    const type = R.roomType(n);
    G.plats = (n === C.MAXROOM ? MD.LAYOUTS[4] : MD.LAYOUTS[(Math.random() * MD.LAYOUTS.length) | 0]).map((p) => ({ x: p.x, y: p.y, w: p.w }));
    G.waves = (type === 'combat' || type === 'elite') ? WAVES[n] : [];
    G.waveIdx = 0; G.waveDelay = .9;
    G.cleared = false; G.door = null; G.doorT = 0; G.victoryT = 0; G.slow = 0; G.doorOpenT = 0; G.cine = null; G.whiteFlash = 0;
    P.x = 60; P.y = C.FLOOR - P.h; P.vx = 0; P.vy = 0; P.face = 1;
    P.atk = null; P.skill = null; P.inv = 1; P.dashT = 0; P.hurtT = 0;
    G.fade = 1;
    I.clear();

    const mus = R.zoneMusic();
    if (mus) A.music(mus);

    if (type === 'boss') {
      MD.UI.banner('최후의 방', '');
      MD.Enemies.spawn('boss', C.W - 200);
      R.cine('intro', 3.4);
    } else if (type === 'combat' || type === 'elite') {
      MD.UI.banner(type === 'elite' ? '정예의 방' : '제 ' + n + ' 방', type === 'elite' ? '강한 기운이 느껴진다' : (n === 1 ? '탈을 쓰고 어둠을 헤쳐라' : ''));
      initHazards();
      const z = MD.Enemies.zone();
      if (!G.zoneSeen[z] && MD.LORE.zone[z]) { G.zoneSeen[z] = 1; MD.UI.say(MD.LORE.narrator, MD.LORE.zone[z]); }
    } else {
      const nm = ({ shop: '떠돌이 장터', rest: '모닥불 쉼터', event: '기이한 기운' })[type];
      MD.UI.banner(nm, type === 'shop' ? '혼으로 물건을 산다' : type === 'rest' ? '잠시 숨을 돌린다' : '무언가가 기다린다');
      G.props = { kind: type, x: 470, t: 0, hold: 0, cool: false, used: false };
      if (type === 'shop') G.props.stock = buildShop();
      if (type === 'event') G.props.ev = EVENTS[(Math.random() * EVENTS.length) | 0];
      G.cleared = true;
      G.door = { x: C.W - 120, y: C.FLOOR - 110, w: 70, h: 110 };
      const rl = MD.LORE.room[type]; if (rl) MD.UI.say(rl[0], rl[1]);
    }
    if (n >= 2) MD.Meta.save();
    if (!opt.noSave && n >= 2 && type !== 'boss') R.saveRun();
  };

  /* ---------- 함정 ---------- */
  function initHazards() {
    const z = MD.Enemies.zone();
    if (z === 'ember') {
      const xs = U.shuffle([200, 340, 480, 620, 760]).slice(0, 3);
      xs.forEach((x, i) => G.hazards.push({ kind: 'geyser', x, t: -U.rnd(0, 2) - i * .6, cyc: 4.2 }));
    } else if (z === 'hall') {
      const xs = U.shuffle([180, 300, 420, 540, 660, 780]).slice(0, 3);
      xs.forEach((x, i) => G.hazards.push({ kind: 'spikes', x, w: 78, t: -i * .7, cyc: 4.4 }));
    } else if (z === 'crypt') {
      G.hazards.push({ kind: 'rocks', t: 1.5, next: U.rnd(2.2, 3.2) });
    }
  }
  function hazardUpdate(dt) {
    const P = G.P;
    for (const h of G.hazards) {
      h.t += dt;
      if (h.kind === 'rocks') {
        if (h.t >= h.next) {
          h.t = 0; h.next = U.rnd(2.2, 3.6);
          const x = U.clamp(P.x + P.w / 2 + U.rnd(-170, 170), 40, C.W - 40);
          G.ezones.push({ x: x - 24, y: C.FLOOR - 74, w: 48, h: 74, delay: 1.0, t: 0, dmg: 11, done: false, type: 'rock' });
        }
      } else if (h.kind === 'geyser') {
        const c = h.t % h.cyc;
        h.ph = c < 2.2 ? 0 : c < 3.0 ? 1 : 2;       // 0 잠잠, 1 경고, 2 분출
        if (h.ph === 2 && !P.dead && Math.abs(P.x + P.w / 2 - h.x) < 24 + P.w / 2 && P.y + P.h > C.FLOOR - 105) Cb.hurtPlayer(9, h.x);
        if (h.ph === 2 && Math.random() < dt * 40) Cb.burst(h.x + U.rnd(-10, 10), C.FLOOR - U.rnd(0, 110), 1, '#ff9a3c', 80, .5, 3);
        if (h.ph === 1 && !h.warned) { h.warned = true; }
        if (h.ph !== 1) h.warned = false;
        if (h.ph === 2 && !h.blast) { h.blast = true; A.sfx.boom(); }
        if (h.ph !== 2) h.blast = false;
      } else if (h.kind === 'spikes') {
        const c = h.t % h.cyc;
        h.ph = c < 2.3 ? 0 : c < 3.0 ? 1 : 2;
        if (h.ph === 2 && !P.dead && P.x + P.w > h.x - h.w / 2 && P.x < h.x + h.w / 2 && P.y + P.h > C.FLOOR - 28) Cb.hurtPlayer(10, h.x);
        if (h.ph === 2 && !h.stab) { h.stab = true; A.sfx.hit(); }
        if (h.ph !== 2) h.stab = false;
      }
    }
  }

  /* ---------- 웨이브 ---------- */
  function spawnWave(list, first) {
    const P = G.P, elite = R.roomType() === 'elite';
    let eliteIdx = -1;
    if (elite && first) eliteIdx = list.findIndex((t) => t === 'soldier' || t === 'brute' || t === 'archer');
    list.forEach((type, i) => {
      const d = MD.ETYPES[type];
      let x;
      if (d.boss) x = C.W - 200;
      else {
        const left = i % 2 === 0;
        x = left ? U.rnd(30, 120) : U.rnd(C.W - 120 - d.w, C.W - 30 - d.w);
        if (Math.abs(x - P.x) < 220) x = left ? C.W - 60 - d.w : 60;
      }
      const y = d.fly ? C.FLOOR - U.rnd(150, 240) : null;
      MD.Enemies.spawn(type, x, y, { elite: i === eliteIdx });
    });
  }

  /* ---------- 튜토리얼 ---------- */
  R.tutStart = () => {
    G.tut = { step: 0, moved: 0, lastX: G.P.x, atk: 0, t: 0, done: false };
    MD.UI.tutShow(0);
  };
  function tutUpdate(dt) {
    const T = G.tut, P = G.P;
    if (!T || T.done) return;
    T.t += dt;
    if (T.step === 0) {
      T.moved += Math.abs(P.x - T.lastX); T.lastX = P.x;
      if (T.moved > 240) tutNext();
    } else if (T.step === 1) {
      if (I.isPressed('jump')) T.jumped = true;
      if (T.jumped && P.onGround) tutNext();
    } else if (T.step === 2) {
      if (I.isPressed('atk')) T.atk++;
      if (T.atk >= 4) tutNext();
    } else if (T.step === 3) {
      if (I.isPressed('dash')) tutNext();
    } else if (T.step === 4) {
      if (I.isPressed('skill') && P.skcd[MD.Player.mask(P).id] > 0) tutNext();
    }
  }
  function tutNext() {
    const T = G.tut;
    T.step++; A.sfx.pickup();
    if (T.step >= 5) { T.done = true; MD.Meta.tut = true; MD.Meta.save(); MD.UI.tutShow(-1); MD.UI.toast('기본 조작을 모두 익혔다', 2.2); }
    else MD.UI.tutShow(T.step);
  }
  R.tutSkip = () => { if (G.tut && !G.tut.done) { G.tut.done = true; MD.Meta.tut = true; MD.Meta.save(); MD.UI.tutShow(-1); } };

  /* ---------- 갱신 ---------- */
  R.update = (dt) => {
    const P = G.P;
    if (G.victoryT > 0) {
      G.victoryT -= dt;
      if (G.victoryT <= 0) MD.Game.end(true);
      return;
    }
    tutUpdate(dt);
    const type = R.roomType();
    if (!G.cleared) {
      hazardUpdate(dt);
      const hold = G.tut && !G.tut.done && G.tut.step < 2;
      if (G.enemies.length === 0 && !hold) {
        G.waveDelay -= dt;
        if (G.waveDelay <= 0) {
          if (G.waveIdx < G.waves.length) { spawnWave(G.waves[G.waveIdx], G.waveIdx === 0); G.waveIdx++; G.waveDelay = .8; }
          else if (type !== 'boss') clearRoom();
        }
      }
    } else {
      if (G.props) propUpdate(dt);
      if (G.door && !P.dead) {
        if (U.overlap(G.door, P)) {
          G.doorT += dt;
          if (G.doorT > .3) R.leave();
        } else G.doorT = 0;
      }
    }
  };

  function clearRoom() {
    const P = G.P;
    G.cleared = true; G.hazards = [];
    G.door = { x: C.W - 120, y: C.FLOOR - 110, w: 70, h: 110 };
    const heal = Math.round(P.maxHp * (.12 + P.st.heal));
    P.hp = Math.min(P.maxHp, P.hp + heal);
    Cb.num(P.x + P.w / 2, P.y - 14, '+' + heal, '#7dffb0', 20);
    Cb.fx({ type: 'icon', key: 'heal_potion', x: P.x + P.w / 2, y: P.y - 30, rise: 46, life: 1.1, size: 34 });
    A.sfx.heal(); A.sfx.door();
    for (const o of G.pickups) o.mag = true;
    MD.UI.banner('방을 정리했다', '오른쪽 문으로 나아가라');
    MD.Meta.memAdd(P.masks[P.cur], 'c');
  }

  /* ---------- 연출 (보스 등장 / 단계 전환 / 처치) ---------- */
  R.cine = (type, dur, data) => {
    G.cine = { type, t: 0, dur, data: data || {}, ev: {} };
    I.clear();
  };
  R.cineUpdate = (dt) => {
    const c = G.cine, boss = G.enemies.find((e) => e.boss);
    const prev = c.t; c.t += dt;
    const at = (t, fn) => { if (prev < t && c.t >= t) fn(); };
    MD.Enemies.cineTick(dt);
    if (c.type === 'intro') {
      at(.01, () => { A.musicStop(.3); A.jingle('boss_intro'); });
      at(1.35, () => {
        A.sfx.roar(); Cb.shake(14); MD.Haptic(80); G.whiteFlash = .35;
        if (boss) Cb.fx({ type: 'ring', x: boss.x + boss.w / 2, y: boss.y + boss.h, r0: 10, r1: 360, life: .8, col: '#ff5a3c', flat: true });
        MD.UI.banner('탈의 군주', '어둠의 성을 지배하는 자');
      });
      at(1.5, () => MD.UI.say(MD.LORE.boss.intro, null, { hold: 800 }));
    } else if (c.type === 'phase') {
      const p3 = c.data.ph === 3;
      at(.01, () => { A.musicStop(.4); G.eprojs.length = 0; G.ezones.length = 0; });
      at(.55, () => { A.sfx.hit && A.sfx.hit(); Cb.shake(3); });
      at(1.15, () => { A.sfx.hit && A.sfx.hit(); Cb.shake(5); });
      at(1.75, () => {
        A.sfx.roar(); Cb.shake(p3 ? 18 : 14); MD.Haptic(80); G.whiteFlash = .55;
        if (boss) {
          const bx = boss.x + boss.w / 2;
          Cb.fx({ type: 'ring', x: bx, y: boss.y + boss.h - 40, r0: 10, r1: 420, life: .9, col: '#ff3c3c' });
          Cb.fx({ type: 'ring', x: bx, y: boss.y + boss.h - 40, r0: 10, r1: 260, life: .6, col: '#ffd27a' });
          Cb.burst(bx, boss.y + 40, 34, '#ff5a3c', 360, .9, 4);
        }
        MD.UI.banner(p3 ? '분 노' : '제 2 막', p3 ? '탈의 군주가 눈을 뜬다' : '탈의 군주의 눈이 붉게 빛난다');
      });
      at(2.0, () => MD.UI.say(p3 ? MD.LORE.boss.p3 : MD.LORE.boss.p2, null, { hold: 900 }));
    } else if (c.type === 'death') {
      at(1.3, () => { G.doorOpenT = .001; A.sfx.door(); Cb.shake(6); });
      at(2.2, () => A.jingle('victory'));
      at(.6, () => MD.UI.say(MD.LORE.boss.death, null, { hold: 900 }));
    }
    if (G.doorOpenT > 0) G.doorOpenT += dt;
    if (c.t >= c.dur) {
      G.cine = null;
      if (c.type === 'intro') A.music('boss');
      else if (c.type === 'phase') A.music(c.data.ph === 3 ? 'boss_p2' : 'boss');
      else if (c.type === 'death') { G.state = 'ending'; MD.UI.sayClear(); MD.UI.showVictory(); }
    }
  };

  R.onBossDead = () => {
    for (const e of G.enemies) if (!e.dead && !e.boss) Cb.kill(e);
    G.eprojs.length = 0; G.ezones.length = 0; G.pickups.length = 0;
    Cb.shake(16); G.whiteFlash = .6; G.slow = 1.3;
    A.musicStop(.6); MD.Haptic(120);
    MD.Meta.clearRun();
    if (G.P) MD.Meta.memAdd(G.P.masks[G.P.cur], 'l');
    R.cine('death', 4.0);
  };

  /* ---------- 상점 / 휴식 / 사건 ---------- */
  function buildShop() {
    const items = U.shuffle(MD.ITEMS.slice()), P = G.P;
    const avail = MD.maskPool().filter((id) => P.masks.indexOf(id) < 0);
    const out = [{ kind: 'item', id: items[0].id, price: 40 + G.room * 3 }];
    if (avail.length && Math.random() < .65) out.push({ kind: 'mask', id: avail[(Math.random() * avail.length) | 0], price: 90 });
    else out.push({ kind: 'item', id: items[1].id, price: 48 + G.room * 3 });
    out.push({ kind: 'heal', price: 25 + G.room * 2 });
    out.push({ kind: 'lv', price: 0 });
    return out;
  }
  const lvPrice = () => 40 + 30 * MD.Player.level(G.P, MD.Player.mask().id);

  function shopCards() {
    const P = G.P, st = G.props.stock;
    return st.map((s) => {
      const base = { price: s.price, sold: s.sold };
      if (s.kind === 'item') {
        const it = MD.ITEMS.find((x) => x.id === s.id);
        return Object.assign(base, { tag: '아이템', name: it.name, desc: it.desc, icon: 'item_' + s.id, glyph: it.glyph, act() { it.apply(P); P.items.push(it.id); s.sold = true; return true; } });
      }
      if (s.kind === 'mask') {
        const m = MD.MASKS[s.id];
        return Object.assign(base, { tag: '가면 · ' + m.tier, tagCol: m.tierColor, name: m.name, desc: m.desc, mask: s.id, act() { MD.Player.giveMask(s.id); s.sold = true; return true; } });
      }
      if (s.kind === 'heal') {
        return Object.assign(base, { tag: '소모품', name: '회복 물약', desc: '체력을 40% 회복한다', icon: 'heal_potion', act() { healP(.4); s.sold = true; return true; } });
      }
      const M = MD.Player.mask(), lv = MD.Player.level(P, M.id);
      return Object.assign(base, {
        price: lvPrice(), tag: '가면 단련', name: M.name + ' 단련', desc: lv >= 5 ? '이미 최고 단계입니다' : '공격력 +18% (Lv.' + lv + ' → Lv.' + (lv + 1) + ')', mask: M.id,
        dis: lv >= 5 ? '최고 단계' : '', act() { MD.Player.levelUp(M.id); return true; }
      });
    });
  }
  function healP(f) {
    const P = G.P, h = Math.round(P.maxHp * f);
    P.hp = Math.min(P.maxHp, P.hp + h);
    Cb.num(P.x + P.w / 2, P.y - 14, '+' + h, '#7dffb0', 20);
    A.sfx.heal();
  }

  const EVENTS = [
    { name: '피의 제단', text: '붉게 젖은 제단이 속삭인다. "대가를 치르면 힘을 주마."', opts: [
      { name: '피를 바친다', desc: '체력 20% 소모, 공격력 +12%', col: '#e0494f', dis: () => G.P.hp <= G.P.maxHp * .3 ? '체력 부족' : '', act() { const P = G.P; P.hp = Math.max(1, P.hp - Math.round(P.maxHp * .2)); P.st.dmgB += .12; Cb.burst(P.x, P.y, 16, '#c3303b', 260, .7, 3); A.sfx.hurt(); } },
      { name: '외면한다', desc: '아무 일도 일어나지 않는다', act() {} }
    ] },
    { name: '떠도는 영혼', text: '길 잃은 영혼이 손을 내민다. 무엇을 나눌까?', opts: [
      { name: '달래 준다', desc: '혼 +45', act() { G.P.gold += 45; G.runGold += 45; A.sfx.pickup(); } },
      { name: '기운을 빌린다', desc: '체력 30% 회복', act() { healP(.3); } },
      { name: '지나친다', desc: '아무 일도 일어나지 않는다', act() {} }
    ] },
    { name: '금이 간 항아리', text: '낡은 항아리 속에서 무언가가 달그락거린다.', opts: [
      { name: '깨뜨린다', desc: '절반의 확률로 혼 +60, 아니면 체력 -12', act() { const P = G.P; if (Math.random() < .5) { P.gold += 60; G.runGold += 60; A.sfx.pickup(); MD.UI.toast('혼 60을 얻었다', 2); } else { P.hp = Math.max(1, P.hp - 12); A.sfx.hurt(); MD.UI.toast('독이 퍼졌다! 체력 -12', 2); } } },
      { name: '지나간다', desc: '아무 일도 일어나지 않는다', act() {} }
    ] },
    { name: '수상한 상인', text: '두건을 쓴 상인이 속삭인다. "싸게 드리죠…"', opts: [
      { name: '혼 35을 낸다', desc: '무작위 아이템 1개', price: 35, act() { const it = MD.ITEMS[(Math.random() * MD.ITEMS.length) | 0]; it.apply(G.P); G.P.items.push(it.id); A.sfx.pick(); MD.UI.toast(it.name + ' 획득', 2); } },
      { name: '거절한다', desc: '아무 일도 일어나지 않는다', act() {} }
    ] },
    { name: '고요한 샘', text: '맑은 물이 솟는 샘. 마시면 기운이 돌 것 같다.', opts: [
      { name: '물을 마신다', desc: '체력 20% 회복, 최대 체력 +6', act() { G.P.maxHp += 6; healP(.2); } },
      { name: '가면을 담근다', desc: '현재 가면 Lv +1', act() { MD.Player.levelUp(MD.Player.mask().id); } }
    ] }
  ];

  function propUpdate(dt) {
    const p = G.props, P = G.P;
    p.t += dt;
    const near = Math.abs(P.x + P.w / 2 - p.x) < 52 && P.onGround;
    if (!near) { p.hold = 0; p.cool = false; return; }
    if (p.cool || (p.used && p.kind !== 'shop') || P.dead) return;
    p.hold += dt;
    if (p.hold > .45) { p.hold = 0; R.openProp(); }
  }

  R.openProp = () => {
    const p = G.props, P = G.P;
    p.cool = true; I.clear(); A.sfx.door();
    if (p.kind === 'shop') {
      G.state = 'shop';
      MD.UI.showChoice({
        title: '떠돌이 장터', sub: '혼으로 물건을 산다 · 1~4 구매 · Esc 나가기', cards: shopCards, keep: true,
        onClose() { G.state = 'play'; }
      });
    } else if (p.kind === 'rest') {
      G.state = 'shop';
      const M = MD.Player.mask();
      MD.UI.showChoice({
        title: '모닥불 쉼터', sub: '한 가지를 고른다', closeOnPick: true,
        cards: () => [
          { tag: '휴식', name: '불가에 앉는다', desc: '체력을 45% 회복한다', icon: 'heal_potion', act() { healP(.45); } },
          { tag: '단련', name: M.name + ' 단련', desc: MD.Player.level(P, M.id) >= 5 ? '이미 최고 단계입니다' : '현재 가면 Lv +1 (공격력 +18%)', mask: M.id, dis: MD.Player.level(P, M.id) >= 5 ? '최고 단계' : '', act() { MD.Player.levelUp(M.id); } },
          { tag: '정화', name: '몸을 단련한다', desc: '최대 체력 +12 (체력 12 회복)', icon: 'item_armor', glyph: '갑', act() { P.maxHp += 12; P.hp = Math.min(P.maxHp, P.hp + 12); A.sfx.heal(); } }
        ],
        onClose(picked) { if (picked) { p.used = true; } G.state = 'play'; }
      });
    } else {
      G.state = 'shop';
      const ev = p.ev;
      MD.UI.showChoice({
        title: ev.name, sub: ev.text, closeOnPick: true,
        cards: () => ev.opts.map((o) => ({ tag: '선택', name: o.name, desc: o.desc, tagCol: o.col, price: o.price || 0, dis: o.dis ? o.dis() : '', glyph: '?', act: o.act })),
        onClose(picked) { if (picked) p.used = true; G.state = 'play'; }
      });
    }
  };

  /* ---------- 방 이동 / 보상 ---------- */
  R.leave = () => {
    const type = R.roomType();
    I.clear();
    if (type === 'combat' || type === 'elite') {
      G.state = 'reward';
      MD.UI.showReward(R.makeChoices(type === 'elite'));
    } else {
      R.start(G.room + 1);
    }
  };

  R.makeChoices = (elite) => {
    const P = G.P, held = P.masks;
    const avail = MD.maskPool().filter((id) => held.indexOf(id) < 0);
    const out = [];
    if (avail.length && (G.room <= 2 || elite || Math.random() < .5)) {
      out.push({ kind: 'mask', id: avail[(Math.random() * avail.length) | 0] });
    } else if (!avail.length && Math.random() < .6) {
      out.push({ kind: 'lv', id: held[(Math.random() * 2) | 0] || held[0] });
    }
    const items = U.shuffle(MD.ITEMS.slice());
    while (out.length < 3) out.push({ kind: 'item', id: items.pop().id });
    return U.shuffle(out);
  };

  R.pick = (c) => {
    const P = G.P;
    if (c.kind === 'mask') MD.Player.giveMask(c.id);
    else if (c.kind === 'lv') MD.Player.levelUp(c.id);
    else {
      const it = MD.ITEMS.find((i) => i.id === c.id);
      it.apply(P); P.items.push(it.id);
    }
    A.sfx.pick();
    G.state = 'play';
    R.start(G.room + 1);
  };

  /* ---------- 이어하기 저장 ---------- */
  R.saveRun = () => {
    const P = G.P;
    if (!P) return;
    MD.Meta.saveRun({
      room: G.room, path: G.path, kills: G.kills, runT: G.runT, runGold: G.runGold,
      P: { hp: P.hp, maxHp: P.maxHp, masks: P.masks, cur: P.cur, items: P.items, gold: P.gold, mlv: P.mlv, st: P.st, dashCharges: 2 }
    });
  };
})();
