/* audio.js — 효과음과 배경음악. assets/audio 의 파일이 있으면 그것을, 없으면 WebAudio 합성음을 사용 */
(() => {
  const MD = window.MD;
  let AC = null, master = null, sfxG = null, bgmG = null;
  const bufs = {};              // 불러온 오디오 버퍼 (확장자 뺀 이름)
  let loading = false;
  let cur = null;               // 현재 음악 { name, g, src, synth }
  let want = null;              // 재생해야 할 음악 이름

  function applyVolumes() {
    if (!AC) return;
    const s = MD.Settings.data, t = AC.currentTime;
    master.gain.setTargetAtTime(s.mute ? 0 : s.master / 100, t, .03);
    sfxG.gain.setTargetAtTime(s.sfx / 100, t, .03);
    bgmG.gain.setTargetAtTime(s.bgm / 100 * .6, t, .08);
  }

  /* 파일은 페이지가 뜨자마자 받아 두고(prefetch), 해독은 첫 입력 후 하나씩 순서대로 한다 → 첫 화면이 버벅이지 않음 */
  const raw = {};
  function prefetch() {
    (MD.AUDIO_FILES || []).forEach((f) => {
      raw[f] = fetch('assets/audio/' + f).then((r) => (r.ok ? r.arrayBuffer() : Promise.reject())).catch(() => null);
    });
  }
  function loadFiles() {
    if (loading || !AC) return;
    loading = true;
    let chain = Promise.resolve();
    (MD.AUDIO_FILES || []).forEach((f) => {
      chain = chain.then(() => raw[f]).then((ab) => (ab ? new Promise((ok, no) => AC.decodeAudioData(ab, ok, no)) : null))
        .then((buf) => {
          if (!buf) return;
          bufs[f.replace(/\.[^.]+$/, '')] = buf;
          if (want && (!cur || cur.name !== want)) music(want, true);
        })
        .catch(() => { /* 파일이 없거나 해독 실패 → 합성음 사용 */ })
        .then(() => new Promise((r) => setTimeout(r, 30)));
    });
  }

  function ensure() {
    if (!AC) {
      try {
        AC = new (window.AudioContext || window.webkitAudioContext)();
        master = AC.createGain(); sfxG = AC.createGain(); bgmG = AC.createGain();
        sfxG.connect(master); bgmG.connect(master); master.connect(AC.destination);
        applyVolumes(); loadFiles();
      } catch (e) { AC = null; }
    }
    if (AC && AC.state === 'suspended') { try { AC.resume(); } catch (e) { /* 무시 */ } }
  }

  function tone(f, d, type, v, slide, dest, delay) {
    if (!AC) return;
    try {
      const t = AC.currentTime + (delay || 0), o = AC.createOscillator(), g = AC.createGain();
      o.type = type || 'square';
      o.frequency.setValueAtTime(f, t);
      if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, f + slide), t + d);
      g.gain.setValueAtTime(v || .04, t);
      g.gain.exponentialRampToValueAtTime(.0001, t + d);
      o.connect(g); g.connect(dest || sfxG);
      o.start(t); o.stop(t + d + .02);
    } catch (e) { /* 무시 */ }
  }
  function noise(d, v, hp, dest, delay) {
    if (!AC) return;
    try {
      const t = AC.currentTime + (delay || 0), n = Math.max(1, (AC.sampleRate * d) | 0);
      const b = AC.createBuffer(1, n, AC.sampleRate), a = b.getChannelData(0);
      for (let i = 0; i < n; i++) a[i] = (Math.random() * 2 - 1) * (1 - i / n);
      const s = AC.createBufferSource(), g = AC.createGain(), f = AC.createBiquadFilter();
      s.buffer = b; f.type = 'highpass'; f.frequency.value = hp || 800;
      g.gain.setValueAtTime(v || .05, t); g.gain.exponentialRampToValueAtTime(.0001, t + d);
      s.connect(f); f.connect(g); g.connect(dest || sfxG); s.start(t);
    } catch (e) { /* 무시 */ }
  }

  /* 파일이 있으면 재생하고 true */
  function play(name, vol, rate) {
    const b = bufs[name];
    if (!AC || !b) return false;
    try {
      const s = AC.createBufferSource(), g = AC.createGain();
      s.buffer = b; s.playbackRate.value = (rate || 1) * (.96 + Math.random() * .08);
      g.gain.value = vol == null ? 1 : vol;
      s.connect(g); g.connect(sfxG); s.start();
    } catch (e) { return false; }
    return true;
  }
  const P = (name, fb, vol) => () => { if (!play(name, vol)) fb(); };
  const comboIdx = { n: 0 };

  const sfx = {
    swing: (n) => {
      const k = Math.min(3, Math.max(1, n || 1));
      if (!play('sfx_swing' + k)) { noise(.08, .03, 1500); tone(340 - k * 30, .07 + k * .01, 'sawtooth', .03, -170); }
    },
    hit: P('sfx_hit', () => { noise(.06, .05, 1200); tone(190, .08, 'square', .045, -90); }),
    crit: P('sfx_crit', () => { noise(.1, .06, 900); tone(420, .1, 'square', .045, -120); tone(210, .12, 'sawtooth', .035, -100); }),
    jump: P('sfx_jump', () => tone(260, .1, 'square', .025, 220)),
    land: P('sfx_land', () => noise(.07, .03, 300), .8),
    dash: P('sfx_dash', () => { noise(.12, .035, 2000); tone(520, .12, 'triangle', .04, -380); }),
    hurt: P('sfx_hurt', () => { noise(.12, .05, 300); tone(140, .25, 'sawtooth', .06, -90); }),
    skill: (id) => {
      if (play('sfx_skill_' + id)) return;
      if (id === 'dokkaebi') { noise(.4, .07, 120); tone(70, .45, 'sawtooth', .07, -30); }
      else if (id === 'fox') { noise(.25, .04, 1800); tone(600, .3, 'triangle', .04, 500); }
      else if (id === 'dosa') { noise(.7, .02, 3000); tone(900, .5, 'triangle', .02, 400); }
      else { noise(.15, .04, 1500); tone(280, .25, 'sawtooth', .045, 300); }
    },
    swap: P('sfx_swap', () => { tone(400, .08, 'triangle', .045, 300); setTimeout(() => tone(600, .1, 'triangle', .045, 200), 70); }),
    kill: P('sfx_kill', () => { noise(.2, .05, 500); tone(120, .18, 'square', .05, -60); }),
    pick: P('sfx_ui_confirm', () => { tone(520, .08, 'triangle', .045); setTimeout(() => tone(780, .14, 'triangle', .045), 80); }),
    shoot: P('sfx_shoot', () => tone(620, .07, 'square', .02, -260)),
    boom: P('sfx_skill_dokkaebi', () => { noise(.4, .07, 100); tone(80, .35, 'sawtooth', .07, -40); }),
    type: () => { if (!play('sfx_type', .6)) tone(500 + Math.random() * 200, .035, 'square', .016, -60); },
    click: P('sfx_ui_click', () => tone(700, .04, 'square', .02, -200)),
    select: P('sfx_ui_move', () => tone(480, .05, 'triangle', .025, 120)),
    back: P('sfx_ui_back', () => tone(380, .06, 'triangle', .025, -80)),
    heal: P('sfx_heal', () => { tone(660, .12, 'triangle', .04); tone(990, .2, 'triangle', .035, 0, null, .08); }),
    pickup: P('sfx_pickup', () => tone(1100, .06, 'triangle', .03, 300), .7),
    buy: P('sfx_pickup', () => { tone(900, .07, 'square', .03); tone(1300, .1, 'square', .03, 0, null, .07); }),
    deny: () => tone(150, .15, 'square', .04, -40),
    door: P('sfx_door_open', () => { noise(.5, .05, 200); tone(180, .6, 'sawtooth', .04, 200); }),
    roar: P('sfx_boss_roar', () => { noise(1.2, .08, 100); tone(90, 1.4, 'sawtooth', .08, -40); tone(130, 1.2, 'square', .04, -60); }),
    bossSwing: P('sfx_boss_swing', () => { noise(.25, .06, 600); tone(200, .3, 'sawtooth', .05, -120); }),
    bossSlam: P('sfx_boss_slam', () => { noise(.8, .1, 80); tone(60, .8, 'sawtooth', .09, -25); }),
    bossVolley: P('sfx_boss_volley', () => { noise(.3, .05, 2000); tone(500, .35, 'sawtooth', .04, 400); }),
    bossDie: P('sfx_boss_die', () => { noise(2, .09, 80); tone(100, 2, 'sawtooth', .08, -70); })
  };

  /* ---------- 합성 배경음 (파일이 없을 때) ---------- */
  const SCALES = {
    minor: [146.83, 174.61, 196, 220, 261.63, 293.66, 349.23],
    low: [98, 116.5, 130.8, 155.6, 196, 233],
    major: [261.63, 329.63, 392, 523.25, 659.25]
  };
  const SYN = {
    menu: { dr: [55, 82.4], sc: 'minor', iv: 950, w: 'triangle', p: .3 },
    castle: { dr: [55, 55.4, 82.4], sc: 'minor', iv: 700, w: 'triangle', p: .35 },
    crypt: { dr: [49, 73.4], sc: 'low', iv: 1150, w: 'sine', p: .4, bell: true },
    ember: { dr: [65.4, 98], sc: 'minor', iv: 380, w: 'sawtooth', p: .2, kick: 480, v: .028 },
    hall: { dr: [41.2, 61.7, 92.5], sc: 'low', iv: 1400, w: 'triangle', p: .5, bell: true },
    boss: { dr: [55, 58.3, 110], sc: 'minor', iv: 260, w: 'sawtooth', p: .15, kick: 340, v: .03 },
    boss_p2: { dr: [55, 58.3, 110], sc: 'minor', iv: 200, w: 'sawtooth', p: .1, kick: 260, v: .034 },
    reward: { dr: [65.4, 98], sc: 'major', iv: 600, w: 'triangle', p: .25 }
  };
  function synthMusic(name, g) {
    const c = SYN[name] || SYN.castle, osc = [];
    try {
      c.dr.forEach((f, i) => {
        const o = AC.createOscillator(), gg = AC.createGain();
        o.type = 'sine'; o.frequency.value = f; gg.gain.value = i === 2 ? .035 : .06;
        o.connect(gg); gg.connect(g); o.start(); osc.push(o);
      });
    } catch (e) { /* 무시 */ }
    const sc = SCALES[c.sc];
    const t1 = setInterval(() => {
      if (Math.random() < c.p) return;
      const f = sc[(Math.random() * sc.length) | 0] * (Math.random() < .25 ? .5 : 1);
      tone(f, c.iv / 1000 * 2.4, c.w, c.v || .05, 0, g);
      if (c.bell && Math.random() < .3) tone(f * 4, .9, 'sine', .018, 0, g);
    }, c.iv);
    let t2 = 0;
    if (c.kick) t2 = setInterval(() => { tone(90, .12, 'sine', .08, -50, g); if (Math.random() < .4) noise(.05, .02, 3000, g); }, c.kick);
    return { stop() { clearInterval(t1); if (t2) clearInterval(t2); osc.forEach((o) => { try { o.stop(); } catch (e) { /* 무시 */ } }); } };
  }

  function killMusic(m, fade) {
    if (!m) return;
    const t = AC.currentTime;
    try { m.g.gain.cancelScheduledValues(t); m.g.gain.setValueAtTime(m.g.gain.value, t); m.g.gain.linearRampToValueAtTime(0, t + fade); } catch (e) { /* 무시 */ }
    setTimeout(() => {
      try { if (m.src) m.src.stop(); } catch (e) { /* 무시 */ }
      if (m.synth) m.synth.stop();
      try { m.g.disconnect(); } catch (e) { /* 무시 */ }
    }, fade * 1000 + 80);
  }

  /* 음악 전환 (이미 같은 곡이면 무시) */
  function music(name, force) {
    want = name;
    if (!AC) return;
    if (cur && cur.name === name && !force) return;
    const hasFile = !!(bufs['bgm_' + name] || (name === 'boss_p2' && bufs.bgm_boss) || (name === 'hall' && bufs.bgm_ember));
    if (cur && cur.name === name && cur.file === hasFile) return;
    killMusic(cur, .9);
    const g = AC.createGain();
    g.gain.value = 0; g.connect(bgmG);
    const m = { name, g, file: hasFile };
    const t = AC.currentTime;
    if (hasFile) {
      const s = AC.createBufferSource();
      s.buffer = bufs['bgm_' + name] || (name === 'hall' ? bufs.bgm_ember : bufs.bgm_boss); s.loop = true; s.connect(g); s.start();
      m.src = s; g.gain.linearRampToValueAtTime(.95, t + .9);
    } else {
      m.synth = synthMusic(name, g);
      g.gain.linearRampToValueAtTime(1, t + .9);
    }
    cur = m;
  }
  function musicStop(fade) { want = null; if (AC && cur) { killMusic(cur, fade == null ? .6 : fade); cur = null; } }

  /* 짧은 연출음 (승리/패배/보스 등장) */
  function jingle(name) {
    if (!AC) return;
    if (play('jingle_' + name, 1)) return;
    if (name === 'victory') [523, 659, 784, 1046].forEach((f, i) => tone(f, .5, 'triangle', .05, 0, null, i * .14));
    else if (name === 'defeat') [330, 262, 196, 130].forEach((f, i) => tone(f, .6, 'sawtooth', .04, -20, null, i * .25));
    else if (name === 'boss_intro') { noise(1, .08, 100); tone(70, 1.3, 'sawtooth', .08, -20); }
  }

  /* 구 인터페이스 호환 */
  function bgmStart() { ensure(); if (AC) music(want || 'menu'); }
  function bgmStop() { musicStop(); }

  prefetch();
  MD.Audio = { ensure, applyVolumes, sfx, music, musicStop, jingle, bgmStart, bgmStop, noise, tone, has: (n) => !!bufs[n] };
})();
