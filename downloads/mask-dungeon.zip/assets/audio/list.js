/* 오디오 파일 목록: 파일을 assets/audio 에 넣고 여기에 이름(확장자 포함)을 적으면 자동으로 사용됩니다.
   없는 항목은 코드로 만든 합성음으로 대체됩니다. 예: 'sfx_hit.ogg', 'bgm_castle.mp3' */
window.MD = window.MD || {};
MD.AUDIO_FILES = ['bgm_menu.mp3', 'bgm_castle.mp3', 'bgm_crypt.mp3', 'bgm_ember.mp3','bgm_hall.mp3', 'bgm_boss.mp3', 'bgm_boss_p2.mp3', 'bgm_reward.mp3', 'jingle_boss_intro.mp3', 'jingle_victory.mp3', 'jingle_defeat.mp3'];
