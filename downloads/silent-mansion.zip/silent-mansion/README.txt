실행: 이 폴더에서 `npx serve` (또는 python3 -m http.server 8000) 후 브라우저로 접속.
Quest: 같은 서버를 HTTPS 주소 또는 adb reverse tcp:8000 tcp:8000 으로 열기.
file:// 로 직접 열면 동작하지 않습니다.

[BGM] assets/audio/ 의 mp3 6개가 장면별로 재생됩니다 (mansion, cellar, bedroom, outside, end_good, end_bad).
파일을 같은 이름으로 바꿔 넣으면 그대로 교체됩니다. 파일이 없으면 코드로 만든 BGM이 대신 나옵니다.

[뒷마당] 부엌 동쪽 벽의 뒷문(열쇠걸이판의 '뒷문' 열쇠)으로 나가면 정원·우물·창고·박 집사의 별채가 있습니다. 새 엔딩 '완전한 진실 — 열두 번째 편지'가 추가되었습니다.
