<?php

namespace anaf2197\EasterEgg;

use pocketmine\item\Item;
use pocketmine\nbt\BigEndianNbtSerializer;
use pocketmine\nbt\TreeRoot;
use pocketmine\player\Player;
use anaf2197\economyapi\EconomyAPI;

class EasterEggUtill
{

    public const DAILY_EGG = 0;
    public const ONCE_EGG = 1;
    public const UNLIMITED_EGG = 2;

    private string $positionId;
    private string $name;
    private int $type;
    private array $rewards;
    private array $clearList;
    private ?string $teleportCommand;
    private bool $showBroadcastMessage;

    public function __construct(string $positionId, string $name, int $type, array $rewards, array $clearList, ?string $teleportCommand = null, bool $showBroadcastMessage = true)
    {
        $this->positionId = $positionId;
        $this->name = $name;
        $this->type = $type;
        $this->rewards = $rewards;
        $this->clearList = $clearList;
        $this->teleportCommand = $teleportCommand;
        $this->showBroadcastMessage = $showBroadcastMessage;
    }

    public static function jsonDeSerialize(string $serialize): self
    {
        $data = json_decode($serialize, true);
        $rewards = [];
        foreach ($data["rewards"] as $rewardData) {
            switch ($rewardData["type"]) {
                case "item" :
                    $rewards[] = self::ItemDataDeserialize($rewardData["reward"]);
                    break;

                case "money" :
                    $rewards[] = $rewardData["reward"];
                    break;
            }
        }
        return new self($data["position_id"], $data["name"], $data["type"], $rewards, $data["clear_list"], $data["teleport_command"] ?? null, $data["show_broadcast_message"] ?? true);
    }

    public function getPositionId(): string
    {
        return $this->positionId;
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function getType(): int
    {
        return $this->type;
    }

    public function getTeleportCommand(): ?string
    {
        return $this->teleportCommand;
    }

    public function isBroadcastMessageEnabled(): bool
    {
        return $this->showBroadcastMessage;
    }

    public function toggleBroadcastMessage(): void
    {
        $this->showBroadcastMessage = !$this->showBroadcastMessage;
    }

    public function getRewardNames(bool $toString = false): array|string
    {
        $rewardNames = [];
        foreach ($this->rewards as $reward) {
            if ($reward instanceof Item) $rewardNames[] = "{$reward->getName()}, {$reward->getCount()}개";
            else $rewardNames[] = "{$reward}원";
        }
        if ($toString) return implode("\n", $rewardNames);
        else return $rewardNames;
    }

    public function addReward($reward): void
    {
        $this->rewards[] = $reward;
    }
    public function removeReward(int $index) : void{
        unset($this->rewards[$index]);
        $this->rewards = array_values($this->rewards);
    }

    public function hasClearedBefore(Player $player) : bool{
        if($this->type == self::UNLIMITED_EGG) return false;
        if($this->type == self::DAILY_EGG){
            if(isset($this->clearList[strtolower($player->getName())])) return $this->clearList[strtolower($player->getName())] == date("Y-m-d");
            else return false;
        } else return isset($this->clearList[strtolower($player->getName())]);
    }

    public function clear(Player $player) : void{
        if($this->type !== self::UNLIMITED_EGG){
            $this->clearList[strtolower($player->getName())] = date("Y-m-d");
        }
        $player->sendMessage(EasterEgg::PREFIX . $this->name . ' §r§8이스터에그를 발견하셨습니다.');
        foreach($this->rewards as $reward){
            if($reward instanceof Item){
                $player->getInventory()->addItem($reward);
                $player->sendMessage(EasterEgg::PREFIX . "  + {$reward->getName()}, {$reward->getCount()}개");
            } else{
                EconomyAPI::getInstance()->addMoney($player, $reward);
                $player->sendMessage(EasterEgg::PREFIX . "  + {$reward}원");
            }
        }
        if($this->teleportCommand !== null){
            $player->getServer()->dispatchCommand($player, $this->teleportCommand);
        }
    }

    public function shouldBroadcast() : bool{
        return $this->showBroadcastMessage;
    }

    public function jsonSerialize() : string{
        $rewards = [];
        foreach($this->rewards as $reward){
            if($reward instanceof Item) $rewards[] = ["type" => "item", "reward" => self::ItemDataSerialize($reward)];
            else $rewards[] = ["type" => "money", "reward" => $reward];
        }
        return json_encode(["position_id" => $this->positionId, "name" => $this->name, "type" => $this->type, "rewards" => $rewards, "clear_list" => $this->clearList, "teleport_command" => $this->teleportCommand, "show_broadcast_message" => $this->showBroadcastMessage]);
    }

    public static function ItemDataSerialize(Item $data): string
    {
        return base64_encode((new BigEndianNbtSerializer())->write(new TreeRoot($data->nbtSerialize())));
    }

    public static function ItemDataDeserialize(string $data): Item
    {
        return Item::nbtDeserialize((new BigEndianNbtSerializer())->read(base64_decode($data))->mustGetCompoundTag());
    }
}