<?php

namespace anaf2197\EasterEgg;

use anaf2197\EasterEgg\Command\EasterEggCommand;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\utils\Config;
use pocketmine\event\player\PlayerInteractEvent;
use anaf2197\EasterEgg\EventListener\EventListener;

class EasterEgg extends PluginBase implements Listener {

    private Config $db;
    private array $data;
    private array $eggs = [];

    protected static self $instance;
    public const PREFIX = '§l§d[이스터에그] §r§8';

    public function onLoad() : void{
        self::$instance = $this;
    }

    public static function getInstance() : self{
        return static::$instance;
    }

    protected function onEnable() : void{
        $this->getServer()->getCommandMap()->register("EasterEgg_Command", new EasterEggCommand());
        $this->getServer()->getPluginManager()->registerEvents(new EventListener(), $this);
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->db = new Config($this->getDataFolder() . "Data.yml", Config::YAML);
        $this->data = $this->db->getAll();

        foreach($this->data as $positionId => $eggData) $this->eggs[$positionId] = EasterEggUtill::jsonDeSerialize($eggData);
    }

    protected function onDisable() : void{
        $this->data = [];
        foreach($this->eggs as $egg) $this->data[$egg->getPositionId()] = $egg->jsonSerialize();
        $this->db->setAll($this->data);
        $this->db->save();
    }

    public function getAllEggs() : array{
        return array_values($this->eggs);
    }

    public function getEgg(string $position2str) : ?EasterEggUtill{
        return $this->eggs[$position2str] ?? null;
    }

    public function addEgg(EasterEggUtill $egg) : void{
        $this->eggs[$egg->getPositionId()] = $egg;
    }

    public function removeEgg(EasterEggUtill $egg) : void{
        unset($this->eggs[$egg->getPositionId()]);
    }

    public function onInteract(PlayerInteractEvent $event) : void{
        $player = $event->getPlayer();
        $egg = $this->getEgg($event->getBlock()->getPosition()->__toString());
        if($egg != null){
            if($egg->hasClearedBefore($player)){
                if($egg->getType() == EasterEggUtill::DAILY_EGG) $player->sendMessage(self::PREFIX . "해당 이스터에그는 오늘 이미 찾으신 이스터에그입니다, 내일 다시 시도해 주세요.");
                else $player->sendMessage(self::PREFIX . '해당 이스터에그는 이미 찾으신 이스터에그입니다.');
            } else{
                $egg->clear($player);
                $this->getServer()->broadcastMessage(self::PREFIX . $player->getName() . '§r§8님이 [' . $egg->getName() . '§r§8] 이스터에그를 발견하셨습니다.');
            }
        }
    }
}
