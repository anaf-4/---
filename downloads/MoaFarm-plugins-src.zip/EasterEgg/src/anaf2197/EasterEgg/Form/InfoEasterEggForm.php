<?php

namespace anaf2197\EasterEgg\Form;

use pocketmine\form\Form;
use pocketmine\player\Player;
use anaf2197\EasterEgg\EasterEgg;
use anaf2197\EasterEgg\EasterEggUtill;

class InfoEasterEggForm implements Form{

    private EasterEggUtill $egg;

    public function __construct(EasterEggUtill $egg) {
        $this->egg = $egg;
    }

    public function jsonSerialize() : array{
        $arr = [];

        $arr[] = array("text" => "이스터에그 제거\n해당 이스터에그를 제거합니다.");
        $arr[] = array("text" => "보상 제거\n보상을 제거합니다.");
        $arr[] = array("text" => "아이템 보상 추가\n현재 들고있는 아이템을 보상으로 추가합니다.");
        $arr[] = array("text" => "돈 보상 추가\n돈 보상을 추가합니다.");
        $arr[] = array("text" => "서버 브로드캐스트 " . ($this->egg->isBroadcastMessageEnabled() ? "§a[켜짐]" : "§c[꺼짐]") . "\n전체 서버에 발견 알림");

        $broadcastStatus = $this->egg->isBroadcastMessageEnabled() ? "§a켜짐" : "§c꺼짐";

        return [
            "type" => "form",
            "title" => "이스터에그 정보",
            "content" => "이름 : {$this->egg->getName()}\n위치 : {$this->egg->getPositionId()}\n타입 : " . match($this->egg->getType()) { EasterEggUtill::DAILY_EGG => "일일", EasterEggUtill::ONCE_EGG => "일회용", default => "제한없음" } . "\n이동 명령어 : " . ($this->egg->getTeleportCommand() !== null ? $this->egg->getTeleportCommand() : "없음") . "\n브로드캐스트 : {$broadcastStatus}§r\n보상 : \n{$this->egg->getRewardNames(true)}",
            "buttons" => $arr
        ];
    }

    public function handleResponse(Player $player, $data) : void{
        if(is_null($data))
            return;

        match ($data) {
            0 => $this->handleRemoveEgg($player),
            1 => $this->handleRemoveReward($player),
            2 => $this->handleAddItemReward($player),
            3 => $this->handleAddMoneyReward($player),
            4 => $this->handleToggleBroadcastMessage($player),
            default => null,
        };
    }

    private function handleRemoveEgg(Player $player): void {
        EasterEgg::getInstance()->removeEgg($this->egg);
        $player->sendMessage(EasterEgg::PREFIX . "해당 이스터에그를 제거하였습니다.");
    }

    private function handleRemoveReward(Player $player): void {
        $player->sendForm(new RemoveEasterEggForm($this->egg));
    }

    private function handleAddItemReward(Player $player): void {
        if ($player->getInventory()->getItemInHand()->getTypeId() == 0) {
            $player->sendMessage(EasterEgg::PREFIX . "공기는 보상으로 추가할 수 없습니다.");
        } else {
            $this->egg->addReward($player->getInventory()->getItemInHand());
            $player->sendMessage(EasterEgg::PREFIX . "해당 아이템을 보상으로 추가하였습니다.");
        }
    }

    private function handleAddMoneyReward(Player $player): void {
        $player->sendForm(new AddMoneyForm($this->egg));
    }

    private function handleToggleBroadcastMessage(Player $player): void {
        $this->egg->toggleBroadcastMessage();
        $status = $this->egg->isBroadcastMessageEnabled() ? "켜짐" : "꺼짐";
        $player->sendMessage(EasterEgg::PREFIX . "서버 브로드캐스트를 {$status}으로 변경하였습니다.");
    }
}