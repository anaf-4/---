<?php

namespace anaf2197\EasterEgg\Form;

use pocketmine\form\Form;
use pocketmine\player\Player;
use anaf2197\EasterEgg\EasterEgg;
use anaf2197\EasterEgg\EasterEggUtill;

class RemoveEasterEggForm implements Form {

    private EasterEggUtill $egg;

    public function __construct(EasterEggUtill $egg){
        $this->egg = $egg;
    }

    public function jsonSerialize() : array{
        $arr = [];

        foreach($this->egg->getRewardNames() as $reward) $arr[] = array("text" => $reward);

        return [
            "type" => "form",
            "title" => "이스터에그 보상 제거",
            "content" => "제거할 보상을 선택해 주세요.",
            "buttons" => $arr
        ];
    }

    public function handleResponse(Player $player, $data) : void{
        if(is_null($data))
            return;

        $this->egg->removeReward($data);
        $player->sendMessage(EasterEgg::PREFIX . "해당 보상을 제거하였습니다.");
    }
}
