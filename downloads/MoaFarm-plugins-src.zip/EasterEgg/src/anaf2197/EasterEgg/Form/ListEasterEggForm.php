<?php

namespace anaf2197\EasterEgg\Form;

use pocketmine\form\Form;
use pocketmine\player\Player;
use anaf2197\EasterEgg\EasterEgg;

class ListEasterEggForm implements Form {

    public function jsonSerialize() : array{
        $arr = [];

        foreach(EasterEgg::getInstance()->getAllEggs() as $egg){
            $arr[] = array("text" => $egg->getName());
        }

        return [
            "type" => "form",
            "title" => "이스터에그 목록",
            "content" => "",
            "buttons" => $arr
        ];
    }

    public function handleResponse(Player $player, $data) : void{
        if(is_null($data))
            return;

        $player->sendForm(new InfoEasterEggForm(EasterEgg::getInstance()->getAllEggs()[$data]));
    }
}