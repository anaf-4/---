<?php

namespace anaf2197\EasterEgg\Form;

use pocketmine\form\Form;
use pocketmine\player\Player;
use anaf2197\EasterEgg\EasterEggUtill;
use anaf2197\EasterEgg\EventListener\EventListener;

class CreateEasterEggForm implements Form {

    public function jsonSerialize() : array{
        return [
            "type" => "custom_form",
            "title" => "이스터에그 생성",
            "content" => [
                [
                    "type" => "input",
                    "text" => "이름"
                ],
                [
                    "type" => "dropdown",
                    "text" => "타입",
                    "options" => ["일일", "일회용", "제한없음"]
                ],
                [
                    "type" => "dropdown",
                    "text" => "이동 방식",
                    "options" => ["이동 없음", "명령어로 이동"]
                ],
                [
                    "type" => "input",
                    "text" => "이동 명령어 (이동 방식이 '명령어로 이동'일 때만 입력, / 제외)",
                    "placeholder" => "예: spawn, warp lobby"
                ]
            ]
        ];
    }

    public function handleResponse(Player $player, $data) : void{
        if (is_null($data)) {
            return;
        }

        $type = match ($data[1]) {
            0 => EasterEggUtill::DAILY_EGG,
            1 => EasterEggUtill::ONCE_EGG,
            default => EasterEggUtill::UNLIMITED_EGG
        };

        $teleportCommand = null;
        if ($data[2] === 1) {
            $cmd = trim($data[3]);
            if ($cmd !== "") {
                $teleportCommand = $cmd;
            } else {
                $player->sendMessage(\MINSEO\EasterEgg\EasterEgg::PREFIX . "이동 명령어를 입력하지 않아 이동 없음으로 설정됩니다.");
            }
        }

        EventListener::addCreator($player, $data[0], $type, $teleportCommand);
    }
}