<?php

namespace anaf2197\EasterEgg\Form;

use pocketmine\form\Form;
use pocketmine\player\Player;
use anaf2197\EasterEgg\EasterEgg;
use anaf2197\EasterEgg\EasterEggUtill;

class AddMoneyForm implements Form {

    private EasterEggUtill $egg;

    public function __construct(EasterEggUtill $egg){
        $this->egg = $egg;
    }

    public function jsonSerialize() : array
    {
        return [
            "type" => "custom_form",
            "title" => "이스터에그 돈 보상추가",
            "content" => [
                [
                    "type" => "input",
                    "text" => "금액"
                ]
            ]
        ];
    }

    public function handleResponse(Player $player, $data) : void{
        if(is_null($data))
            return;

        if((int)$data[0] <= 0){
            $player->sendMessage(EasterEgg::PREFIX . "금액은 1이상의 금액을 입력해 주세요.");
            return;
        }

        $this->egg->addReward((int)$data[0]);
        $player->sendMessage(EasterEgg::PREFIX . "이스터에그의 보상에 " . ((int)$data[0]) . "원을 추가하였습니다.");
    }
}
