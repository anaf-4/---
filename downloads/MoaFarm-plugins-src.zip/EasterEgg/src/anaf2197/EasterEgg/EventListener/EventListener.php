<?php

namespace anaf2197\EasterEgg\EventListener;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\player\Player;
use anaf2197\EasterEgg\EasterEgg;
use anaf2197\EasterEgg\EasterEggUtill;

class EventListener implements Listener {

    private static array $creators = [];

    public static function addCreator(Player $player, string $name, int $type, ?string $teleportCommand = null) : void{
        self::$creators[strtolower($player->getName())] = ["name" => $name, "type" => $type, "teleport_command" => $teleportCommand];
        $player->sendMessage(EasterEgg::PREFIX . "이스터에그로 지정할 블록을 터치하세요.");
    }

    public function onInteract(PlayerInteractEvent $event) : void{
        $player = $event->getPlayer();
        $name = strtolower($player->getName());
        if(isset(self::$creators[$name])){
            if(EasterEgg::getInstance()->getEgg($event->getBlock()->getPosition()->__toString()) != null){
                $player->sendMessage(EasterEgg::PREFIX . "해당 위치에는 이미 이스터에그가 존재합니다.");
                return;
            }
            EasterEgg::getInstance()->addEgg(new EasterEggUtill($event->getBlock()->getPosition()->__toString(), self::$creators[$name]["name"], self::$creators[$name]["type"], [], [], self::$creators[$name]["teleport_command"]));
            unset(self::$creators[$name]);
            $player->sendMessage(EasterEgg::PREFIX . "이스터에그를 생성하였습니다.");
            $event->cancel();
        }
    }
}