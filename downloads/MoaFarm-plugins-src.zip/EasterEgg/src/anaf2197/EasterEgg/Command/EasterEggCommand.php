<?php

namespace anaf2197\EasterEgg\Command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use anaf2197\EasterEgg\EasterEgg;
use anaf2197\EasterEgg\Form\CreateEasterEggForm;
use anaf2197\EasterEgg\Form\ListEasterEggForm;

class EasterEggCommand extends Command{

    public function __construct(){
        parent::__construct("이스터에그", "이스터에그 관련 명령어입니다.", "/이스터에그");
        $this->setPermission(DefaultPermissions::ROOT_OPERATOR);
    }

    public function execute(CommandSender $sender, string $command, array $args) : void{

        if (!isset($args[0])) {
            $this->sendUsage($sender);
            return;
        }

        match ($args[0]) {
            "생성" => $sender->sendForm(new CreateEasterEggForm()),
            "목록" => $sender->sendForm(new ListEasterEggForm()),
            default => $this->sendUsage($sender),
        };
    }

    private function sendUsage(CommandSender $sender) : void {
        $sender->sendMessage(EasterEgg::PREFIX . "/이스터에그 생성");
        $sender->sendMessage(EasterEgg::PREFIX . "/이스터에그 목록");
    }
}
