<?php

declare(strict_types=1);

namespace anaf2197\utils\color;

use pocketmine\color\Color;

class RandomBrightnessColor implements EffectColor {
    public function __construct(private int $minBrightness, private int $maxBrightness) {
    }

    public function asColor(): Color {
        $brightness = mt_rand($this->minBrightness, $this->maxBrightness);
        return new Color($brightness, $brightness, $brightness);
    }
}