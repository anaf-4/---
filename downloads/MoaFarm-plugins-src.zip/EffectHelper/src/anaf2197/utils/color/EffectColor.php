<?php

declare(strict_types=1);

namespace anaf2197\utils\color;

use pocketmine\color\Color;

interface EffectColor {
    public function asColor(): Color;
}