<?php

declare(strict_types=1);

namespace anaf2197\utils;

interface RotationTypes {
    public const ROTATION_ROLL = 0;
    public const ROTATION_YAW = 1;
    public const ROTATION_PITCH = 2;
}