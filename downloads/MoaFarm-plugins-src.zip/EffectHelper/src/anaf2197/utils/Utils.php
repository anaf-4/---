<?php

declare(strict_types=1);

namespace anaf2197\utils;

use http\Exception\InvalidArgumentException;
use pocketmine\math\Vector3;

class Utils implements RotationTypes {
    public static function random(float|int $min, float|int $max): float {
        $max -= $min;
        $value = mt_rand() / mt_getrandmax();
        return $value * $max + $min;
    }

    public static function getRotationMatrix(int $rotationType, int|float $angle): array {
        $rotationType = max(self::ROTATION_ROLL, min(self::ROTATION_PITCH, $rotationType));
        $angle = deg2rad($angle);
        $cos = cos($angle);
        $sin = sin($angle);
        $matrix = [];
        switch($rotationType) {
            case self::ROTATION_ROLL :
                $matrix = [[1, 0 ,0],[0, $cos, -$sin],[0, $sin, $cos]];
                break;
            case self::ROTATION_YAW :
                $matrix = [[$cos, 0, $sin],[0, 1, 0],[-$sin, 0, $cos]];
                break;
            case self::ROTATION_PITCH :
                $matrix = [[$cos, -$sin, 0],[$sin, $cos, 0],[0, 0, 1]];
                break;
        }
        return $matrix;
    }

    public static function vec3ToArray(Vector3 $vector3): array {
        return ['x'=> $vector3->getX(), 'y'=> $vector3->getY(), 'z'=> $vector3->getZ()];
    }

    public static function arrayToVec3(array $vector3Array): Vector3 {
        if(self::isValidVector3Array($vector3Array))
            throw new InvalidArgumentException("This parameter is an invalid array.");
        return new Vector3($vector3Array['x'], $vector3Array['y'], $vector3Array['z']);
    }

    private static function isValidVector3Array(array $vector3Array): bool {
        $keys = ['x', 'y', 'z'];
        $isValid = true;
        foreach($vector3Array as $key => $value)
            if(!in_array($key, $keys) || !is_numeric($value))
                $isValid = false;
        return $isValid;
    }
}