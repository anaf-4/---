<?php

declare(strict_types=1);

namespace anaf2197\motion;

use anaf2197\content\motion\MotionContent;
use anaf2197\content\shape\ShapeContent;
use anaf2197\shape\Shape;

abstract class Motion {
    protected abstract function write(MotionContent $content, ShapeContent $shapeContent, int $time): void;

    /**
     * The duration is in seconds.
     */
    public function get(ShapeContent $shapeContent, int|float $duration): MotionContent {
        $content = new MotionContent();
        $duration = (int)($duration / 0.05);
        for($tick = 0; $tick <= $duration; $tick++) {
            $this->write($content, $shapeContent, $tick);
        }
        return $content;
    }

    public function multi(Motion $subMotion): MultiMotion {
        return new MultiMotion($this, $subMotion);
    }

    public function chain(Motion $subMotion): ChainMotion {
        return new ChainMotion($this, $subMotion);
    }
}