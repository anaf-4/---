<?php

declare(strict_types=1);

namespace anaf2197\motion;

use Closure;
use anaf2197\content\motion\MotionContent;
use anaf2197\content\shape\ShapeContent;

class ClosureMotion extends Motion {
    public function __construct(private Closure $write) {
    }

    protected function write(MotionContent $content, ShapeContent $shapeContent, int $time): void {
        ($this->write)($content, $shapeContent, $time);
    }
}