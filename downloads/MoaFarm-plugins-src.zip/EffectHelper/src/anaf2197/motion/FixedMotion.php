<?php

declare(strict_types=1);

namespace anaf2197\motion;

use anaf2197\content\motion\MotionContent;
use anaf2197\content\shape\ShapeContent;

class FixedMotion extends Motion {
    /**
     * The afterimage interval indicates how many seconds the afterimage will be displayed.
     */
    public function __construct(private float|int|null $afterimageInterval = null) {
    }

    protected function write(MotionContent $content, ShapeContent $shapeContent, int $time): void {
        $interval = ($this->afterimageInterval ?? 0.05) / 0.05;
        if($time % intval($interval) == 0.0)
            $content->put($shapeContent, null, $time);
    }
}