<?php

declare(strict_types=1);

namespace anaf2197\motion;

use anaf2197\content\motion\MotionContent;
use anaf2197\content\shape\ShapeContent;
use anaf2197\shape\ShapeShifter;
use pocketmine\math\Vector3;

class OscillationMotion extends Motion {
    public function __construct(private Vector3 $directionVector,
                                private float|int $amplitude,
                                private float|int $cycle,
                                private float|int|null $afterimageInterval = null) {}

    protected function write(MotionContent $content, ShapeContent $shapeContent, int $time): void {
        $inverval = $this->afterimageInterval * 0.05 ?? 0.05;
        $unitVector = $this->directionVector->divide((new Vector3(0, 0, 0))->distance($this->directionVector));
        $cycle = $this->cycle * 0.05;

        $y = ($cycle - floor($cycle))*(floor($cycle)%2)+(1-$cycle+floor($cycle))*((floor($cycle)+1)%2) * $this->amplitude;
        $sc = ShapeShifter::move($shapeContent, 0, $y, 0);
        $content->put($sc, null, $time);
    }
}