<?php

declare(strict_types=1);

namespace anaf2197\shape;

use anaf2197\content\shape\ShapeContent;

class PointShape extends Shape {
    protected function write(ShapeContent $content): void {
        $content->put(0, 0, 0);
    }
}