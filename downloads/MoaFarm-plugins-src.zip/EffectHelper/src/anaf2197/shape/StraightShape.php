<?php

declare(strict_types=1);

namespace anaf2197\shape;

use anaf2197\content\shape\ShapeContent;
use pocketmine\math\Vector3;

class StraightShape extends Shape {
    public function __construct(private Vector3 $endPoint, private float|int $interval) {
    }
    protected function write(ShapeContent $content): void {
        $distance = $this->endPoint->distance(new Vector3(0, 0, 0));
        $unitVector = $this->endPoint->divide($distance);
        $step = $unitVector->multiply($this->interval);
        for($i = 0; $i < $distance/$this->interval; $i++)
            $content->putVector3($step->multiply($i));
        $content->putVector3($this->endPoint);
    }
}