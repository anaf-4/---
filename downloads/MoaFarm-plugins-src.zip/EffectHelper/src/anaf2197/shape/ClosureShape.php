<?php

declare(strict_types=1);

namespace anaf2197\shape;

use Closure;
use anaf2197\content\shape\ShapeContent;

class ClosureShape extends Shape {
    public function __construct(private Closure $write) {
    }

    protected function write(ShapeContent $content): void {
        ($this->write)($content);
    }
}