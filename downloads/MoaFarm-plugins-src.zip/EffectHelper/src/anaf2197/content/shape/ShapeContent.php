<?php

declare(strict_types=1);

namespace anaf2197\content\shape;

use anaf2197\shape\ShapeShifter;
use anaf2197\utils\Utils;
use pocketmine\math\Vector3;
use JsonSerializable;

class ShapeContent implements JsonSerializable {
    /** @var Vector3[] */
    public array $content = [];

    public function put(int|float $x, int|float $y, int|float $z): void {
        $this->content[] = new Vector3($x, $y, $z);
    }

    public function putVector3(Vector3 $vector3): void {
        $this->content[] = $vector3;
    }

    /** @return Vector3[] */
    public function get(): array {
        return $this->content;
    }

    public function merge(ShapeContent $shapeContent): void {
        foreach ($shapeContent->content as $vector3) {
            $this->content [] = $vector3;
        }
    }


    public function jsonSerialize(): array {
        $json = [];
        foreach ($this->get() as $vector3)
            $json[] = Utils::vec3ToArray($vector3);
        return $json;
    }

    public static function jsonDeserialize(array $json): ShapeContent {
        $deserializedContent = new ShapeContent();
        foreach ($json as $pos)
            if (($vec = Utils::arrayToVec3($pos)) instanceof Vector3)
                $deserializedContent->putVector3($vec);
        return $deserializedContent;
    }
}