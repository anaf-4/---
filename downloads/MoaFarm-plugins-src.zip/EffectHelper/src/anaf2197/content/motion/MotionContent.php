<?php

declare(strict_types=1);

namespace anaf2197\content\motion;

use http\Exception\InvalidArgumentException;
use anaf2197\content\shape\ShapeContent;
use anaf2197\utils\Utils;
use pocketmine\math\Vector3;
use JsonSerializable;

class MotionContent implements JsonSerializable {
    /** @var MotionContentData[] */
    private array $content = [];
    private int $motionLength = 0;

    public function put(ShapeContent $shapeContent, ?Vector3 $offCenter, int $time): void {
        $this->content[] = new MotionContentData($shapeContent, $offCenter ?? new Vector3(0, 0, 0), $time);
        $this->updateMotionLength($time);
    }

    public function putContentData(MotionContentData $motionContentData): void {
        $this->content[] = $motionContentData;
        $this->updateMotionLength($motionContentData->getTime());
    }

    /** @return MotionContentData[] */
    public function get(): array {
        return $this->content;
    }

    public function getMotionLength(): int {
        return $this->motionLength;
    }

    public function isEmpty(): bool {
        return empty($this->content);
    }

    private function updateMotionLength(int $time): void {
        $this->motionLength = max($this->motionLength, $time);
    }

    public function jsonSerialize(): array {
        $json = [];
        foreach($this->get() as $contentData) {
            $convertedContentData = [];
            $convertedContentData["shape"] = $contentData->getShapeContent()->jsonSerialize();
            $convertedContentData["off_center"] = Utils::vec3ToArray($contentData->getOffCenter());
            $convertedContentData["time"] = $contentData->getTime();
            $json[] = $convertedContentData;
        }
        return $json;
    }

    public static function jsonDeserialize(array $json): MotionContent {
        $deserializedContent = new MotionContent();
        foreach($json as $data) {
            if(array_keys($data) !== ["shape", "off_center", "time"])
                throw new InvalidArgumentException("Invalid json given.");
            $deserializedContent->put(ShapeContent::jsonDeserialize($data["shape"]),
                Utils::arrayToVec3($json["off_center"]),
                $json["time"]);
        }
        return $deserializedContent;
    }
}