<?php

declare(strict_types=1);

namespace anaf2197\content\effect;

use anaf2197\content\motion\MotionContent;
use anaf2197\effect\EffectCenterVector;
use anaf2197\particle\EffectParticle;
use anaf2197\utils\Utils;
use pocketmine\math\Vector3;
use pocketmine\network\mcpe\protocol\ClientboundPacket;

class EffectContentData {
    public function __construct(private EffectParticle $particle, private MotionContent $motionContent) {
    }

    public function getParticle(): EffectParticle {
        return $this->particle;
    }

    public function getMotionContent(): MotionContent {
        return $this->motionContent;
    }

    /** @return Vector3[] */
    public function getPoints(): array {
        $points = [];
        foreach($this->motionContent->get() as $contentData)
            foreach($contentData->getShapeContent()->get() as $vector3)
                $points[] = $vector3->addVector($contentData->getOffCenter());
        return $points;
    }


    /** @return ClientboundPacket[] */
    public function getPackets(EffectCenterVector $centerVector): array {
        $packets = [];
        foreach($this->getPoints() as $point) {
            $point = $point->addVector($centerVector->getOffCenter());
           // var_dump($centerVector->getCenter()->getZ() . ':' . $centerVector->getCenter()->getY() . ':' . $centerVector->getCenter()->getZ());
            if($centerVector->getYaw() != 0 || $centerVector->getPitch() != 0)
                $point = $this->reposition($point, $centerVector->getCenter(), $centerVector->getYaw(), $centerVector->getPitch());
            $packets[] = $this->getParticle()->encode($point);
        }
        return $packets;
    }

    private function reposition(Vector3 $point, Vector3 $center, $yaw, $pitch): Vector3 {
        $point = $point->subtractVector($center);
        $yaw = deg2rad(270-$yaw);
        $pitch = deg2rad($pitch);
        $x = $point->getX();
        $y = $point->getY();
        $z = $point->getZ();
        $cos = cos($yaw);
        $sin = sin($yaw);
        $yx = $cos * $x + $sin * $z;
        $yz = -$sin * $x + $cos * $z;
        $cos = cos($pitch);
        $sin = sin($pitch);
        $px = $cos * $yx + -$sin * $y;
        $py = $sin * $yx + $cos * $y;
        return $center->add($px, $py, $yz);
    }
}