<?php

declare(strict_types=1);

namespace anaf2197\content\effect;

use anaf2197\content\motion\MotionContent;
use anaf2197\particle\EffectParticle;
use JsonSerializable;
use anaf2197\utils\Utils;

class EffectContent implements JsonSerializable {
    private array $content = [];

    public function put(EffectParticle $particle, MotionContent $motionContent, int $delay = 0): void {
        $delay = max(0, $delay);
        foreach($motionContent->get() as $motionContentData) {
            $time = $motionContentData->getTime();
            $partialMotionContent = $this->splitMotionContentData($motionContent, $time);
            $time += $delay;
            if(!isset($this->content[$time]))
                $this->content[$time] = [];
            $this->content[$time][] = new EffectContentData($particle, $partialMotionContent);
        }
    }

    public function putContentData(EffectContentData $contentData): void {
        $this->content[] = $contentData;
    }

    /** @param EffectContentData[] $contentDataArray */
    public function putContentDataArray(array $contentDataArray, int $time): void {
        if(!isset($this->content[$time]))
            $this->content[$time] = [];
        $this->content[$time] = array_merge($this->content[$time], $contentDataArray);
    }

    /** @return EffectContentData[] */
    public function get(int $time): array {
        return $this->content[$time] ?? [];
    }

    /** @return EffectContentData[] */
    public function getAll(): array {
        return $this->content;
    }

    /** @return int[] */
    public function getTimeline(): array {
        $timeline = array_keys($this->content);
        sort($timeline);
        return $timeline;
    }

    public function getContentLength(): int {
        return max(array_keys($this->content));
    }

    public function isEmpty(): bool {
        return empty($this->content);
    }

    public function splitMotionContentData(MotionContent $motionContent, int $time): MotionContent {
        $splitMotionContent = new MotionContent();
        foreach($motionContent->get() as $motionContentData)
            if($motionContentData->getTime() == $time)
                $splitMotionContent->putContentData($motionContentData);
        return $splitMotionContent;
    }

    public function jsonSerialize(): array {
        $serializedObject = [];
        foreach(array_keys($this->getAll()) as $time) {
            if(!isset($serializedObject[$time]))
                $serializedObject[$time] = [];
            foreach($this->get($time) as $effectContentData) {
                $baseElements = array_fill_keys(["color", "uv_pos", "motion_speed", "motion_acc",
                    "motion_drag", "size", "lifetime", "count", "emitter_radius", "frame"], []);
                $variableElements = [];
                foreach($effectContentData->getPoints() as $vector3) {
                    $particle = $effectContentData->getParticle();
                    $baseElements["color"][] = $particle->getColor()->toARGB();
                    $baseElements["uv_pos"][] = $particle->getUvPos();
                    $baseElements["motion_speed"][] = $particle->getMotionSpeed();
                    $baseElements["motion_acc"][] = $particle->getMotionAcc();
                    $baseElements["motion_drag"][] = $particle->getMotionDrag();
                    $baseElements["size"][] = $particle->getParticleSize();
                    $baseElements["lifetime"][] = $particle->getLifetime();
                    $baseElements["count"][] = $particle->getParticleCount();
                    $baseElements["emitter_radius"][] = $particle->getEmitterRadius();
                    $baseElements["frame"][] = $particle->getFrame();
                }
                foreach($baseElements as $element => $data) {
                    $uniqueData = array_unique($data);
                    if(count($uniqueData) == 1)
                        $baseElements[$element] = $uniqueData[0];
                    else {
                        $variableElements[$element] = $data;
                        unset($baseElements[$element]);
                    }
                }
                $serializedContentData = ["base_elements"=> $baseElements,
                    "points"=> []];
                foreach($effectContentData->getPoints() as $index => $vector3) {
                    $point = [
                        "pos"=> $vector3,
                        "particle_elements"=> []];
                    foreach($variableElements as $element => $data)
                        $point["particle_elements"][$element] = $data[$index];
                    $serializedContentData["points"][] = $point;
                }
                $serializedObject[$time][] = $serializedContentData;
            }
        }
        return $serializedObject;
    }
}