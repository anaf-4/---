<?php

declare(strict_types=1);

namespace anaf2197;

use anaf2197\content\effect\EffectContent;
use anaf2197\effect\Effect;
use anaf2197\effect\EffectPlayer;
use anaf2197\task\ParticlePacketSendTask;
use pocketmine\plugin\PluginBase;

class EffectHelper extends PluginBase {
    private EffectPlayer $effectPlayer;
    private static ?EffectHelper $instance = null;

    public function onEnable(): void {
        self::$instance = $this;

        $this->effectPlayer = new EffectPlayer();
        $this->getScheduler()->scheduleRepeatingTask(new ParticlePacketSendTask($this->effectPlayer), 1);
    }

    public function getEffectPlayer(): EffectPlayer {
        return $this->effectPlayer;
    }

    public static function getInstance(): ?EffectHelper {
        return self::$instance;
    }

    public static function extractEffect(Effect $effect, string $effectName): void {
        $effectContent = new EffectContent();
        $effect->write($effectContent);
        $dir = self::getInstance()->getDataFolder(). "extract_effects";
        @mkdir($dir);
        $fileStream = fopen($dir."\\". $effectName.".json", "w");
        fwrite($fileStream, json_encode($effectContent));
        fclose($fileStream);
    }
}