<?php

namespace anaf2197\Excavation;

use pocketmine\block\VanillaBlocks;
use pocketmine\event\Listener;
use pocketmine\item\VanillaItems;
use pocketmine\world\Position;
use pocketmine\plugin\PluginBase;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\player\Player;
use anaf2197\check\CheckLoader;
use anaf2197\servercore\item\ItemDesign;
use anaf2197\servercore\item\ItemTypes;
use anaf2197\virtualchest\VirtualChest;
use anaf2197\virtualchest\VirtualChestLoader;

class Excavation extends PluginBase implements Listener
{
    public function onEnable(): void
    {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function onBlockBreak(BlockBreakEvent $event): true
    {
        $player   = $event->getPlayer();
        $block    = $event->getBlock();
        $blockPos = $block->getPosition();
        $world    = $blockPos->world;

        if ($world->getDisplayName() !== 'main') {
            return true;
        }

        $x = $blockPos->x;
        $y = $blockPos->y;
        $z = $blockPos->z;
        $bone = VanillaItems::BONE();

        if ($block->getTypeId() === VanillaBlocks::BONE_BLOCK()->getTypeId()) {
            $event->cancel();
            $world->setBlock(new Position($x, $y, $z, $world), VanillaBlocks::BONE_BLOCK());

            $rand   = mt_rand(1, 100);
            $fossil = match (true) {
                $rand <= 6  => '티라노사우르스 화석',
                $rand <= 7  => '브라키오사우르스 화석',
                $rand <= 9  => '스피노사우르스 화석',
                $rand <= 15 => '알로사우르스 화석',
                $rand <= 35 => '케라토사우르스 화석',
                $rand <= 40 => '트리케라톱스 화석',
                default     => null,
            };

            if ($fossil !== null) {
                ItemDesign::setItemDesign($bone, ItemTypes::NORMAL, $fossil, [
                    "{$fossil}이다.",
                ], '/판매전체');
                $player->getInventory()->addItem($bone);
            }
            if (mt_rand(1, 10000) <= 1) {
                $player->getInventory()->addItem(CheckLoader::getInstance()->getCheck(100000));
                $player->sendMessage('§l§d[발굴] §r§8축하합니다! 발굴을 통해 10만원 수표를 획득하였습니다.');
            }
            if (mt_rand(1, 100000) <= 1) {
                $player->getInventory()->addItem(VanillaItems::NETHER_STAR()->setCount(1));
                $player->sendMessage('§l§d[발굴] §r§8축하합니다! 발굴을 통해 네더의 별을 획득하였습니다.');
            }
            if (mt_rand(1, 10000) <= 3) {
                $player->getInventory()->addItem(VirtualChestLoader::getInstance()->getSlotCoin());
                $player->sendMessage('§l§d[발굴] §r§8축하합니다! 발굴을 통해 창고 확장권을 획득하였습니다.');
            }

            // ── WeeklyRanking 발굴 카테고리 점수 ─────────────────────────────
            if (class_exists(\anaf2197\weeklyranking\WeeklyRankingLoader::class)) {
                \anaf2197\weeklyranking\WeeklyRankingLoader::getInstance()
                    ->addScore(\anaf2197\weeklyranking\WeeklyRankingLoader::CAT_EXCAVATION, $player->getName());
            }

            // ── Achievement 발굴 업적 진행도 ──────────────────────────────────
            if (class_exists(\anaf2197\achievement\AchievementLoader::class)) {
                \anaf2197\achievement\AchievementLoader::getInstance()
                    ->addProgress($player, \anaf2197\achievement\Achievement::TYPE_EXCAVATION);
            }

            // ── DailyMission 발굴 진행도 ──────────────────────────────────────
            if (class_exists(\anaf2197\dailymission\DailyMissionLoader::class)) {
                \anaf2197\dailymission\DailyMissionLoader::getInstance()
                    ->addProgress($player, 'EXCAVATION');
            }

            return true;
        }
        return true;
    }
}
