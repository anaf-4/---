<?php

namespace anaf2197\guideapi;

use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;
use anaf2197\guideapi\command\GuideCommand;
use anaf2197\guideapi\command\GuideTpCommand;
use anaf2197\lib\provider\DataProvider;
use anaf2197\lib\provider\ProviderHandler;
use anaf2197\lib\color\ServerColor;
use anaf2197\servercore\Unicode;

final class GuideAPI extends PluginBase {

    public const DB_GUIDE = 'guides';

    /*
     * 가이드 칭호를 설정할 때 무조건 초기 설정값 (색코드 제외)이 포함되어야 합니다.
     * 그렇지 않으면 가이드 권환을 회수할 때 칭호가 같이 회수되지 않습니다.
     * + 유니코드일 경우 해당 X
     */
    public const GUIDE_PREFIX = Unicode::GUIDE;

    use SingletonTrait;

    public static string $prefix;

    private DataProvider $provider;

    protected function onEnable(): void {
        if (!$this->provider->getObject(self::DB_GUIDE) instanceof GuideManager) {
            $this->provider->setObject(self::DB_GUIDE, new GuideManager(self::DB_GUIDE, []));
        }
        $this->getServer()->getCommandMap()->register(strtolower($this->getName()), new GuideCommand());
        $this->getServer()->getCommandMap()->register(strtolower($this->getName()), new GuideTpCommand());
    }

    protected function onLoad(): void {
        self::setInstance($this);
        ServerColor::setPrefix($this, '가이드');
        if (!ProviderHandler::isRegistered($this)) {
            ProviderHandler::register($this, GuideManager::class);
            $this->provider = ProviderHandler::get($this);
        }
    }

    protected function onDisable(): void {
        $this->saveDatabase();
    }

    public function saveDatabase(): void {
        $this->provider->save();
    }

    public function getGuideManager(): GuideManager {
        return $this->provider->getObject(self::DB_GUIDE);
    }
}