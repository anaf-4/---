<?php

namespace anaf2197\guideapi;

use pocketmine\utils\TextFormat;
use anaf2197\advancedprefix\AdvancedPrefix;
use anaf2197\crystalapi\CrystalAPI;

final class GuideManager implements \JsonSerializable {

    public function __construct(private string $id, protected array $guides) { }

    public function getGuides(): array {
        return $this->guides;
    }

    public function isGuide(string $playerId): bool {
        return in_array($playerId, $this->guides);
    }

    public function addGuide(string $playerId): void {
        $this->guides [] = $playerId;
        AdvancedPrefix::getInstance()->getPlayerPrefix($playerId)->addPrefix(GuideAPI::GUIDE_PREFIX);
    }

    public function removeGuide(string $playerId): void {
        unset($this->guides [array_search($playerId, $this->guides)]);
        $playerPefix = AdvancedPrefix::getInstance()->getPlayerPrefix($playerId);
        foreach ($playerPefix->getPrefixes() as $key => $prefix)
            if ($prefix === GuideAPI::GUIDE_PREFIX)
                $playerPefix->removePrefix($key);
    }

    public function sendReward(): void {
        $crystalManager = CrystalAPI::getInstance()->getCrystalManager();
        foreach ($this->guides as $playerId) {
            $crystalManager->addCrystal($playerId, 10000);
        }
    }

    public function jsonSerialize(): array {
        return [
            $this->id,
            $this->guides
        ];
    }

    public static function jsonDeserialize(array $data): self {
        return new self (... $data);
    }
}