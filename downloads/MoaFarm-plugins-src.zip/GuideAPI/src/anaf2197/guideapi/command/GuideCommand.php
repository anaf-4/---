<?php

namespace anaf2197\guideapi\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\Server;
use anaf2197\guideapi\GuideAPI;
use anaf2197\lib\timeparser\TimeParser;
use anaf2197\playtime\PlayTime;

final class GuideCommand extends Command {

    public function __construct() {
        parent::__construct('가이드', '가이드 관리 명령어입니다.');
        $this->setPermission(DefaultPermissions::ROOT_OPERATOR);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($this->testPermission($sender)) {
            $guideManager = GuideAPI::getInstance()->getGuideManager();
            switch (array_shift($args)) {
                case '추가':
                    $playerId = array_shift($args);
                    if (trim((string)$playerId) !== '') {
                        $server = Server::getInstance();
                        if (!is_null($server->getPlayerExact($playerId)) or !is_null($server->getOfflinePlayerData($playerId))) {
                            if (!$guideManager->isGuide($playerId)) {
                                $guideManager->addGuide($playerId);
                                $sender->sendMessage(GuideAPI::$prefix . '해당 유저를 가이드로 지정했습니다.');
                            } else {
                                $sender->sendMessage(GuideAPI::$prefix . '이미 가이드로 지정된 닉네임입니다.');
                            }
                        } else {
                            $sender->sendMessage(GuideAPI::$prefix . '접속 기록이 없는 닉네임입니다.');
                        }
                    } else {
                        $sender->sendMessage(GuideAPI::$prefix . '/가이드 추가 [닉네임]');
                    }
                    break;

                case '제거':
                    $playerId = array_shift($args);
                    if (trim((string)$playerId) !== '') {
                        if ($guideManager->isGuide($playerId)) {
                            $guideManager->removeGuide($playerId);
                            $sender->sendMessage(GuideAPI::$prefix . '해당 유저의 가이드 권한을 박탈했습니다.');
                        } else {
                            $sender->sendMessage(GuideAPI::$prefix . '가이드로 지정되지 않은 닉네임입니다.');
                        }
                    } else {
                        $sender->sendMessage(GuideAPI::$prefix . '/가이드 제거 [닉네임]');
                    }
                    break;

                case '목록':
                    $sender->sendMessage(GuideAPI::$prefix . '현재 지정된 가이드 §l§a' . count($guideManager->getGuides()) . '§r§8명');
                    foreach ($guideManager->getGuides() as $i => $guideId) {
                        $sender->sendMessage('§8' . ($i + 1) . '. ' . $guideId . ' (' . TimeParser::koreanTimeFormat(PlayTime::getInstance()->getPlayTime($guideId)) . ')');
                    }
                    break;

                case '보상지급':
                    $guideManager->sendReward();
                    $sender->sendMessage(GuideAPI::$prefix . '모든 가이드에게 보상을 지급했습니다.');
                    break;

                default:
                    $sender->sendMessage(GuideAPI::$prefix . '/가이드 추가 [닉네임]');
                    $sender->sendMessage(GuideAPI::$prefix . '/가이드 제거 [닉네임]');
                    $sender->sendMessage(GuideAPI::$prefix . '/가이드 목록');
                    $sender->sendMessage(GuideAPI::$prefix . '/가이드 보상지급');
            }
        }
    }
}