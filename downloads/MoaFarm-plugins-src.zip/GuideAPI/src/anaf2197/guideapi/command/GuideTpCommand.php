<?php

namespace anaf2197\guideapi\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use pocketmine\Server;
use anaf2197\guideapi\GuideAPI;

final class GuideTpCommand extends Command
{

    public function __construct()
    {
        parent::__construct('티피', '§r§8대상 게이머에게 순간이동합니다.');
        $this->setPermission(DefaultPermissions::ROOT_USER);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void
    {
        if ($this->testPermission($sender)) {
            if ($sender->hasPermission(DefaultPermissions::ROOT_OPERATOR) or GuideAPI::getInstance()->getGuideManager()->isGuide($sender->getName())) {
                if ($sender instanceof Player) {
                    if (count($args) >= 1) {
                        if ($sender->hasPermission(DefaultPermissions::ROOT_OPERATOR) or GuideAPI::getInstance()->getGuideManager()->isGuide($sender->getName())) {
                            if ($sender instanceof Player) {
                                if (count($args) >= 1) {
                                    $to = array_shift($args);
                                    $player = Server::getInstance()->getPlayerExact($to);
                                    if ($player instanceof Player) {
                                        $sender->teleport($player->getPosition());
                                    } else {
                                        $sender->sendMessage(GuideAPI::$prefix . '플레이어를 찾을 수 없습니다.');
                                    }
                                } else {
                                    $sender->sendMessage(GuideAPI::$prefix . '/티피 [닉네임] - 풀네임으로 입력해주세요.');
                                }
                            }
                        } else {
                            $sender->sendMessage(GuideAPI::$prefix . '가이드 권한이 필요합니다.');
                        }
                    }
                }
            }
        }
    }
}