<?php

namespace anaf2197\easyshop\menu;

use anaf2197\easyshop\EasyShop;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\transaction\InvMenuTransaction;
use muqsit\invmenu\transaction\InvMenuTransactionResult;
use muqsit\invmenu\type\InvMenuTypeIds;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\player\Player;
use anaf2197\awayfromkeyboard\AwayFromKeyboard;
use anaf2197\crystalapi\CrystalAPI;
use anaf2197\economyapi\EconomyAPI;
use anaf2197\servercore\CoreLoader;
use anaf2197\servercore\item\ServerItems;
use anaf2197\shopkeeper\form\BuyShopItemForm;
use anaf2197\shopkeeper\ShopKeeperLoader;
use anaf2197\shopkeeper\ShopObject;
use anaf2197\synthesisprice\SynthesisPrice;

class EasyShopMenu{

    private InvMenu $menu;
    private int $page = 0;

    private array $sessions = [];

    public function __construct(private Player $player, private ShopObject $shopObject){
        $this->menu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST)
            ->setName('§b')
            ->setListener($this->onTransaction(...))
            ->setInventoryCloseListener($this->onClose(...));
        $this->reloadInv();
    }

    public function onTransaction(InvMenuTransaction $transaction) : InvMenuTransactionResult{

        $player = $transaction->getPlayer();
        $action = $transaction->getAction();
        $sourceItem = $action->getSourceItem();
        $slot = $action->getSlot();

        $priceObject = SynthesisPrice::getInstance()->getShop();
        $crtPriceObject = SynthesisPrice::getInstance()->getCrystal();
        $afkPriceObject = SynthesisPrice::getInstance()->getAFK();
        $economyData = EconomyAPI::getInstance()->getEconomyData($player);

        switch ($slot) {
            case 45:
                if (!$sourceItem->isNull()) {
                    $this->page--;
                    $this->reloadInv();
                }
                break;

            case 8:
                $profit = 0;
                $sold = [];
                foreach (array_keys($this->menu->getInventory()->getContents()) as $i) {
                    if (!in_array($i, [0, 1, 7])) {
                        $item = $this->shopObject->getItems($this->page) [$i] ?? null;
                        if ($item instanceof Item) {
                            $playerInv = $player->getInventory();
                            $sellPrice = $priceObject->getSellPrice($item);
                            if ($sellPrice > -1) {
                                if ($playerInv->contains($item)) {
                                    $hollCount = CoreLoader::itemHollCount($playerInv, $item);
                                    $item->setCount($hollCount);
                                    $playerInv->removeItem($item);
                                    $profit += ($sellPrice * $hollCount);
                                    $sold [] = $item;
                                }
                            }
                        }
                    }
                }
                $mymoney = $economyData->getMoney();
                $economyData->addMoney($profit, '상점 - 모두 판매하기');
                $player->removeCurrentWindow();
                $player->sendMessage(ShopKeeperLoader::$prefix . '판매한 아이템: ' . implode(', ', array_map(function (Item $item): string {
                        return $item->getName() . '§r§8 (' . $item->getCount() . ')';
                    }, $sold)));
                $player->sendMessage(ShopKeeperLoader::$prefix . '획득: ' . ($profit > 0 ? EconomyAPI::koreanWonFormat($profit) : '0원') . '§r§8, 기존 소지: ' . EconomyAPI::koreanWonFormat($mymoney) . '§r§8, 최종 소지: ' . EconomyAPI::koreanWonFormat($mymoney + $profit));
                EasyShop::getInstance()->reducePoint($player, 1);
                if ( $profit > 0 ) {
                    $this->sessions[strtolower($player->getName())] = true;
                }
                break;

            case 53:
                if (!$sourceItem->isNull()) {
                    $this->page++;
                    $this->reloadInv();
                }
                break;

            default:
                $item = $this->shopObject->getItems($this->page) [$slot] ?? null;
                if ($item instanceof Item) {
                    $priceData = $priceObject->getPrice($item);
                    $crtPriceData = $crtPriceObject->getPrice($item);
                    $afkPriceData = $afkPriceObject->getPrice($item);
                    if ((is_array($priceData) and ($priceData [0] > -1 or $priceData [1] > -1)) or (is_array($crtPriceData) and $crtPriceData [0] > -1) or (is_array($afkPriceData) and $afkPriceData [0] > -1)) {
                        $this->sessions[strtolower($player->getName())] = true;
                        $player->removeCurrentWindow();

                        // 1틱 후에 Form 열기
                        EasyShop::getInstance()->getScheduler()->scheduleDelayedTask(
                            new \pocketmine\scheduler\ClosureTask(
                                function() use ($player, $economyData, $priceObject, $crtPriceObject, $afkPriceObject, $item) : void {
                                    if($player->isOnline()){
                                        $player->sendForm(new BuyShopItemForm(
                                            $economyData,
                                            AwayFromKeyboard::getInstance()->getPlayerAFK($player),
                                            $priceObject,
                                            $crtPriceObject,
                                            $afkPriceObject,
                                            CrystalAPI::getInstance()->getCrystalManager(),
                                            $item,
                                            $player,
                                            true
                                        ));
                                    }
                                }
                            ),
                            2
                        );
                    }
                }
        }
        return $transaction->discard();
    }

    private function reloadInv(): void {

        $priceObject = SynthesisPrice::getInstance()->getShop();
        $crtPriceObject = SynthesisPrice::getInstance()->getCrystal();
        $afkPriceObject = SynthesisPrice::getInstance()->getAFK();
        $this->menu->getInventory()->setContents(array_map(function (Item $item) use ($priceObject, $crtPriceObject, $afkPriceObject): Item {
            $icon = clone $item;
            $lore = [' '];
            foreach ([$priceObject, $crtPriceObject, $afkPriceObject] as $method) {
                if (is_array(($priceData = $method->getPrice($icon)))) {
                    $buyPrice = array_shift($priceData);
                    $sellPrice = array_shift($priceData) ?? -1;
                    $unit = str_replace([SynthesisPrice::LABEL_SHOP, SynthesisPrice::LABEL_CRYSTAL, SynthesisPrice::LABEL_AFK], [null, '§b CRT', '§a AP'], $method->getLabel());
                    if ($buyPrice > -1) $lore [] = '§r§8구매: ' . EconomyAPI::koreanWonFormat($buyPrice, $unit);
                    if ($sellPrice > -1) {
                        $lore [] = '§r§8판매: ' . EconomyAPI::koreanWonFormat($sellPrice, $unit);
                        $lore [] = '§r§8  - 현재 ' . CoreLoader::itemHollCount($this->player->getInventory(), $icon) . '개 보유중';
                    }
                }
            }
            return $icon->setLore(array_merge($icon->getLore(), $lore));
        }, $this->shopObject->getItems($this->page)));
        $this->menu->getInventory()->setItem(8, ServerItems::TRANSPARENT()->setCustomName('§r§l§f모두 판매하기')->setLore([' ', '§r§8판매 가능한 아이템을 모두 판매합니다.']));
        if ($this->shopObject->existsPage($this->page - 1)) {
            $this->menu->getInventory()->setItem(45, ServerItems::LEFT_ARROW()->setCustomName('§r§l§f이전 페이지로')->setLore([' ', '§r§8현재 페이지: ' . ($this->page + 1)]));
        }
        if ($this->shopObject->existsPage($this->page + 1)) {
            $this->menu->getInventory()->setItem(53, ServerItems::RIGHT_ARROW()->setCustomName('§r§l§f다음 페이지로')->setLore([' ', '§r§8현재 페이지: ' . ($this->page + 1)]));
        }
    }

    public function onClose(Player $player) : void{
        if ( ! isset ( $this->sessions[strtolower($player->getName())] ) ) {
            $player->sendMessage(EasyShop::$prefix . '포인트가 소모되지 않았습니다.');
        }
    }

    public function sendTo(Player $player) : void{
        $this->menu->send($player);
    }

}