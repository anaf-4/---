<?php

namespace anaf2197\easyshop;

use jsondata\JsonData;
use anaf2197\easyshop\command\MainCommand;
use anaf2197\easyshop\command\ManageCommand;
use anaf2197\playerparser\PlayerParser;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\item\Item;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;
use anaf2197\lib\color\ServerColor;
use anaf2197\servercore\item\ItemDesign;
use anaf2197\servercore\item\ItemTypes;
use anaf2197\servercore\item\ServerItems;

class EasyShop extends PluginBase implements Listener {

    use SingletonTrait;

    public static string $prefix;

    private JsonData $data;

    private const TAG_COUPON = 'easyshop_coupon';

    protected function onLoad(): void{
        self::setInstance($this);
        ServerColor::setPrefix($this, '간편상점');
    }

    protected function onEnable(): void{
        $this->data = new JsonData($this, 'point');
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getServer()->getCommandMap()->registerAll($this->getName(), [new MainCommand(), new ManageCommand()]);
    }

    public function onJoin(PlayerJoinEvent $event) : void{
        $player = $event->getPlayer();
        $this->createData($player);
    }

    public function onUse(PlayerItemUseEvent $event) : void{
        $player = $event->getPlayer();
        $item = $event->getItem();
        if ( ($tag=$item->getNamedTag()->getTag(self::TAG_COUPON)) !== null ){
            $event->cancel(); // ← 이 줄 추가
            $amount = $tag->getValue();
            $this->addPoint($player, $amount);
            $item = $this->getCouponItem($amount);
            $player->getInventory()->removeItem($item);
            $player->sendMessage(self::$prefix.'간편 상점 포인트가 '.$amount.' 만큼 충전되었습니다.');
        }
    }

    public function createData(Player|string $player) : void{
        $playerName = PlayerParser::getName($player);
        if ( ! $this->data->isset($playerName) ){
            $this->data->set($playerName, 0);
        }
    }

    public function addPoint(Player|string $player, int $amount) : void{
        $this->createData($player);
        $playerName = PlayerParser::getName($player);
        $this->data->set($playerName, $this->getPoint($player) + $amount);
    }

    public function reducePoint(Player|string $player, int $amount) : void{
        $this->createData($player);
        $playerName = PlayerParser::getName($player);
        $amount = max(0, $this->getPoint($player) - $amount);
        $this->data->set($playerName, $amount);
        $player->sendMessage(self::$prefix.$amount.' 포인트가 소모되었습니다.');
    }

    public function setPoint(Player|string $player, int $amount) : void{
        $playerName = PlayerParser::getName($player);
        $this->data->set($playerName, $amount);
    }

    public function getPoint(Player|string $player) : ?int{
        $playerName = PlayerParser::getName($player);
        return $this->data->get($playerName);
    }

    public function getCouponItem(int $amount) : Item{
        $item = ServerItems::EASYPOINT();
        ItemDesign::setItemDesign($item, ItemTypes::UNIQUE, '간편 상점 포인트권', [
            '간편 상점 포인트를 '.$amount.' 포인트 충전합니다.',
        ], '터치');
        $item->getNamedTag()->setInt(self::TAG_COUPON, $amount);
        return $item;
    }

    public function onDisable(): void{
        $this->data->save();
    }

}