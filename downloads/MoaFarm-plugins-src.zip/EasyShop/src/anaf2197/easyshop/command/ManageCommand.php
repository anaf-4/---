<?php

namespace anaf2197\easyshop\command;

use anaf2197\easyshop\EasyShop;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;

class ManageCommand extends Command{

    public function __construct(){
        parent::__construct('간편상점관리', '간편 상점 관리 명령어입니다.');
        $this->setPermission(DefaultPermissions::ROOT_OPERATOR);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args) : void{
        if(!$sender instanceof Player)return;
        if(!$this->testPermission($sender))return;
        switch(array_shift($args)){
            case '포인트설정':
                $target = array_shift($args);
                $amount = array_shift($args);
                if ( $target === null or $amount === null ){
                    $sender->sendMessage(EasyShop::$prefix.'/간편상점관리 포인트설정 [닉네임] [포인트]');
                    return;
                }
                if ( ! is_numeric($amount) ){
                    $sender->sendMessage(EasyShop::$prefix.'/간편상점관리 포인트설정 [닉네임] [포인트]');
                    return;
                }
                if ( EasyShop::getInstance()->getPoint($target) === null ){
                    $sender->sendMessage(EasyShop::$prefix.'접속 기록이 존재하지 않는 플레이어입니다.');
                    return;
                }
                EasyShop::getInstance()->setPoint($target, (int)$amount);
                $sender->sendMessage(EasyShop::$prefix.$target.'님의 간편 상점 포인트를 '.$amount.' (으)로 설정했습니다.');
                break;
            case '포인트보기':
                $target = array_shift($args);
                if ( $target === null ){
                    $sender->sendMessage(EasyShop::$prefix.'/간편상점관리 포인트보기 [닉네임]');
                    return;
                }
                if ( ($point=EasyShop::getInstance()->getPoint($target)) === null ){
                    $sender->sendMessage(EasyShop::$prefix.'접속 기록이 존재하지 않는 플레이어입니다.');
                    return;
                }
                $sender->sendMessage(EasyShop::$prefix.$target.'님의 간편 상점 포인트: '.$point);
                break;
            case '포인트권':
                $amount = array_shift($args);
                if ($amount === null ){
                    $sender->sendMessage(EasyShop::$prefix.'/간편상점관리 포인트권 [포인트]');
                    return;
                }
                if ( ! is_numeric($amount) ){
                    $sender->sendMessage(EasyShop::$prefix.'/간편상점관리 포인트권 [포인트]');
                    return;
                }
                $item = EasyShop::getInstance()->getCouponItem($amount);
                $sender->getInventory()->addItem($item);
                $sender->sendMessage(EasyShop::$prefix.'포인트권이 지급되었습니다.');
                break;
            default:
                $sender->sendMessage(EasyShop::$prefix.'/간편상점관리 포인트설정 [닉네임] [포인트]');
                $sender->sendMessage(EasyShop::$prefix.'/간편상점관리 포인트보기 [닉네임]');
                $sender->sendMessage(EasyShop::$prefix.'/간편상점관리 포인트권 [포인트]');
                break;
        }
    }

}