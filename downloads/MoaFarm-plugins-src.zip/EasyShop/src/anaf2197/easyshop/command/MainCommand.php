<?php

namespace anaf2197\easyshop\command;

use anaf2197\easyshop\EasyShop;
use anaf2197\easyshop\menu\EasyShopMenu;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\shopkeeper\ShopKeeperLoader;
use anaf2197\shopkeeper\ShopObject;

class MainCommand extends Command{

    public function __construct(){
        parent::__construct('간편상점', '간편 상점 명령어입니다.');
        $this->setPermission(DefaultPermissions::ROOT_USER);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args) : void{
        if(!$sender instanceof Player)return;
        if(!isset($args[0])){
            $sender->sendMessage(EasyShop::$prefix.'/간편상점 [상점] - 포인트를 소모하여 상점을 이용합니다.');
            return;
        }
        $shopName = array_shift($args);
        $shop = ShopKeeperLoader::getInstance()->getShop($shopName);

        if (!$shop instanceof ShopObject) {
            $sender->sendMessage(EasyShop::$prefix.'존재하지 않는 상점 이름입니다.');
            return;
        }

        // 숨김 처리된 상점은 /간편상점 명령어로 접근 불가
        // (샵키퍼 엔티티를 직접 클릭해야만 이용 가능)
        if ($shop->isHidden()) {
            $sender->sendMessage(EasyShop::$prefix.'존재하지 않는 상점 이름입니다.');
            return;
        }

        if ( ($point = EasyShop::getInstance()->getPoint($sender)) === null ){
            $sender->sendMessage(EasyShop::$prefix.'오류가 발생했습니다.');
            return;
        }
        if ( $point < 1 ){
            $sender->sendMessage(EasyShop::$prefix.'보유 포인트가 부족합니다.');
            return;
        }

        // 1틱 후에 메뉴 열기
        EasyShop::getInstance()->getScheduler()->scheduleDelayedTask(
            new \pocketmine\scheduler\ClosureTask(
                function() use ($sender, $shop) : void {
                    if($sender->isOnline()){
                        (new EasyShopMenu($sender, $shop))->sendTo($sender);
                    }
                }
            ),
            1
        );
    }

}