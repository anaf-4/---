<?php

declare(strict_types=1);

namespace CoreCoordination;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\network\mcpe\protocol\GameRulesChangedPacket;
use pocketmine\network\mcpe\protocol\types\BoolGameRule;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\scheduler\ClosureTask;

final class Main extends PluginBase implements Listener {

    /** @var array<string, bool> */
    private array $coord = [];

    public function onEnable(): void {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getLogger()->info("core_coordination enabled");
    }

    public function onPlayerJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        $name = $player->getName();

        // 접속 시 자동으로 좌표 켜기
        $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function() use ($player, $name): void {
            if (!$player->isOnline()) {
                return;
            }

            $this->coord[$name] = true;
            $pk = GameRulesChangedPacket::create([
                "showcoordinates" => new BoolGameRule(true, true),
            ]);
            $player->getNetworkSession()->sendDataPacket($pk);
        }), 20);
    }

    public function onDisable(): void {
        $this->coord = [];
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if ($command->getName() !== "coordinates") {
            return false;
        }

        if (!$sender instanceof Player) {
            $sender->sendMessage("§c게임 내에서만 가능합니다.");
            return true;
        }

        if (!$sender->hasPermission("core_coordination.use")) {
            $sender->sendMessage("§c권한이 없습니다.");
            return true;
        }

        $name = $sender->getName();
        $enabled = !($this->coord[$name] ?? false);
        $this->coord[$name] = $enabled;

        $pk = GameRulesChangedPacket::create([
            "showcoordinates" => new BoolGameRule($enabled, true),
        ]);
        $sender->getNetworkSession()->sendDataPacket($pk);

        $sender->sendMessage($enabled ? "§e좌표 표시 켜짐" : "§e좌표 표시 꺼짐");
        return true;
    }
}
