<?php

declare(strict_types=1);

namespace anaf2197\blackmarket\listener;

use anaf2197\auctionhouse\event\BuyAuctionItemEvent;
use anaf2197\blackmarket\BlackMarketLoader;
use pocketmine\event\Listener;

/**
 * 거래소(AuctionHouse) 구매 이벤트를 감지해 price_index_log 테이블에 기록.
 * BlackMarket의 PriceManager가 이 데이터를 참조해 시장 평균가를 조회할 수 있다.
 */
final class AuctionPriceListener implements Listener {

    public function __construct(private \mysqli $db) {}

    /**
     * @priority MONITOR
     * @ignoreCancelled true
     */
    public function onBuyAuctionItem(BuyAuctionItemEvent $event): void {
        $item      = $event->getAuctionItem()->getItem();
        $price     = $event->getAuctionItem()->getPrice();
        $count     = $item->getCount();
        $itemName  = $item->getName();
        $perUnit   = $count > 0 ? (int) round($price / $count) : $price;

        try {
            if (!@$this->db->ping()) BlackMarketLoader::getInstance()->reconnectPriceDb();
            $db = BlackMarketLoader::getInstance()->getPriceDb();
            if ($db === null) return;

            $stmt = $db->prepare(
                'INSERT INTO price_index_log (item_name, price_per_unit, sold_at) VALUES (?, ?, ?)'
            );
            $now = time();
            $stmt->bind_param('sii', $itemName, $perUnit, $now);
            $stmt->execute();
            $stmt->close();
        } catch (\Throwable) {
            // 가격 로깅 실패는 조용히 무시
        }
    }
}
