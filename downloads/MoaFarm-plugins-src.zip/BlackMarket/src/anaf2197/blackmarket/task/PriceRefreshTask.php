<?php

namespace anaf2197\blackmarket\task;

use pocketmine\scheduler\Task;
use anaf2197\blackmarket\BlackMarketLoader;

final class PriceRefreshTask extends Task {

    public function onRun(): void {
        $loader  = BlackMarketLoader::getInstance();
        $percent = $loader->getPriceManager()->refreshAll();

        if (count($loader->getServer()->getOnlinePlayers()) >= 1) {
            $sign = $percent >= 0 ? '+' : '';
            $loader->getServer()->broadcastMessage(
                BlackMarketLoader::$prefix . "암상인 가격이 변동되었습니다! §f{$sign}{$percent}%"
            );
        }
    }
}