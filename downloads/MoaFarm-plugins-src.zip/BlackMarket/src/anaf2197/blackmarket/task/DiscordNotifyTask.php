<?php

declare(strict_types=1);

namespace anaf2197\blackmarket\task;

use pocketmine\scheduler\AsyncTask;

final class DiscordNotifyTask extends AsyncTask {

    public function __construct(
        private readonly string $url,
        private readonly string $payload
    ) {}

    public function onRun(): void {
        $context = stream_context_create([
            'http' => [
                'method'        => 'POST',
                'header'        => "Content-Type: application/json\r\nContent-Length: " . strlen($this->payload),
                'content'       => $this->payload,
                'timeout'       => 5,
                'ignore_errors' => true,
            ],
        ]);
        @file_get_contents($this->url, false, $context);
    }
}
