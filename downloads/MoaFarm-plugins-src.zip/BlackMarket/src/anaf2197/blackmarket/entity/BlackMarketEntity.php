<?php

namespace anaf2197\blackmarket\entity;

use muqsit\invmenu\InvMenu;
use muqsit\invmenu\transaction\InvMenuTransaction;
use muqsit\invmenu\transaction\InvMenuTransactionResult;
use muqsit\invmenu\type\InvMenuTypeIds;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use pocketmine\scheduler\ClosureTask;
use anaf2197\blackmarket\BlackMarketLoader;
use anaf2197\blackmarket\BlackMarketObject;
use anaf2197\blackmarket\form\BlackMarketBuyForm;
use anaf2197\blackmarket\form\DeleteBlackMarketForm;
use anaf2197\blackmarketprice\BlackMarketPrice;
use anaf2197\economyapi\EconomyAPI;
use anaf2197\servercore\CoreLoader;
use anaf2197\servercore\entity\PlayerClone;
use anaf2197\servercore\item\ServerItems;

final class BlackMarketEntity extends PlayerClone {

    private string $marketLabel = '';
    protected array $page = [];

    protected function initEntity(CompoundTag $nbt): void {
        parent::initEntity($nbt);
        $this->setNameTagVisible();
        $this->setNameTagAlwaysVisible();
        $this->marketLabel = $nbt->getString('marketLabel', '');
    }

    public function saveNBT(): CompoundTag {
        $nbt = parent::saveNBT();
        $nbt->setString('marketLabel', $this->marketLabel);
        return $nbt;
    }

    public function attack(EntityDamageEvent $source): void {
        $source->cancel();
        parent::attack($source);
    }

    public function interact(Player $player): void {
        $loader       = BlackMarketLoader::getInstance();
        $marketObject = $loader->getMarket($this->marketLabel);

        if (is_null($marketObject) || $marketObject->isClosed()) {
            $this->close();
            return;
        }

        $isOp = $player->hasPermission(DefaultPermissions::ROOT_OPERATOR);
        if ($isOp && $player->isSneaking()) {
            $this->close();
                $player->sendMessage(BlackMarketLoader::$prefix . "삽키퍼를 제거했습니다.");
                return;
        }

        $this->interactLookAt($player);
        $invMenu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
        $invMenu->setName('§b');
        $this->page[spl_object_id($player)] = 0;
        $this->reloadInv($invMenu->getInventory(), $player);

        $invMenu->setListener(function (InvMenuTransaction $transaction) use ($marketObject): InvMenuTransactionResult {
            $player     = $transaction->getPlayer();
            $action     = $transaction->getAction();
            $slot       = $action->getSlot();
            $sourceItem = $action->getSourceItem();
            $inventory  = $action->getInventory();
            $pid        = spl_object_id($player);

            switch ($slot) {
                case 45:
                    if (!$sourceItem->isNull()) {
                        $this->page[$pid]--;
                        $this->reloadInv($inventory, $player);
                    }
                    break;

                case 8:
                    $this->handleSellAll($player, $marketObject, $inventory);
                    break;

                case 53:
                    if (!$sourceItem->isNull()) {
                        $this->page[$pid]++;
                        $this->reloadInv($inventory, $player);
                    }
                    break;

                default:
                    $page  = $this->page[$pid] ?? 0;
                    $entry = $marketObject->getItemEntries($page)[$slot] ?? null;
                    if ($entry !== null && $entry['item'] instanceof Item) {
                        $item        = $entry['item'];
                        $priceObject = BlackMarketPrice::getInstance()->getPriceObject();
                        $buyPrice    = $priceObject->getBuyNow($item);
                        $sellPrice   = $priceObject->getSellNow($item);

                        if ($buyPrice > -1 || $sellPrice > -1) {
                            $economyData = EconomyAPI::getInstance()->getEconomyData($player);
                            $player->removeCurrentWindow();
                            BlackMarketLoader::getInstance()->getScheduler()->scheduleDelayedTask(
                                new ClosureTask(function () use ($player, $economyData, $item, $buyPrice, $sellPrice): void {
                                    if ($player->isOnline()) {
                                        $player->sendForm(new BlackMarketBuyForm($economyData, $item, $buyPrice, $sellPrice, $player));
                                    }
                                }), 20
                            );
                        }
                    }
                    break;
            }
            return $transaction->discard();
        });

        $invMenu->send($player);
    }

    // ── 모두 판매 ────────────────────────────────────────────

    private function handleSellAll(Player $player, BlackMarketObject $marketObject, Inventory $inventory): void {
        $economyData = EconomyAPI::getInstance()->getEconomyData($player);
        $priceObject = BlackMarketPrice::getInstance()->getPriceObject();
        $pid         = spl_object_id($player);
        $page        = $this->page[$pid] ?? 0;
        $profit      = 0;
        $sold        = [];

        foreach ($marketObject->getItemEntries($page) as $slot => $entry) {
            if (in_array($slot, [0, 1, 7, 8], true)) continue;
            if (!($entry['item'] instanceof Item)) continue;

            $sellPrice = $priceObject->getSellNow($entry['item']);
            if ($sellPrice <= -1) continue;

            $playerInv = $player->getInventory();
            if (!$playerInv->contains($entry['item'])) continue;

            $count        = CoreLoader::itemHollCount($playerInv, $entry['item']);
            $itemToRemove = clone $entry['item'];
            $itemToRemove->setCount($count);
            $playerInv->removeItem($itemToRemove);
            $profit += $sellPrice * $count;
            $sold[]  = $itemToRemove;
        }

        $mymoney = $economyData->getMoney();
        $economyData->addMoney($profit, '암상인 - 모두 판매하기');
        $player->removeCurrentWindow();

        if (empty($sold)) {
            $player->sendMessage(BlackMarketLoader::$prefix . '판매 가능한 아이템이 없습니다.');
            return;
        }

        $soldStr = implode(', ', array_map(fn(Item $i) => $i->getName() . '§r§8(' . $i->getCount() . ')', $sold));
        $player->sendMessage(BlackMarketLoader::$prefix . '판매한 아이템: §8' . $soldStr);
        $player->sendMessage(BlackMarketLoader::$prefix . '획득: ' . EconomyAPI::koreanWonFormat($profit)
            . '§r§8, 기존: ' . EconomyAPI::koreanWonFormat($mymoney)
            . '§r§8, 최종: ' . EconomyAPI::koreanWonFormat($mymoney + $profit));
    }

    // ── 인벤토리 갱신 ────────────────────────────────────────

    private function reloadInv(Inventory $inventory, Player $player): void {
        $loader       = BlackMarketLoader::getInstance();
        $marketObject = $loader->getMarket($this->marketLabel);
        $priceObject  = BlackMarketPrice::getInstance()->getPriceObject();
        $pid          = spl_object_id($player);
        $page         = $this->page[$pid] ?? 0;

        $contents = [];
        foreach ($marketObject->getItemEntries($page) as $slot => $entry) {
            if (!($entry['item'] instanceof Item)) continue;

            $icon      = clone $entry['item'];
            $buyPrice  = $priceObject->getBuyNow($icon);
            $sellPrice = $priceObject->getSellNow($icon);

            $lore = array_merge($icon->getLore(), [' ']);
            if ($buyPrice > -1)  $lore[] = '§r§8구매: ' . EconomyAPI::koreanWonFormat($buyPrice);
            if ($sellPrice > -1) {
                $lore[] = '§r§8판매: ' . EconomyAPI::koreanWonFormat($sellPrice);
                $lore[] = '§r§8  - 현재 ' . CoreLoader::itemHollCount($player->getInventory(), $icon) . '개 보유중';
            }
            $lore[] = ' ';

            $contents[$slot] = $icon->setLore($lore);
        }

        $inventory->setContents($contents);

        $inventory->setItem(8, ServerItems::TRANSPARENT()
            ->setCustomName('§r§l§5모두 판매하기')
            ->setLore([' ', '§r§8판매 가능한 아이템을 모두 판매합니다.']));

        if ($marketObject->existsPage($page - 1)) {
            $inventory->setItem(45, ServerItems::LEFT_ARROW()
                ->setCustomName('§r§l§f이전 페이지로')
                ->setLore([' ', '§r§8현재 페이지: ' . ($page + 1)]));
        }
        if ($marketObject->existsPage($page + 1)) {
            $inventory->setItem(53, ServerItems::RIGHT_ARROW()
                ->setCustomName('§r§l§f다음 페이지로')
                ->setLore([' ', '§r§8현재 페이지: ' . ($page + 1)]));
        }
    }
}