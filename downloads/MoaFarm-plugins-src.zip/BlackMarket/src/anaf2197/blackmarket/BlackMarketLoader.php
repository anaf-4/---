<?php

namespace anaf2197\blackmarket;

use jsondata\JsonData;
use muqsit\invmenu\InvMenuHandler;
use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\EntityFactory;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\plugin\PluginBase;
use pocketmine\scheduler\ClosureTask;
use pocketmine\utils\SingletonTrait;
use pocketmine\world\World;
use anaf2197\blackmarket\command\CreateMarketCommand;
use anaf2197\blackmarket\command\CreateMarketPageCommand;
use anaf2197\blackmarket\command\DeleteMarketCommand;
use anaf2197\blackmarket\command\DeleteMarketPageCommand;
use anaf2197\blackmarket\command\MarketContentsCommand;
use anaf2197\blackmarket\command\MarketListCommand;
use anaf2197\blackmarket\command\MarketPriceCommand;
use anaf2197\blackmarket\command\MarketPriceSummaryCommand;
use anaf2197\blackmarket\command\MoveMarketCommand;
use anaf2197\blackmarket\command\SpawnMarketCommand;
use anaf2197\blackmarket\entity\BlackMarketEntity;
use anaf2197\blackmarket\task\PriceRefreshTask;
use anaf2197\lib\color\ServerColor;

final class BlackMarketLoader extends PluginBase {

    use SingletonTrait;

    public static string $prefix = '§l§5[암상인] §r§8';

    /** 갱신 주기: 30분 = 20틱/초 × 60초 × 60분 */
    private const PRICE_REFRESH_TICKS = 20 * 60 * 60;

    private JsonData $provider;
    private PriceManager $priceManager;
    private ?\mysqli $priceDb = null;

    protected function onLoad(): void {
        self::setInstance($this);
        ServerColor::setPrefix($this, '암상인');
    }

    protected function onEnable(): void {
        $this->provider     = new JsonData($this, 'blackmarkets', BlackMarketObject::class);
        $this->priceManager = new PriceManager();

        $this->getServer()->getCommandMap()->registerAll(strtolower($this->getName()), [
            new CreateMarketCommand(),
            new CreateMarketPageCommand(),
            new DeleteMarketCommand(),
            new DeleteMarketPageCommand(),
            new MarketContentsCommand(),
            new MarketListCommand(),
            new MarketPriceCommand(),
            new MarketPriceSummaryCommand(),
            new MoveMarketCommand(),
            new SpawnMarketCommand(),
        ]);

        EntityFactory::getInstance()->register(
            BlackMarketEntity::class,
            function (World $world, CompoundTag $nbt): BlackMarketEntity {
                return new BlackMarketEntity(EntityDataHelper::parseLocation($nbt, $world), $nbt);
            },
            ['minecraft::blackmarket']
        );

        if (!InvMenuHandler::isRegistered()) {
            InvMenuHandler::register($this);
        }

        // 다음 정각/30분까지 남은 틱 계산 후 첫 갱신 예약
        $this->scheduleNextRefresh();

        // 거래소 가격 지수 MySQL 연동
        $this->connectPriceDb();

        $this->getLogger()->info('§5[BlackMarket] §r암상인 시스템이 활성화되었습니다.');
    }

    protected function onDisable(): void {
        $this->provider->save();
        $this->priceDb?->close();
        $this->getLogger()->info('§5[BlackMarket] §r암상인 시스템이 비활성화되었습니다.');
    }

    private function connectPriceDb(): void {
        $sharedPath = $this->getServer()->getDataPath() . 'plugins/mysql_shared.yml';
        $cfg = [];
        if (file_exists($sharedPath)) {
            $shared = new \pocketmine\utils\Config($sharedPath);
            $cfg = (array) $shared->get('mysql', []);
        }
        try {
            $db = new \mysqli(
                (string) ($cfg['host'] ?? '127.0.0.1'),
                (string) ($cfg['user'] ?? 'root'),
                (string) ($cfg['password'] ?? ''),
                (string) ($cfg['database'] ?? 'moafarm'),
                (int) ($cfg['port'] ?? 3306)
            );
            if ($db->connect_error) throw new \RuntimeException($db->connect_error);
            $db->set_charset('utf8mb4');
            $db->query('CREATE TABLE IF NOT EXISTS price_index_log (
                id INT AUTO_INCREMENT PRIMARY KEY,
                item_name VARCHAR(200) NOT NULL,
                price_per_unit INT NOT NULL,
                sold_at INT NOT NULL,
                INDEX idx_item_time (item_name, sold_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
            $this->priceDb = $db;

            // AuctionHouse 이벤트 리스너 등록
            if (class_exists(\anaf2197\auctionhouse\event\BuyAuctionItemEvent::class)) {
                $this->getServer()->getPluginManager()->registerEvents(
                    new \anaf2197\blackmarket\listener\AuctionPriceListener($db),
                    $this
                );
                $this->getLogger()->info('§5[BlackMarket] §f거래소 시세 연동 활성화.');
            }
        } catch (\Throwable $e) {
            $this->getLogger()->warning('§5[BlackMarket] §c거래소 시세 MySQL 연결 실패: ' . $e->getMessage());
        }
    }

    public function getPriceDb(): ?\mysqli {
        return $this->priceDb;
    }

    public function reconnectPriceDb(): void {
        try { $this->priceDb?->close(); } catch (\Throwable) {}
        $this->priceDb = null;
        $this->connectPriceDb();
    }

    /**
     * 다음 정각(:00) 또는 30분(:30) 까지 남은 틱을 계산하여
     * 첫 갱신을 예약하고, 이후 30분 주기로 반복합니다.
     */
    private function scheduleNextRefresh(): void {
        $now        = time();
        $minute     = (int)date('i', $now);
        $second     = (int)date('s', $now);

        // 다음 :00 또는 :30 까지 남은 초 계산
        if ($minute < 00) {
            $remainSeconds = (00 - $minute) * 60 - $second;
        } else {
            $remainSeconds = (60 - $minute) * 60 - $second;
        }

        // 최소 1초 보장
        $remainSeconds = max(1, $remainSeconds);
        $delayTicks    = $remainSeconds * 20;

        $this->getLogger()->info("§5[BlackMarket] §r다음 가격 갱신까지 §f{$remainSeconds}초");

        // 첫 갱신: 정각/30분 맞춰서 1회 실행 후 30분 반복 등록
        $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function (): void {
            $this->getScheduler()->scheduleRepeatingTask(new PriceRefreshTask(), self::PRICE_REFRESH_TICKS);
            // 첫 갱신도 즉시 실행
            (new PriceRefreshTask())->onRun();
        }), $delayTicks);
    }

    // ── PriceManager ─────────────────────────────────────────

    public function getPriceManager(): PriceManager {
        return $this->priceManager;
    }

    // ── 프리셋 CRUD ──────────────────────────────────────────

    public function getMarkets(): array {
        return $this->provider->getAll();
    }

    public function getMarket(string $label): ?BlackMarketObject {
        return $this->provider->get($label);
    }

    public function createMarket(string $label, BlackMarketObject $obj): void {
        $this->provider->set($label, $obj);
    }

    public function deleteMarket(string $label): void {
        $this->provider->unset($label);
    }
}