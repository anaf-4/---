<?php

namespace anaf2197\blackmarket\form;

use pocketmine\form\Form;
use pocketmine\item\Item;
use pocketmine\player\Player;
use anaf2197\blackmarket\BlackMarketLoader;
use anaf2197\economyapi\EconomyAPI;
use anaf2197\economyapi\EconomyData;
use anaf2197\servercore\CoreLoader;

final class BlackMarketBuyForm implements Form {

    /** @param int $buyPrice  -1 = 구매 불가 */
    /** @param int $sellPrice -1 = 판매 불가 */
    public function __construct(
        private EconomyData $economyData,
        private Item        $item,
        private int         $buyPrice,
        private int         $sellPrice,
        private Player      $player
    ) {}

    public function jsonSerialize(): array {
        $options = [];
        $label   = [' '];

        if ($this->buyPrice > -1) {
            $label[]   = '§r§8구매가: §f' . EconomyAPI::koreanWonFormat($this->buyPrice);
            $options[] = '구매';
        }
        if ($this->sellPrice > -1) {
            $label[]   = '§r§8판매가: §f' . EconomyAPI::koreanWonFormat($this->sellPrice);
            $label[]   = '§r§8  - 현재 ' . CoreLoader::itemHollCount($this->player->getInventory(), $this->item) . '개 보유중';
            $options[] = '판매';
        }

        $label[] = ' ';
        $label[] = '§r§8보유중인 돈: §f' . EconomyAPI::koreanWonFormat($this->economyData->getMoney());
        $label[] = ' ';

        return [
            'type'    => 'custom_form',
            'title'   => '§l§5' . $this->item->getName() . ' §r§8[암상인]',
            'content' => [
                [
                    'type'    => 'dropdown',
                    'text'    => implode(PHP_EOL, $label),
                    'options' => $options,
                    'default' => 0,
                ],
                [
                    'type'        => 'input',
                    'text'        => PHP_EOL . '개수' . PHP_EOL . ' ',
                    'placeholder' => '§8구매 또는 판매할 개수를 입력해주세요.',
                ],
            ],
        ];
    }

    public function handleResponse(Player $player, $data): void {
        if (!is_array($data)) return;

        $options = [];
        if ($this->buyPrice > -1) $options[]  = '구매';
        if ($this->sellPrice > -1) $options[] = '판매';

        $typeIndex = array_shift($data);
        $type      = $options[$typeIndex] ?? null;
        $countRaw  = array_shift($data) ?? null;

        if ($type === null) return;

        if (!is_numeric($countRaw)) {
            $player->sendMessage(BlackMarketLoader::$prefix . '수량은 숫자로 입력해주세요.');
            return;
        }

        $count = (int)floor(abs((float)$countRaw));
        if ($count <= 0) {
            $player->sendMessage(BlackMarketLoader::$prefix . '수량은 0보다 커야합니다.');
            return;
        }

        $economyData = $this->economyData;
        $mymoney     = $economyData->getMoney();

        if ($type === '구매') {
            $totalPrice = $this->buyPrice * $count;
            if ($mymoney < $totalPrice) {
                $player->sendMessage(BlackMarketLoader::$prefix . '소지중인 돈이 부족합니다.');
                return;
            }
            $itemToAdd = clone $this->item;
            $itemToAdd->setCount($count);
            if (!$player->getInventory()->canAddItem($itemToAdd)) {
                $player->sendMessage(BlackMarketLoader::$prefix . '인벤토리가 부족합니다.');
                return;
            }
            $player->getInventory()->addItem($itemToAdd);
            $economyData->reduceMoney($totalPrice, false, '암상인 - 아이템 구매');
            $player->sendMessage(BlackMarketLoader::$prefix . $this->item->getName() . ' §r§8(을)를 §d' . $count . '§8개 구매하셨습니다.');
            $player->sendMessage(BlackMarketLoader::$prefix . '소비: ' . EconomyAPI::koreanWonFormat($totalPrice)
                . '§r§8, 기존: ' . EconomyAPI::koreanWonFormat($mymoney)
                . '§r§8, 최종: ' . EconomyAPI::koreanWonFormat($mymoney - $totalPrice));
        } else {
            $have = CoreLoader::itemHollCount($player->getInventory(), $this->item);
            if ($have < $count) {
                $player->sendMessage(BlackMarketLoader::$prefix . '소지중인 아이템이 부족합니다. (보유: ' . $have . '개)');
                return;
            }
            $totalPrice    = $this->sellPrice * $count;
            $itemToRemove  = clone $this->item;
            $itemToRemove->setCount($count);
            $player->getInventory()->removeItem($itemToRemove);
            $economyData->addMoney($totalPrice, false, '암상인 - 아이템 판매');
            $player->sendMessage(BlackMarketLoader::$prefix . $this->item->getName() . ' §r§8(을)를 §d' . $count . '§8개 판매하셨습니다.');
            $player->sendMessage(BlackMarketLoader::$prefix . '획득: ' . EconomyAPI::koreanWonFormat($totalPrice)
                . '§r§8, 기존: ' . EconomyAPI::koreanWonFormat($mymoney)
                . '§r§8, 최종: ' . EconomyAPI::koreanWonFormat($mymoney + $totalPrice));
        }
    }
}
