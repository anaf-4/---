<?php

namespace anaf2197\blackmarket\form;

use pocketmine\form\Form;
use pocketmine\player\Player;
use anaf2197\blackmarket\BlackMarketLoader;
use anaf2197\blackmarket\BlackMarketObject;
use anaf2197\blackmarket\entity\BlackMarketEntity;

final class DeleteBlackMarketForm implements Form {

    public function __construct(private string $marketLabel, private BlackMarketEntity $entity) {}

    public function jsonSerialize(): array {
        return [
            'type'    => 'modal',
            'title'   => '§l§5암상인 완전 삭제',
            'content' => "§8정말로 '§f{$this->marketLabel}§8' 암상인 프리셋을 완전히 삭제하시겠습니까?\n\n§4이 암상인과 관련된 모든 엔티티가 제거되며,\n§4프리셋 데이터도 영구적으로 삭제됩니다.\n\n§e이 작업은 되돌릴 수 없습니다!",
            'button1' => '§l§4완전 삭제',
            'button2' => '§l§0취소',
        ];
    }

    public function handleResponse(Player $player, $data): void {
        if ($data !== true) return;

        $loader = BlackMarketLoader::getInstance();
        $obj    = $loader->getMarket($this->marketLabel);
        if ($obj instanceof BlackMarketObject) {
            $obj->close();
            $loader->deleteMarket($this->marketLabel);
            $player->sendMessage(BlackMarketLoader::$prefix . "§5'{$this->marketLabel}'§8 암상인 프리셋과 관련된 모든 엔티티가 제거되었습니다.");
        } else {
            $player->sendMessage(BlackMarketLoader::$prefix . '이미 삭제된 프리셋입니다.');
        }
    }
}
