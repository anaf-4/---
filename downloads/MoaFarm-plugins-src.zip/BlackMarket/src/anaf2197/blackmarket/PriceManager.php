<?php

namespace anaf2197\blackmarket;

use pocketmine\item\Item;
use anaf2197\blackmarket\task\DiscordNotifyTask;
use anaf2197\blackmarketprice\BlackMarketPrice;

final class PriceManager {

    private const RANDOM_RANGE    = 0.20;
    private const DISCORD_BOT_URL = 'http://127.0.0.1:8765/blackmarket_price';

    public function refreshAll(): float {
        $plugin      = BlackMarketPrice::getInstance();
        $priceObject = $plugin->getPriceObject();

        $factors = [];
        $priceObject->refreshNowPrices(function (int $base) use (&$factors): int {
            if ($base <= -1) return -1;
            $min       = (int)((1.0 - self::RANDOM_RANGE) * 100);
            $max       = (int)((1.0 + self::RANDOM_RANGE) * 100);
            $factor    = mt_rand($min, $max) / 100.0;
            $factors[] = $factor;
            return (int)round($base * $factor);
        });

        $this->notifyDiscord();

        if (empty($factors)) return 0.0;
        $avgFactor = array_sum($factors) / count($factors);
        return round(($avgFactor - 1.0) * 100, 1);
    }

    /**
     * 프리셋별로 전체 아이템 목록을 봇으로 전송
     * payload: { markets: [ { name, items: [...] }, ... ] }
     * 페이지 분할은 봇에서 처리
     */
    private function notifyDiscord(): void {
        $loader      = BlackMarketLoader::getInstance();
        $priceObject = BlackMarketPrice::getInstance()->getPriceObject();
        $markets     = $loader->getMarkets();

        if (empty($markets)) return;

        $marketData = [];

        /** @var BlackMarketObject $marketObj */
        foreach ($markets as $marketObj) {
            $presetName  = $marketObj->getLabel();
            $presetItems = [];

            for ($p = 0; $marketObj->existsPage($p); $p++) {
                foreach ($marketObj->getItemEntries($p) as $entry) {
                    if (!($entry['item'] instanceof Item)) continue;
                    $item = $entry['item'];
                    $presetItems[] = [
                        'name'     => $item->getName(),
                        'buyBase'  => $priceObject->getBuyBase($item),
                        'sellBase' => $priceObject->getSellBase($item),
                        'buyNow'   => $priceObject->getBuyNow($item),
                        'sellNow'  => $priceObject->getSellNow($item),
                    ];
                }
            }

            if (!empty($presetItems)) {
                $marketData[] = [
                    'name'  => $presetName,
                    'items' => $presetItems,
                ];
            }
        }

        if (empty($marketData)) return;

        $payload = json_encode(['markets' => $marketData]);
        BlackMarketLoader::getInstance()->getServer()->getAsyncPool()->submitTask(
            new DiscordNotifyTask(self::DISCORD_BOT_URL, $payload)
        );
    }

    /**
     * 지정한 퍼센트로 모든 아이템 현재가를 고정 갱신합니다.
     * @param float $percent  변동 퍼센트 (예: 10 = +10%, -5 = -5%)
     * @return float  실제 적용된 퍼센트
     */
    public function refreshWithPercent(float $percent): float {
        $plugin      = BlackMarketPrice::getInstance();
        $priceObject = $plugin->getPriceObject();
        $factor      = 1.0 + ($percent / 100.0);

        $priceObject->refreshNowPrices(function (int $base) use ($factor): int {
            if ($base <= -1) return -1;
            return (int)round($base * $factor);
        });

        $this->notifyDiscord();
        return round($percent, 1);
    }

    public function getBuyNow(Item $item): int {
        return BlackMarketPrice::getInstance()->getPriceObject()->getBuyNow($item);
    }

    public function getSellNow(Item $item): int {
        return BlackMarketPrice::getInstance()->getPriceObject()->getSellNow($item);
    }

    public function getStatusSummary(): string {
        $count = BlackMarketPrice::getInstance()->getPriceObject()->count();
        return "§8등록 아이템: §f{$count}개 §8| 변동 범위: §f±20%";
    }

    /**
     * 최근 7일 거래소 거래 데이터 기반 아이템 평균 단가.
     * 데이터 없으면 -1 반환.
     */
    public function getAuctionAvgPrice(string $itemName): int {
        $db = BlackMarketLoader::getInstance()->getPriceDb();
        if ($db === null) return -1;

        $since = time() - 7 * 86400;
        $stmt  = $db->prepare(
            'SELECT AVG(price_per_unit) AS avg_price, COUNT(*) AS cnt
             FROM price_index_log
             WHERE item_name = ? AND sold_at >= ?'
        );
        $stmt->bind_param('si', $itemName, $since);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ((int) ($row['cnt'] ?? 0) === 0) return -1;
        return (int) round((float) $row['avg_price']);
    }

    /**
     * 최근 7일 기준 거래량 상위 아이템 목록 반환.
     */
    public function getTopAuctionItems(int $limit = 10): array {
        $db = BlackMarketLoader::getInstance()->getPriceDb();
        if ($db === null) return [];

        $since = time() - 7 * 86400;
        $stmt  = $db->prepare(
            'SELECT item_name, AVG(price_per_unit) AS avg_price, COUNT(*) AS trades
             FROM price_index_log
             WHERE sold_at >= ?
             GROUP BY item_name
             ORDER BY trades DESC
             LIMIT ?'
        );
        $stmt->bind_param('ii', $since, $limit);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        return $rows;
    }
}