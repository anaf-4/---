<?php

namespace anaf2197\blackmarket\command;

use pocketmine\player\Player;
use anaf2197\blackmarket\BlackMarketLoader;
use anaf2197\blackmarket\entity\BlackMarketEntity;

final class MoveMarketCommand extends BlackMarketCommand {

    public function __construct() {
        parent::__construct('암상인이동', '특정 암상인을 자신의 위치로 이동시킵니다.', ['movemarket']);
    }

    protected function run(Player $player, array $args): void {
        $label = implode(' ', $args);
        if (trim($label) === '') {
            $player->sendMessage(BlackMarketLoader::$prefix . '/암상인이동 [이름]');
            return;
        }
        $loader = BlackMarketLoader::getInstance();
        if ($loader->getMarket($label) === null) {
            $player->sendMessage(BlackMarketLoader::$prefix . '존재하지 않는 프리셋입니다.');
            return;
        }
        $location = $player->getLocation();
        $moved    = 0;
        foreach ($player->getWorld()->getEntities() as $entity) {
            if (!$entity instanceof BlackMarketEntity) continue;
            $nbt = $entity->saveNBT();
            if ($nbt->getString('marketLabel', '') === $label) {
                $entity->teleport($location);
                $moved++;
            }
        }
        if ($moved > 0) {
            $player->sendMessage(BlackMarketLoader::$prefix . "§5'{$label}'§8 암상인 §d{$moved}§8개를 현재 위치로 이동시켰습니다.");
        } else {
            $player->sendMessage(BlackMarketLoader::$prefix . "이 월드에 §5'{$label}'§8 암상인이 없습니다.");
        }
    }
}
