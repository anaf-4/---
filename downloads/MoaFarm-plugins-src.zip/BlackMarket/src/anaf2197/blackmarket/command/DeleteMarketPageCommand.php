<?php

namespace anaf2197\blackmarket\command;

use pocketmine\player\Player;
use anaf2197\blackmarket\BlackMarketLoader;
use anaf2197\blackmarket\BlackMarketObject;

final class DeleteMarketPageCommand extends BlackMarketCommand {

    public function __construct() {
        parent::__construct('암상인페이지제거', '암상인 페이지를 제거합니다.', ['deletemarketpage']);
    }

    protected function run(Player $player, array $args): void {
        $page  = array_pop($args);
        $label = implode(' ', $args);

        if (trim($label) === '' || trim((string)$page) === '') {
            $player->sendMessage(BlackMarketLoader::$prefix . '/암상인페이지제거 [이름] [페이지]');
            return;
        }
        if (!is_numeric($page)) {
            $player->sendMessage(BlackMarketLoader::$prefix . '페이지는 숫자로 입력해야합니다.');
            return;
        }

        $pageIndex = (int)$page - 1;
        $obj       = BlackMarketLoader::getInstance()->getMarket($label);

        if (!$obj instanceof BlackMarketObject) {
            $player->sendMessage(BlackMarketLoader::$prefix . '존재하지 않는 프리셋입니다.');
            return;
        }
        if (!$obj->existsPage($pageIndex)) {
            $player->sendMessage(BlackMarketLoader::$prefix . '존재하지 않는 페이지입니다.');
            return;
        }

        $obj->deletePage($pageIndex);
        $player->sendMessage(BlackMarketLoader::$prefix . ($pageIndex + 1) . '페이지를 제거했습니다.');
    }
}
