<?php

namespace anaf2197\blackmarket\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;

abstract class BlackMarketCommand extends Command {

    public function __construct(string $name, string $description, array $aliases = []) {
        parent::__construct($name, $description, null, $aliases);
        $this->setPermission(DefaultPermissions::ROOT_OPERATOR);
    }

    final public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if (!$sender instanceof Player) {
            $sender->sendMessage('§c플레이어만 사용 가능한 커맨드입니다.');
            return;
        }
        if ($this->testPermission($sender)) {
            $this->run($sender, $args);
        }
    }

    abstract protected function run(Player $player, array $args): void;
}
