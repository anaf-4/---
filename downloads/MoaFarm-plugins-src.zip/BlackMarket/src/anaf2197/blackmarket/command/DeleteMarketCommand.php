<?php

namespace anaf2197\blackmarket\command;

use pocketmine\player\Player;
use anaf2197\blackmarket\BlackMarketLoader;

final class DeleteMarketCommand extends BlackMarketCommand {

    public function __construct() {
        parent::__construct('암상인제거', '암상인 프리셋을 제거합니다.', ['deletemarket']);
    }

    protected function run(Player $player, array $args): void {
        $label = implode(' ', $args);
        if (trim($label) === '') {
            $player->sendMessage(BlackMarketLoader::$prefix . '/암상인제거 [이름]');
            return;
        }
        $loader = BlackMarketLoader::getInstance();
        $obj    = $loader->getMarket($label);
        if ($obj === null) {
            $player->sendMessage(BlackMarketLoader::$prefix . '존재하지 않는 프리셋입니다.');
            return;
        }
        $obj->close();
        $loader->deleteMarket($label);
        $player->sendMessage(BlackMarketLoader::$prefix . "§5'{$label}'§8 암상인 프리셋을 제거했습니다. 관련 엔티티가 모두 제거됩니다.");
    }
}
