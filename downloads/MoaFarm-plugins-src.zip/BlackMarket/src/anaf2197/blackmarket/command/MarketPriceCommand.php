<?php

namespace anaf2197\blackmarket\command;

use pocketmine\player\Player;
use anaf2197\blackmarket\BlackMarketLoader;

/**
 * /암상인가격              → 현재 상태 조회
 * /암상인가격 갱신         → 랜덤 변동 즉시 재갱신
 * /암상인가격 갱신 [퍼센트] → 지정 퍼센트로 고정 갱신 (예: 갱신 10 = +10%, 갱신 -5 = -5%)
 */
final class MarketPriceCommand extends BlackMarketCommand {

    public function __construct() {
        parent::__construct('암상인가격', '암상인 가격 상태를 확인하거나 즉시 갱신합니다.', ['marketprice']);
    }

    protected function run(Player $player, array $args): void {
        $pm     = BlackMarketLoader::getInstance()->getPriceManager();
        $prefix = BlackMarketLoader::$prefix;

        if (empty($args)) {
            $player->sendMessage($prefix . $pm->getStatusSummary());
            $player->sendMessage('§8  /암상인가격 갱신          §8- 랜덤 변동 즉시 재갱신');
            $player->sendMessage('§8  /암상인가격 갱신 [퍼센트] §8- 지정 퍼센트로 고정 갱신 (예: 10, -5)');
            return;
        }

        if ($args[0] === '갱신') {
            $fixedPercent = isset($args[1]) && is_numeric($args[1]) ? (float)$args[1] : null;

            if ($fixedPercent !== null) {
                if ($fixedPercent < -20.0 || $fixedPercent > 20.0) {
                    $player->sendMessage($prefix . '퍼센트는 -20 ~ +20 범위 내로 입력해주세요.');
                    return;
                }
                $percent = $pm->refreshWithPercent($fixedPercent);
            } else {
                $percent = $pm->refreshAll();
            }

            $sign = $percent >= 0 ? '+' : '';
            BlackMarketLoader::getInstance()->getServer()->broadcastMessage(
                $prefix . "암상인 가격이 변동되었습니다! §f{$sign}{$percent}%"
            );
            $player->sendMessage($prefix . $pm->getStatusSummary());
            return;
        }

        $player->sendMessage($prefix . '올바른 인자를 입력해주세요. /암상인가격 으로 도움말 확인.');
    }
}