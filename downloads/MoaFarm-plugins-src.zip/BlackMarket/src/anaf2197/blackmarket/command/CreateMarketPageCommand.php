<?php

namespace anaf2197\blackmarket\command;

use pocketmine\player\Player;
use anaf2197\blackmarket\BlackMarketLoader;
use anaf2197\blackmarket\BlackMarketObject;

final class CreateMarketPageCommand extends BlackMarketCommand {

    public function __construct() {
        parent::__construct('암상인페이지생성', '암상인에 페이지를 추가합니다.', ['createmarketpage']);
    }

    protected function run(Player $player, array $args): void {
        $label = implode(' ', $args);
        if (trim($label) === '') {
            $player->sendMessage(BlackMarketLoader::$prefix . '/암상인페이지생성 [이름]');
            return;
        }
        $obj = BlackMarketLoader::getInstance()->getMarket($label);
        if (!$obj instanceof BlackMarketObject) {
            $player->sendMessage(BlackMarketLoader::$prefix . '존재하지 않는 프리셋입니다.');
            return;
        }
        $obj->createPage();
        $player->sendMessage(BlackMarketLoader::$prefix . "§5'{$label}'§8 에 새 페이지를 추가했습니다. (총 §d" . $obj->getPageCount() . "§8페이지)");
    }
}
