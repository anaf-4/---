<?php

namespace anaf2197\blackmarket\command;

use pocketmine\player\Player;
use anaf2197\blackmarket\BlackMarketLoader;
use anaf2197\blackmarket\BlackMarketObject;

final class CreateMarketCommand extends BlackMarketCommand {

    public function __construct() {
        parent::__construct('암상인생성', '암상인 프리셋을 생성합니다.', ['createmarket']);
    }

    protected function run(Player $player, array $args): void {
        $label = implode(' ', $args);
        if (trim($label) === '') {
            $player->sendMessage(BlackMarketLoader::$prefix . '/암상인생성 [이름]');
            return;
        }
        $loader = BlackMarketLoader::getInstance();
        if ($loader->getMarket($label) !== null) {
            $player->sendMessage(BlackMarketLoader::$prefix . '이미 존재하는 프리셋 이름입니다.');
            return;
        }
        $loader->createMarket($label, new BlackMarketObject($label, false, [[]]));
        $player->sendMessage(BlackMarketLoader::$prefix . "§5'{$label}'§8 암상인 프리셋을 생성했습니다.");
    }
}
