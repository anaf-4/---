<?php

declare(strict_types=1);

namespace anaf2197\blackmarket\command;

use anaf2197\blackmarket\BlackMarketLoader;
use anaf2197\blackmarketprice\BlackMarketPrice;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\form\Form;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;

final class MarketPriceSummaryCommand extends Command {

    public function __construct() {
        parent::__construct('시세', '암상인 현재 시세를 확인합니다.', '/시세', ['market_price']);
        $this->setPermission(DefaultPermissions::ROOT_USER);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if (!$this->testPermission($sender)) return;
        if (!$sender instanceof Player) {
            $sender->sendMessage('§c플레이어만 사용 가능합니다.');
            return;
        }

        $pricePlugin = BlackMarketPrice::getInstance();
        if ($pricePlugin === null) {
            $sender->sendMessage(BlackMarketLoader::$prefix . '가격 데이터를 불러올 수 없습니다.');
            return;
        }

        $priceObj = $pricePlugin->getPriceObject();
        $all      = $priceObj->getAll();

        if (empty($all)) {
            $sender->sendMessage(BlackMarketLoader::$prefix . '등록된 아이템이 없습니다.');
            return;
        }

        // 마켓 프리셋별로 아이템 분류
        $markets = BlackMarketLoader::getInstance()->getMarkets();
        $sections = [];

        /** @var \anaf2197\blackmarket\BlackMarketObject $marketObj */
        foreach ($markets as $marketObj) {
            $presetName = $marketObj->getLabel();
            $lines = [];

            for ($p = 0; $marketObj->existsPage($p); $p++) {
                foreach ($marketObj->getItemEntries($p) as $entry) {
                    if (!($entry['item'] instanceof \pocketmine\item\Item)) continue;
                    $item    = $entry['item'];
                    $buyNow  = $priceObj->getBuyNow($item);
                    $sellNow = $priceObj->getSellNow($item);
                    $buyBase = $priceObj->getBuyBase($item);

                    if ($buyNow < 0 && $sellNow < 0) continue;

                    // 등락 표시
                    $arrow = '';
                    if ($buyBase > 0 && $buyNow > 0) {
                        $diff = $buyNow - $buyBase;
                        if ($diff > 0)       $arrow = ' §a▲';
                        elseif ($diff < 0)   $arrow = ' §c▼';
                        else                  $arrow = ' §8─';
                    }

                    $buyStr  = $buyNow  > 0 ? '§e' . number_format($buyNow)  . '원' : '§8-';
                    $sellStr = $sellNow > 0 ? '§b' . number_format($sellNow) . '원' : '§8-';
                    $lines[] = ' §f' . $item->getName() . $arrow;
                    $lines[] = '   §8구매 ' . $buyStr . '  §8판매 ' . $sellStr;
                }
            }

            if (!empty($lines)) {
                $sections[] = '§l§5[ ' . $presetName . ' ]';
                foreach ($lines as $line) $sections[] = $line;
                $sections[] = ' ';
            }
        }

        // 프리셋 분류 안된 아이템이 있으면 최상위 10개 추가
        if (empty($sections)) {
            $sections[] = '§l§5[ 암상인 시세 요약 ]';
            $count = 0;
            foreach ($all as $data) {
                if ($count >= 20) break;
                $buyNow  = (int)($data['buyNow']  ?? -1);
                $sellNow = (int)($data['sellNow'] ?? -1);
                $buyBase = (int)($data['buyBase'] ?? 0);
                if ($buyNow < 0 && $sellNow < 0) continue;

                $arrow = '';
                if ($buyBase > 0 && $buyNow > 0) {
                    $diff = $buyNow - $buyBase;
                    if ($diff > 0) $arrow = ' §a▲';
                    elseif ($diff < 0) $arrow = ' §c▼';
                    else $arrow = ' §8─';
                }

                $buyStr  = $buyNow  > 0 ? '§e' . number_format($buyNow)  . '원' : '§8-';
                $sellStr = $sellNow > 0 ? '§b' . number_format($sellNow) . '원' : '§8-';
                $sections[] = ' §f' . ($data['itemName'] ?? '?') . $arrow;
                $sections[] = '   §8구매 ' . $buyStr . '  §8판매 ' . $sellStr;
                $count++;
            }
        }

        $content = implode("\n", $sections);

        $sender->sendForm(new class($content) implements Form {
            public function __construct(private string $content) {}
            public function jsonSerialize(): array {
                return [
                    'type'    => 'form',
                    'title'   => '§l§5암상인 현재 시세',
                    'content' => $this->content,
                    'buttons' => [['text' => '§a확인']],
                ];
            }
            public function handleResponse(Player $player, $data): void {}
        });
    }
}
