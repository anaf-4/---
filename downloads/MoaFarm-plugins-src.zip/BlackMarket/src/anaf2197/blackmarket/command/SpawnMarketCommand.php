<?php

namespace anaf2197\blackmarket\command;

use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\player\Player;
use anaf2197\blackmarket\BlackMarketLoader;
use anaf2197\blackmarket\entity\BlackMarketEntity;
use anaf2197\lib\skinparser\SkinParser;

final class SpawnMarketCommand extends BlackMarketCommand {

    public function __construct() {
        parent::__construct('암상인소환', '암상인 엔티티를 소환합니다.', ['spawnmarket']);
    }

    protected function run(Player $player, array $args): void {
        $label = implode(' ', $args);
        if (trim($label) === '') {
            $player->sendMessage(BlackMarketLoader::$prefix . '/암상인소환 [이름]');
            return;
        }
        $loader = BlackMarketLoader::getInstance();
        if ($loader->getMarket($label) === null) {
            $player->sendMessage(BlackMarketLoader::$prefix . '존재하지 않는 프리셋입니다.');
            return;
        }
        $location = $player->getLocation();
        $entity   = new BlackMarketEntity(
            $location,
            CompoundTag::create()
                ->setTag('Rotation', new ListTag([new FloatTag($location->getYaw()), new FloatTag($location->getPitch())]))
                ->setString('marketLabel', $label)
                ->setString('skin', implode(':', SkinParser::toArray($player->getSkin())))
        );
        $entity->spawnToAll();
        $entity->setNameTag("§l§5암상인\n§r§f" . $label);
        $player->sendMessage(BlackMarketLoader::$prefix . "§5'{$label}'§8 암상인을 소환했습니다.");
    }
}
