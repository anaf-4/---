<?php

namespace anaf2197\blackmarket\command;

use muqsit\invmenu\InvMenu;
use muqsit\invmenu\transaction\InvMenuTransaction;
use muqsit\invmenu\transaction\InvMenuTransactionResult;
use muqsit\invmenu\type\InvMenuTypeIds;
use pocketmine\block\VanillaBlocks;
use pocketmine\item\Item;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use anaf2197\blackmarket\BlackMarketLoader;
use anaf2197\blackmarket\BlackMarketObject;

/**
 * /암상인수정 [이름] [페이지] - 아이템 배치만 수정
 * 기존 가격(buyBase, sellBase)은 유지됩니다.
 */
final class MarketContentsCommand extends BlackMarketCommand {

    public function __construct() {
        parent::__construct('암상인수정', '암상인 아이템 배치를 수정합니다.', ['editmarket', 'marketcontents']);
    }

    protected function run(Player $player, array $args): void {
        $page  = array_pop($args);
        $label = implode(' ', $args);

        if (trim($label) === '' || trim((string)$page) === '') {
            $player->sendMessage(BlackMarketLoader::$prefix . '/암상인수정 [이름] [페이지]');
            return;
        }
        if (!is_numeric($page)) {
            $player->sendMessage(BlackMarketLoader::$prefix . '페이지는 숫자로 입력해야합니다.');
            return;
        }

        $pageIndex = (int)$page - 1;
        $loader    = BlackMarketLoader::getInstance();
        $obj       = $loader->getMarket($label);

        if (!$obj instanceof BlackMarketObject) {
            $player->sendMessage(BlackMarketLoader::$prefix . '존재하지 않는 프리셋입니다.');
            return;
        }
        if (!$obj->existsPage($pageIndex)) {
            $player->sendMessage(BlackMarketLoader::$prefix . '존재하지 않는 페이지입니다.');
            return;
        }

        $invMenu   = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
        $invMenu->setName('§b');
        $inventory = $invMenu->getInventory();

        // 기존 아이템 로드
        $existing = [];
        foreach ($obj->getItemEntries($pageIndex) as $slot => $entry) {
            if ($entry['item'] instanceof Item) {
                $existing[$slot] = $entry['item'];
            }
        }
        $inventory->setContents($existing);

        $barrier = VanillaBlocks::BARRIER()->asItem()->setCustomName(' ');
        foreach ([45, 53, 8] as $s) $inventory->setItem($s, $barrier);
        $inventory->setItem(7, VanillaItems::NETHER_STAR()
            ->setCustomName('§r§l§f배치 저장')
            ->setLore([' ', '§r§8터치 시 현재 배치로 저장됩니다.', '§r§8가격은 기존 값이 유지됩니다.']));

        $invMenu->setListener(function (InvMenuTransaction $transaction) use ($obj, $pageIndex): InvMenuTransactionResult {
            $action = $transaction->getAction();
            $slot   = $action->getSlot();
            $player = $transaction->getPlayer();

            if (!in_array($slot, [45, 53, 7, 8], true)) {
                return $transaction->continue();
            }

            if ($slot === 7) {
                // 기존 가격 데이터 보존
                $oldEntries = $obj->getItemEntries($pageIndex);

                $newEntries = [];
                foreach ($action->getInventory()->getContents() as $i => $item) {
                    if (in_array($i, [45, 53, 7, 8], true)) continue;
                    $newEntries[$i] = [
                        'item'     => $item->setCount(1),
                        'buyBase'  => $oldEntries[$i]['buyBase']  ?? -1,
                        'sellBase' => $oldEntries[$i]['sellBase'] ?? -1,
                    ];
                }

                $obj->setItemEntries($pageIndex, $newEntries);
                $player->removeCurrentWindow();
                $player->sendMessage(BlackMarketLoader::$prefix . ($pageIndex + 1) . '페이지 배치를 저장했습니다.');
            }
            return $transaction->discard();
        });

        $invMenu->send($player);
    }
}