<?php

namespace anaf2197\blackmarket\command;

use pocketmine\player\Player;
use anaf2197\blackmarket\BlackMarketLoader;
use anaf2197\blackmarket\BlackMarketObject;

final class MarketListCommand extends BlackMarketCommand {

    public function __construct() {
        parent::__construct('암상인목록', '생성된 암상인 프리셋 목록을 확인합니다.', ['marketlist']);
    }

    protected function run(Player $player, array $args): void {
        $markets = BlackMarketLoader::getInstance()->getMarkets();
        $pm      = BlackMarketLoader::getInstance()->getPriceManager();

        $player->sendMessage(BlackMarketLoader::$prefix . '생성된 암상인 프리셋: §d' . count($markets) . '§8개');
        $player->sendMessage(BlackMarketLoader::$prefix . $pm->getStatusSummary());

        /** @var BlackMarketObject $obj */
        foreach ($markets as $obj) {
            $entries  = $obj->getItemEntries(0);
            $nameList = [];
            foreach (array_slice($entries, 0, 3, true) as $entry) {
                if ($entry['item'] !== null) {
                    $nameList[] = $entry['item']->getName();
                }
            }
            $preview = implode(', ', $nameList);
            if (empty($preview)) $preview = '§8(비어있음)';
            $pages = $obj->getPageCount();
            $player->sendMessage("§8- §5" . $obj->getLabel() . "§8: {$preview} ... §8[{$pages}페이지]");
        }
    }
}
