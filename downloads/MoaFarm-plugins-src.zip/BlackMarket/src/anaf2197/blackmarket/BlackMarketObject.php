<?php

namespace anaf2197\blackmarket;

use jsondata\JsonObject;
use pocketmine\item\Item;
use anaf2197\lib\itemparser\ItemParser;

/**
 * 암상인 프리셋 데이터
 *
 * 각 아이템마다 독립적인 기준가격(buyBase, sellBase)을 가지며,
 * 시간대별 배율과 랜덤 ±20% 변동이 적용됩니다.
 *
 * items 구조:
 *   [ page => [ slot => ['item' => itemString, 'buyBase' => int, 'sellBase' => int] ] ]
 */
final class BlackMarketObject implements JsonObject {

    public function __construct(
        private string $label,
        private bool   $closed,
        private array  $items   // page => slot => ['item'=>string, 'buyBase'=>int, 'sellBase'=>int]
    ) {}

    public function getLabel(): string {
        return $this->label;
    }

    public function isClosed(): bool {
        return $this->closed;
    }

    public function close(): void {
        $this->closed = true;
    }

    // ── 페이지 관련 ─────────────────────────────────────────

    public function existsPage(int $page): bool {
        return isset($this->items[$page]);
    }

    public function createPage(): void {
        $this->items[] = [];
    }

    public function deletePage(int $page): void {
        unset($this->items[$page]);
        $this->items = array_values($this->items);
    }

    public function getPageCount(): int {
        return count($this->items);
    }

    // ── 아이템 관련 ─────────────────────────────────────────

    /**
     * 특정 페이지의 아이템 배열 반환
     * [ slot => ['item' => Item, 'buyBase' => int, 'sellBase' => int] ]
     */
    public function getItemEntries(int $page): array {
        return $this->items[$page] ?? [];
    }

    public function setItemEntries(int $page, array $entries): void {
        $this->items[$page] = $entries;
    }

    /**
     * 특정 슬롯의 Item 객체만 반환 (없으면 null)
     */
    public function getItem(int $page, int $slot): ?Item {
        $entry = $this->items[$page][$slot] ?? null;
        if ($entry === null) return null;
        return $entry['item'] instanceof Item ? $entry['item'] : null;
    }

    /**
     * 특정 슬롯의 기준 구매가 반환 (-1 = 구매 불가)
     */
    public function getBuyBase(int $page, int $slot): int {
        return $this->items[$page][$slot]['buyBase'] ?? -1;
    }

    /**
     * 특정 슬롯의 기준 판매가 반환 (-1 = 판매 불가)
     */
    public function getSellBase(int $page, int $slot): int {
        return $this->items[$page][$slot]['sellBase'] ?? -1;
    }

    // ── 직렬화 ──────────────────────────────────────────────

    public function jsonSerialize(): array {
        return [
            $this->label,
            $this->closed,
            array_map(function (array $slots): array {
                $result = [];
                foreach ($slots as $slot => $entry) {
                    $result[$slot] = [
                        'item'     => ItemParser::toString($entry['item']),
                        'buyBase'  => $entry['buyBase'],
                        'sellBase' => $entry['sellBase'],
                    ];
                }
                return $result;
            }, $this->items)
        ];
    }

    public static function jsonDeserialize(array $json): self {
        $pages = array_map(function (array $slots): array {
            $result = [];
            foreach ($slots as $slot => $entry) {
                $result[(int)$slot] = [
                    'item'     => ItemParser::fromString($entry['item']),
                    'buyBase'  => (int)$entry['buyBase'],
                    'sellBase' => (int)$entry['sellBase'],
                ];
            }
            return $result;
        }, $json[2]);

        return new self($json[0], $json[1], $pages);
    }
}
