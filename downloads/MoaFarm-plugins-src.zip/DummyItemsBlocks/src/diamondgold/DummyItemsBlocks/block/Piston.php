<?php

namespace diamondgold\DummyItemsBlocks\block;

use diamondgold\DummyItemsBlocks\Main;
use diamondgold\DummyItemsBlocks\tile\DummyTile;
use diamondgold\DummyItemsBlocks\tile\DummyTileTrait;
use diamondgold\DummyItemsBlocks\tile\TileNames;
use diamondgold\DummyItemsBlocks\tile\TileNbtTagNames;
use Kkevin14\StickyPiston\sound\PistonInSound;
use Kkevin14\StickyPiston\sound\PistonOutSound;
use pocketmine\block\Air;
use pocketmine\block\Block;
use pocketmine\block\Opaque;
use pocketmine\block\tile\Tile;
use pocketmine\block\utils\AnyFacingTrait;
use pocketmine\block\VanillaBlocks;
use pocketmine\data\bedrock\block\BlockTypeNames;
use pocketmine\item\Item;
use pocketmine\math\Facing;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\player\Player;
use pocketmine\world\BlockTransaction;
use pocketmine\world\format\io\GlobalBlockStateHandlers;

class Piston extends Opaque
{
    use AnyFacingTrait;
    use DummyTileTrait;

    public const STATE_RETRACTED  = 0;
    public const STATE_EXTENDED = 2;

    public function place(BlockTransaction $tx, Item $item, Block $blockReplace, Block $blockClicked, int $face, Vector3 $clickVector, ?Player $player = null): bool
    {
        $this->setFacing(in_array($face, Facing::HORIZONTAL) ? Facing::opposite($face) : $face);
        return parent::place($tx, $item, $blockReplace, $blockClicked, $face, $clickVector, $player);
    }

    public function onInteract(Item $item, int $face, Vector3 $clickVector, ?Player $player = null, array &$returnedItems = []): bool
    {
        if (!Main::canChangeBlockStates($this, $player)) return false;
        $tile = $this->position->getWorld()->getTile($this->position);
        if ($tile instanceof DummyTile) {
            $nbt = $tile->saveNBT();
            $nbt->setByte(TileNbtTagNames::State, $nbt->getByte(TileNbtTagNames::State) === 0 ? 2 : 0); // 0 = retracted, 2 = extended
            $tile->readSaveData($nbt);
            $this->position->getWorld()->setBlock($this->position, $this, false);
            return true;
        }
        return false;
    }

    public function changeState(int $toState = -1): bool//TODO: 끈끈이 피스톤이면 하나 끌어오기, 밀땐 최대 15블럭, 베드락 옵시디언 스포너 뭐 그런 것들 안밀리게
    {
        $tile = $this->position->getWorld()->getTile($this->position);
        $position = $tile->getPosition();
        $x = $position->getFloorX();
        $y = $position->getFloorY();
        $z = $position->getFloorZ();
        if ($tile instanceof DummyTile) {
            $nbt = $tile->saveNBT();
            $state = $this->getState();
            $toState = $toState < 0 ? ($state === 0 ? 2 : 0) : $toState;
            if($state === $toState) return false;
            if($state === self::STATE_RETRACTED){
                //TODO: 블럭 확인, 안되면 return false
                [$dx, $dy, $dz] = Facing::OFFSET[in_array($this->getFacing(), Facing::HORIZONTAL) ? Facing::opposite($this->getFacing()) : $this->getFacing()];
                $canBeBlocked = false;
                $target = new Vector3($x + $dx*13, $y + $dy*13, $z + $dz*13);
                if($position->getWorld()->getBlock($target)->getStateId() !== VanillaBlocks::AIR()->getStateId())
                    $canBeBlocked = true;
                $blockList = [];
                for($i = 1; $i <= 12; $i++){
                    $target = new Vector3($x + $dx*$i, $y + $dy*$i, $z + $dz*$i);
                    $targetBlock = $position->getWorld()->getBlock($target);
                    if(!$targetBlock instanceof Air){
                        $blockList[$i] = $targetBlock;
                    }else{
                        $canBeBlocked = false;
                        break;
                    }
                }
                if($canBeBlocked) return false;
                [$dx, $dy, $dz] = Facing::OFFSET[in_array($this->getFacing(), Facing::HORIZONTAL) ? Facing::opposite($this->getFacing()) : $this->getFacing()];
                $target = new Vector3($x + $dx, $y + $dy, $z + $dz);
                $position->getWorld()->setBlock($target, VanillaBlocks::AIR());

                /**
                 * @var int $index
                 * @var Block $oldBlock
                 */
                foreach($blockList as $index => $oldBlock){
                    $position->getWorld()->setBlock($oldBlock->getPosition()->add($dx, $dy, $dz), $oldBlock);
                }
            }else{
                //TODO: 블럭 땡겨오기
                if($this->isSticky()){
                    [$dx, $dy, $dz] = Facing::OFFSET[in_array($this->getFacing(), Facing::HORIZONTAL) ? Facing::opposite($this->getFacing()) : $this->getFacing()];
                    $target = new Vector3($x + $dx*2, $y + $dy*2, $z + $dz*2);
                    $targetBlock = $position->getWorld()->getBlock($target);
                    $position->getWorld()->setBlock($target, VanillaBlocks::AIR());
                    $position->getWorld()->setBlock($target->subtract($dx, $dy, $dz), $targetBlock);
                }
            }
            $nbt->setByte(TileNbtTagNames::State, $toState);
            $tile->readSaveData($nbt);
            $this->position->getWorld()->setBlock($this->position, $this, false);
            $sound = $toState === 2 ? new PistonOutSound() : new PistonInSound();
            $this->getPosition()->getWorld()->addSound($this->getPosition()->add(0.5, 0.5, 0.5), $sound);
            return true;
        }
        return false;
    }

    public function getState(): int
    {
        $tile = $this->position->getWorld()->getTile($this->position);
        if($tile instanceof DummyTile) {
            $nbt = $tile->saveNBT();
            return $nbt->getByte(TileNbtTagNames::State);
        }
        return -1;
    }

    public function isSticky(): bool
    {
        $tile = $this->position->getWorld()->getTile($this->position);
        if($tile instanceof DummyTile) {
            $nbt = $tile->saveNBT();
            return $nbt->getByte(TileNbtTagNames::Sticky) === 1;
        }
        return false;
    }


    protected function writeDefaultTileData(CompoundTag $tag): void
    {
        $tag->setString(Tile::TAG_ID, TileNames::PISTON_ARM);
        $this->setTagIfNotExist($tag, TileNbtTagNames::AttachedBlocks, new ListTag([]));
        $this->setTagIfNotExist($tag, TileNbtTagNames::BreakBlocks, new ListTag([]));
        $this->setTagIfNotExist($tag, TileNbtTagNames::LastProgress, new FloatTag(0));
        $this->setTagIfNotExist($tag, TileNbtTagNames::NewState, new ByteTag(0));
        $this->setTagIfNotExist($tag, TileNbtTagNames::Progress, new FloatTag(0));
        $this->setTagIfNotExist($tag, TileNbtTagNames::State, new ByteTag(0)); // appear as extended if 1 or 2, in vanilla value of 2 is seen in fully extended piston
        $this->setTagIfNotExist($tag, TileNbtTagNames::Sticky, new ByteTag((int)(GlobalBlockStateHandlers::getSerializer()->serializeBlock($this)->getName() === BlockTypeNames::STICKY_PISTON))); // appear as sticky if 1, doesn't matter if block is not sticky
        $this->setTagIfNotExist($tag, TileNbtTagNames::isMovable, new ByteTag(1));
    }
}