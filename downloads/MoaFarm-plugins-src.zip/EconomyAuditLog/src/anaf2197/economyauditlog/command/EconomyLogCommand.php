<?php
declare(strict_types=1);

namespace anaf2197\economyauditlog\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use anaf2197\economyauditlog\EconomyAuditLogLoader;

/**
 * /경제로그 [플레이어명] [페이지]
 * 자신 또는 타인의 경제 거래 내역 확인 (OP 전용)
 */
final class EconomyLogCommand extends Command {

    public function __construct() {
        parent::__construct('경제로그', '경제 거래 내역 조회', '/경제로그 [플레이어명] [페이지]', ['moneylog', '돈로그']);
        $this->setPermission('economyauditlog.use');
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if (!$this->testPermission($sender)) return;

        $loader     = EconomyAuditLogLoader::getInstance();
        $prefix     = EconomyAuditLogLoader::$prefix;
        $targetName = $args[0] ?? ($sender instanceof Player ? $sender->getName() : '');
        $page       = max(1, (int) ($args[1] ?? 1));

        if ($targetName === '') {
            $sender->sendMessage($prefix . '§c사용법: /경제로그 <플레이어명> [페이지]');
            return;
        }

        $perPage   = 10;
        $logs      = $loader->getPlayerLogs($targetName, $page, $perPage);
        $total     = $loader->getPlayerLogCount($targetName);
        $maxPage   = max(1, (int) ceil($total / $perPage));

        $sender->sendMessage(' ');
        $sender->sendMessage($prefix . '§l' . $targetName . ' 경제 내역 §8(§8' . $page . '/' . $maxPage . '쪽 §8| 총 §8' . $total . '건§8)');

        if (empty($logs)) {
            $sender->sendMessage('§8내역이 없습니다.');
            $sender->sendMessage(' ');
            return;
        }

        $typeColor = ['ADD' => '§a+', 'REDUCE' => '§c-', 'SET' => '§e='];
        foreach ($logs as $log) {
            $sign   = $typeColor[$log['type']] ?? '§8';
            $date   = date('m/d H:i', (int) $log['created_at']);
            $reason = $log['reason'] !== '' ? ' §8(' . mb_substr($log['reason'], 0, 20) . ')' : '';
            $sender->sendMessage(
                '§8[§8' . $date . '§8] ' . $sign . number_format((int) $log['amount']) . '원§8 → §f' .
                number_format((int) $log['balance_after']) . '원' . $reason
            );
        }

        if ($page < $maxPage) {
            $sender->sendMessage('§8다음 페이지: §f/경제로그 ' . $targetName . ' ' . ($page + 1));
        }
        $sender->sendMessage(' ');
    }
}
