<?php
declare(strict_types=1);

namespace anaf2197\economyauditlog\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use anaf2197\economyauditlog\EconomyAuditLogLoader;

/**
 * /경제통계 [일수=7]
 * 서버 경제 대시보드 (OP 전용)
 */
final class EconomyStatsCommand extends Command {

    public function __construct() {
        parent::__construct('경제통계', '서버 경제 통계 대시보드', '/경제통계 [일수]', ['ecostats', '경제대시보드']);
        $this->setPermission('economyauditlog.admin');
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if (!$this->testPermission($sender)) return;

        $loader  = EconomyAuditLogLoader::getInstance();
        $prefix  = EconomyAuditLogLoader::$prefix;
        $days    = max(1, min(90, (int) ($args[0] ?? 7)));
        $stats   = $loader->getServerStats($days);

        $sender->sendMessage(' ');
        $sender->sendMessage($prefix . '§l경제 통계 §8(최근 §8' . $days . '일§8)');
        $sender->sendMessage('§e획득 총액: §a+' . number_format($stats['total_add']) . '원');
        $sender->sendMessage('§e지출 총액: §c-' . number_format($stats['total_reduce']) . '원');
        $net = $stats['total_add'] - $stats['total_reduce'];
        $sender->sendMessage('§e순환 차이: ' . ($net >= 0 ? '§a+' : '§c') . number_format($net) . '원');

        $sender->sendMessage(' ');
        $sender->sendMessage('§6▶ 최다 획득 TOP5');
        foreach ($stats['top_earners'] as $i => $row) {
            $sender->sendMessage('  §8' . ($i + 1) . '. §f' . $row['player'] . ' §a+' . number_format((int) $row['total']) . '원');
        }

        $sender->sendMessage('§6▶ 최다 지출 TOP5');
        foreach ($stats['top_spenders'] as $i => $row) {
            $sender->sendMessage('  §8' . ($i + 1) . '. §f' . $row['player'] . ' §c-' . number_format((int) $row['total']) . '원');
        }
        $sender->sendMessage(' ');
        $sender->sendMessage('§8로그 정리: /경제통계 정리 <일수> (OP)');
        $sender->sendMessage(' ');
    }
}
