<?php
declare(strict_types=1);

namespace anaf2197\economyauditlog;

use pocketmine\event\Listener;
use anaf2197\economyapi\event\AddMoneyEvent;
use anaf2197\economyapi\event\ReduceMoneyEvent;
use anaf2197\economyapi\event\SetMoneyEvent;

final class AuditEventListener implements Listener {

    public function __construct(private EconomyAuditLog $plugin) {}

    /**
     * @priority MONITOR
     * @ignoreCancelled true
     */
    public function onAddMoney(AddMoneyEvent $event): void {
        $this->plugin->record(
            $event->getPlayer(),
            'add',
            $event->getAmount(),
            $event->getBeforeMoney(),
            $event->getAfterMoney(),
            $event->getCause()
        );
    }

    /**
     * @priority MONITOR
     * @ignoreCancelled true
     */
    public function onReduceMoney(ReduceMoneyEvent $event): void {
        $this->plugin->record(
            $event->getPlayer(),
            'reduce',
            $event->getAmount(),
            $event->getBeforeMoney(),
            $event->getAfterMoney(),
            $event->getCause()
        );
    }

    /**
     * @priority MONITOR
     * @ignoreCancelled true
     */
    public function onSetMoney(SetMoneyEvent $event): void {
        $this->plugin->record(
            $event->getPlayer(),
            'set',
            $event->getAmount(),
            $event->getBeforeMoney(),
            $event->getAfterMoney(),
            $event->getCause()
        );
    }
}
