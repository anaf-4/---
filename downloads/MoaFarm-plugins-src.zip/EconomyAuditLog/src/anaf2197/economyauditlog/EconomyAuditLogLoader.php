<?php
declare(strict_types=1);

namespace anaf2197\economyauditlog;

use pocketmine\event\EventPriority;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\Server;
use pocketmine\utils\SingletonTrait;
use anaf2197\economyauditlog\command\EconomyLogCommand;
use anaf2197\economyauditlog\command\EconomyStatsCommand;
use anaf2197\lib\color\ServerColor;

/**
 * 경제 거래 내역 로그 + 대시보드 (#39)
 *
 * MySQL 테이블: economy_audit_log
 *   id, player, type(ADD/REDUCE/SET), amount, balance_after, reason, created_at
 */
final class EconomyAuditLogLoader extends PluginBase {

    use SingletonTrait;

    public static string $prefix;

    private \mysqli $db;

    // ─── 공통 MySQL 설정 ─────────────────────────────────────────────────────

    private function loadMysqlConfig(): array {
        $sharedPath = $this->getServer()->getDataPath() . 'plugins/mysql_shared.yml';
        if (file_exists($sharedPath)) {
            $shared = new \pocketmine\utils\Config($sharedPath);
            $cfg    = $shared->get('mysql', null);
            if (is_array($cfg)) return $cfg;
        }
        return (array) $this->getConfig()->get('mysql', []);
    }

    // ─── 생명주기 ────────────────────────────────────────────────────────────

    protected function onLoad(): void {
        self::setInstance($this);
        ServerColor::setPrefix($this, '경제로그');
    }

    protected function onEnable(): void {
        $this->saveDefaultConfig();
        if (!$this->connectDb()) return;
        $this->initTables();

        $pm = $this->getServer()->getPluginManager();

        // EconomyAPI 이벤트 후킹
        if ($pm->getPlugin('EconomyAPI') !== null) {
            $pm->registerEvent(
                \anaf2197\economyapi\event\AddMoneyEvent::class,
                function (\anaf2197\economyapi\event\AddMoneyEvent $event): void {
                    $player = Server::getInstance()->getPlayerExact($event->getPlayer());
                    $bal    = $player !== null
                        ? (int) \anaf2197\economyapi\EconomyAPI::getInstance()->getEconomyData($player)->getMoney()
                        : 0;
                    $this->log($event->getPlayer(), 'ADD', (int) $event->getAmount(), $bal, (string) $event->getCause());
                },
                EventPriority::MONITOR,
                $this
            );

            $pm->registerEvent(
                \anaf2197\economyapi\event\ReduceMoneyEvent::class,
                function (\anaf2197\economyapi\event\ReduceMoneyEvent $event): void {
                    $player = Server::getInstance()->getPlayerExact($event->getPlayer());
                    $bal    = $player !== null
                        ? (int) \anaf2197\economyapi\EconomyAPI::getInstance()->getEconomyData($player)->getMoney()
                        : 0;
                    $this->log($event->getPlayer(), 'REDUCE', (int) $event->getAmount(), $bal, (string) $event->getCause());
                },
                EventPriority::MONITOR,
                $this
            );
        }

        $cmdMap = $this->getServer()->getCommandMap();
        $cmdMap->register(strtolower($this->getName()), new EconomyLogCommand());
        $cmdMap->register(strtolower($this->getName()), new EconomyStatsCommand());
    }

    protected function onDisable(): void {
        if (isset($this->db)) $this->db->close();
    }

    // ─── MySQL ───────────────────────────────────────────────────────────────

    private function connectDb(): bool {
        $cfg    = $this->loadMysqlConfig();
        $host   = (string) ($cfg['host'] ?? '127.0.0.1');
        $port   = (int) ($cfg['port'] ?? 3306);
        $user   = (string) ($cfg['user'] ?? 'root');
        $pass   = (string) ($cfg['password'] ?? '');
        $dbName = (string) ($cfg['database'] ?? 'moafarm');
        try {
            $this->db = new \mysqli($host, $user, $pass, $dbName, $port);
        } catch (\mysqli_sql_exception $e) {
            $this->getLogger()->error('MySQL 연결 실패: ' . $e->getMessage());
            $this->getServer()->getPluginManager()->disablePlugin($this);
            return false;
        }
        if ($this->db->connect_error) {
            $this->getLogger()->error('MySQL 연결 실패: ' . $this->db->connect_error);
            $this->getServer()->getPluginManager()->disablePlugin($this);
            return false;
        }
        $this->db->set_charset('utf8mb4');
        return true;
    }

    private function ensureConnected(): void {
        try { if (!@$this->db->ping()) $this->connectDb(); } catch (\Throwable) { $this->connectDb(); }
    }

    private function initTables(): void {
        $this->db->query('CREATE TABLE IF NOT EXISTS economy_audit_log (
            id BIGINT AUTO_INCREMENT PRIMARY KEY,
            player VARCHAR(100) NOT NULL,
            type ENUM(\'ADD\',\'REDUCE\',\'SET\') NOT NULL DEFAULT \'ADD\',
            amount BIGINT NOT NULL DEFAULT 0,
            balance_after BIGINT NOT NULL DEFAULT 0,
            reason VARCHAR(500) NOT NULL DEFAULT \'\',
            created_at INT NOT NULL DEFAULT 0,
            INDEX idx_player (player),
            INDEX idx_created_at (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
    }

    // ─── 로그 기록 ───────────────────────────────────────────────────────────

    public function log(string $playerName, string $type, int $amount, int $balanceAfter, string $reason = ''): void {
        $this->ensureConnected();
        $key  = strtolower($playerName);
        $now  = time();
        $stmt = $this->db->prepare(
            'INSERT INTO economy_audit_log (player, type, amount, balance_after, reason, created_at) VALUES (?, ?, ?, ?, ?, ?)'
        );
        $stmt->bind_param('ssiisi', $key, $type, $amount, $balanceAfter, $reason, $now);
        $stmt->execute();
        $stmt->close();
    }

    // ─── 조회 ────────────────────────────────────────────────────────────────

    /**
     * 플레이어 거래 내역 조회
     * @return array[] [{id, type, amount, balance_after, reason, created_at}]
     */
    public function getPlayerLogs(string $playerName, int $page = 1, int $perPage = 10): array {
        $this->ensureConnected();
        $key    = strtolower($playerName);
        $offset = max(0, ($page - 1) * $perPage);
        $stmt   = $this->db->prepare(
            'SELECT id, type, amount, balance_after, reason, created_at
             FROM economy_audit_log WHERE player = ?
             ORDER BY created_at DESC LIMIT ? OFFSET ?'
        );
        $stmt->bind_param('sii', $key, $perPage, $offset);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        return $rows;
    }

    public function getPlayerLogCount(string $playerName): int {
        $this->ensureConnected();
        $key  = strtolower($playerName);
        $stmt = $this->db->prepare('SELECT COUNT(*) AS cnt FROM economy_audit_log WHERE player = ?');
        $stmt->bind_param('s', $key);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return (int) ($row['cnt'] ?? 0);
    }

    /**
     * 서버 전체 경제 통계
     * @return array{total_add: int, total_reduce: int, top_earners: array, top_spenders: array}
     */
    public function getServerStats(int $daysBack = 7): array {
        $this->ensureConnected();
        $since = time() - ($daysBack * 86400);

        $stmt = $this->db->prepare(
            'SELECT type, SUM(amount) AS total FROM economy_audit_log WHERE created_at >= ? GROUP BY type'
        );
        $stmt->bind_param('i', $since);
        $stmt->execute();
        $totals    = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        $totalAdd    = 0;
        $totalReduce = 0;
        foreach ($totals as $row) {
            if ($row['type'] === 'ADD')    $totalAdd    = (int) $row['total'];
            if ($row['type'] === 'REDUCE') $totalReduce = (int) $row['total'];
        }

        // 최다 획득 TOP5
        $stmt = $this->db->prepare(
            'SELECT player, SUM(amount) AS total FROM economy_audit_log
             WHERE type = \'ADD\' AND created_at >= ? GROUP BY player ORDER BY total DESC LIMIT 5'
        );
        $stmt->bind_param('i', $since);
        $stmt->execute();
        $topEarners = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        // 최다 지출 TOP5
        $stmt = $this->db->prepare(
            'SELECT player, SUM(amount) AS total FROM economy_audit_log
             WHERE type = \'REDUCE\' AND created_at >= ? GROUP BY player ORDER BY total DESC LIMIT 5'
        );
        $stmt->bind_param('i', $since);
        $stmt->execute();
        $topSpenders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        return [
            'total_add'    => $totalAdd,
            'total_reduce' => $totalReduce,
            'top_earners'  => $topEarners,
            'top_spenders' => $topSpenders,
            'days'         => $daysBack,
        ];
    }

    public function purgeOldLogs(int $daysBack = 30): int {
        $this->ensureConnected();
        $cutoff = time() - ($daysBack * 86400);
        $this->db->query('DELETE FROM economy_audit_log WHERE created_at < ' . $cutoff);
        return $this->db->affected_rows;
    }
}
