<?php
declare(strict_types=1);

namespace anaf2197\economyauditlog;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;

final class EconomyAuditLog extends PluginBase {

    use SingletonTrait;

    private \SQLite3 $db;

    protected function onLoad(): void {
        self::setInstance($this);
    }

    protected function onEnable(): void {
        @mkdir($this->getDataFolder(), 0777, true);
        $this->db = new \SQLite3($this->getDataFolder() . 'audit.db');
        $this->db->exec("
            CREATE TABLE IF NOT EXISTS transactions (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                player     TEXT NOT NULL,
                type       TEXT NOT NULL,
                amount     INTEGER NOT NULL,
                before     INTEGER NOT NULL,
                after      INTEGER NOT NULL,
                cause      TEXT,
                logged_at  INTEGER NOT NULL
            )
        ");
        $this->db->exec("CREATE INDEX IF NOT EXISTS idx_player ON transactions(player)");
        $this->db->exec("CREATE INDEX IF NOT EXISTS idx_type ON transactions(type)");
        $this->db->exec("CREATE INDEX IF NOT EXISTS idx_at ON transactions(logged_at)");

        $this->getServer()->getPluginManager()->registerEvents(new AuditEventListener($this), $this);
        $this->getLogger()->info('EconomyAuditLog 활성화 (모든 거래 기록 중)');
    }

    protected function onDisable(): void {
        $this->db->close();
    }

    public function record(string $player, string $type, int $amount, int $before, int $after, ?string $cause): void {
        $stmt = $this->db->prepare("
            INSERT INTO transactions (player, type, amount, before, after, cause, logged_at)
            VALUES (:player, :type, :amount, :before, :after, :cause, :at)
        ");
        $stmt->bindValue(':player', strtolower($player));
        $stmt->bindValue(':type',   $type);
        $stmt->bindValue(':amount', $amount);
        $stmt->bindValue(':before', $before);
        $stmt->bindValue(':after',  $after);
        $stmt->bindValue(':cause',  $cause ?? '');
        $stmt->bindValue(':at',     time());
        $stmt->execute();
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        switch ($command->getName()) {
            case '경제로그':
                return $this->cmdLog($sender, $args);
            case '경제통계':
                return $this->cmdStats($sender);
        }
        return false;
    }

    private function cmdLog(CommandSender $sender, array $args): bool {
        if (!$sender->hasPermission('economyauditlog.view')) {
            $sender->sendMessage('§c권한이 없습니다.');
            return true;
        }
        if (empty($args[0])) {
            $sender->sendMessage('§c사용법: /경제로그 [플레이어명] [페이지]');
            return true;
        }

        $targetName = strtolower($args[0]);
        $page       = max(1, (int) ($args[1] ?? 1));
        $perPage    = 10;
        $offset     = ($page - 1) * $perPage;

        $stmt = $this->db->prepare("
            SELECT type, amount, before, after, cause, logged_at
            FROM transactions
            WHERE player = :p
            ORDER BY logged_at DESC
            LIMIT :limit OFFSET :offset
        ");
        $stmt->bindValue(':p',      $targetName);
        $stmt->bindValue(':limit',  $perPage);
        $stmt->bindValue(':offset', $offset);
        $result = $stmt->execute();

        $rows = [];
        while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
            $rows[] = $row;
        }

        if (empty($rows)) {
            $sender->sendMessage("§8{$targetName}의 경제 로그가 없거나 페이지가 없습니다.");
            return true;
        }

        $typeColor = ['add' => '§a+', 'reduce' => '§c-', 'set' => '§e='];
        $sender->sendMessage("§e━━━━ §f{$targetName}§e 경제 로그 ({$page}페이지) ━━━━");
        foreach ($rows as $row) {
            $time   = date('m/d H:i', (int) $row['logged_at']);
            $tc     = $typeColor[$row['type']] ?? '§8?';
            $amount = number_format((int) $row['amount']);
            $after  = number_format((int) $row['after']);
            $cause  = $row['cause'] ?: '-';
            $sender->sendMessage("§8[{$time}] {$tc}{$amount}원 §8잔액: §f{$after}원 §8사유: §e{$cause}");
        }
        $sender->sendMessage("§8다음 페이지: §f/경제로그 {$targetName} " . ($page + 1));
        $sender->sendMessage('§e━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        return true;
    }

    private function cmdStats(CommandSender $sender): bool {
        if (!$sender->hasPermission('economyauditlog.admin')) {
            $sender->sendMessage('§c권한이 없습니다.');
            return true;
        }

        $today = mktime(0, 0, 0, (int)date('n'), (int)date('j'), (int)date('Y'));

        $totalAdded   = $this->db->querySingle("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE type='add' AND logged_at >= {$today}");
        $totalReduced = $this->db->querySingle("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE type='reduce' AND logged_at >= {$today}");
        $totalTx      = $this->db->querySingle("SELECT COUNT(*) FROM transactions WHERE logged_at >= {$today}");
        $topSpender   = $this->db->querySingle("SELECT player FROM transactions WHERE type='reduce' AND logged_at >= {$today} GROUP BY player ORDER BY SUM(amount) DESC LIMIT 1");
        $topEarner    = $this->db->querySingle("SELECT player FROM transactions WHERE type='add'    AND logged_at >= {$today} GROUP BY player ORDER BY SUM(amount) DESC LIMIT 1");

        $sender->sendMessage('§e━━━━━━━━ 오늘의 경제 통계 ━━━━━━━━');
        $sender->sendMessage("§f총 거래 횟수: §a{$totalTx}회");
        $sender->sendMessage("§f총 지급 금액: §a" . number_format((int)$totalAdded) . '원');
        $sender->sendMessage("§f총 차감 금액: §c" . number_format((int)$totalReduced) . '원');
        $sender->sendMessage("§f최다 지출: §e" . ($topSpender ?: '-'));
        $sender->sendMessage("§f최다 수입: §e" . ($topEarner  ?: '-'));
        $sender->sendMessage('§e━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        return true;
    }
}
