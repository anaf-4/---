<?php

namespace anaf2197\contents\task;

use pocketmine\scheduler\Task;
use anaf2197\contents\ContentsLoader;

final class ClearContentTask extends Task {

    public function onRun(): void {
        if (date('G') == 12) {
            if ((int)date('i') === 00) {
                foreach (ContentsLoader::getInstance()->getContents() as $content) {
                    $content->clearCompletedIds();
                }
            }
        }
    }
}