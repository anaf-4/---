<?php

namespace anaf2197\contents\form;

use pocketmine\form\Form;
use pocketmine\player\Player;
use anaf2197\contents\Content;

final class ContentForm implements Form {

    public function __construct(private readonly Content $content, private readonly Player $player) { }

    public function jsonSerialize(): array {
        $rank = $this->content->getRank($this->player);
        return [
            'type' => 'form',
            'title' => '§l§0' . $this->content->getId(),
            'content' => PHP_EOL . '§l-§r 원하는 작업을 선택해주세요.' . PHP_EOL . ' ',
            'buttons' => [
                [
                    'text' => '§l§0> 플레이하기 <' . PHP_EOL . '§r§8' . (!$this->content->isCompleted($this->player) ? '터치하여 플레이하기' : '이미 클리어한 콘텐츠')
                ],
                [
                    'text' => '§l§0> 랭킹보기 <' . PHP_EOL . '§r§8현재 내 랭킹: ' . (is_numeric($rank) ? ($rank + 1) . '위' : '기록 없음')
                ]
            ]
        ];
    }

    public function handleResponse(Player $player, $data): void {
        if (is_numeric($data)) {
            if ($data === 0) {
                $this->content->start($player);
            } else {
                $player->sendForm(new ContentRankingForm($this->content, $this->player));
            }
        }
    }
}