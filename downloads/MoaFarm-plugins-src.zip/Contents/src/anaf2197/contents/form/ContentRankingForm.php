<?php

namespace anaf2197\contents\form;

use pocketmine\form\Form;
use pocketmine\player\Player;
use anaf2197\contents\Content;
use anaf2197\lib\timeparser\TimeParser;

final class ContentRankingForm implements Form {

    public function __construct(private readonly Content $content, private readonly Player $player) {
        $this->content->sortRanks();
    }

    public function jsonSerialize(): array {
        $content = [' '];
        $rank = 1;
        foreach ($this->content->getRanks() as $playerId => $time) {
            if ($rank > 20) break;
            $content [] = $rank . '. ' . $playerId . ': ' . $time . '초';
            $rank++;
        }
        $content [] = ' ';
        return [
            'type' => 'form',
            'title' => '§l§0' . $this->content->getId(),
            'content' => implode(PHP_EOL, $content),
            'buttons' => [
                [
                    'text' => '§l§0> 돌아가기 <'
                ]
            ]
        ];
    }

    public function handleResponse(Player $player, $data): void {
        if (is_numeric($data)) {
            $player->sendForm(new ContentForm($this->content, $this->player));
        }
    }
}