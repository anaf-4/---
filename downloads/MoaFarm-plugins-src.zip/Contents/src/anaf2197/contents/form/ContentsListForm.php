<?php

namespace anaf2197\contents\form;

use pocketmine\form\Form;
use pocketmine\player\Player;
use anaf2197\contents\Content;
use anaf2197\contents\ContentsLoader;

final class ContentsListForm implements Form {

    /** @var Content[] */
    private array $contents;

    public function __construct() {
        $this->contents = array_values(ContentsLoader::getInstance()->getContents());
    }

    public function jsonSerialize(): array {
        return [
            'type' => 'form',
            'title' => '§l콘텐츠 목록',
            'content' => PHP_EOL . '§l- §r원하는 콘텐츠를 클릭해주세요.' . PHP_EOL . ' ',
            'buttons' => array_map(function (Content $content) {
                return [
                    'text' => '§l§0' . $content->getId() . PHP_EOL . '§r§8- 터치하여 자세히보기 -'
                ];
            }, $this->contents)
        ];
    }

    public function handleResponse(Player $player, $data): void {
        if (is_numeric($data)) {
            $content = $this->contents[$data] ?? null;
            if ($content instanceof Content) {
                $player->sendForm(new ContentForm($content, $player));
            }
        }
    }
}