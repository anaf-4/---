<?php

namespace anaf2197\contents;

use pocketmine\scheduler\TaskHandler;

final class ContentsQueue {

    public const QUEUE_FIRST = 'queue.first_block';
    public const QUEUE_SECOND = 'queue.second_block';

    public static array $queue = [];
    public static array $playingIds = [];
    public static array $taskHandlers = [];

    public static function addTaskHandler(string $playerName, TaskHandler $handler): void {
        self::$taskHandlers[$playerName] = $handler;
    }

    public static function removeTaskHandler(string $playerName): void {
        if (isset(self::$taskHandlers[$playerName])) {
            self::$taskHandlers[$playerName]->cancel();
            unset(self::$taskHandlers[$playerName]);
        }
    }
}
