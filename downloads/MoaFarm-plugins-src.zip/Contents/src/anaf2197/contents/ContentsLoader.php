<?php

namespace anaf2197\contents;

use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\EventPriority;
use pocketmine\plugin\PluginBase;
use pocketmine\Server;
use pocketmine\utils\SingletonTrait;
use anaf2197\contents\command\ContentsCommand;
use anaf2197\contents\command\ManageContentsCommand;
use anaf2197\contents\command\ShortcutContentCommand;
use anaf2197\contents\task\ClearContentTask;
use anaf2197\lib\color\ServerColor;
use anaf2197\lib\positionparser\PositionParser;
use anaf2197\lib\provider\DataProvider;
use anaf2197\lib\provider\ProviderHandler;

final class ContentsLoader extends PluginBase {

    use SingletonTrait;

    public static string $prefix;

    private DataProvider $provider;

    /** @var array<int, float> 마지막 블록 파괴 시간 기록 */
    private array $lastBreakTime = [];

    protected function onEnable(): void {
        $this->getServer()->getCommandMap()->registerAll(strtolower($this->getName()), [
            new ContentsCommand(),
            new ManageContentsCommand($this)
        ]);
        $this->getServer()->getPluginManager()->registerEvent(BlockBreakEvent::class, function (BlockBreakEvent $event): void {
            $player = $event->getPlayer();
            $object_id = spl_object_id($player);
            $queueValue = ContentsQueue::$queue[$object_id] ?? null;

            if (is_array($queueValue)) {
                // 쿨다운 체크 (0.5초)
                $currentTime = microtime(true);
                $lastTime = $this->lastBreakTime[$object_id] ?? 0;

                if ($currentTime - $lastTime < 0.5) {
                    $event->cancel();
                    return;
                }

                $this->lastBreakTime[$object_id] = $currentTime;

                $blockPositionHash = PositionParser::toString($event->getBlock()->getPosition());
                $worldId = $player->getWorld()->getFolderName();

                switch ($queueValue[0]) {
                    case ContentsQueue::QUEUE_FIRST:
                        if ($queueValue[2] === $worldId) {
                            $queueValue[0] = ContentsQueue::QUEUE_SECOND;
                            $queueValue[] = $blockPositionHash;
                            ContentsQueue::$queue[$object_id] = $queueValue;
                            $player->sendMessage(self::$prefix . '두번째 지점을 지정해주세요.');
                        } else {
                            $player->sendMessage(self::$prefix . '시작 지점과 같은 월드에서 시도해주세요.');
                        }
                        $event->cancel();
                        return;

                    case ContentsQueue::QUEUE_SECOND:
                        if ($queueValue[2] === $worldId) {
                            $queueValue[] = $blockPositionHash;
                            $queueValue[] = [];
                            $queueValue[] = [];
                            $queueValue[] = [];
                            array_shift($queueValue);
                            $queueValue = array_values($queueValue);
                            $this->newContent(new Content(...$queueValue));
                            unset(ContentsQueue::$queue[$object_id]);
                            unset($this->lastBreakTime[$object_id]); // 쿨다운 제거
                            $player->sendMessage(self::$prefix . '콘텐츠 생성을 완료했습니다!');
                        } else {
                            $player->sendMessage(self::$prefix . '시작 지점과 같은 월드에서 시도해주세요.');
                        }
                        $event->cancel();
                        return;
                }
            }
        }, EventPriority::HIGHEST, $this); // NORMAL에서 HIGHEST로 변경

        $this->getScheduler()->scheduleDelayedRepeatingTask(new ClearContentTask(), 20 * 30, 20 * 30);
        $this->loadShortcutContent(array_map(function (Content $content): string {
            return $content->getId();
        }, $this->getContents()));
    }

    protected function onLoad(): void {
        self::setInstance($this);
        ServerColor::setPrefix($this, '콘텐츠');
        if (!ProviderHandler::isRegistered($this)) {
            ProviderHandler::register($this, Content::class);
            $this->provider = ProviderHandler::get($this);
        }
    }

    protected function onDisable(): void {
        $this->saveDatabase();
    }

    public function saveDatabase(): void {
        $this->provider->save();
    }

    private function loadShortcutContent(string|array $ids): void {
        if (is_string($ids)) {
            $ids = [$ids];
        }
        $this->getLogger()->info(count($ids) . '개의 콘텐츠 명령어가 생성되었습니다.');
        foreach ($ids as $id) {
            $this->getServer()->getCommandMap()->register(strtolower($this->getName()), new ShortcutContentCommand($id));
        }
    }

    /** @return Content[] */
    public function getContents(): array {
        return $this->provider->getAll();
    }

    public function getContent(string $id): ?Content {
        return $this->provider->getObject($id);
    }

    public function newContent(Content $content): void {
        $contentId = $content->getId();
        $this->provider->setObject($contentId, $content);
        $this->loadShortcutContent($contentId);
    }

    public function removeContent(string $id): void {
        $commandMap = Server::getInstance()->getCommandMap();
        $commandMap->unregister($commandMap->getCommand($id));
        $this->provider->deleteObject($id);
    }
}