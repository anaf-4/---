<?php

namespace anaf2197\contents\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\contents\Content;
use anaf2197\contents\ContentsLoader;
use anaf2197\contents\ContentsQueue;
use anaf2197\lib\positionparser\PositionParser;

final class ManageContentsCommand extends Command {

    public function __construct(private readonly ContentsLoader $plugin) {
        parent::__construct('콘텐츠관리', '콘텐츠 관리 명령어입니다.');
        $this->setPermission(DefaultPermissions::ROOT_OPERATOR);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($this->testPermission($sender)) {
            if ($sender instanceof Player) {
                switch (array_shift($args)) {
                    case '생성':
                        $id = array_shift($args);
                        $timeLimit = array_shift($args);
                        if (trim((string)$timeLimit) !== '') {
                            if (is_numeric($timeLimit)) {
                                if (!$this->plugin->getContent($id) instanceof Content) {
                                    $object_id = spl_object_id($sender);
                                    if (!isset(ContentsQueue::$queue [$object_id])) {
                                        if ($timeLimit <= 0) $timeLimit = null;
                                        ContentsQueue::$queue [$object_id] = [ContentsQueue::QUEUE_FIRST, $id, $sender->getWorld()->getFolderName(), $timeLimit, PositionParser::toString($sender->getPosition())];
                                        $sender->sendMessage(ContentsLoader::$prefix . '첫번째 지점을 지정해주세요. (블록 파괴)');
                                    } else {
                                        $sender->sendMessage(ContentsLoader::$prefix . '이미 진행 중인 작업이 존재합니다.');
                                    }
                                } else {
                                    $sender->sendMessage(ContentsLoader::$prefix . '이미 존재하는 이름입니다.');
                                }
                            } else {
                                $sender->sendMessage(ContentsLoader::$prefix . '제한 시간은 숫자로 입력해야합니다.');
                            }
                        } else {
                            $sender->sendMessage(ContentsLoader::$prefix . '/콘텐츠관리 생성 [이름] [제한 시간(음수로 무한)]');
                        }
                        break;

                    case '제거':
                        $id = array_shift($args);
                        if (trim((string)$id) !== '') {
                            if ($this->plugin->getContent($id) instanceof Content) {
                                $this->plugin->removeContent($id);
                                $sender->sendMessage(ContentsLoader::$prefix . '해당 콘텐츠를 제거했습니다.');
                            } else {
                                $sender->sendMessage(ContentsLoader::$prefix . '존재하지 않는 이름입니다.');
                            }
                        } else {
                            $sender->sendMessage(ContentsLoader::$prefix . '/콘텐츠관리 제거 [이름]');
                        }
                        break;

                    case '클리어보상':
                        $id = array_shift($args);
                        if (trim((string)$id) !== '') {
                            if (($content = $this->plugin->getContent($id)) instanceof Content) {
                                $content->sendManageItemInv($sender);
                            } else {
                                $sender->sendMessage(ContentsLoader::$prefix . '존재하지 않는 이름입니다.');
                            }
                        } else {
                            $sender->sendMessage(ContentsLoader::$prefix . '/콘텐츠관리 클리어보상 [이름]');
                        }
                        break;

                    case '정보':
                        $id = array_shift($args);
                        if (trim((string)$id) !== '') {
                            $content = $this->plugin->getContent($id);
                            if ($content instanceof Content) {
                                $timeLimit = $content->getTimeLimit();
                                $sender->sendMessage(ContentsLoader::$prefix . '콘텐츠 이름: ' . $content->getId());
                                $sender->sendMessage(ContentsLoader::$prefix . '소속 월드: ' . $content->getWorldName());
                                $sender->sendMessage(ContentsLoader::$prefix . '제한 시간: ' . (is_numeric($timeLimit) ? $timeLimit . '초' : '없음'));
                                $sender->sendMessage('§r§8- - - - - - - - - - -');
                                $sender->sendMessage(ContentsLoader::$prefix . '시작 지점: ' . PositionParser::toString($content->getStartPos()));
                                $sender->sendMessage(ContentsLoader::$prefix . '도착 지점1: ' . PositionParser::toString($content->getFirstEndPos()));
                                $sender->sendMessage(ContentsLoader::$prefix . '도착 지점2: ' . PositionParser::toString($content->getSecondEndPos()));
                            } else {
                                $sender->sendMessage(ContentsLoader::$prefix . '존재하지 않는 이름입니다.');
                            }
                        } else {
                            $sender->sendMessage(ContentsLoader::$prefix . '/콘텐츠관리 정보 [이름]');
                        }
                        break;

                    case '기록제거':
                        foreach ($this->plugin->getContents() as $content){
                            $content->clearCompletedIds();
                        }
                        $sender->sendMessage(ContentsLoader::$prefix . '모든 콘텐츠의 금일 클리어 기록을 제거했습니다.');
                        break;

                    case '목록':
                        $sender->sendMessage(ContentsLoader::$prefix . '콘텐츠 목록: ' . implode(', ', array_keys($this->plugin->getContents())));
                        break;

                    case '작업중지':
                        $object_id = spl_object_id($sender);
                        if (isset(ContentsQueue::$queue [$object_id])) {
                            unset(ContentsQueue::$queue [$object_id]);
                            $sender->sendMessage(ContentsLoader::$prefix . '진행 중인 작업을 중지했습니다.');
                        } else {
                            $sender->sendMessage(ContentsLoader::$prefix . '현재 진행 중인 작업이 없습니다.');
                        }
                        break;

                    default:
                        $sender->sendMessage(ContentsLoader::$prefix . '/콘텐츠관리 생성 [이름] [제한 시간(음수로 무한)]');
                        $sender->sendMessage(ContentsLoader::$prefix . '/콘텐츠관리 제거 [이름]');
                        $sender->sendMessage(ContentsLoader::$prefix . '/콘텐츠관리 클리어보상 [이름]');
                        $sender->sendMessage(ContentsLoader::$prefix . '/콘텐츠관리 정보 [이름]');
                        $sender->sendMessage(ContentsLoader::$prefix . '/콘텐츠관리 기록제거');
                        $sender->sendMessage(ContentsLoader::$prefix . '/콘텐츠관리 목록');
                        $sender->sendMessage(ContentsLoader::$prefix . '/콘텐츠관리 작업중지');
                }
            }
        }
    }
}