<?php

namespace anaf2197\contents\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\advancedlevel\AdvancedLevel;
use anaf2197\advancedwarp\AdvancedWarp;
use anaf2197\contents\Content;
use anaf2197\contents\ContentsLoader;

final class ShortcutContentCommand extends Command {

    private readonly Content $content;

    public function __construct(string $id) {
        parent::__construct($id, $id . '(으)로 이동합니다.');
        $this->setPermission(DefaultPermissions::ROOT_USER);
        $this->content = ContentsLoader::getInstance()->getContent($id);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($sender instanceof Player) {
            if ($this->testPermission($sender)) {
                $this->content->start($sender);
            }
        }
    }
}