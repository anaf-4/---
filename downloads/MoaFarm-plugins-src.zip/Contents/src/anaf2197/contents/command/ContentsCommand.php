<?php

namespace anaf2197\contents\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\contents\ContentsLoader;
use anaf2197\contents\ContentsQueue;
use anaf2197\contents\form\ContentsListForm;

final class ContentsCommand extends Command
{
    public function __construct()
    {
        parent::__construct('콘텐츠', '콘텐츠 사용 명령어입니다.', null, ['컨텐츠']);
        $this->setPermission(DefaultPermissions::ROOT_USER);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void
    {
        if ($this->testPermission($sender)) {
            if (!$sender instanceof Player) {
                return;
            }

            $name = $sender->getName();
            if (in_array($name, ContentsQueue::$playingIds)) {
                ContentsQueue::removeTaskHandler($name);
                unset(ContentsQueue::$playingIds[array_search($name, ContentsQueue::$playingIds)]);
                $sender->sendMessage(ContentsLoader::$prefix . '진행 중이던 콘텐츠를 포기했습니다.');
            } else {
                $sender->sendForm(new ContentsListForm());
            }
        }
    }
}
