<?php

namespace anaf2197\contents;

use JsonSerializable;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\type\InvMenuTypeIds;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\player\Player;
use pocketmine\scheduler\Task;
use pocketmine\Server;
use pocketmine\world\Position;
use anaf2197\deliveryapi\DeliveryAPI;
use anaf2197\lib\itemparser\ItemParser;
use anaf2197\lib\positionparser\PositionParser;

final class Content implements JsonSerializable {

    private readonly Position $startPos;
    private readonly Position $firstEndPos;
    private readonly Position $secondEndPos;

    /** @var Item[] */
    protected array $items;

    public function __construct(private readonly string $id, private readonly string $worldName, private readonly ?int $timeLimit, string $startPosHash, string $firstEndHash, string $secondEndHash, public array $completedIds, public array $ranks, array $itemDatas) {
        $server = Server::getInstance();
        $server->getWorldManager()->loadWorld($worldName);
        $this->startPos = PositionParser::fromString($startPosHash, $server, $worldName);
        $this->firstEndPos = PositionParser::fromString($firstEndHash, $server, $worldName);
        $this->secondEndPos = PositionParser::fromString($secondEndHash, $server, $worldName);
        $this->items = array_map(function (string $itemData): Item {
            return ItemParser::fromString($itemData);
        }, $itemDatas);
    }

    public function getId(): string {
        return $this->id;
    }

    public function getTimeLimit(): ?int {
        return $this->timeLimit;
    }

    public function sortRanks(): void {
        asort($this->ranks);
    }

    public function getRanks(): array {
        return $this->ranks;
    }

    public function getRank(Player $player): ?int {
        $key = array_search($player->getName(), array_keys($this->ranks), true);
        return $key !== false ? ($key + 1) : null;
    }

    public function getWorldName(): string {
        return $this->worldName;
    }

    public function getStartPos(): Position {
        return $this->startPos;
    }

    public function getFirstEndPos(): Position {
        return $this->firstEndPos;
    }

    public function getSecondEndPos(): Position {
        return $this->secondEndPos;
    }

    public function getCompletedIds(): array {
        return $this->completedIds;
    }

    public function clearCompletedIds(): void {
        $this->completedIds = [];
    }

    public function getItems(): array {
        return $this->items;
    }

    public function isCompleted(Player $player): bool {
        return in_array($player->getName(), $this->completedIds);
    }

    public function sendManageItemInv(Player $player): void {
        $invMenu = InvMenu::create(InvMenuTypeIds::TYPE_CHEST);
        $invMenu->setName('클리어 보상 수정');
        $invMenu->getInventory()->setContents($this->items);
        $invMenu->setInventoryCloseListener(function (Player $player, Inventory $inventory): void {
            $this->items = $inventory->getContents();
            $player->sendMessage(ContentsLoader::$prefix . '해당 콘텐츠의 클리어 보상을 수정했습니다.');
        });
        $invMenu->send($player);
    }

    public function start(Player $player): void {
        $playerName = $player->getName();
        if (!in_array($playerName, ContentsQueue::$playingIds)) {
            if (!in_array($playerName, $this->completedIds)) {
                ContentsQueue::$playingIds[] = $playerName;
                $player->teleport($this->startPos);

                $taskHandler = ContentsLoader::getInstance()->getScheduler()->scheduleDelayedRepeatingTask(new class ($this, $player, $playerName) extends Task {
                    private int $tick = 0;

                    public function __construct(private readonly Content $content, private readonly Player $player, private readonly string $playerName) { }

                    public function onRun(): void {
                        $this->tick++;
                        $timeLimit = $this->content->getTimeLimit();
                        if (!$this->player->isOnline()) {
                            $this->done();
                            return;
                        }
                        if (is_numeric($timeLimit) and ($this->tick / 10) >= $timeLimit) {
                            $this->done();
                            $this->player->sendMessage(ContentsLoader::$prefix . '시간 초과로 인해 도전이 종료되었습니다.');
                            return;
                        }
                        if ($this->inArea($this->player)) {
                            $contentId = $this->content->getId();
                            $this->player->sendMessage(ContentsLoader::$prefix . '[ ' . $contentId . ' ] (을)를 클리어했습니다.');
                            $this->content->completedIds[] = $this->playerName;
                            $this->content->ranks[$this->playerName] = $this->tick / 10;
                            DeliveryAPI::getInstance()->getMailBox($this->playerName)?->new('[' . $contentId . '] 클리어 보상', $this->content->getItems(), null, '청야팜');
                            $this->done();
                            return;
                        }
                        $this->player->sendJukeboxPopup('§f[ 기록: ' . ($this->tick / 10) . '초 ]');
                    }

                    public function inArea(Player $player): bool {
                        $firstEndPos = $this->content->getFirstEndPos();
                        $secondEndPos = $this->content->getSecondEndPos();
                        $x = [$firstEndPos->getX(), $secondEndPos->getX()];
                        $y = [$firstEndPos->getY(), $secondEndPos->getY()];
                        $z = [$firstEndPos->getZ(), $secondEndPos->getZ()];
                        $center = $player->getPosition();
                        $centerX = $center->getX();
                        $centerY = $center->getY(); // Y 보정 제거 (PocketMine은 이미 발 위치 반환)
                        $centerZ = $center->getZ();
                        // 여유 범위(margin)를 추가하여 도착 판정을 넉넉하게 처리
                        $margin = 1.0;
                        return $centerX >= (min($x) - $margin) and $centerZ >= (min($z) - $margin)
                            and $centerX <= (max($x) + 1 + $margin) and $centerZ <= (max($z) + 1 + $margin)
                            and $centerY >= (min($y) - $margin) and $centerY <= (max($y) + 2 + $margin);
                    }

                    public function done(): void {
                        $this->getHandler()->cancel();
                        ContentsQueue::removeTaskHandler($this->playerName);
                        $key = array_search($this->playerName, ContentsQueue::$playingIds, true);
                        if ($key !== false) {
                            unset(ContentsQueue::$playingIds[$key]);
                        }
                    }
                }, 2, 2);

                ContentsQueue::addTaskHandler($playerName, $taskHandler);
            } else {
                $player->sendMessage(ContentsLoader::$prefix . '이미 해당 콘텐츠를 클리어했습니다.');
            }
        } else {
            $player->sendMessage(ContentsLoader::$prefix . '이미 해당 콘텐츠를 진행 중입니다.');
        }
    }

    public function jsonSerialize(): array {
        return [
            $this->id,
            $this->worldName,
            $this->timeLimit,
            PositionParser::toString($this->startPos, $this->worldName),
            PositionParser::toString($this->firstEndPos, $this->worldName),
            PositionParser::toString($this->secondEndPos, $this->worldName),
            $this->completedIds,
            $this->ranks,
            array_map(function (Item $item): string {
                return ItemParser::toString($item);
            }, $this->items)
        ];
    }

    public static function jsonDeserialize(array $data): Content {
        return new self (... $data);
    }
}