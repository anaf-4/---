<?php

namespace anaf2197\crystalapi;

use pocketmine\event\EventPriority;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;
use anaf2197\crystalapi\command\GiveCrystalCommand;
use anaf2197\crystalapi\command\MyCrystalCommand;
use anaf2197\crystalapi\command\SetCrystalCommand;
use anaf2197\crystalapi\command\TakeCrystalCommand;
use anaf2197\lib\provider\DataProvider;
use anaf2197\lib\provider\ProviderHandler;
use anaf2197\lib\color\ServerColor;

final class CrystalAPI extends PluginBase {

    const DB_CRYSTAL = 'label_crystal';

    use SingletonTrait;

    public static string $prefix;

    private DataProvider $provider;

    protected function onEnable(): void {
        if (!$this->provider->getObject(self::DB_CRYSTAL) instanceof CrystalManager){
            $this->provider->setObject(self::DB_CRYSTAL, new CrystalManager(self::DB_CRYSTAL, []));
        }
        $this->getServer()->getPluginManager()->registerEvent(PlayerJoinEvent::class, function (PlayerJoinEvent $event): void {
            $player = $event->getPlayer();
            $crystalManager = $this->getCrystalManager();
            if (is_null($crystalManager->getCrystal($player))) {
                $crystalManager->setCrystal($player, 0);
            }
        }, EventPriority::MONITOR, $this);
        $this->getServer()->getCommandMap()->registerAll(strtolower($this->getName()), [
            new GiveCrystalCommand(),
            new MyCrystalCommand(),
            new SetCrystalCommand(),
            new TakeCrystalCommand()
        ]);
    }

    protected function onDisable(): void {
        $this->saveDatabase();
    }

    public function saveDatabase(): void {
        $this->provider->save();
    }

    protected function onLoad(): void {
        self::setInstance($this);
        ServerColor::setPrefix($this, '크리스탈');
        if (!ProviderHandler::isRegistered($this)) {
            ProviderHandler::register($this, CrystalManager::class);
            $this->provider = ProviderHandler::get($this);
        }
    }

    public function getCrystalManager(): CrystalManager {
        return $this->provider->getObject(self::DB_CRYSTAL);
    }
}