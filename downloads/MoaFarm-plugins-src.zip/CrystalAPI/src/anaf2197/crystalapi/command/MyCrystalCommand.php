<?php

namespace anaf2197\crystalapi\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\crystalapi\CrystalAPI;

final class MyCrystalCommand extends Command {

    public function __construct() {
        parent::__construct('내크리스탈', '내 크리스탈을 확인합니다.', null, ['크리스탈', 'mycrystal', 'crystal']);
        $this->setPermission(DefaultPermissions::ROOT_USER);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($sender instanceof Player) {
            if ($this->testPermission($sender)) {
                $sender->sendMessage(CrystalAPI::$prefix . '내 크리스탈: ' . CrystalAPI::getInstance()->getCrystalManager()->getCrystal($sender) . '개');
            }
        }
    }
}