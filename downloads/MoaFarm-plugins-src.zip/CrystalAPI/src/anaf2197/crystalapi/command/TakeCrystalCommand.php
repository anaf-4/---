<?php

namespace anaf2197\crystalapi\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\crystalapi\CrystalAPI;

final class TakeCrystalCommand extends Command {

    public function __construct() {
        parent::__construct('크리스탈뺏기', '크리스탈을 회수합니다.', null, ['takecrystal']);
        $this->setPermission(DefaultPermissions::ROOT_OPERATOR);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($sender instanceof Player) {
            if ($this->testPermission($sender)) {
                $to = array_shift($args);
                $crystal = (string)array_shift($args);
                if (trim($crystal) !== '') {
                    if (is_numeric($crystal)) {
                        $crystalManager = CrystalAPI::getInstance()->getCrystalManager();
                        if (is_numeric($crystalManager->getCrystal($to))) {
                            settype($crystal, 'integer');
                            $crystalManager->reduceCrystal($to, $crystal);
                            $sender->sendMessage(CrystalAPI::$prefix . $to . '님의 크리스탈을 회수했습니다.');
                        } else {
                            $sender->sendMessage(CrystalAPI::$prefix . '데이터가 존재하지 않습니다.');
                        }
                    } else {
                        $sender->sendMessage(CrystalAPI::$prefix . '값은 숫자로 입력해야합니다.');
                    }
                } else {
                    $sender->sendMessage(CrystalAPI::$prefix . '/크리스탈뺏기 [닉네임] [값] - 크리스탈을 회수합니다.');
                }
            }
        }
    }
}