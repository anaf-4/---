<?php

namespace anaf2197\crystalapi;

use pocketmine\player\Player;
use pocketmine\Server;
use anaf2197\lib\scoreboard\Scoreboard;
use anaf2197\servercore\CoreLoader;

final class CrystalManager implements \JsonSerializable {

    public function __construct(private string $label, protected array $crystals) { }

    public function getCrystal($key): ?int {
        return $this->crystals [strtolower($key instanceof Player ? $key->getName() : $key)] ?? null;
    }

    public function setCrystal($key, int $crystal): void {
        $key = strtolower($key instanceof Player ? $key->getName() : $key);
        $this->crystals [$key] = $crystal;
    }

    public function addCrystal($key, int $crystal): void {
        $key = strtolower($key instanceof Player ? $key->getName() : $key);
        $this->crystals [$key] += $crystal;
    }

    public function reduceCrystal($key, int $crystal): void {
        $key = strtolower($key instanceof Player ? $key->getName() : $key);
        $this->crystals [$key] -= $crystal;
    }

    public function jsonSerialize(): array {
        return [
            $this->label,
            $this->crystals
        ];
    }

    public static function jsonDeserialize(array $data): self {
        return new self (... $data);
    }
}