<?php
declare(strict_types=1);

namespace anaf2197\antibot;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;

final class AntiBot extends PluginBase implements Listener {

    use SingletonTrait;

    /** @var array<string, int> IP → 현재 접속자 수 */
    private array $connections = [];

    /** @var array<string, int[]> IP → 로그인 시도 타임스탬프 목록 */
    private array $loginAttempts = [];

    /** @var string[] 차단된 IP 목록 */
    private array $bannedIps = [];

    protected function onLoad(): void {
        self::setInstance($this);
    }

    protected function onEnable(): void {
        $this->saveDefaultConfig();
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getLogger()->info('AntiBot 활성화');
    }

    /**
     * @priority LOWEST
     */
    public function onLogin(PlayerLoginEvent $event): void {
        $player = $event->getPlayer();
        $ip     = $player->getNetworkSession()->getIp();
        $cfg    = $this->getConfig();

        $whitelist = (array) $cfg->get('whitelist', ['127.0.0.1']);
        if (in_array($ip, $whitelist, true)) return;

        // IP 차단 확인
        if (isset($this->bannedIps[$ip])) {
            $event->setKickMessage('§c[AntiBot] IP가 일시적으로 차단됐습니다. 잠시 후 재접속해주세요.');
            $event->cancel();
            return;
        }

        // 동시 접속 수 체크
        $maxConn = (int) $cfg->get('max_connections_per_ip', 3);
        $current = $this->connections[$ip] ?? 0;
        if ($current >= $maxConn) {
            $event->setKickMessage("§c[AntiBot] 동일 IP의 최대 접속 수({$maxConn}명)를 초과했습니다.");
            $event->cancel();
            return;
        }

        // 분당 로그인 횟수 체크
        $now = time();
        $this->loginAttempts[$ip] = array_values(array_filter(
            $this->loginAttempts[$ip] ?? [],
            fn($t) => $now - $t < 60
        ));
        $this->loginAttempts[$ip][] = $now;

        $maxAttempts = (int) $cfg->get('max_attempts_per_minute', 10);
        if (count($this->loginAttempts[$ip]) > $maxAttempts) {
            $banDuration = (int) $cfg->get('ban_duration_seconds', 600);
            if ($banDuration > 0) {
                $this->bannedIps[$ip] = $now + $banDuration;
                $this->getLogger()->warning("[AntiBot] IP 차단: {$ip} ({$banDuration}초)");
                // 자동 해제 태스크
                $this->getScheduler()->scheduleDelayedTask(
                    new \pocketmine\scheduler\ClosureTask(function () use ($ip): void {
                        unset($this->bannedIps[$ip]);
                        $this->getLogger()->info("[AntiBot] IP 차단 해제: {$ip}");
                    }),
                    $banDuration * 20
                );
            }
            $event->setKickMessage('§c[AntiBot] 과도한 접속 시도가 감지됐습니다. 잠시 후 재접속해주세요.');
            $event->cancel();
            return;
        }

        $this->connections[$ip] = $current + 1;
    }

    public function onQuit(PlayerQuitEvent $event): void {
        $ip = $event->getPlayer()->getNetworkSession()->getIp();
        if (isset($this->connections[$ip])) {
            $this->connections[$ip] = max(0, $this->connections[$ip] - 1);
            if ($this->connections[$ip] === 0) {
                unset($this->connections[$ip]);
            }
        }
    }
}
