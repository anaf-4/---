<?php

namespace anaf2197\AdvancedTrash;

use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;
use anaf2197\lib\color\ServerColor;
use anaf2197\AdvancedTrash\command\TrashCommand;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\InvMenuHandler;
final class TrashLoader extends PluginBase
{

    use SingletonTrait;

    public static string $prefix;

    protected function onEnable(): void
    {
        $this->getServer()->getCommandMap()->registerAll(strtolower($this->getName()), [
            new TrashCommand()
        ]);
        if (!InvMenuHandler::isRegistered()) {
            InvMenuHandler::register($this);
        }
    }

    protected function onLoad(): void
    {
        self::setInstance($this);
        ServerColor::setPrefix($this, '쓰레기통');
    }

    public function onOpen(Player $player): void
    {
        $menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST);
        $menu->setName("§3");
        $menu->setInventoryCloseListener(function (Player $player): void {
            $player->sendMessage(self::$prefix . '쓰레기통에 있는 아이템이 제거되었습니다.');
        });
        $menu->send($player);
    }
}