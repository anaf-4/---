<?php

namespace anaf2197\AdvancedTrash\command;

use anaf2197\AdvancedTrash\TrashLoader;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;

final class TrashCommand extends Command {

    public function __construct() {
        parent::__construct('쓰레기통', '쓰레기통을 엽니다.');
        $this->setPermission(DefaultPermissions::ROOT_USER);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void
    {
        if ($sender instanceof Player) {
            if ($this->testPermission($sender)) {
                TrashLoader::getInstance()->onOpen($sender);
            }
        }
    }
}