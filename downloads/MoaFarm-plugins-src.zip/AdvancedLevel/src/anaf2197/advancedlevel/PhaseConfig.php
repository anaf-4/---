<?php

namespace anaf2197\advancedlevel;

use pocketmine\item\Item;
use anaf2197\phaseitemconfig\PhaseItemConfig;

/**
 * 위상 설정 클래스
 *
 * 아이템 관련 저장/로드는 PhaseItemConfig 플러그인에 위임합니다.
 * YAML 키 타입 문제(int vs string)를 원천 차단하기 위해 분리했습니다.
 */
final class PhaseConfig {

    // 위상별 최대 레벨
    private const PHASE_MAX_LEVELS = [
        0  => 65,
        1  => 125,
        2  => 185,
        3  => 245,
        4  => 305,
        5  => 365,
        6  => 405,
        7  => 465,
        8  => 525,
        9  => 585,
        10 => 645,
    ];

    // 위상별 승급 비용
    private const PHASE_UPGRADE_COSTS = [
        1  => 1000000,
        2  => 2500000,
        3  => 5000000,
        4  => 10000000,
        5  => 20000000,
        6  => 50000000,
        7  => 75000000,
        8  => 100000000,
        9  => 150000000,
        10 => 300000000,
    ];

    // 위상별 경험치 보너스 (%)
    private const PHASE_EXP_BONUS = [
        0  => 0,
        1  => 1.5,
        2  => 2,
        3  => 4.5,
        4  => 6,
        5  => 8.5,
        6  => 10,
        7  => 12.5,
        8  => 13.5,
        9  => 15,
        10 => 17,
    ];

    // 위상별 데미지 보너스 (%)
    private const PHASE_DAMAGE_BONUS = [
        0  => 0,
        1  => 0.5,
        2  => 1,
        3  => 2,
        4  => 3.5,
        5  => 4.5,
        6  => 5.5,
        7  => 7,
        8  => 8.5,
        9  => 10,
        10 => 11.5,
    ];

    // 위상별 이름
    private const PHASE_NAMES = [
        0  => '길 잃은 여행자',
        1  => '초보 모험가',
        2  => '숙련된 모험가',
        3  => '떠오르는 영웅',
        4  => '전설의 모험가',
        5  => '초월자',
        6  => '운명의 개척자',
        7  => '차원의 수호자',
        8  => '별의 지배자',
        9  => '신화의 존재',
        10 => '세계의 수호자',
    ];

    // 위상별 색상
    private const PHASE_COLORS = [
        0  => '§8',
        1  => '§8',
        2  => '§f',
        3  => '§a',
        4  => '§2',
        5  => '§b',
        6  => '§3',
        7  => '§9',
        8  => '§d',
        9  => '§5',
        10 => '§6',
    ];

    // ── 아이템 관련 (PhaseItemConfig 위임) ──────────────────

    /**
     * 위상 승급에 필요한 아이템 설정 배열 반환
     * @return array [['type'=>string, 'item'=>string, 'count'=>int, ...], ...]
     */
    public static function getUpgradeItems(int $targetPhase): array {
        return PhaseItemConfig::getInstance()->getPhaseItems($targetPhase);
    }

    /**
     * 아이템 설정 배열을 표시용 문자열로 변환
     */
    public static function formatItemRequirementFromConfig(array $itemConfig): string {
        return PhaseItemConfig::getInstance()->getItemObject()->formatItem($itemConfig);
    }

    /**
     * ServerItems 키로 표시용 문자열 변환 (구버전 호환)
     */
    public static function formatItemRequirement(string $itemKey, int $count): string {
        try {
            $item = \anaf2197\servercore\item\ServerItems::{$itemKey}();
            $name = $item->hasCustomName() ? $item->getCustomName() : $item->getName();
            return "§f{$name} §8x{$count}";
        } catch (\Throwable) {
            return "§f{$itemKey} §8x{$count}";
        }
    }

    // ── 기본 스탯 접근자 ──────────────────────────────────────

    public static function getMaxPhase(): int {
        return 10;
    }

    public static function getMaxLevel(int $phase): int {
        return self::PHASE_MAX_LEVELS[$phase] ?? 100;
    }

    public static function getUpgradeCost(int $targetPhase): int {
        return self::PHASE_UPGRADE_COSTS[$targetPhase] ?? 0;
    }

    public static function getExpBonus(int $phase): float {
        return self::PHASE_EXP_BONUS[$phase] ?? 0;
    }

    public static function getDamageBonus(int $phase): float {
        return self::PHASE_DAMAGE_BONUS[$phase] ?? 0;
    }

    public static function getPhaseName(int $phase): string {
        return self::PHASE_NAMES[$phase] ?? '알 수 없음';
    }

    public static function getPhaseColor(int $phase): string {
        return self::PHASE_COLORS[$phase] ?? '§f';
    }
}