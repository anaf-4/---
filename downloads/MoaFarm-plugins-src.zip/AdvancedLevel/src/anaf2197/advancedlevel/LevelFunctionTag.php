<?php

namespace anaf2197\advancedlevel;

use pocketmine\item\Item;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\StringTag;

final class LevelFunctionTag {

    const TYPE_LEVEL = 'levelUp';
    const TYPE_POINT = 'pointUp';
    const TYPE_BOOSTER = 'booster';

    public static function createTag(CompoundTag $nbt, string $id, int|string $value): void {
        $setTag = is_numeric($value) ? 'setInt' : 'setString';
        $nbt->$setTag('advancedlevel.' . $id, $value);
    }

    public static function readFunctionId(Item $item): ?string {
        foreach ($item->getNamedTag()->getValue() as $tagName => $tag) {
            if (in_array($tag, [IntTag::class, StringTag::class])) continue;
            if (count(($cuttingValue = explode('advancedlevel.', $tagName))) >= 2) return $cuttingValue [1];
        }
        return null;
    }

    public static function readValue(Item $item, string $id): null|int|string {
        return $item->getNamedTag()->getTag('advancedlevel.' . $id)?->getValue();
    }

    public static function getAll(): array {
        return [
            self::TYPE_LEVEL,
            self::TYPE_POINT,
            self::TYPE_BOOSTER
        ];
    }
}