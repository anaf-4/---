<?php

namespace anaf2197\advancedlevel;

use pocketmine\item\Item;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;
use anaf2197\advancedlevel\command\GiveBoosterCommand;
use anaf2197\advancedlevel\command\GiveLevelCommand;
use anaf2197\advancedlevel\command\GivePointCommand;
use anaf2197\advancedlevel\command\LevelCommand;
use anaf2197\advancedlevel\command\LevelRankCommand;
use anaf2197\advancedlevel\command\SetLevelCommand;
use anaf2197\advancedlevel\command\PhaseCommand;
use anaf2197\advancedlevel\command\PhaseUpCommand;
use anaf2197\advancedlevel\command\SetPhaseCommand;
use anaf2197\advancedlevel\command\PhaseRankCommand;
use anaf2197\advancedlevel\command\PhaseAdminCommand;
use anaf2197\lib\provider\DataProvider;
use anaf2197\lib\provider\ProviderHandler;
use anaf2197\lib\color\ServerColor;
use anaf2197\servercore\item\ItemDesign;
use anaf2197\servercore\item\ItemTypes;
use anaf2197\servercore\item\ServerItems;

final class AdvancedLevel extends PluginBase {

    public static string $prefix;

    private DataProvider $provider;
    private DataProvider $phaseProvider;

    use SingletonTrait;

    protected function onEnable(): void {
        $this->getServer()->getPluginManager()->registerEvents(new EventListener(), $this);
        $this->getServer()->getCommandMap()->registerAll(strtolower($this->getName()), [
            // 레벨 시스템 명령어
            new GiveBoosterCommand(),
            new GiveLevelCommand(),
            new GivePointCommand(),
            new LevelCommand(),
            new SetLevelCommand(),
            new LevelRankCommand(),
            // 위상 시스템 명령어
            new PhaseCommand(),
            new PhaseUpCommand(),
            new SetPhaseCommand(),
            new PhaseRankCommand(),
            new PhaseAdminCommand()
        ]);
    }

    protected function onLoad(): void {
        self::setInstance($this);
        ServerColor::setPrefix($this, '레벨');

        // 레벨 시스템 프로바이더
        if (!ProviderHandler::isRegistered($this)) {
            ProviderHandler::register($this, PlayerLevel::class);
            $this->provider = ProviderHandler::get($this);
        }

        // 위상 시스템 프로바이더 (별도 저장)
        $phaseKey = $this->getName() . '_phase';
        if (!ProviderHandler::isRegistered($this, $phaseKey)) {
            ProviderHandler::register($this, PlayerPhase::class, $phaseKey);
            $this->phaseProvider = ProviderHandler::get($this, $phaseKey);
        }

        // 위상 아이템 설정은 PhaseItemConfig 플러그인이 담당합니다.
        // PhaseConfig::getDebugInfo() / PhaseConfig::saveConfig() 호출 불필요
    }

    protected function onDisable(): void {
        $this->saveDatabase();
    }

    public function saveDatabase(): void {
        $this->provider->save();
        $this->phaseProvider->save();
        // 아이템 설정 저장은 PhaseItemConfig 플러그인의 onDisable()에서 처리
    }

    public function getPointBooster(int $x, int $minute): Item {
        $item = ServerItems::TICKET_EXP();
        ItemDesign::setItemDesign($item, ItemTypes::CONSUME, '경험치 부스터: ' . $x . '%', [
            '지속시간동안 추가 경험치를 획득합니다.',
            '이 증가율은 200%를 초과할 수 없습니다.',
            null,
            '지속 시간: ' . ($minute / 60) . '분'
        ], '웅크리기 + 터치');
        LevelFunctionTag::createTag($item->getNamedTag(), LevelFunctionTag::TYPE_BOOSTER, $x . ':' . $minute);
        return $item;
    }

    public function getLevelPaper(int $amount): Item {
        $item = ServerItems::ROLL_LEVEL();
        ItemDesign::setItemDesign($item, ItemTypes::CONSUME, '레벨업권: ' . $amount . 'Lv', [
            '사용자의 레벨을 올립니다.'
        ], '웅크리기 + 터치');
        LevelFunctionTag::createTag($item->getNamedTag(), LevelFunctionTag::TYPE_LEVEL, $amount);
        return $item;
    }

    public function getPointPaper(int $amount): Item {
        $item = ServerItems::ROLL_EXP();
        ItemDesign::setItemDesign($item, ItemTypes::CONSUME, '경험치권: ' . $amount . 'XP', [
            '사용자의 경험치를 올립니다.'
        ], '웅크리기 + 터치');
        LevelFunctionTag::createTag($item->getNamedTag(), LevelFunctionTag::TYPE_POINT, $amount);
        return $item;
    }

    // ========== 레벨 시스템 메서드 ==========

    public function getAll(): array {
        return $this->provider->getAll();
    }

    public function getAll1(): array {
        $all = $this->provider->getAll();
        array_walk($all, function (PlayerLevel &$economyData) {
            $economyData = $economyData->getLevel();
        });
        arsort($all);
        return $all;
    }

    public function getPlayerLevel($key): ?PlayerLevel {
        return $this->provider->getObject($key);
    }

    public function getRankToPlayer(int $rank): ?string {
        return array_keys($this->getAll1()) [$rank - 1] ?? null;
    }

    public function setPlayerLevel($key, PlayerLevel $playerLevel): void {
        $this->provider->setObject($key, $playerLevel);
    }

    // ========== 위상 시스템 메서드 ==========

    public function getAllPhase(): array {
        return $this->phaseProvider->getAll();
    }

    public function getAllPhaseRanking(): array {
        $all = $this->phaseProvider->getAll();

        uasort($all, function (PlayerPhase $a, PlayerPhase $b): int {
            if ($a->getPhase() !== $b->getPhase()) {
                return $b->getPhase() <=> $a->getPhase();
            }
            $levelA = $this->getPlayerLevel($a->getName())?->getLevel() ?? 0;
            $levelB = $this->getPlayerLevel($b->getName())?->getLevel() ?? 0;
            return $levelB <=> $levelA;
        });

        return $all;
    }

    public function getPlayerPhase($key): ?PlayerPhase {
        return $this->phaseProvider->getObject($key);
    }

    public function getPhaseRankToPlayer(int $rank): ?string {
        return array_keys($this->getAllPhaseRanking()) [$rank - 1] ?? null;
    }

    public function setPlayerPhase($key, PlayerPhase $playerPhase): void {
        $this->phaseProvider->setObject($key, $playerPhase);
    }
}