<?php

namespace anaf2197\advancedlevel\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use anaf2197\advancedlevel\AdvancedLevel;

final class LevelRankCommand extends Command {

    public function __construct() {
        parent::__construct('레벨순위', '§r§8전체 레벨 순위를 확인합니다.');
        $this->setPermission(DefaultPermissions::ROOT_USER);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($this->testPermission($sender)) {
            $all = AdvancedLevel::getInstance()->getAll1();
            $maxpage = (int)max(1, ceil(count($all) / 5));
            $page = array_shift($args);
            if (!is_numeric($page)) {
                $page = 1;
            }
            $page = intval(min(max(1, $page), $maxpage) - 1);
            $min = 5 * $page;
            $max = 5 * ($page + 1);
            $sender->sendMessage(AdvancedLevel::$prefix . '레벨 순위 (페이지: §l§a' . ($page + 1) . '§r§8/' . $maxpage . ')');
            for ($i = $min; $i < $max; $i++) {
                $rank = $i + 1;
                $username = AdvancedLevel::getInstance()->getRankToPlayer($rank);
                if (is_string($username)) {
                    $sender->sendMessage('§8- ' . $rank . '. ' . $username . ' (' . AdvancedLevel::getInstance()->getPlayerLevel($username)->getLevel() . ')');
                } else {
                    break;
                }
            }
        }
    }
}