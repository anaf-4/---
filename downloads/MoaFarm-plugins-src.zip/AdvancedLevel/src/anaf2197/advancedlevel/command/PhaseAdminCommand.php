<?php

namespace anaf2197\advancedlevel\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use pocketmine\Server;
use anaf2197\advancedlevel\AdvancedLevel;
use anaf2197\advancedlevel\PhaseConfig;
use anaf2197\advancedlevel\PlayerPhase;
use anaf2197\advancedlevel\PlayerLevel;

final class PhaseAdminCommand extends Command {

    public function __construct() {
        parent::__construct('위상관리', '§r§8관리자 전용 위상 관리 명령어입니다.', null, ['phaseadmin', 'adminphase']);
        $this->setPermission(DefaultPermissions::ROOT_OPERATOR);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if (!$this->testPermission($sender)) {
            return;
        }

        $subCommand = array_shift($args);

        if ($subCommand === null) {
            $this->sendHelp($sender);
            return;
        }

        switch (strtolower($subCommand)) {
            case '설정':
            case 'set':
                $this->handleSet($sender, $args);
                break;

            case '조회':
            case 'view':
            case 'info':
                $this->handleView($sender, $args);
                break;

            case '강제승급':
            case 'forceup':
                $this->handleForceUp($sender, $args);
                break;

            case '초기화':
            case 'reset':
                $this->handleReset($sender, $args);
                break;

            case '전체조회':
            case 'list':
                $this->handleList($sender, $args);
                break;

            case '통계':
            case 'stats':
                $this->handleStats($sender);
                break;

            case '아이템관리':
            case 'itemmanage':
            case 'items':
                $sender->sendMessage(AdvancedLevel::$prefix . '아이템 관리는 PhaseItemConfig 플러그인 명령어를 사용하세요.');
                $sender->sendMessage('§r§8/위상아이템추가 <위상> <개수> §f- 손에 든 아이템 추가');
                $sender->sendMessage('§r§8/위상아이템제거 <위상> <번호> §f- 아이템 제거');
                $sender->sendMessage('§r§8/위상아이템초기화 <위상> §f- 기본값으로 초기화');
                $sender->sendMessage('§r§8/위상아이템목록 [위상] §f- 아이템 목록 확인');
                break;

            default:
                $sender->sendMessage(AdvancedLevel::$prefix . '§c알 수 없는 명령어입니다.');
                $this->sendHelp($sender);
                break;
        }
    }

    private function sendHelp(CommandSender $sender): void {
        $sender->sendMessage('§l§e━━━━━ [위상 관리 명령어] ━━━━━');
        $sender->sendMessage('§r§8/위상관리 설정 <닉네임> <위상> §f- 위상 설정');
        $sender->sendMessage('§r§8/위상관리 조회 <닉네임> §f- 위상 정보 조회');
        $sender->sendMessage('§r§8/위상관리 강제승급 <닉네임> §f- 강제로 위상 승급');
        $sender->sendMessage('§r§8/위상관리 초기화 <닉네임> §f- 위상 초기화 (위상 0)');
        $sender->sendMessage('§r§8/위상관리 전체조회 §f- 모든 플레이어 위상 목록');
        $sender->sendMessage('§r§8/위상관리 통계 §f- 위상별 플레이어 통계');
        $sender->sendMessage('§r§a/위상아이템추가·제거·목록 §f- 아이템 관리 (PhaseItemConfig)');
        $sender->sendMessage('§l§e━━━━━━━━━━━━━━━━━━');
    }

    private function handleSet(CommandSender $sender, array $args): void {
        $target = array_shift($args);
        $phase  = array_shift($args);

        if ($target === null || $phase === null) {
            $sender->sendMessage(AdvancedLevel::$prefix . '§c사용법: /위상관리 설정 <닉네임> <위상>');
            return;
        }

        if (!is_numeric($phase)) {
            $sender->sendMessage(AdvancedLevel::$prefix . '§c위상은 숫자로 입력해주세요.');
            return;
        }

        $phase    = (int)$phase;
        $maxPhase = PhaseConfig::getMaxPhase();

        if ($phase < 0 || $phase > $maxPhase) {
            $sender->sendMessage(AdvancedLevel::$prefix . "§c위상은 0부터 {$maxPhase}까지 설정 가능합니다.");
            return;
        }

        $playerPhase = AdvancedLevel::getInstance()->getPlayerPhase($target);
        if (!$playerPhase instanceof PlayerPhase) {
            $sender->sendMessage(AdvancedLevel::$prefix . '§c존재하지 않는 플레이어입니다.');
            return;
        }

        $before    = $playerPhase->getPhase();
        $playerPhase->setPhase($phase);
        $color     = PhaseConfig::getPhaseColor($phase);
        $phaseName = PhaseConfig::getPhaseName($phase);

        $sender->sendMessage(AdvancedLevel::$prefix . "§a{$target}님의 위상을 {$color}위상 {$phase} ({$phaseName})§a(으)로 설정했습니다. (이전: 위상 {$before})");

        $player = Server::getInstance()->getPlayerExact($target);
        if ($player instanceof Player) {
            $player->sendMessage(AdvancedLevel::$prefix . "§e관리자가 당신의 위상을 {$color}위상 {$phase} ({$phaseName})§e(으)로 설정했습니다.");
        }
    }

    private function handleView(CommandSender $sender, array $args): void {
        $target = array_shift($args);

        if ($target === null) {
            $sender->sendMessage(AdvancedLevel::$prefix . '§c사용법: /위상관리 조회 <닉네임>');
            return;
        }

        $playerPhase = AdvancedLevel::getInstance()->getPlayerPhase($target);
        $playerLevel = AdvancedLevel::getInstance()->getPlayerLevel($target);

        if (!$playerPhase instanceof PlayerPhase || !$playerLevel instanceof PlayerLevel) {
            $sender->sendMessage(AdvancedLevel::$prefix . '§c존재하지 않는 플레이어입니다.');
            return;
        }

        $phase     = $playerPhase->getPhase();
        $level     = $playerLevel->getLevel();
        $maxLevel  = $playerPhase->getMaxLevel();
        $color     = PhaseConfig::getPhaseColor($phase);
        $phaseName = PhaseConfig::getPhaseName($phase);

        $sender->sendMessage('§l§e━━━━━ [관리자 위상 조회] ━━━━━');
        $sender->sendMessage("§r§8플레이어: §f{$target}");
        $sender->sendMessage("§r§8현재 위상: {$color}§l위상 {$phase} §r{$color}({$phaseName})");
        $sender->sendMessage("§r§8레벨: §f{$level} §8/ §f{$maxLevel}");
        $sender->sendMessage("§r§8경험치: §f" . $playerLevel->getPoint() . " §8/ §f" . $playerLevel->getMaxPoint());
        $sender->sendMessage("§r§8경험치 보너스: §a+" . $playerPhase->getExpBonus() . "%");
        $sender->sendMessage("§r§8데미지 보너스: §c+" . $playerPhase->getDamageBonus() . "%");

        if ($phase < PhaseConfig::getMaxPhase()) {
            $nextPhase     = $phase + 1;
            $requiredLevel = $playerPhase->getRequiredLevelForNextPhase();
            $cost          = PhaseConfig::getUpgradeCost($nextPhase);
            $sender->sendMessage('§r§8§m                         ');
            $sender->sendMessage("§r§8다음 위상 조건:");
            $sender->sendMessage("§r§8  필요 레벨: §f{$requiredLevel} Lv");
            $sender->sendMessage("§r§8  승급 비용: §e" . number_format($cost) . "원");

            $items = PhaseConfig::getUpgradeItems($nextPhase);
            if (!empty($items)) {
                $sender->sendMessage("§r§8  필요 아이템:");
                foreach ($items as $itemConfig) {
                    $formatted = PhaseConfig::formatItemRequirementFromConfig($itemConfig);
                    $sender->sendMessage("§r§8    - {$formatted}");
                }
            }
        }
        $sender->sendMessage('§l§e━━━━━━━━━━━━━━━━━━');
    }

    private function handleForceUp(CommandSender $sender, array $args): void {
        $target = array_shift($args);

        if ($target === null) {
            $sender->sendMessage(AdvancedLevel::$prefix . '§c사용법: /위상관리 강제승급 <닉네임>');
            return;
        }

        $playerPhase = AdvancedLevel::getInstance()->getPlayerPhase($target);
        if (!$playerPhase instanceof PlayerPhase) {
            $sender->sendMessage(AdvancedLevel::$prefix . '§c존재하지 않는 플레이어입니다.');
            return;
        }

        $currentPhase = $playerPhase->getPhase();
        if ($currentPhase >= PhaseConfig::getMaxPhase()) {
            $sender->sendMessage(AdvancedLevel::$prefix . '§c이미 최대 위상입니다.');
            return;
        }

        $playerPhase->phaseUp();
        $newPhase  = $playerPhase->getPhase();
        $color     = PhaseConfig::getPhaseColor($newPhase);
        $phaseName = PhaseConfig::getPhaseName($newPhase);

        $sender->sendMessage(AdvancedLevel::$prefix . "§a{$target}님을 {$color}위상 {$newPhase} ({$phaseName})§a(으)로 강제 승급시켰습니다.");

        $player = Server::getInstance()->getPlayerExact($target);
        if ($player instanceof Player) {
            $player->sendTitle('§l§6PHASE UP!', $color . '§l위상 ' . $newPhase . ' §r' . $color . $phaseName);
            $player->sendMessage(AdvancedLevel::$prefix . "§e관리자가 당신의 위상을 승급시켰습니다!");
            $player->sendMessage(AdvancedLevel::$prefix . "§8새로운 최대 레벨: §f" . $playerPhase->getMaxLevel() . " Lv");
        }
    }

    private function handleReset(CommandSender $sender, array $args): void {
        $target = array_shift($args);

        if ($target === null) {
            $sender->sendMessage(AdvancedLevel::$prefix . '§c사용법: /위상관리 초기화 <닉네임>');
            return;
        }

        $playerPhase = AdvancedLevel::getInstance()->getPlayerPhase($target);
        if (!$playerPhase instanceof PlayerPhase) {
            $sender->sendMessage(AdvancedLevel::$prefix . '§c존재하지 않는 플레이어입니다.');
            return;
        }

        $before = $playerPhase->getPhase();
        $playerPhase->setPhase(0);

        $sender->sendMessage(AdvancedLevel::$prefix . "§a{$target}님의 위상을 초기화했습니다. (위상 {$before} → 0)");

        $player = Server::getInstance()->getPlayerExact($target);
        if ($player instanceof Player) {
            $player->sendMessage(AdvancedLevel::$prefix . "§c관리자가 당신의 위상을 초기화했습니다.");
        }
    }

    private function handleList(CommandSender $sender, array $args): void {
        $all = AdvancedLevel::getInstance()->getAllPhaseRanking();

        if (empty($all)) {
            $sender->sendMessage(AdvancedLevel::$prefix . '§c플레이어 데이터가 없습니다.');
            return;
        }

        $page    = isset($args[0]) && is_numeric($args[0]) ? (int)$args[0] : 1;
        $maxpage = (int)max(1, ceil(count($all) / 15));
        $page    = min(max(1, $page), $maxpage) - 1;
        $min     = 15 * $page;
        $max     = 15 * ($page + 1);

        $sender->sendMessage('§l§e━━━ [전체 위상 목록] ━━━');
        $sender->sendMessage('§r§8페이지: §l§a' . ($page + 1) . '§r§8/' . $maxpage);
        $sender->sendMessage('§r§8§m                    ');

        $i = 0;
        foreach ($all as $name => $playerPhase) {
            if ($i < $min) { $i++; continue; }
            if ($i >= $max) break;

            $phase       = $playerPhase->getPhase();
            $playerLevel = AdvancedLevel::getInstance()->getPlayerLevel($name);
            $level       = $playerLevel ? $playerLevel->getLevel() : 0;
            $color       = PhaseConfig::getPhaseColor($phase);

            $sender->sendMessage('§8' . ($i + 1) . '. §f' . $name . ' ' . $color . '§l[위상 ' . $phase . '] §r§8Lv.' . $level);
            $i++;
        }

        $sender->sendMessage('§l§e━━━━━━━━━━━━━━━');
    }

    private function handleStats(CommandSender $sender): void {
        $all = AdvancedLevel::getInstance()->getAllPhase();

        if (empty($all)) {
            $sender->sendMessage(AdvancedLevel::$prefix . '§c플레이어 데이터가 없습니다.');
            return;
        }

        $stats = [];
        for ($i = 0; $i <= PhaseConfig::getMaxPhase(); $i++) {
            $stats[$i] = 0;
        }
        foreach ($all as $playerPhase) {
            $stats[$playerPhase->getPhase()]++;
        }

        $totalPlayers = count($all);

        $sender->sendMessage('§l§e━━━━━ [위상 통계] ━━━━━');
        $sender->sendMessage("§r§8총 플레이어 수: §f{$totalPlayers}명");
        $sender->sendMessage('§r§8§m                    ');

        for ($i = 0; $i <= PhaseConfig::getMaxPhase(); $i++) {
            $count      = $stats[$i];
            $percentage = $totalPlayers > 0 ? round(($count / $totalPlayers) * 100, 1) : 0;
            $color      = PhaseConfig::getPhaseColor($i);
            $phaseName  = PhaseConfig::getPhaseName($i);

            $sender->sendMessage($color . "§l위상 {$i} §r§8({$phaseName}): §f{$count}명 §8({$percentage}%)");
            $sender->sendMessage("§r§8" . $this->createBar($percentage));
        }

        $sender->sendMessage('§l§e━━━━━━━━━━━━━━━━');
    }

    private function createBar(float $percentage): string {
        $filled = (int)round(($percentage / 100) * 20);
        return '§a' . str_repeat('█', $filled) . '§8' . str_repeat('░', 20 - $filled);
    }
}