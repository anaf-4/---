<?php

namespace anaf2197\advancedlevel\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\advancedlevel\AdvancedLevel;

final class GiveBoosterCommand extends Command {

    public function __construct() {
        parent::__construct('경험치부스터', '§r§8경험치 부스터를 지급받습니다.', null, ['givelbooster']);
        $this->setPermission(DefaultPermissions::ROOT_OPERATOR);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($sender instanceof Player) {
            if ($this->testPermission($sender)) {
                $x = array_shift($args);
                $minute = array_shift($args);
                if (trim((string)$minute) !== '') {
                    if (is_numeric($x) and is_numeric($minute)) {
                        $x = (int)$x;
                        $minute = (int)($minute * 60);
                        $sender->getInventory()->addItem(AdvancedLevel::getInstance()->getPointBooster($x, $minute));
                        $sender->sendMessage(AdvancedLevel::$prefix . '경험치 부스터를 지급받았습니다.');
                    } else {
                        $sender->sendMessage(AdvancedLevel::$prefix . '값은 숫자로 입력해 주세요.');
                    }
                } else {
                    $sender->sendMessage(AdvancedLevel::$prefix . '/경험치부스터 [퍼센트] [지속시간(분)] - 경험치 부스터를 지급받습니다.');
                }
            }
        }
    }
}