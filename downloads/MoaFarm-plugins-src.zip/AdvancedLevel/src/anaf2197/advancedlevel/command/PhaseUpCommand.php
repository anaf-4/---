<?php

namespace anaf2197\advancedlevel\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\advancedlevel\AdvancedLevel;
use anaf2197\advancedlevel\form\PhaseForm;

final class PhaseUpCommand extends Command {

    public function __construct() {
        parent::__construct('위상승급', '§r§8위상을 승급합니다.', null, ['phaseup', '승급']);
        $this->setPermission(DefaultPermissions::ROOT_USER);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if (!$sender instanceof Player) return;
        if (!$this->testPermission($sender)) return;

        // /위상 폼을 열면 승급 버튼까지 포함되어 있어 그대로 재사용
        $sender->sendForm(new PhaseForm($sender->getName()));
    }
}
