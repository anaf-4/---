<?php

namespace anaf2197\advancedlevel\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\advancedlevel\AdvancedLevel;
use anaf2197\advancedlevel\PlayerLevel;
use anaf2197\advancedlevel\PointBooster;
use anaf2197\lib\timeparser\TimeParser;

final class LevelCommand extends Command {

    public function __construct() {
        parent::__construct('레벨', '§r§8나의 레벨을 확인합니다.', null, ['level', 'mylevel', '내레벨']);
        $this->setPermission(DefaultPermissions::ROOT_USER);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($sender instanceof Player) {
            if ($this->testPermission($sender)) {
                $target = (string)(array_shift($args) ?? $sender->getName());
                $playerLevel = AdvancedLevel::getInstance()->getPlayerLevel($target);
                if ($playerLevel instanceof PlayerLevel) {
                    $sender->sendMessage(AdvancedLevel::$prefix . '내 레벨: ' . $playerLevel->getLevel() . ' §l§gLv §r§8(' . $playerLevel->getLevelUpProgress(true) . '%)');
                    $boosters = array_map(function (PointBooster $booster): string {
                        return $booster->getX() . '% - ' . TimeParser::timeToMinute($booster->getTime()) . '분';
                    }, array_filter(array_values($playerLevel->getBoosters()), function (PointBooster $booster): bool { return !$booster->isClosed(); }));
                    if (!empty($boosters)) $sender->sendMessage(AdvancedLevel::$prefix . '경험치 부스터: ' . implode(', ', $boosters));
                } else {
                    $sender->sendMessage(AdvancedLevel::$prefix . '데이터가 존재하지 않는 닉네임입니다.');
                }
            }
        }
    }
}