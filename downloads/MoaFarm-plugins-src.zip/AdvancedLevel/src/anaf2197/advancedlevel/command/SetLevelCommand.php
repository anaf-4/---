<?php

namespace anaf2197\advancedlevel\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\advancedlevel\AdvancedLevel;
use anaf2197\advancedlevel\PlayerLevel;
use anaf2197\advancedlevel\PlayerPhase;
use anaf2197\advancedlevel\PhaseConfig;

final class SetLevelCommand extends Command {

    public function __construct() {
        parent::__construct('레벨설정', '§r§8대상 게이머의 레벨을 설정합니다.', null, ['setlevel']);
        $this->setPermission(DefaultPermissions::ROOT_OPERATOR);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($sender instanceof Player) {
            if ($this->testPermission($sender)) {
                $to = array_shift($args);
                $amount = array_shift($args);
                
                if (trim((string)$amount) !== '') {
                    if (is_numeric($amount)) {
                        $amount = (int)$amount;
                        
                        $playerLevel = AdvancedLevel::getInstance()->getPlayerLevel($to);
                        $playerPhase = AdvancedLevel::getInstance()->getPlayerPhase($to);
                        
                        if ($playerLevel instanceof PlayerLevel && $playerPhase instanceof PlayerPhase) {
                            $maxLevel = $playerPhase->getMaxLevel();
                            $currentPhase = $playerPhase->getPhase();
                            
                            // 위상별 최대 레벨 체크
                            if ($amount > $maxLevel) {
                                $sender->sendMessage(AdvancedLevel::$prefix . '§c설정하려는 레벨이 최대 레벨을 초과합니다!');
                                $sender->sendMessage(AdvancedLevel::$prefix . '§8플레이어: §f' . $to);
                                $sender->sendMessage(AdvancedLevel::$prefix . '§8현재 위상: §f위상 ' . $currentPhase);
                                $sender->sendMessage(AdvancedLevel::$prefix . '§8최대 레벨: §f' . $maxLevel . 'Lv');
                                $sender->sendMessage(AdvancedLevel::$prefix . '§8요청한 레벨: §c' . $amount . 'Lv §8(초과: §c' . ($amount - $maxLevel) . 'Lv§8)');
                                $sender->sendMessage(AdvancedLevel::$prefix . '§8최대 레벨로 설정하려면: §a/레벨설정 ' . $to . ' ' . $maxLevel);
                                return;
                            }
                            
                            $beforeLevel = $playerLevel->getLevel();
                            $playerLevel->setLevel($amount);
                            
                            $sender->sendMessage(AdvancedLevel::$prefix . $playerLevel->getName() . '님의 레벨을 ' . $amount . '(으)로 설정하였습니다. (이전: ' . $beforeLevel . 'Lv)');
                            
                            // 대상 플레이어에게 알림
                            $targetPlayer = \pocketmine\Server::getInstance()->getPlayerExact($to);
                            if ($targetPlayer instanceof Player) {
                                $targetPlayer->sendMessage(AdvancedLevel::$prefix . '§e관리자가 당신의 레벨을 §f' . $amount . 'Lv§e(으)로 설정했습니다.');
                            }
                        } else {
                            $sender->sendMessage(AdvancedLevel::$prefix . '데이터가 존재하지 않는 닉네임입니다.');
                        }
                    } else {
                        $sender->sendMessage(AdvancedLevel::$prefix . '레벨은 숫자로 입력해 주세요.');
                    }
                } else {
                    $sender->sendMessage(AdvancedLevel::$prefix . '/레벨설정 [게이머태그] [레벨] - 대상 게이머의 레벨을 설정합니다.');
                    $sender->sendMessage(AdvancedLevel::$prefix . '§8※ 위상별 최대 레벨을 초과할 수 없습니다.');
                }
            }
        }
    }
}