<?php

namespace anaf2197\advancedlevel\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\advancedlevel\AdvancedLevel;
use anaf2197\advancedlevel\form\PhaseForm;

final class PhaseCommand extends Command {

    public function __construct() {
        parent::__construct('위상', '§r§8나의 위상 정보를 확인합니다.', null, ['phase']);
        $this->setPermission(DefaultPermissions::ROOT_USER);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if (!$sender instanceof Player) return;
        if (!$this->testPermission($sender)) return;

        $target = (string)(array_shift($args) ?? $sender->getName());
        $sender->sendForm(new PhaseForm($target));
    }
}
