<?php

namespace anaf2197\advancedlevel\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\advancedlevel\AdvancedLevel;
use anaf2197\advancedlevel\PlayerPhase;

final class SetPhaseCommand extends Command {

    public function __construct() {
        parent::__construct('위상설정', '§r§8대상 게이머의 위상을 설정합니다.', null, ['setphase']);
        $this->setPermission(DefaultPermissions::ROOT_OPERATOR);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($sender instanceof Player) {
            if ($this->testPermission($sender)) {
                $target = array_shift($args);
                $phase = array_shift($args);
                
                if (trim((string)$phase) !== '') {
                    if (is_numeric($phase)) {
                        $phase = (int)$phase;
                        
                        $playerPhase = AdvancedLevel::getInstance()->getPlayerPhase($target);
                        if ($playerPhase instanceof PlayerPhase) {
                            $playerPhase->setPhase($phase);
                            $sender->sendMessage(AdvancedLevel::$prefix . $playerPhase->getName() . '님의 위상을 ' . $phase . '(으)로 설정하였습니다.');
                        } else {
                            $sender->sendMessage(AdvancedLevel::$prefix . '데이터가 존재하지 않는 닉네임입니다.');
                        }
                    } else {
                        $sender->sendMessage(AdvancedLevel::$prefix . '위상은 숫자로 입력해 주세요.');
                    }
                } else {
                    $sender->sendMessage(AdvancedLevel::$prefix . '/위상설정 [게이머태그] [위상] - 대상 게이머의 위상을 설정합니다.');
                }
            }
        }
    }
}