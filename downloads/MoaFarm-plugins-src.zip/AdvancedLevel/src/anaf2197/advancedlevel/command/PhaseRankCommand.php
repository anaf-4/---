<?php

namespace anaf2197\advancedlevel\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use anaf2197\advancedlevel\AdvancedLevel;
use anaf2197\advancedlevel\PhaseConfig;

final class PhaseRankCommand extends Command {

    public function __construct() {
        parent::__construct('위상순위', '§r§8전체 위상 순위를 확인합니다.', null, ['phaserank']);
        $this->setPermission(DefaultPermissions::ROOT_USER);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($this->testPermission($sender)) {
            $all = AdvancedLevel::getInstance()->getAllPhaseRanking();
            $maxpage = (int)max(1, ceil(count($all) / 10));
            $page = array_shift($args);
            
            if (!is_numeric($page)) {
                $page = 1;
            }
            
            $page = intval(min(max(1, $page), $maxpage) - 1);
            $min = 10 * $page;
            $max = 10 * ($page + 1);
            
            $sender->sendMessage('§l§e━━━━━ [위상 순위] ━━━━━');
            $sender->sendMessage('§r§8페이지: §l§a' . ($page + 1) . '§r§8/' . $maxpage);
            $sender->sendMessage('§r§8§m                    ');
            
            for ($i = $min; $i < $max; $i++) {
                $rank = $i + 1;
                $username = AdvancedLevel::getInstance()->getPhaseRankToPlayer($rank);
                
                if (is_string($username)) {
                    $playerPhase = AdvancedLevel::getInstance()->getPlayerPhase($username);
                    $playerLevel = AdvancedLevel::getInstance()->getPlayerLevel($username);
                    
                    if ($playerPhase && $playerLevel) {
                        $phase = $playerPhase->getPhase();
                        $level = $playerLevel->getLevel();
                        $color = PhaseConfig::getPhaseColor($phase);
                        
                        $sender->sendMessage(
                            '§8' . $rank . '. §f' . $username . ' ' . 
                            $color . '§l[위상 ' . $phase . '] §r§8Lv.' . $level
                        );
                    }
                } else {
                    break;
                }
            }
            
            $sender->sendMessage('§l§e━━━━━━━━━━━━━━━━');
        }
    }
}