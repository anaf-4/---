<?php

namespace anaf2197\advancedlevel\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\advancedlevel\AdvancedLevel;

final class GiveLevelCommand extends Command {

    public function __construct() {
        parent::__construct('레벨업권', '§r§8레벨업권을 지급받습니다.', null, ['givelevel']);
        $this->setPermission(DefaultPermissions::ROOT_OPERATOR);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($sender instanceof Player) {
            if ($this->testPermission($sender)) {
                $amount = array_shift($args);
                if (trim((string)$amount) !== '') {
                    if (is_numeric($amount)) {
                        $amount = min((int)$amount, 0x7fffffff);
                        $sender->getInventory()->addItem(AdvancedLevel::getInstance()->getLevelPaper($amount));
                        $sender->sendMessage(AdvancedLevel::$prefix . '레벨업권을 지급받았습니다.');
                    } else {
                        $sender->sendMessage(AdvancedLevel::$prefix . '값은 숫자로 입력해 주세요.');
                    }
                } else {
                    $sender->sendMessage(AdvancedLevel::$prefix . '/레벨업권 [값] - 레벨업권을 지급받습니다.');
                }
            }
        }
    }
}