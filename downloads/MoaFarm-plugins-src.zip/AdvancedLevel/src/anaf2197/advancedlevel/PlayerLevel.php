<?php

namespace anaf2197\advancedlevel;

use pocketmine\player\Player;
use pocketmine\Server;
use anaf2197\advancedlevel\event\LevelDownEvent;
use anaf2197\advancedlevel\event\LevelUpEvent;
use anaf2197\advancedlevel\event\PointDownEvent;
use anaf2197\advancedlevel\event\PointUpEvent;

final class PlayerLevel implements \JsonSerializable {

    protected array $boosters;

    public function __construct(private string $name, protected int $level, protected int $point, array $boosterDatas) {
        $this->boosters = array_map(function (array $boosterData): PointBooster {
            return PointBooster::jsonDeserialize($boosterData);
        }, $boosterDatas);
    }

    public function getName(): string {
        return $this->name;
    }

    public function getPlayer(): ?Player {
        return Server::getInstance()->getPlayerExact($this->name);
    }

    public function getLevel(): int {
        return $this->level;
    }

    /**
     * 위상 시스템과 연동하여 최대 레벨 확인
     */
    private function getMaxLevelByPhase(): int {
        $playerPhase = AdvancedLevel::getInstance()->getPlayerPhase($this->name);
        if ($playerPhase instanceof PlayerPhase) {
            return $playerPhase->getMaxLevel();
        }
        return 100; // 기본 최대 레벨 (위상 0)
    }

    protected function callUpdateLevel(): void {
        $i = 0;
        $maxLevel = $this->getMaxLevelByPhase();
        
        while ($this->point >= ($max = $this->getMaxPoint($this->level + $i))) {
            // 위상 최대 레벨 체크
            if ($this->level + $i >= $maxLevel) {
                break;
            }
            $i++;
            $this->pointDown($max, false, false);
        }
        
        if ($i > 0) {
            $this->levelUp($i);
        }
        
        // 최대 레벨 도달 시 경험치 초과분 제거
        if ($this->level >= $maxLevel) {
            $player = $this->getPlayer();
            if ($player !== null && $this->point > 0) {
                $playerPhase = AdvancedLevel::getInstance()->getPlayerPhase($this->name);
                
                if ($playerPhase instanceof PlayerPhase) {
                    $currentPhase = $playerPhase->getPhase();
                    
                    // 최고 위상이 아닌 경우에만 승급 안내
                    if ($currentPhase < PhaseConfig::getMaxPhase()) {
                        $nextPhase = $currentPhase + 1;
                        $nextColor = PhaseConfig::getPhaseColor($nextPhase);
                        $player->sendTip(
                            '§l§e최대 레벨 도달! §r§8위상을 승급하세요 §l§a(/위상)'
                        );
                    } else {
                        // 최고 위상인 경우
                        $player->sendTip(
                            '§l§6최고 위상 달성! §r§8더 이상 레벨을 올릴 수 없습니다.'
                        );
                    }
                }
            }
            // 경험치를 최대치로 유지 (넘치지 않도록)
            $this->point = min($this->point, $this->getMaxPoint($this->level) - 1);
        }
    }

    public function updateXpManager(): void {
        $this->getPlayer()?->getXpManager()->setXpAndProgressNoEvent($this->level, $this->getLevelUpProgress());
    }

    public function setLevel(int $amount): void {
        $maxLevel = $this->getMaxLevelByPhase();
        $this->level = min($amount, $maxLevel);
        $this->updateXpManager();
    }

    public function levelUp(int $amount = 1, bool $sendTitle = true): bool {
        $maxLevel = $this->getMaxLevelByPhase();
        
        // 최대 레벨 도달 확인
        if ($this->level >= $maxLevel) {
            if ($sendTitle) {
                $playerPhase = AdvancedLevel::getInstance()->getPlayerPhase($this->name);
                if ($playerPhase instanceof PlayerPhase) {
                    $currentPhase = $playerPhase->getPhase();
                    
                    if ($currentPhase < PhaseConfig::getMaxPhase()) {
                        $this->getPlayer()?->sendTip('§l§c최대 레벨 도달! §r§8위상을 승급하세요 §a(/위상)');
                    } else {
                        $this->getPlayer()?->sendTip('§l§6최고 위상 달성! §r§8더 이상 레벨업 불가');
                    }
                }
            }
            return false;
        }
        
        // 실제 올릴 수 있는 레벨 계산
        $actualAmount = min($amount, $maxLevel - $this->level);
        
        $event = new LevelUpEvent($this, $actualAmount);
        $event->call();
        $isSuccess = !$event->isCancelled();
        
        if ($isSuccess) {
            $before = $this->level;
            $this->level += $actualAmount;
            $this->updateXpManager();
            
            if ($sendTitle) {
                $this->getPlayer()?->sendTitle('§l§b§oLEVEL UP', '§f' . $before . ' §e-> §f' . $this->level);
                
                // 최대 레벨 도달 시 추가 메시지
                if ($this->level >= $maxLevel) {
                    $playerPhase = AdvancedLevel::getInstance()->getPlayerPhase($this->name);
                    if ($playerPhase instanceof PlayerPhase) {
                        $currentPhase = $playerPhase->getPhase();
                        $phaseColor = PhaseConfig::getPhaseColor($currentPhase);
                        $phaseName = PhaseConfig::getPhaseName($currentPhase);
                        
                        $this->getPlayer()?->sendMessage(AdvancedLevel::$prefix . '§l§e최대 레벨에 도달했습니다!');
                        $this->getPlayer()?->sendMessage(AdvancedLevel::$prefix . '§8현재 위상: ' . $phaseColor . '§l위상 ' . $currentPhase . ' §r§8(' . $phaseName . ')');
                        $this->getPlayer()?->sendMessage(AdvancedLevel::$prefix . '§8최대 레벨: §f' . $maxLevel . 'Lv');
                        
                        if ($currentPhase < PhaseConfig::getMaxPhase()) {
                            $nextPhase = $currentPhase + 1;
                            $nextColor = PhaseConfig::getPhaseColor($nextPhase);
                            $nextName = PhaseConfig::getPhaseName($nextPhase);
                            $nextMaxLevel = PhaseConfig::getMaxLevel($nextPhase);
                            
                            $this->getPlayer()?->sendMessage(AdvancedLevel::$prefix . '§8위상을 승급하여 더 높은 레벨로 성장하세요. §a/위상');
                            $this->getPlayer()?->sendMessage(AdvancedLevel::$prefix . '§8다음 위상: ' . $nextColor . '§l위상 ' . $nextPhase . ' §r§8(' . $nextName . ') - 최대 §f' . $nextMaxLevel . 'Lv');
                        } else {
                            $this->getPlayer()?->sendMessage(AdvancedLevel::$prefix . '§6축하합니다! 최고 위상의 최대 레벨에 도달하셨습니다!');
                        }
                    }
                }
            }
        }
        return $isSuccess;
    }

    public function levelDown(int $amount = 1, bool $sendTitle = true): bool {
        $event = new LevelDownEvent($this, $amount);
        $event->call();
        $isSuccess = !$event->isCancelled();
        if ($isSuccess) {
            $before = $this->level;
            $this->level = max(1, $this->level - $amount); // 최소 레벨 1
            $this->updateXpManager();
            if ($sendTitle) $this->getPlayer()?->sendTitle('§l§c§oLEVEL DOWN', '§e*§f ' . $before . ' ' . $this->level);
        }
        return $isSuccess;
    }

    public function getLevelUpProgress(bool $percentage = false): float|int {
        $progress = min(1, max(0, $this->point / $this->getMaxPoint()));
        if ($percentage) $progress = (int)($progress * 100);
        return $progress;
    }

    public function getMaxPoint(?int $level = null): int {
        $level = $level ?? $this->level;
        // 경험치 요구량 공식
        return 850 * $level + 100 * ($level - 1);
    }

    public function getPoint(): int {
        return $this->point;
    }

    public function setPoint(int $amount, bool $updateLv = true): void {
        $this->point = $amount;
        if ($updateLv) $this->callUpdateLevel();
    }

    public function pointUp(int $amount, bool $sendTip = true, bool $updateLv = true, bool $useBooster = true): bool {
        // ※ 1.5배 기본 배율 제거! 몹이 주는 경험치 그대로 사용
        
        // 위상 보너스 적용
        $playerPhase = AdvancedLevel::getInstance()->getPlayerPhase($this->name);
        if ($playerPhase instanceof PlayerPhase) {
            $phaseBonus = $playerPhase->getExpBonus();
            if ($phaseBonus > 0) {
                $amount += (int)($amount * ($phaseBonus / 100));
            }
        }
        
        if ($useBooster) {
            $amount += (int)($amount * ($this->getBoosterX() / 100));
        }
        
        $event = new PointUpEvent($this, $amount);
        $event->call();
        $isSuccess = !$event->isCancelled();
        
        if ($isSuccess) {
            $beforeProgress = $this->getLevelUpProgress(true);
            $this->point += $event->getFinalAmount();
            
            // 최대 레벨 체크
            $maxLevel = $this->getMaxLevelByPhase();
            $isAtMaxLevel = $this->level >= $maxLevel;
            
            if ($sendTip) {
                if ($isAtMaxLevel) {
                    // 최대 레벨인 경우 위상 승급 안내
                    if ($playerPhase instanceof PlayerPhase && $playerPhase->getPhase() < PhaseConfig::getMaxPhase()) {
                        $tipMessage = '§l§c최대 레벨! §r§8위상 승급 필요 §a(/위상)';
                    } else {
                        $tipMessage = '§l§6최고 위상 달성! §r§8더 이상 레벨업 불가';
                    }
                } else {
                    $tipMessage = '§l§b+ §r' . $beforeProgress . '%% ' . $this->getLevelUpProgress(true) . '%% §l§b+';
                    
                    // 위상 보너스 표시
                    if ($playerPhase instanceof PlayerPhase && $playerPhase->getExpBonus() > 0) {
                        $tipMessage .= ' §r§8(위상 +' . $playerPhase->getExpBonus() .'%)';
                    }
                }
                
                $this->getPlayer()?->sendTip($tipMessage);
            }
            
            if ($updateLv) $this->callUpdateLevel();
            $this->updateXpManager();
        }
        return $isSuccess;
    }

    public function pointDown(int $amount, bool $sendTip = true, bool $updateLv = true): bool {
        $event = new PointDownEvent($this, $amount);
        $event->call();
        $isSuccess = !$event->isCancelled();
        if ($isSuccess) {
            $beforeProgress = $this->getLevelUpProgress(true);
            $this->point = max(0, $this->point - $event->getFinalAmount()); // 최소 경험치 0
            if ($sendTip) $this->getPlayer()?->sendTip('§l§c- §r' . $beforeProgress . '%% ' . $this->getLevelUpProgress(true) . '%% §l§c-');
            if ($updateLv) $this->callUpdateLevel();
            $this->updateXpManager();
        }
        return $isSuccess;
    }

    public function getBoosterX(): float {
        $x = 0;
        /** @var PointBooster $booster */
        foreach ($this->boosters as $key => $booster) {
            if (!$booster instanceof PointBooster or $booster->isClosed()) {
                unset($this->boosters [$key]);
            } else {
                $x += $booster->getX();
            }
        }
        return $x;
    }

    /** @return PointBooster[] */
    public function getBoosters(): array {
        return $this->boosters;
    }

    public function addBooster(PointBooster $booster): void {
        $this->boosters [] = $booster;
    }

    public function jsonSerialize(): array {
        return [
            $this->name,
            $this->level,
            $this->point,
            $this->boosters
        ];
    }

    public static function jsonDeserialize(array $data): self {
        return new self ($data [0], $data [1], $data [2], $data [3]);
    }
}