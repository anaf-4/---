<?php
declare(strict_types=1);

namespace anaf2197\advancedlevel\form;

use pocketmine\form\Form;
use pocketmine\player\Player;
use anaf2197\advancedlevel\AdvancedLevel;
use anaf2197\advancedlevel\event\PhaseUpEvent;
use anaf2197\advancedlevel\PhaseConfig;
use anaf2197\advancedlevel\PlayerLevel;
use anaf2197\advancedlevel\PlayerPhase;
use anaf2197\economyapi\EconomyAPI;
use anaf2197\servercore\item\ServerItems;

final class PhaseForm implements Form {

    public function __construct(private string $targetName) {}

    public function jsonSerialize(): array {
        $plugin = AdvancedLevel::getInstance();
        $playerPhase = $plugin->getPlayerPhase($this->targetName);
        $playerLevel  = $plugin->getPlayerLevel($this->targetName);

        if (!$playerPhase instanceof PlayerPhase || !$playerLevel instanceof PlayerLevel) {
            return [
                'type'    => 'form',
                'title'   => '§l위상 정보',
                'content' => '§c데이터를 불러올 수 없습니다.',
                'buttons' => [['text' => '§8닫기']],
            ];
        }

        $phase    = $playerPhase->getPhase();
        $level    = $playerLevel->getLevel();
        $maxLevel = $playerPhase->getMaxLevel();
        $color    = PhaseConfig::getPhaseColor($phase);
        $name     = PhaseConfig::getPhaseName($phase);
        $maxPhase = PhaseConfig::getMaxPhase();

        $moneyBonus = match(true) {
            $phase >= 5 => $phase * 5,
            $phase >= 1 => $phase * 5,
            default     => 0
        };
        $moneyBonus = match($phase) {
            1 => 5, 2 => 10, 3 => 15, 4 => 20, 5 => 25,
            6 => 30, 7 => 35, 8 => 40, 9 => 45, 10 => 50,
            default => 0
        };

        $content  = "{$color}§l위상 {$phase} §r{$color}({$name})§r\n";
        $content .= "§8레벨: §f{$level} §8/ §f{$maxLevel} Lv\n";
        $content .= "\n§8▶ 보너스\n";
        $content .= "§8경험치: §a+{$playerPhase->getExpBonus()}%\n";
        $content .= "§8데미지: §c+{$playerPhase->getDamageBonus()}%\n";
        $content .= "§8돈 획득: §e+{$moneyBonus}%\n";

        $buttons = [];

        if ($phase >= $maxPhase) {
            $content .= "\n§6★ 최고 위상에 도달하셨습니다!";
            $buttons[] = ['text' => '§8닫기'];
        } else {
            $nextPhase     = $phase + 1;
            $nextColor     = PhaseConfig::getPhaseColor($nextPhase);
            $nextName      = PhaseConfig::getPhaseName($nextPhase);
            $reqLevel      = $playerPhase->getRequiredLevelForNextPhase();
            $cost          = PhaseConfig::getUpgradeCost($nextPhase);
            $requiredItems = PhaseConfig::getUpgradeItems($nextPhase);

            $content .= "\n§8▶ 다음 위상: {$nextColor}§l위상 {$nextPhase} §r{$nextColor}({$nextName})§r\n";
            $content .= "§8필요 레벨: §f{$reqLevel} Lv\n";
            $content .= "§8승급 비용: §e" . EconomyAPI::koreanWonFormat($cost) . "\n";

            if (!empty($requiredItems)) {
                $content .= "§8필요 아이템:\n";
                foreach ($requiredItems as $cfg) {
                    $content .= "§8  • §f" . PhaseConfig::formatItemRequirementFromConfig($cfg) . "\n";
                }
            }

            // 승급 조건 상태 계산
            $canLevel  = $playerPhase->canPhaseUp($level);
            $economy   = EconomyAPI::getInstance();
            $canAfford = $economy->canAffordPhaseUpgrade($playerPhase->getPlayer() ?? $plugin->getServer()->getPlayerExact($this->targetName), $nextPhase);
            $hasItems  = self::checkItems($requiredItems, $plugin->getServer()->getPlayerExact($this->targetName));

            $content .= "\n§8━━━━━━━━━━━━━━━━━━━━\n";
            $content .= ($canLevel  ? "§a✔" : "§c✘") . " §8레벨: §f{$level} / {$reqLevel} Lv\n";
            $content .= ($canAfford ? "§a✔" : "§c✘") . " §8비용: §e" . EconomyAPI::koreanWonFormat($cost) . "\n";
            if (!empty($requiredItems)) {
                $content .= ($hasItems ? "§a✔" : "§c✘") . " §8아이템 보유 여부\n";
            }

            if ($canLevel && $canAfford && $hasItems) {
                $buttons[] = ['text' => "§a§l▶ 위상 승급하기\n§r§8위상 {$nextPhase} {$nextName}"];
            } else {
                $buttons[] = ['text' => "§c§l▶ 위상 승급하기\n§r§8(조건 미충족)"];
            }
            $buttons[] = ['text' => '§8닫기'];
        }

        return [
            'type'    => 'form',
            'title'   => '§l⚔ 위상 시스템',
            'content' => $content,
            'buttons' => $buttons,
        ];
    }

    public function handleResponse(Player $player, $data): void {
        if ($data === null) return;

        $plugin       = AdvancedLevel::getInstance();
        $playerPhase  = $plugin->getPlayerPhase($this->targetName);
        $playerLevel  = $plugin->getPlayerLevel($this->targetName);

        if (!$playerPhase instanceof PlayerPhase || !$playerLevel instanceof PlayerLevel) return;

        $phase    = $playerPhase->getPhase();
        $maxPhase = PhaseConfig::getMaxPhase();

        // 최고 위상이면 버튼 0 = 닫기
        if ($phase >= $maxPhase) return;

        // 버튼 0 = 승급하기, 버튼 1 = 닫기
        if ($data !== 0) return;

        $nextPhase     = $phase + 1;
        $level         = $playerLevel->getLevel();
        $cost          = PhaseConfig::getUpgradeCost($nextPhase);
        $requiredItems = PhaseConfig::getUpgradeItems($nextPhase);
        $canLevel      = $playerPhase->canPhaseUp($level);
        $canAfford     = EconomyAPI::getInstance()->canAffordPhaseUpgrade($player, $nextPhase);
        $hasItems      = self::checkItems($requiredItems, $player);

        // 조건 불충족 시 메시지 + 폼 다시 열기
        if (!$canLevel || !$canAfford || !$hasItems) {
            if (!$canLevel) {
                $reqLevel = $playerPhase->getRequiredLevelForNextPhase();
                $player->sendMessage(AdvancedLevel::$prefix . "§c레벨이 부족합니다. (현재: {$level}Lv / 필요: {$reqLevel}Lv)");
            }
            if (!$canAfford) {
                $currentMoney = EconomyAPI::getInstance()->getMoney($player);
                $player->sendMessage(AdvancedLevel::$prefix . "§c돈이 부족합니다. (보유: " . EconomyAPI::koreanWonFormat($currentMoney) . " / 필요: " . EconomyAPI::koreanWonFormat($cost) . ")");
            }
            if (!$hasItems) {
                $player->sendMessage(AdvancedLevel::$prefix . "§c필요 아이템이 부족합니다.");
            }
            $plugin->getScheduler()->scheduleDelayedTask(
                new \pocketmine\scheduler\ClosureTask(fn() => $player->isOnline() && $player->sendForm(new self($this->targetName))),
                2
            );
            return;
        }

        // 확인 모달 표시
        $color    = PhaseConfig::getPhaseColor($nextPhase);
        $nextName = PhaseConfig::getPhaseName($nextPhase);
        $player->sendForm(new PhaseConfirmForm($this->targetName, $nextPhase));
    }

    /** 필요 아이템 보유 여부 확인 */
    public static function checkItems(array $requiredItems, ?Player $player): bool {
        if ($player === null || empty($requiredItems)) return true;

        foreach ($requiredItems as $cfg) {
            $count = $cfg['count'];
            $type  = $cfg['type'] ?? 'serveritem';

            try {
                if ($type === 'custom') {
                    $typeId = $cfg['id'] ?? 0;
                    $name   = $cfg['name'] ?? '';
                    $held   = 0;
                    foreach ($player->getInventory()->getContents() as $inv) {
                        if ($inv->getTypeId() === $typeId) {
                            $invName = $inv->hasCustomName() ? $inv->getCustomName() : $inv->getName();
                            if ($invName === $name) $held += $inv->getCount();
                        }
                    }
                    if ($held < $count) return false;
                } elseif ($type === 'direct') {
                    $item = unserialize(base64_decode($cfg['item']));
                    if ($item instanceof \pocketmine\item\Item) {
                        $item->setCount($count);
                        if (!$player->getInventory()->contains($item)) return false;
                    }
                } else {
                    $item = ServerItems::{$cfg['item']}();
                    $item->setCount($count);
                    if (!$player->getInventory()->contains($item)) return false;
                }
            } catch (\Throwable) {
                return false;
            }
        }
        return true;
    }
}
