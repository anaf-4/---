<?php
declare(strict_types=1);

namespace anaf2197\advancedlevel\form;

use pocketmine\form\Form;
use pocketmine\player\Player;
use anaf2197\advancedlevel\AdvancedLevel;
use anaf2197\advancedlevel\event\PhaseUpEvent;
use anaf2197\advancedlevel\PhaseConfig;
use anaf2197\advancedlevel\PlayerLevel;
use anaf2197\advancedlevel\PlayerPhase;
use anaf2197\economyapi\EconomyAPI;
use anaf2197\servercore\item\ServerItems;

final class PhaseConfirmForm implements Form {

    public function __construct(
        private string $targetName,
        private int $nextPhase
    ) {}

    public function jsonSerialize(): array {
        $cost          = PhaseConfig::getUpgradeCost($this->nextPhase);
        $color         = PhaseConfig::getPhaseColor($this->nextPhase);
        $nextName      = PhaseConfig::getPhaseName($this->nextPhase);
        $requiredItems = PhaseConfig::getUpgradeItems($this->nextPhase);

        $content  = "§r{$color}§l위상 {$this->nextPhase} §r{$color}({$nextName})§r §r§8으로 승급합니다.\n\n";
        $content .= "§8차감 비용: §c" . EconomyAPI::koreanWonFormat($cost) . "\n";

        if (!empty($requiredItems)) {
            $content .= "§8차감 아이템:\n";
            foreach ($requiredItems as $cfg) {
                $content .= "§8  • §f" . PhaseConfig::formatItemRequirementFromConfig($cfg) . "\n";
            }
        }

        $content .= "\n§e정말로 승급하시겠습니까?";

        return [
            'type'    => 'modal',
            'title'   => '§l⚔ 위상 승급 확인',
            'content' => $content,
            'button1' => '§a승급하기',
            'button2' => '§c취소',
        ];
    }

    public function handleResponse(Player $player, $data): void {
        // false = button2 (취소), null = 닫기
        if ($data !== true) {
            $player->sendForm(new PhaseForm($this->targetName));
            return;
        }

        $plugin      = AdvancedLevel::getInstance();
        $playerPhase = $plugin->getPlayerPhase($this->targetName);
        $playerLevel = $plugin->getPlayerLevel($this->targetName);

        if (!$playerPhase instanceof PlayerPhase || !$playerLevel instanceof PlayerLevel) {
            $player->sendMessage(AdvancedLevel::$prefix . '§c데이터를 불러올 수 없습니다.');
            return;
        }

        $currentPhase  = $playerPhase->getPhase();
        $currentLevel  = $playerLevel->getLevel();
        $nextPhase     = $this->nextPhase;
        $cost          = PhaseConfig::getUpgradeCost($nextPhase);
        $requiredItems = PhaseConfig::getUpgradeItems($nextPhase);
        $economy       = EconomyAPI::getInstance();

        // 재확인 (폼이 열린 사이 상태 변경 대비)
        if ($currentPhase >= PhaseConfig::getMaxPhase()) {
            $player->sendMessage(AdvancedLevel::$prefix . '이미 최고 위상에 도달하셨습니다.');
            return;
        }
        if ($currentPhase !== $nextPhase - 1) {
            $player->sendMessage(AdvancedLevel::$prefix . '§c위상 상태가 변경되었습니다. 다시 시도해주세요.');
            $player->sendForm(new PhaseForm($this->targetName));
            return;
        }
        if (!$playerPhase->canPhaseUp($currentLevel)) {
            $reqLevel = $playerPhase->getRequiredLevelForNextPhase();
            $player->sendMessage(AdvancedLevel::$prefix . "§c레벨이 부족합니다. (필요: {$reqLevel}Lv)");
            $player->sendForm(new PhaseForm($this->targetName));
            return;
        }
        if (!$economy->canAffordPhaseUpgrade($player, $nextPhase)) {
            $player->sendMessage(AdvancedLevel::$prefix . '§c돈이 부족합니다.');
            $player->sendForm(new PhaseForm($this->targetName));
            return;
        }
        if (!PhaseForm::checkItems($requiredItems, $player)) {
            $player->sendMessage(AdvancedLevel::$prefix . '§c필요 아이템이 부족합니다.');
            $player->sendForm(new PhaseForm($this->targetName));
            return;
        }

        // 이벤트 호출
        $phaseUpEvent = new PhaseUpEvent($playerPhase, $currentPhase, $nextPhase);
        $phaseUpEvent->call();
        if ($phaseUpEvent->isCancelled()) {
            $player->sendMessage(AdvancedLevel::$prefix . '위상 승급이 취소되었습니다.');
            return;
        }

        // 비용 차감
        if (!$economy->chargePhaseUpgradeCost($player, $nextPhase)) {
            $player->sendMessage(AdvancedLevel::$prefix . '§c결제 처리 중 오류가 발생했습니다.');
            return;
        }

        // 아이템 차감
        self::consumeItems($requiredItems, $player);

        // 승급 처리
        $playerPhase->phaseUp();

        $color    = PhaseConfig::getPhaseColor($nextPhase);
        $nextName = PhaseConfig::getPhaseName($nextPhase);

        $player->sendTitle('§l§6PHASE UP!', "{$color}§l위상 {$nextPhase} §r{$color}{$nextName}");

        // 서버 전체 공지 (위상 3 이상)
        if ($nextPhase >= 3) {
            foreach ($plugin->getServer()->getOnlinePlayers() as $p) {
                $p->sendMessage("§l§6[공지] §r§f{$player->getName()} §8님이 {$color}§l위상 {$nextPhase} §r§8에 도달하셨습니다!");
            }
        } else {
            $player->sendMessage(AdvancedLevel::$prefix . "{$color}§l위상 {$nextPhase} §r§8({$nextName})§r§8 승급 완료!");
        }

        // 업데이트된 정보 폼 다시 표시
        $plugin->getScheduler()->scheduleDelayedTask(
            new \pocketmine\scheduler\ClosureTask(fn() => $player->isOnline() && $player->sendForm(new PhaseForm($this->targetName))),
            20
        );
    }

    private static function consumeItems(array $requiredItems, Player $player): void {
        foreach ($requiredItems as $cfg) {
            $count = $cfg['count'];
            $type  = $cfg['type'] ?? 'serveritem';
            try {
                if ($type === 'custom') {
                    $typeId    = $cfg['id'] ?? 0;
                    $itemName  = $cfg['name'] ?? '';
                    $remaining = $count;
                    foreach ($player->getInventory()->getContents() as $slot => $inv) {
                        if ($remaining <= 0) break;
                        if ($inv->getTypeId() === $typeId) {
                            $n = $inv->hasCustomName() ? $inv->getCustomName() : $inv->getName();
                            if ($n === $itemName) {
                                $take = min($remaining, $inv->getCount());
                                $inv->setCount($inv->getCount() - $take);
                                $inv->getCount() <= 0
                                    ? $player->getInventory()->clear($slot)
                                    : $player->getInventory()->setItem($slot, $inv);
                                $remaining -= $take;
                            }
                        }
                    }
                } elseif ($type === 'direct') {
                    $item = unserialize(base64_decode($cfg['item']));
                    if ($item instanceof \pocketmine\item\Item) {
                        $item->setCount($count);
                        $player->getInventory()->removeItem($item);
                    }
                } else {
                    $item = ServerItems::{$cfg['item']}();
                    $item->setCount($count);
                    $player->getInventory()->removeItem($item);
                }
            } catch (\Throwable) {}
        }
    }
}
