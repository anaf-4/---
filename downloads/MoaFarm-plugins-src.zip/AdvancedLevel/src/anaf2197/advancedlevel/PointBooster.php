<?php

namespace anaf2197\advancedlevel;

final class PointBooster implements \JsonSerializable {

    public function __construct(private int $x, private int $closedTime) { }

    public function getX(): int {
        return $this->x;
    }

    public function isClosed(): bool {
        return $this->closedTime <= time();
    }

    public function getTime(): int {
        return $this->closedTime - time();
    }

    public function jsonSerialize(): array {
        return [
            $this->x,
            $this->closedTime
        ];
    }

    public static function jsonDeserialize(array $data): self {
        return new self (... $data);
    }
}