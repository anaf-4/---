<?php

namespace anaf2197\advancedlevel;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\item\Item;
use pocketmine\player\Player;

final class EventListener implements Listener {

    /** @var array<string, float> Bedrock 더블파이어 방지 쿨다운 */
    private array $ticketCooldown = [];

    public function onPlayerJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();

        $playerLevel = AdvancedLevel::getInstance()->getPlayerLevel($player);
        if ($playerLevel instanceof PlayerLevel) {
            $playerLevel->updateXpManager();
        } else {
            AdvancedLevel::getInstance()->setPlayerLevel($player, new PlayerLevel(strtolower($player->getName()), 1, 0, []));
        }

        $playerPhase = AdvancedLevel::getInstance()->getPlayerPhase($player);
        if (!$playerPhase instanceof PlayerPhase) {
            AdvancedLevel::getInstance()->setPlayerPhase($player, new PlayerPhase(strtolower($player->getName()), 0));
        }
    }

    /**
     * Bedrock에서 커스텀 아이템은 PlayerItemUseEvent 대신 PlayerInteractEvent를 통해 사용됨.
     * WorldGuard가 cancel해도 @handleCancelled true 로 처리.
     *
     * @priority HIGHEST
     * @handleCancelled true
     */
    public function onPlayerInteract(PlayerInteractEvent $event): void {
        $action = $event->getAction();
        if ($action === PlayerInteractEvent::LEFT_CLICK_BLOCK) {
            return;
        }
        $item = $event->getItem();
        $player = $event->getPlayer();
        if (!$player->isSneaking()) return;
        if (!is_string(LevelFunctionTag::readFunctionId($item))) return;

        if (!$this->checkCooldown($player)) {
            $event->cancel();
            return;
        }
        $event->cancel();
        $this->processTicket($player, $item);
    }

    /**
     * PlayerItemUseEvent 는 일부 환경에서 발동될 수 있으므로 fallback으로 유지.
     * 쿨다운으로 중복 처리 방지.
     */
    public function onPlayerItemUse(PlayerItemUseEvent $event): void {
        $item = $event->getItem();
        $player = $event->getPlayer();
        if (!$player->isSneaking()) return;
        if (!is_string(LevelFunctionTag::readFunctionId($item))) return;

        if (!$this->checkCooldown($player)) return;
        $this->processTicket($player, $item);
    }

    private function checkCooldown(Player $player): bool {
        $name = strtolower($player->getName());
        $now = microtime(true);
        if (isset($this->ticketCooldown[$name]) && $now - $this->ticketCooldown[$name] < 0.5) {
            return false;
        }
        $this->ticketCooldown[$name] = $now;
        return true;
    }

    private function processTicket(Player $player, Item $item): void {
        $functionId = LevelFunctionTag::readFunctionId($item);
        if (!is_string($functionId)) return;

        $playerLevel = AdvancedLevel::getInstance()->getPlayerLevel($player);
        $playerPhase = AdvancedLevel::getInstance()->getPlayerPhase($player);

        if (!$playerLevel instanceof PlayerLevel || !$playerPhase instanceof PlayerPhase) {
            return;
        }

        $success = true;

        if ($functionId !== LevelFunctionTag::TYPE_BOOSTER) {
            $count = $item->getCount();

            if ($functionId === LevelFunctionTag::TYPE_LEVEL) {
                $currentLevel = $playerLevel->getLevel();
                $currentPhase = $playerPhase->getPhase();
                $maxLevel = $playerPhase->getMaxLevel();
                $addLevel = LevelFunctionTag::readValue($item, $functionId) * $count;

                if ($currentLevel >= $maxLevel) {
                    $player->sendMessage(AdvancedLevel::$prefix . '§c이미 최대 레벨에 도달했습니다!');
                    $player->sendMessage(AdvancedLevel::$prefix . '§8현재 위상: §f위상 ' . $currentPhase . ' §8(최대 레벨: §f' . $maxLevel . 'Lv§8)');
                    if ($currentPhase < PhaseConfig::getMaxPhase()) {
                        $player->sendMessage(AdvancedLevel::$prefix . '§8더 높은 레벨을 원하시면 위상을 승급하세요. §a/위상');
                    } else {
                        $player->sendMessage(AdvancedLevel::$prefix . '§6최고 위상에 도달하여 더 이상 레벨을 올릴 수 없습니다.');
                    }
                    $success = false;
                } elseif ($currentLevel + $addLevel > $maxLevel) {
                    $canAdd = $maxLevel - $currentLevel;
                    $excessLevel = $addLevel - $canAdd;
                    $player->sendMessage(AdvancedLevel::$prefix . '§c현재 위상에서 최대 레벨은 §f' . $maxLevel . 'Lv§c입니다.');
                    $player->sendMessage(AdvancedLevel::$prefix . '§8추가 가능: §a' . $canAdd . 'Lv §8/ 초과: §c' . $excessLevel . 'Lv');
                    $player->sendMessage(AdvancedLevel::$prefix . '§8현재 위상: §f위상 ' . $currentPhase);
                    if ($currentPhase < PhaseConfig::getMaxPhase()) {
                        $player->sendMessage(AdvancedLevel::$prefix . '§8더 높은 레벨을 원하시면 위상을 승급하세요. §a/위상');
                    }
                    $success = false;
                }
            }

            if ($success) {
                $playerLevel->$functionId(LevelFunctionTag::readValue($item, $functionId) * $count, true, true, false);
                $player->sendMessage(AdvancedLevel::$prefix . '수상한 종이를 사용하였습니다.');
                $player->getInventory()->removeItem($item->setCount($count));
            }
        } else {
            [$x, $minute] = explode(':', LevelFunctionTag::readValue($item, $functionId));
            if ((int)$x + $playerLevel->getBoosterX() <= 200) {
                $playerLevel->addBooster(new PointBooster($x, time() + (int)$minute));
                $player->sendMessage(AdvancedLevel::$prefix . '경험치 부스터를 사용하였습니다.');
                $player->getInventory()->removeItem($item->setCount(1));
            } else {
                $player->sendMessage(AdvancedLevel::$prefix . '부스터로 인한 증가율은 200%를 초과할 수 없습니다.');
            }
        }
    }
}
