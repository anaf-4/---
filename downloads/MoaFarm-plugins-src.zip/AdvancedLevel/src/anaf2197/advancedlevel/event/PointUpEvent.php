<?php

namespace anaf2197\advancedlevel\event;

use pocketmine\event\Cancellable;
use pocketmine\event\CancellableTrait;
use pocketmine\event\Event;
use pocketmine\player\Player;
use anaf2197\advancedlevel\PlayerLevel;

final class PointUpEvent extends Event implements Cancellable {

    use CancellableTrait;

    public function __construct(private PlayerLevel $playerLevel, private int $amount, private array $modifiers = []) { }

    public function getPlayerLevel(): PlayerLevel {
        return $this->playerLevel;
    }

    public function getPlayer(): ?Player {
        return $this->playerLevel->getPlayer();
    }


    public function getAmount(): int {
        return $this->amount;
    }

    public function getModifiers(): array {
        return $this->modifiers;
    }

    public function setModifier(int $value): void {
        $this->modifiers[] = $value;
    }

    public function getFinalAmount(): int {
        return $this->amount + array_sum($this->modifiers);
    }
}
