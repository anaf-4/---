<?php

namespace anaf2197\advancedlevel\event;

use pocketmine\event\Cancellable;
use pocketmine\event\CancellableTrait;
use pocketmine\event\Event;
use anaf2197\advancedlevel\PlayerPhase;

final class PhaseUpEvent extends Event implements Cancellable {

    use CancellableTrait;

    public function __construct(
        private PlayerPhase $playerPhase,
        private int $beforePhase,
        private int $afterPhase
    ) {}

    public function getPlayerPhase(): PlayerPhase {
        return $this->playerPhase;
    }

    public function getBeforePhase(): int {
        return $this->beforePhase;
    }

    public function getAfterPhase(): int {
        return $this->afterPhase;
    }
}