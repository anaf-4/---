<?php

namespace anaf2197\advancedlevel\event;

use pocketmine\event\Cancellable;
use pocketmine\event\CancellableTrait;
use pocketmine\event\Event;
use pocketmine\player\Player;
use anaf2197\advancedlevel\PlayerLevel;

final class LevelDownEvent extends Event implements Cancellable {

    use CancellableTrait;

    public function __construct(private PlayerLevel $playerLevel, private int $amount) { }

    public function getPlayerLevel(): PlayerLevel {
        return $this->playerLevel;
    }

    public function getPlayer(): ?Player {
        return $this->playerLevel->getPlayer();
    }


    public function getAmount(): int {
        return $this->amount;
    }
}