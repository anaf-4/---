<?php

namespace anaf2197\advancedlevel;

use pocketmine\player\Player;
use pocketmine\Server;

final class PlayerPhase implements \JsonSerializable {

    public function __construct(
        private string $name,
        private int $phase
    ) {}

    public function getName(): string {
        return $this->name;
    }

    public function getPlayer(): ?Player {
        return Server::getInstance()->getPlayerExact($this->name);
    }

    public function getPhase(): int {
        return $this->phase;
    }

    public function setPhase(int $phase): void {
        $this->phase = $phase;
    }

    public function phaseUp(): void {
        $this->phase++;
    }

    /**
     * 현재 위상에서의 최대 레벨 반환
     */
    public function getMaxLevel(): int {
        return PhaseConfig::getMaxLevel($this->phase);
    }

    /**
     * 다음 위상 승급에 필요한 레벨
     */
    public function getRequiredLevelForNextPhase(): int {
        return PhaseConfig::getMaxLevel($this->phase);
    }

    /**
     * 승급 가능 여부 확인
     */
    public function canPhaseUp(int $currentLevel): bool {
        // 최대 위상 도달 확인
        if ($this->phase >= PhaseConfig::getMaxPhase()) {
            return false;
        }
        
        // 레벨 조건 확인
        return $currentLevel >= $this->getRequiredLevelForNextPhase();
    }

    /**
     * 위상별 경험치 획득 보너스 (%)
     */
    public function getExpBonus(): float {
        return PhaseConfig::getExpBonus($this->phase);
    }

    /**
     * 위상별 데미지 보너스 (%)
     */
    public function getDamageBonus(): float {
        return PhaseConfig::getDamageBonus($this->phase);
    }

    public function jsonSerialize(): array {
        return [
            $this->name,
            $this->phase
        ];
    }

    public static function jsonDeserialize(array $data): self {
        return new self($data[0], $data[1]);
    }
}