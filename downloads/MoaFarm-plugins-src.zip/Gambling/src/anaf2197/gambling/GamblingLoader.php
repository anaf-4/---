<?php
declare(strict_types=1);

namespace anaf2197\gambling;

use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;

final class GamblingLoader extends PluginBase {

    use SingletonTrait;

    public static string $prefix = '§l§6[도박사] §r';

    /** @var array<string, float> 연속 사용 방지 쿨다운 (플레이어명 => 타임스탬프) */
    private array $cooldown = [];

    protected function onLoad(): void {
        self::setInstance($this);
    }

    protected function onEnable(): void {
        $this->getLogger()->info('도박 시스템이 활성화되었습니다.');
    }

    public function onCommand(
        \pocketmine\command\CommandSender $sender,
        \pocketmine\command\Command $command,
        string $label,
        array $args
    ): bool {
        if (!$sender instanceof \pocketmine\player\Player) {
            $sender->sendMessage('§c플레이어만 사용 가능합니다.');
            return true;
        }
        $sender->sendForm(new \anaf2197\gambling\form\GamblingMenuForm());
        return true;
    }

    /** 쿨다운 체크 (초 단위). 쿨다운 중이면 true 반환. */
    public function checkCooldown(string $playerName, float $seconds = 2.0): bool {
        $key = strtolower($playerName);
        $now = microtime(true);
        if (isset($this->cooldown[$key]) && $now - $this->cooldown[$key] < $seconds) {
            return true;
        }
        $this->cooldown[$key] = $now;
        return false;
    }
}
