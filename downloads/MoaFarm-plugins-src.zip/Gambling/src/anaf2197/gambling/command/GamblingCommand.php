<?php
declare(strict_types=1);

namespace anaf2197\gambling\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\gambling\form\GamblingMenuForm;

final class GamblingCommand extends Command {

    public function __construct() {
        parent::__construct('도박', '도박 NPC 메뉴를 엽니다.', '/도박');
        $this->setPermission(DefaultPermissions::ROOT_USER);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if (!$sender instanceof Player || !$this->testPermission($sender)) return;
        $sender->sendForm(new GamblingMenuForm());
    }
}
