<?php
declare(strict_types=1);

namespace anaf2197\gambling\form;

use pocketmine\form\Form;
use pocketmine\player\Player;
use anaf2197\economyapi\EconomyAPI;
use anaf2197\gambling\GamblingLoader;

final class CoinFlipForm implements Form {

    private const MIN_BET =     100;
    private const MAX_BET = 1_000_000;

    public function jsonSerialize(): array {
        return [
            'type'    => 'custom_form',
            'title'   => '§l§e동전 뒤집기',
            'content' => [
                [
                    'type' => 'label',
                    'text' => "§f내밀어봐. 앞면이야 뒷면이야?\n§f맞추면 두 배로 주지.\n\n§8최소 §e" . number_format(self::MIN_BET) . "원 §8/ 최대 §e" . number_format(self::MAX_BET) . "원",
                ],
                [
                    'type'        => 'input',
                    'text'        => '§f베팅 금액 (원)',
                    'placeholder' => '예: 1000',
                    'default'     => '1000',
                ],
                [
                    'type'    => 'dropdown',
                    'text'    => '§f선택',
                    'options' => ['앞면', '뒷면'],
                    'default' => 0,
                ],
            ],
        ];
    }

    public function handleResponse(Player $player, $data): void {
        if ($data === null) return;

        $bet    = (int) ($data[1] ?? 0);
        $choice = (int) ($data[2] ?? 0); // 0=앞면, 1=뒷면
        $prefix = GamblingLoader::$prefix;

        if ($bet < self::MIN_BET) {
            $player->sendMessage($prefix . '§c최소 베팅은 §e' . number_format(self::MIN_BET) . '원§c입니다.');
            $player->sendForm(new self());
            return;
        }
        if ($bet > self::MAX_BET) {
            $player->sendMessage($prefix . '§c최대 베팅은 §e' . number_format(self::MAX_BET) . '원§c입니다.');
            $player->sendForm(new self());
            return;
        }

        $eco     = EconomyAPI::getInstance();
        $balance = (int) $eco->getMoney($player);

        if ($balance < $bet) {
            $player->sendMessage($prefix . '§c잔액이 부족합니다. §8(보유: §e' . number_format($balance) . '원§8)');
            return;
        }

        // 베팅 즉시 차감
        $eco->reduceMoney($player, $bet);

        // 결과 결정
        $result      = random_int(0, 1);
        $win         = ($choice === $result);
        $choiceLabel = $choice === 0 ? '앞면' : '뒷면';
        $resultLabel = $result  === 0 ? '앞면' : '뒷면';

        if ($win) {
            $eco->addMoney($player, $bet * 2); // 베팅액 복구 + 동액 보상
            $netGain    = $bet;
            $newBalance = $balance + $bet;
        } else {
            $netGain    = -$bet;
            $newBalance = $balance - $bet;
        }

        $player->sendForm(new GamblingResultForm(
            win: $win,
            gameTitle: '동전 뒤집기',
            netGain: $netGain,
            bet: $bet,
            newBalance: $newBalance,
            detail: "§8내 선택: §f{$choiceLabel}\n§8결과:  §f§l{$resultLabel}",
            retryForm: fn() => new CoinFlipForm(),
        ));
    }
}
