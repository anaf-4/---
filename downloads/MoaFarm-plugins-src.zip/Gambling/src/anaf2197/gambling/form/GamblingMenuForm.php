<?php
declare(strict_types=1);

namespace anaf2197\gambling\form;

use pocketmine\form\Form;
use pocketmine\player\Player;

final class GamblingMenuForm implements Form {

    public function jsonSerialize(): array {
        return [
            'type'    => 'form',
            'title'   => '§l§6도박사',
            'content' => "§f운을 한번 시험해봐.\n§8어차피 잃어도 내 탓은 아니거든.\n\n§8뭘 해볼 텐가?",
            'buttons' => [
                ['text' => "§l§e동전 뒤집기\n§r§8앞면? 뒷면? 50:50"],
                ['text' => "§l§b하이로우\n§r§8숫자가 높을까, 낮을까?"],
            ],
        ];
    }

    public function handleResponse(Player $player, $data): void {
        if ($data === null) return;
        match ((int) $data) {
            0 => $player->sendForm(new CoinFlipForm()),
            1 => $player->sendForm(new HighLowForm()),
            default => null,
        };
    }
}
