<?php
declare(strict_types=1);

namespace anaf2197\gambling\form;

use pocketmine\form\Form;
use pocketmine\player\Player;
use anaf2197\economyapi\EconomyAPI;
use anaf2197\gambling\GamblingLoader;

final class HighLowForm implements Form {

    private const MIN_BET =     100;
    private const MAX_BET = 1_000_000;

    private int $base;

    public function __construct() {
        // 1 또는 9가 기준이면 한쪽 결과가 100% 확정되므로 2~8만 허용
        $this->base = random_int(2, 8);
    }

    public function jsonSerialize(): array {
        return [
            'type'    => 'custom_form',
            'title'   => '§l§b하이로우',
            'content' => [
                [
                    'type' => 'label',
                    'text' => "§f현재 나의 숫자는 §l§e[ {$this->base} ] §r§f일세.\n§f다음에 나올 숫자는 이보다 높을까, 낮을까?\n§c같은 숫자가 나오면 패배!\n\n§8최소 §e" . number_format(self::MIN_BET) . "원 §8/ 최대 §e" . number_format(self::MAX_BET) . "원",
                ],
                [
                    'type'        => 'input',
                    'text'        => '§f베팅 금액 (원)',
                    'placeholder' => '예: 1000',
                    'default'     => '1000',
                ],
                [
                    'type'    => 'dropdown',
                    'text'    => '§f예측',
                    'options' => ['높다 (High)', '낮다 (Low)'],
                    'default' => 0,
                ],
            ],
        ];
    }

    public function handleResponse(Player $player, $data): void {
        if ($data === null) return;

        $bet    = (int) ($data[1] ?? 0);
        $choice = (int) ($data[2] ?? 0); // 0=High, 1=Low
        $prefix = GamblingLoader::$prefix;

        if ($bet < self::MIN_BET) {
            $player->sendMessage($prefix . '§c최소 베팅은 §e' . number_format(self::MIN_BET) . '원§c입니다.');
            $player->sendForm(new self());
            return;
        }
        if ($bet > self::MAX_BET) {
            $player->sendMessage($prefix . '§c최대 베팅은 §e' . number_format(self::MAX_BET) . '원§c입니다.');
            $player->sendForm(new self());
            return;
        }

        $eco     = EconomyAPI::getInstance();
        $balance = (int) $eco->getMoney($player);

        if ($balance < $bet) {
            $player->sendMessage($prefix . '§c잔액이 부족합니다. §8(보유: §e' . number_format($balance) . '원§8)');
            return;
        }

        // 1~9 전체에서 뽑아 타이 가능 → 같은 숫자 = 패배 (하우스 어드밴티지 ~1/9)
        $next   = random_int(1, 9);
        $isTie  = $next === $this->base;
        $isHigh = $next > $this->base;
        $win    = !$isTie && (($choice === 0 && $isHigh) || ($choice === 1 && !$isHigh));

        $choiceLabel = $choice === 0 ? '높다 (High)' : '낮다 (Low)';
        $resultLabel = $isTie ? '같음 (Tie) — 패배' : ($isHigh ? '높음 (High)' : '낮음 (Low)');

        $eco->reduceMoney($player, $bet);
        if ($win) {
            $eco->addMoney($player, $bet * 2);
            $netGain    = $bet;
            $newBalance = $balance + $bet;
        } else {
            $netGain    = -$bet;
            $newBalance = $balance - $bet;
        }

        $base = $this->base;
        $player->sendForm(new GamblingResultForm(
            win: $win,
            gameTitle: '하이로우',
            netGain: $netGain,
            bet: $bet,
            newBalance: $newBalance,
            detail: "§8기준 숫자: §e§l{$base}\n§8다음 숫자: §e§l{$next} §r§8({$resultLabel})\n§8내 예측: §f{$choiceLabel}",
            retryForm: fn() => new HighLowForm(),
        ));
    }
}
