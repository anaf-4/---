<?php
declare(strict_types=1);

namespace anaf2197\gambling\form;

use pocketmine\form\Form;
use pocketmine\player\Player;

final class GamblingResultForm implements Form {

    public function __construct(
        private bool     $win,
        private string   $gameTitle,
        private int      $netGain,
        private int      $bet,
        private int      $newBalance,
        private string   $detail,
        /** @var \Closure(): Form */
        private \Closure $retryForm,
    ) {}

    public function jsonSerialize(): array {
        $header    = $this->win ? '§l§a★ 승리! ★' : '§l§c✖ 패배...';
        $gainLine  = $this->win
            ? '§8수익: §a+§e' . number_format($this->netGain) . '원'
            : '§8손실: §c-§e' . number_format(abs($this->netGain)) . '원';

        $content = implode("\n", [
            ' ',
            $header,
            ' ',
            $this->detail,
            ' ',
            '§8베팅: §f' . number_format($this->bet) . '원',
            $gainLine,
            '§8잔액: §f' . number_format($this->newBalance) . '원',
            ' ',
        ]);

        return [
            'type'    => 'form',
            'title'   => '§l§6' . $this->gameTitle . ' 결과',
            'content' => $content,
            'buttons' => [
                ['text' => '§l§a한 번 더!'],
                ['text' => '§8그만할게'],
            ],
        ];
    }

    public function handleResponse(Player $player, $data): void {
        if ($data === 0) {
            $player->sendForm(($this->retryForm)());
        }
    }
}
