<?php
declare(strict_types=1);

namespace anaf2197\attendancecheck\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use pocketmine\Server;
use anaf2197\attendancecheck\AttendanceCheck;

/**
 * /출석체크관리 [보상추가|보상제거|보상초기화|보상목록|출석초기화|출석확인]
 */
final class AttendanceAdminCommand extends Command {

    public function __construct() {
        parent::__construct(
            '출석체크관리',
            '출석체크 관리 명령어',
            '/출석체크관리 [보상추가|보상제거|보상초기화|보상목록|출석초기화|출석확인]',
            []
        );
        $this->setPermission(DefaultPermissions::ROOT_OPERATOR);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if (!$this->testPermission($sender)) return;

        $owner  = AttendanceCheck::getInstance();
        $prefix = AttendanceCheck::prefix;
        $sub    = array_shift($args);

        switch ($sub) {

            case '보상추가':
                // /출석체크관리 보상추가 [일]
                if (!($sender instanceof Player)) {
                    $sender->sendMessage($prefix . '§c게임 내에서만 사용 가능합니다.');
                    return;
                }
                if (!isset($args[0]) || !is_numeric($args[0])) {
                    $sender->sendMessage($prefix . '§8사용법: /출석체크관리 보상추가 [일차]');
                    return;
                }
                $day  = max(1, (int)$args[0]);
                $item = $sender->getInventory()->getItemInHand();
                if ($item->isNull()) {
                    $sender->sendMessage($prefix . '공기는 보상으로 추가할 수 없습니다.');
                    return;
                }
                $owner->addReward($item, $day);
                $sender->sendMessage($prefix . $day . '일차 보상에 아이템을 추가했습니다.');
                break;

            case '보상제거':
                // /출석체크관리 보상제거 [일차] [번호]
                if (!isset($args[0], $args[1]) || !is_numeric($args[0]) || !is_numeric($args[1])) {
                    $sender->sendMessage($prefix . '§8사용법: /출석체크관리 보상제거 [일차] [번호]');
                    return;
                }
                $day   = max(1, (int)$args[0]);
                $index = (int)$args[1] - 1;
                $owner->removeReward($day, $index);
                $sender->sendMessage($prefix . $day . '일차 ' . ($index + 1) . '번 보상을 제거했습니다.');
                break;

            case '보상초기화':
                // /출석체크관리 보상초기화        → 전체 초기화
                // /출석체크관리 보상초기화 [일차]  → 특정 일차만 초기화
                if (isset($args[0]) && is_numeric($args[0])) {
                    $day = max(1, (int)$args[0]);
                    $owner->clearRewards($day);
                    $sender->sendMessage($prefix . $day . '일차 보상을 초기화했습니다.');
                } else {
                    $owner->clearRewards();
                    $sender->sendMessage($prefix . '모든 일차 보상을 초기화했습니다.');
                }
                break;

            case '보상목록':
                // /출석체크관리 보상목록        → 전체 일차 목록
                // /출석체크관리 보상목록 [일차]  → 특정 일차 목록
                if (isset($args[0]) && is_numeric($args[0])) {
                    $day     = max(1, (int)$args[0]);
                    $rewards = $owner->getRewards($day);
                    if (empty($rewards)) {
                        $sender->sendMessage($prefix . $day . '일차에 설정된 보상이 없습니다.');
                        return;
                    }
                    $sender->sendMessage($prefix . $day . '일차 보상 (총 ' . count($rewards) . '개)');
                    foreach ($rewards as $i => $itemData) {
                        $item = AttendanceCheck::ItemDataDeserialize($itemData);
                        $sender->sendMessage('  §f' . ($i + 1) . '. §7' . $item->getName() . ' §8x' . $item->getCount());
                    }
                } else {
                    $all = $owner->getRewards();
                    if (empty($all)) {
                        $sender->sendMessage($prefix . '설정된 보상이 없습니다.');
                        return;
                    }
                    $maxDay = $owner->getMaxDay();
                    $sender->sendMessage($prefix . '일별 보상 목록 (총 ' . $maxDay . '일차까지)');
                    foreach ($all as $day => $items) {
                        $names = array_map(function (string $d): string {
                            $item = AttendanceCheck::ItemDataDeserialize($d);
                            return $item->getName() . '×' . $item->getCount();
                        }, $items);
                        $sender->sendMessage('  §e' . $day . '일차: §7' . implode(', ', $names));
                    }
                }
                break;

            case '출석초기화':
                if (!isset($args[0])) {
                    $sender->sendMessage($prefix . '§8사용법: /출석체크관리 출석초기화 [닉네임]');
                    return;
                }
                $targetName = implode(' ', $args);
                $target = Server::getInstance()->getPlayerByPrefix($targetName);
                if ($target instanceof Player) {
                    $owner->resetAttendance($target);
                    $sender->sendMessage($prefix . "§f{$target->getName()}§8 님의 출석을 초기화했습니다.");
                } else {
                    $sender->sendMessage($prefix . '§c해당 플레이어를 찾을 수 없습니다. (접속 중이어야 합니다)');
                }
                break;

            case '출석확인':
                if (!isset($args[0])) {
                    $sender->sendMessage($prefix . '§8사용법: /출석체크관리 출석확인 [닉네임]');
                    return;
                }
                $targetName = implode(' ', $args);
                $target = Server::getInstance()->getPlayerByPrefix($targetName);
                if ($target instanceof Player) {
                    $count   = $owner->getAttendanceCount($target);
                    $streak  = $owner->getStreak($target);
                    $today   = $owner->hasChecked($target) ? '§a완료' : '§c미완료';
                    $maxDay  = $owner->getMaxDay();
                    $nextDay = $count + 1;
                    $sender->sendMessage($prefix . "§f{$target->getName()}§8 님의 출석 정보");
                    $sender->sendMessage("  §8누적 출석: §f{$count}일");
                    $sender->sendMessage("  §8연속 출석: §f{$streak}일");
                    $sender->sendMessage("  §8오늘 출석: {$today}");
                    if (!$owner->hasChecked($target) && $maxDay > 0) {
                        $has = !empty($owner->getRewards($nextDay));
                        $sender->sendMessage("  §8다음 보상: §f{$nextDay}일차 " . ($has ? '§a있음' : '§7없음'));
                    }
                } else {
                    $sender->sendMessage($prefix . '§c해당 플레이어를 찾을 수 없습니다. (접속 중이어야 합니다)');
                }
                break;

            default:
                $sender->sendMessage($prefix . '§l§6출석체크관리 명령어');
                $sender->sendMessage('§8/출석체크관리 보상추가 §f[일차] - 손에 든 아이템을 해당 일차 보상으로 추가');
                $sender->sendMessage('§8/출석체크관리 보상제거 §f[일차] [번호] - 해당 일차 보상 제거');
                $sender->sendMessage('§8/출석체크관리 보상초기화 §f([일차]) - 전체 또는 특정 일차 보상 초기화');
                $sender->sendMessage('§8/출석체크관리 보상목록 §f([일차]) - 전체 또는 특정 일차 보상 목록');
                $sender->sendMessage('§8/출석체크관리 출석초기화 §f[닉네임] - 플레이어 출석 초기화');
                $sender->sendMessage('§8/출석체크관리 출석확인 §f[닉네임] - 플레이어 출석 정보 확인');
                break;
        }
    }
}
