<?php

namespace anaf2197\attendancecheck\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\attendancecheck\AttendanceCheck;
use pocketmine\world\sound\FizzSound;

final class AttendanceCommand extends Command {

    public function __construct() {
        parent::__construct('출석체크', '출석체크를 진행합니다.', null, ['출석', 'attendance', 'attendace']);
        $this->setPermission(DefaultPermissions::ROOT_USER);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if (!($sender instanceof Player) || !$this->testPermission($sender)) {
            return;
        }

        $owner = AttendanceCheck::getInstance();

        if (!$owner->hasChecked($sender)) {
            $sender->getWorld()->addSound($sender->getPosition()->asVector3(), new FizzSound());
            $owner->checkPlayer($sender);
            $count  = $owner->getAttendanceCount($sender);
            $streak = $owner->getStreak($sender);
            $streakMsg = $streak >= 2 ? ' §e연속 ' . $streak . '일!' : '';
            $sender->sendTitle('§l§a출석체크 완료!', '§l§f우편함을 확인해주세요! (누적: ' . $count . '일' . $streakMsg . ')', 5, 40, 5);
        } else {
            $count  = $owner->getAttendanceCount($sender);
            $streak = $owner->getStreak($sender);
            $next3  = 3 - ($streak % 3);
            $next7  = 7 - ($streak % 7);
            $sender->sendMessage(AttendanceCheck::prefix . '오늘의 출석체크를 이미 완료했습니다. (누적: ' . $count . '일 / 연속: ' . $streak . '일)');
            if ($next3 === 3 && $streak % 7 !== 0) {
                $sender->sendMessage(AttendanceCheck::prefix . '§8연속 보너스: §f3일 후 §6+1,000원');
            } elseif ($next7 !== 7) {
                $sender->sendMessage(AttendanceCheck::prefix . '§8연속 보너스: §f' . $next7 . '일 후 §6+5,000원');
            }
        }
    }
}