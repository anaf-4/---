<?php
declare(strict_types=1);

namespace anaf2197\attendancecheck;

/**
 * 플레이어 1명의 출석 데이터 VO.
 * JsonDataProvider를 통해 CoreSystem의 players/ 폴더에 저장됩니다.
 * (AttendanceCheck 전용 필드만 담당)
 */
final class AttendanceData implements \JsonSerializable {

    public function __construct(
        private string $name,
        /** 출석한 날짜 목록 ['2026-05-01', ...] */
        private array  $checkedDates = [],
    ) {
        // 오래된 날짜 정리 (최근 365일치만 보관)
        $cutoff = date('Y-m-d', strtotime('-365 days'));
        $this->checkedDates = array_values(
            array_filter($this->checkedDates, fn($d) => $d >= $cutoff)
        );
    }

    // ── 조회 ─────────────────────────────────────────────

    public function getName(): string { return $this->name; }

    /** 오늘 출석 여부 */
    public function hasCheckedToday(): bool {
        return in_array($this->today(), $this->checkedDates, true);
    }

    /** 누적 출석 일수 */
    public function getTotalCount(): int {
        return count($this->checkedDates);
    }

    /** 이번 달 출석 일수 */
    public function getMonthlyCount(): int {
        $month = date('Y-m');
        return count(array_filter($this->checkedDates, fn($d) => str_starts_with($d, $month)));
    }

    /** 최근 N일 연속 출석 일수 계산 */
    public function getStreak(): int {
        if (empty($this->checkedDates)) return 0;
        $streak  = 0;
        $checkDay = new \DateTime($this->today());
        $sorted   = $this->checkedDates;
        rsort($sorted); // 최신순

        foreach ($sorted as $date) {
            if ($date === $checkDay->format('Y-m-d')) {
                $streak++;
                $checkDay->modify('-1 day');
            } else {
                break;
            }
        }
        return $streak;
    }

    // ── 조작 ─────────────────────────────────────────────

    public function check(): void {
        if (!$this->hasCheckedToday()) {
            $this->checkedDates[] = $this->today();
        }
    }

    public function reset(): void {
        $this->checkedDates = [];
    }

    // ── 직렬화 ───────────────────────────────────────────

    public function jsonSerialize(): array {
        return [$this->name, $this->checkedDates];
    }

    public static function jsonDeserialize(array $data): self {
        return new self($data[0], $data[1] ?? []);
    }

    public static function createDefault(string $name): self {
        return new self($name);
    }

    private function today(): string {
        return date('Y-m-d');
    }
}
