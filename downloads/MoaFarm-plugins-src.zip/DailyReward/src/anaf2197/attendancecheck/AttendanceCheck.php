<?php

namespace anaf2197\attendancecheck;

use pocketmine\event\EventPriority;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\item\Item;
use pocketmine\nbt\BigEndianNbtSerializer;
use pocketmine\nbt\TreeRoot;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use pocketmine\utils\SingletonTrait;
use anaf2197\attendancecheck\command\AttendanceAdminCommand;
use anaf2197\attendancecheck\command\AttendanceCommand;
use anaf2197\deliveryapi\DeliveryAPI;

final class AttendanceCheck extends PluginBase {

    public const prefix = '§l§d[출석체크]§r§8 ';

    use SingletonTrait;

    private Config $config;

    protected array $db;

    protected function onEnable(): void {
        $this->config = new Config($this->getDataFolder() . 'config.yml', Config::YAML, [[], []]);
        $this->db = $this->config->getAll();

        // 기본 구조 초기화
        if (!isset($this->db[0])) $this->db[0] = [];
        if (!isset($this->db[1])) $this->db[1] = [];

        // 구버전 flat list → 일별 구조 마이그레이션
        if (!empty($this->db[1]) && is_string(reset($this->db[1]))) {
            $this->db[1] = [1 => array_values($this->db[1])];
            $this->getLogger()->info('출석체크 보상 데이터를 일별 형식으로 마이그레이션했습니다.');
        }
        
        $cmdMap = $this->getServer()->getCommandMap();
        $cmdMap->register(strtolower($this->getName()), new AttendanceCommand());
        $cmdMap->register(strtolower($this->getName()), new AttendanceAdminCommand());
        $this->getServer()->getPluginManager()->registerEvent(PlayerJoinEvent::class, function (PlayerJoinEvent $event): void {
            $id = strtolower($event->getPlayer()->getName());
            if (!isset($this->db[0][$id])) {
                $this->db[0][$id] = [];
            }
        }, EventPriority::NORMAL, $this);
    }

    protected function onDisable(): void {
        $this->config->setAll($this->db);
        $this->config->save();
    }

    protected function onLoad(): void {
        date_default_timezone_set('Asia/Seoul');
        self::setInstance($this);
    }

    private function nowTimeId(): string {
        return date('Y-m-d');
    }

    public function hasChecked(Player $player): bool {
        $name = strtolower($player->getName());
        return isset($this->db[0][$name]) && in_array($this->nowTimeId(), $this->db[0][$name]);
    }

    public function checkPlayer(Player $player): void {
        $name = strtolower($player->getName());
        if (!isset($this->db[0][$name])) {
            $this->db[0][$name] = [];
        }
        $dayNum = count($this->db[0][$name]) + 1;  // 오늘이 N번째 출석
        $this->db[0][$name][] = $this->nowTimeId();

        $todayItems = $this->db[1][$dayNum] ?? [];
        $mailTitle  = '출석체크 보상 (' . $dayNum . '일차)';
        foreach ($todayItems as $itemData) {
            DeliveryAPI::getInstance()->getMailBox($player)->new($mailTitle, [self::ItemDataDeserialize($itemData)]);
        }

        // ── 연속 출석 streak 보너스 ──────────────────────────────────────────
        $streak = $this->getStreak($player);
        $streakBonus = match (true) {
            $streak % 30 === 0 => 50000,
            $streak % 14 === 0 => 15000,
            $streak % 7  === 0 => 5000,
            $streak % 3  === 0 => 1000,
            default            => 0,
        };
        if ($streakBonus > 0 && class_exists(\anaf2197\economyapi\EconomyAPI::class)) {
            \anaf2197\economyapi\EconomyAPI::getInstance()->addMoney($player, $streakBonus);
            $player->sendMessage(self::prefix . '§e연속 출석 ' . $streak . '일 달성! §6+' . number_format($streakBonus) . '원 §8보너스 지급!');
        }

        // ── Achievement 출석 업적 진행도 ─────────────────────────────────────
        if (class_exists(\anaf2197\achievement\AchievementLoader::class)) {
            $totalDays = count($this->db[0][$name] ?? []);
            $loader    = \anaf2197\achievement\AchievementLoader::getInstance();
            $pa        = $loader->getPlayerAchievement($player);
            if ($pa !== null) {
                $current = $pa->getProgress(\anaf2197\achievement\Achievement::TYPE_ATTENDANCE);
                if ($totalDays > $current) {
                    $loader->addProgress($player, \anaf2197\achievement\Achievement::TYPE_ATTENDANCE, $totalDays - $current);
                }
            }
        }

        // ── DailyMission 출석 진행도 ─────────────────────────────────────────
        if (class_exists(\anaf2197\dailymission\DailyMissionLoader::class)) {
            \anaf2197\dailymission\DailyMissionLoader::getInstance()
                ->addProgress($player, 'ATTENDANCE');
        }
    }

    /** 현재 연속 출석일 수를 반환합니다. */
    public function getStreak(Player $player): int {
        $name  = strtolower($player->getName());
        $dates = $this->db[0][$name] ?? [];
        if (empty($dates)) return 0;

        $sorted = array_unique($dates);
        sort($sorted);

        $streak  = 1;
        $prevDay = \DateTimeImmutable::createFromFormat('Y-m-d', end($sorted));
        if ($prevDay === false) return 1;

        for ($i = count($sorted) - 2; $i >= 0; $i--) {
            $day = \DateTimeImmutable::createFromFormat('Y-m-d', $sorted[$i]);
            if ($day === false) break;
            if ((int) $prevDay->diff($day)->days === 1) {
                $streak++;
                $prevDay = $day;
            } else {
                break;
            }
        }
        return $streak;
    }

    public function addReward(Item $item, int $day): void {
        if (!isset($this->db[1][$day])) $this->db[1][$day] = [];
        $this->db[1][$day][] = self::ItemDataSerialize($item);
        ksort($this->db[1]);
    }

    public function removeReward(int $day, int $index): void {
        if (!isset($this->db[1][$day][$index])) return;
        unset($this->db[1][$day][$index]);
        $this->db[1][$day] = array_values($this->db[1][$day]);
        if (empty($this->db[1][$day])) unset($this->db[1][$day]);
    }

    public function clearRewards(?int $day = null): void {
        if ($day === null) {
            $this->db[1] = [];
        } else {
            unset($this->db[1][$day]);
        }
    }

    /** @return array [day => [item_data, ...], ...] OR [item_data, ...] for specific day */
    public function getRewards(?int $day = null): array {
        if ($day === null) return $this->db[1] ?? [];
        return $this->db[1][$day] ?? [];
    }

    public function getMaxDay(): int {
        return empty($this->db[1]) ? 0 : max(array_keys($this->db[1]));
    }

    public function getAttendanceCount(Player $player): int {
        $name = strtolower($player->getName());
        return isset($this->db[0][$name]) ? count($this->db[0][$name]) : 0;
    }

    public function resetAttendance(Player $player): void {
        $name = strtolower($player->getName());
        $this->db[0][$name] = [];
    }

    public static function ItemDataSerialize(Item $data): string {
        return base64_encode((new BigEndianNbtSerializer())->write(new TreeRoot($data->nbtSerialize())));
    }

    public static function ItemDataDeserialize(string $data): Item {
        return Item::nbtDeserialize((new BigEndianNbtSerializer())->read(base64_decode($data))->mustGetCompoundTag());
    }
}