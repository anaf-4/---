<?php
declare(strict_types=1);

namespace anaf2197\attendancecheck\listener;

use anaf2197\attendancecheck\AttendanceCheck;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;

final class AttendanceListener implements Listener {

    public function __construct(private AttendanceCheck $plugin) {}

    public function onJoin(PlayerJoinEvent $event): void {
        $this->plugin->loadPlayer($event->getPlayer());
    }

    public function onQuit(PlayerQuitEvent $event): void {
        $this->plugin->unloadPlayer($event->getPlayer());
    }
}
