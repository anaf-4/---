<?php
declare(strict_types=1);

namespace anaf2197\dailypass;

use pocketmine\utils\Config;

/**
 * PassManager — 패스 구매 유저 목록 관리.
 * DailyPassLoader에서 직접 배열을 다루던 로직을 분리합니다.
 */
final class PassManager {

    /** 패스 보유자 목록 [소문자 이름 => true] */
    private array $holders = [];

    private Config $config;

    public function __construct(string $dataFolder) {
        $this->config  = new Config($dataFolder . 'pass_holders.json', Config::JSON, []);
        $this->holders = array_fill_keys(
            array_map('strtolower', $this->config->getAll()),
            true
        );
    }

    // ── 조회 ─────────────────────────────────────────────

    public function has(string $name): bool {
        return isset($this->holders[strtolower($name)]);
    }

    /** 이름 목록 (원본 대소문자 반환) */
    public function getAll(): array {
        return array_keys($this->holders);
    }

    public function count(): int {
        return count($this->holders);
    }

    // ── 조작 ─────────────────────────────────────────────

    public function add(string $name): bool {
        $key = strtolower($name);
        if (isset($this->holders[$key])) return false;
        $this->holders[$key] = true;
        $this->save();
        return true;
    }

    public function remove(string $name): bool {
        $key = strtolower($name);
        if (!isset($this->holders[$key])) return false;
        unset($this->holders[$key]);
        $this->save();
        return true;
    }

    private function save(): void {
        $this->config->setAll(array_keys($this->holders));
        $this->config->save();
    }
}
