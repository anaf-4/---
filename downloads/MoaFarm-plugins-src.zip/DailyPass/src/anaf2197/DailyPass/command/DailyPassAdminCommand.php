<?php
declare(strict_types=1);

namespace anaf2197\DailyPass\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\DailyPass\DailyPassLoader;

/**
 * /데일리패스관리 [보상추가|보상제거|보상초기화|보상목록|유저추가|유저제거|유저목록]
 */
final class DailyPassAdminCommand extends Command {

    public function __construct() {
        parent::__construct(
            '데일리패스관리',
            '데일리패스 관리 명령어',
            '/데일리패스관리 [보상추가|보상제거|보상초기화|보상목록|유저추가|유저제거|유저목록]',
            []
        );
        $this->setPermission(DefaultPermissions::ROOT_OPERATOR);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if (!$this->testPermission($sender)) return;

        $owner  = DailyPassLoader::getInstance();
        $prefix = DailyPassLoader::$prefix;
        $sub    = array_shift($args);

        switch ($sub) {

            case '보상추가':
                if (!($sender instanceof Player)) {
                    $sender->sendMessage($prefix . '§c게임 내에서만 사용 가능합니다.');
                    return;
                }
                $item = $sender->getInventory()->getItemInHand();
                if ($item->isNull()) {
                    $sender->sendMessage($prefix . '공기는 보상으로 추가할 수 없습니다.');
                    return;
                }
                $owner->addReward($item);
                $sender->sendMessage($prefix . '해당 아이템을 보상으로 추가했습니다.');
                break;

            case '보상제거':
                if (!isset($args[0]) || !is_numeric($args[0])) {
                    $sender->sendMessage($prefix . '§8사용법: /데일리패스관리 보상제거 [번호]');
                    return;
                }
                $index = (int)$args[0] - 1;
                $owner->removeReward($index);
                $sender->sendMessage($prefix . ($index + 1) . '번 보상을 제거했습니다.');
                break;

            case '보상초기화':
                $owner->clearRewards();
                $sender->sendMessage($prefix . '모든 보상을 초기화했습니다.');
                break;

            case '보상목록':
                $rewards = $owner->getRewards();
                if (empty($rewards)) {
                    $sender->sendMessage($prefix . '설정된 보상이 없습니다.');
                    return;
                }
                $sender->sendMessage($prefix . '보상 목록 (총 ' . count($rewards) . '개)');
                foreach ($rewards as $key => $reward) {
                    $item = DailyPassLoader::ItemDataDeserialize($reward['item_data']);
                    $sender->sendMessage('  §f' . ($key + 1) . '. §7' . $item->getName() . ' §8x' . $item->getCount());
                }
                break;

            case '유저추가':
                if (!isset($args[0])) {
                    $sender->sendMessage($prefix . '§8사용법: /데일리패스관리 유저추가 [닉네임]');
                    return;
                }
                $targetName = implode(' ', $args);
                $owner->addAllowedPlayer($targetName);
                $sender->sendMessage($prefix . "§f{$targetName}§8 님을 패스 목록에 추가했습니다.");
                break;

            case '유저제거':
                if (!isset($args[0])) {
                    $sender->sendMessage($prefix . '§8사용법: /데일리패스관리 유저제거 [닉네임]');
                    return;
                }
                $targetName = implode(' ', $args);
                $owner->removeAllowedPlayer($targetName);
                $sender->sendMessage($prefix . "§f{$targetName}§8 님을 패스 목록에서 제거했습니다.");
                break;

            case '유저목록':
                $players = $owner->getAllowedPlayers();
                if (empty($players)) {
                    $sender->sendMessage($prefix . '패스 구매 유저가 없습니다.');
                    return;
                }
                $sender->sendMessage($prefix . '§l패스 구매 유저 목록 §8(총 ' . count($players) . '명)');
                foreach (array_chunk($players, 10) as $chunk) {
                    $sender->sendMessage('  §f' . implode('§8, §f', $chunk));
                }
                break;

            default:
                $sender->sendMessage($prefix . '§l§6데일리패스관리 명령어');
                $sender->sendMessage('§8/데일리패스관리 보상추가 §f- 손에 든 아이템 보상 추가');
                $sender->sendMessage('§8/데일리패스관리 보상제거 §f[번호] - 보상 제거');
                $sender->sendMessage('§8/데일리패스관리 보상초기화 §f- 모든 보상 제거');
                $sender->sendMessage('§8/데일리패스관리 보상목록 §f- 보상 목록 확인');
                $sender->sendMessage('§8/데일리패스관리 유저추가 §f[닉네임] - 구매자 추가');
                $sender->sendMessage('§8/데일리패스관리 유저제거 §f[닉네임] - 구매자 제거');
                $sender->sendMessage('§8/데일리패스관리 유저목록 §f- 구매자 목록 확인');
                break;
        }
    }
}
