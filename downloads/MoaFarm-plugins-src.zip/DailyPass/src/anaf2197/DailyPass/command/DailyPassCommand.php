<?php

namespace anaf2197\DailyPass\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use pocketmine\world\sound\FizzSound;
use anaf2197\DailyPass\DailyPassLoader;

final class DailyPassCommand extends Command {

    public function __construct() {
        parent::__construct('데일리패스', '데일리패스 출석을 진행합니다.');
        $this->setPermission(DefaultPermissions::ROOT_USER);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if (!($sender instanceof Player) || !$this->testPermission($sender)) {
            return;
        }

        $owner = DailyPassLoader::getInstance();

        // 일반 유저 - 출석 체크
        $rewards = $owner->getRewards();

        // 관리자이거나 허용된 플레이어인지 확인
        if (!$sender->hasPermission(DefaultPermissions::ROOT_OPERATOR) && !$owner->isAllowedPlayer($sender)) {
            $sender->sendMessage(DailyPassLoader::$prefix . '패스를 구매하지 않은 유저입니다. 관리자에게 문의 부탁드립니다.');
            return;
        }

        $totalDays   = (int) date('t');
        $checkedDays = $owner->getMonthCheckedCount($sender);

        if (!$owner->hasChecked($sender)) {
            if (empty($rewards)) {
                $sender->sendMessage(DailyPassLoader::$prefix . '패스 보상이 설정되지 않았습니다.');
                return;
            }
            $sender->getWorld()->addSound($sender->getPosition()->asVector3(), new FizzSound());
            $owner->checkPlayer($sender);
            $checkedDays++;
            $filled = (int) ($checkedDays / $totalDays * 10);
            $bar    = '§a' . str_repeat('█', $filled) . '§8' . str_repeat('█', 10 - $filled);
            $sender->sendTitle('§l§a패스 출석 완료!', '§r§f이번 달: ' . $checkedDays . ' / ' . $totalDays . '일', 5, 40, 5);
            $sender->sendMessage(DailyPassLoader::$prefix . '이번 달 출석: ' . $bar . ' §f' . $checkedDays . ' / ' . $totalDays . '일');
        } else {
            $filled = (int) ($checkedDays / $totalDays * 10);
            $bar    = '§a' . str_repeat('█', $filled) . '§8' . str_repeat('█', 10 - $filled);
            $sender->sendMessage(DailyPassLoader::$prefix . '오늘의 데일리 패스 출석을 이미 완료했습니다.');
            $sender->sendMessage(DailyPassLoader::$prefix . '이번 달 출석: ' . $bar . ' §f' . $checkedDays . ' / ' . $totalDays . '일');
        }
    }
}