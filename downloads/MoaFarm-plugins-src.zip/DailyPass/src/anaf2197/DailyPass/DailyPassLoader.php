<?php

declare(strict_types=1);

namespace anaf2197\DailyPass;

use pocketmine\event\EventPriority;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\item\Item;
use pocketmine\scheduler\ClosureTask;
use pocketmine\nbt\BigEndianNbtSerializer;
use pocketmine\nbt\TreeRoot;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;
use anaf2197\DailyPass\command\DailyPassAdminCommand;
use anaf2197\DailyPass\command\DailyPassCommand;
use anaf2197\DailyPass\db\Database;
use anaf2197\deliveryapi\DeliveryAPI;
use anaf2197\lib\color\ServerColor;

final class DailyPassLoader extends PluginBase {

    public static string $prefix;

    use SingletonTrait;

    private ?Database $database = null;

    /** [playerName => true] */
    private array $allowedPlayers = [];
    /** [['id' => int, 'item_data' => string], ...] */
    private array $rewards = [];

    protected function onLoad(): void {
        date_default_timezone_set('Asia/Seoul');
        ServerColor::setPrefix($this, '데일리패스');
        self::setInstance($this);
    }

    protected function onEnable(): void {
        $this->saveResource('db.yml', false);
        $dbConfig = new \pocketmine\utils\Config($this->getDataFolder() . 'db.yml', \pocketmine\utils\Config::YAML);
        $cfg = $dbConfig->get('database');

        try {
            $this->database = new Database(
                $cfg['host'], (int)$cfg['port'],
                $cfg['username'], $cfg['password'], $cfg['database']
            );
        } catch (\Throwable $e) {
            $this->getLogger()->error('DB 연결 실패: ' . $e->getMessage());
            $this->getServer()->getPluginManager()->disablePlugin($this);
            return;
        }

        $this->allowedPlayers = $this->database->loadPlayers();
        $this->rewards        = $this->database->loadRewards();
        $this->getLogger()->info("구매자 " . count($this->allowedPlayers) . "명, 보상 " . count($this->rewards) . "개 로드 완료");

        // 서버 시작 시 + 1시간마다 월 초기화 체크
        $this->runMonthlyReset();
        $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(function (): void {
            $this->runMonthlyReset();
        }), 72000);

        $cmdMap = $this->getServer()->getCommandMap();
        $cmdMap->register(strtolower($this->getName()), new DailyPassCommand());
        $cmdMap->register(strtolower($this->getName()), new DailyPassAdminCommand());
        $this->getServer()->getPluginManager()->registerEvent(
            PlayerJoinEvent::class,
            function (PlayerJoinEvent $event): void {
                $player = $event->getPlayer();
                if ($this->isAllowedPlayer($player) && !$this->hasChecked($player)) {
                    $player->sendMessage(self::$prefix . '§a데일리패스 보상을 수령하지 않았습니다! §8/데일리패스 로 수령하세요.');
                }
            },
            EventPriority::NORMAL,
            $this
        );
    }

    protected function onDisable(): void {
        $this->database?->close();
    }

    private function today(): string {
        return date('Y-m-d');
    }

    private function runMonthlyReset(): void {
        if ($this->database === null) return;
        $currentMonth = date('Y-m');
        $lastReset    = $this->database->getLastResetMonth();
        if ($lastReset === $currentMonth) return;

        $this->getLogger()->info("데일리패스 월 초기화: {$lastReset} → {$currentMonth}");
        $this->database->resetOldCheckHistory();
        $this->database->setLastResetMonth($currentMonth);
    }

    public function hasChecked(Player $player): bool {
        return $this->database->hasChecked(strtolower($player->getName()), $this->today());
    }

    // DailyPassListener 호환용
    public function hasCheckedToday(Player $player): bool {
        return $this->hasChecked($player);
    }

    public function hasPass(Player $player): bool {
        return $this->isAllowedPlayer($player);
    }

    public function checkPlayer(Player $player): void {
        $name = strtolower($player->getName());
        $this->database->addCheck($name, $this->today());

        $mailBox = DeliveryAPI::getInstance()->getMailBox($player);
        if ($mailBox === null) return;
        foreach ($this->rewards as $reward) {
            $mailBox->new('데일리패스 보상', [self::ItemDataDeserialize($reward['item_data'])]);
        }
    }

    // ── 구매자 ───────────────────────────────────────────────

    public function isAllowedPlayer(Player $player): bool {
        return isset($this->allowedPlayers[strtolower($player->getName())]);
    }

    public function addAllowedPlayer(string $name): void {
        $name = strtolower($name);
        $this->allowedPlayers[$name] = true;
        $this->database->addPlayer($name);
    }

    public function removeAllowedPlayer(string $name): void {
        $name = strtolower($name);
        unset($this->allowedPlayers[$name]);
        $this->database->removePlayer($name);
    }

    public function getAllowedPlayers(): array {
        return array_keys($this->allowedPlayers);
    }

    // ── 보상 ─────────────────────────────────────────────────

    public function addReward(Item $item): void {
        $this->database->addReward(self::ItemDataSerialize($item));
        $this->rewards = $this->database->loadRewards();
    }

    public function removeReward(int $index): void {
        if (!isset($this->rewards[$index])) return;
        $this->database->removeReward($this->rewards[$index]['id']);
        $this->rewards = $this->database->loadRewards();
    }

    public function clearRewards(): void {
        $this->database->clearRewards();
        $this->rewards = [];
    }

    public function getRewards(): array {
        return $this->rewards;
    }

    public function getMonthCheckedCount(Player $player): int {
        return $this->database?->getMonthCheckedCount(strtolower($player->getName())) ?? 0;
    }

    // ── 아이템 직렬화 ────────────────────────────────────────

    public static function ItemDataSerialize(Item $item): string {
        return base64_encode((new BigEndianNbtSerializer())->write(new TreeRoot($item->nbtSerialize())));
    }

    public static function ItemDataDeserialize(string $data): Item {
        return Item::nbtDeserialize((new BigEndianNbtSerializer())->read(base64_decode($data))->mustGetCompoundTag());
    }
}
