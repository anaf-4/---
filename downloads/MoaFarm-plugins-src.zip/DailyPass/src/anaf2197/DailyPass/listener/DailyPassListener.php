<?php
declare(strict_types=1);

namespace anaf2197\dailypass\listener;

use anaf2197\dailypass\DailyPassLoader;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;

final class DailyPassListener implements Listener {

    public function __construct(private DailyPassLoader $plugin) {}

    public function onJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        if (!$this->plugin->hasPass($player)) return;

        // 패스 보유자가 접속 시 오늘 수령 여부 알림
        if (!$this->plugin->hasCheckedToday($player)) {
            $player->sendMessage(DailyPassLoader::$prefix
                . '§a데일리패스 보상을 수령하지 않았습니다! §8/데일리패스 로 수령하세요.');
        }
    }
}
