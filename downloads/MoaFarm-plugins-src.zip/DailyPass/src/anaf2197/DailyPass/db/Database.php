<?php

declare(strict_types=1);

namespace anaf2197\DailyPass\db;

use mysqli;
use RuntimeException;

final class Database {

    private mysqli $db;

    public function __construct(
        private string $host,
        private int    $port,
        private string $user,
        private string $pass,
        private string $dbName
    ) {
        $this->connect();
        $this->initTables();
    }

    private function connect(): void {
        $this->db = new mysqli($this->host, $this->user, $this->pass, $this->dbName, $this->port);
        if ($this->db->connect_errno) {
            throw new RuntimeException('DailyPass DB 연결 실패: ' . $this->db->connect_error);
        }
        $this->db->set_charset('utf8mb4');
    }

    private function initTables(): void {
        $this->db->query("
            CREATE TABLE IF NOT EXISTS daily_pass_players (
                player_name VARCHAR(64) NOT NULL,
                added_at    DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (player_name)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
        $this->db->query("
            CREATE TABLE IF NOT EXISTS daily_check_history (
                player_name VARCHAR(64) NOT NULL,
                check_date  DATE        NOT NULL,
                PRIMARY KEY (player_name, check_date)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
        $this->db->query("
            CREATE TABLE IF NOT EXISTS daily_rewards (
                id        INT AUTO_INCREMENT PRIMARY KEY,
                item_data MEDIUMBLOB NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
        $this->db->query("
            CREATE TABLE IF NOT EXISTS daily_settings (
                setting_key   VARCHAR(64)  NOT NULL,
                setting_value VARCHAR(255) NOT NULL DEFAULT '',
                PRIMARY KEY (setting_key)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
        $this->db->query("INSERT IGNORE INTO daily_settings (setting_key, setting_value) VALUES ('last_reset_month', '')");
    }

    // ── 구매자 ───────────────────────────────────────────────

    public function loadPlayers(): array {
        $result = $this->db->query("SELECT player_name FROM daily_pass_players");
        if ($result === false) return [];
        $players = [];
        while ($row = $result->fetch_assoc()) {
            $players[$row['player_name']] = true;
        }
        $result->free();
        return $players;
    }

    public function addPlayer(string $name): void {
        $stmt = $this->db->prepare("INSERT IGNORE INTO daily_pass_players (player_name) VALUES (?)");
        if ($stmt === false) throw new RuntimeException($this->db->error);
        $stmt->bind_param('s', $name);
        $stmt->execute();
        $stmt->close();
    }

    public function removePlayer(string $name): void {
        $stmt = $this->db->prepare("DELETE FROM daily_pass_players WHERE player_name=?");
        if ($stmt === false) throw new RuntimeException($this->db->error);
        $stmt->bind_param('s', $name);
        $stmt->execute();
        $stmt->close();
    }

    // ── 출석 기록 ────────────────────────────────────────────

    public function hasChecked(string $name, string $date): bool {
        $stmt = $this->db->prepare("SELECT 1 FROM daily_check_history WHERE player_name=? AND check_date=?");
        if ($stmt === false) return false;
        $stmt->bind_param('ss', $name, $date);
        $stmt->execute();
        $result = $stmt->get_result();
        $found  = $result->num_rows > 0;
        $result->free();
        $stmt->close();
        return $found;
    }

    public function addCheck(string $name, string $date): void {
        $stmt = $this->db->prepare("INSERT IGNORE INTO daily_check_history (player_name, check_date) VALUES (?, ?)");
        if ($stmt === false) throw new RuntimeException($this->db->error);
        $stmt->bind_param('ss', $name, $date);
        $stmt->execute();
        $stmt->close();
    }

    // ── 보상 ─────────────────────────────────────────────────

    public function loadRewards(): array {
        $result = $this->db->query("SELECT id, item_data FROM daily_rewards ORDER BY id ASC");
        if ($result === false) return [];
        $rewards = [];
        while ($row = $result->fetch_assoc()) {
            $rewards[] = ['id' => (int)$row['id'], 'item_data' => $row['item_data']];
        }
        $result->free();
        return $rewards;
    }

    public function addReward(string $itemData): void {
        $stmt = $this->db->prepare("INSERT INTO daily_rewards (item_data) VALUES (?)");
        if ($stmt === false) throw new RuntimeException($this->db->error);
        $stmt->bind_param('s', $itemData);
        $stmt->execute();
        $stmt->close();
    }

    public function removeReward(int $id): void {
        $stmt = $this->db->prepare("DELETE FROM daily_rewards WHERE id=?");
        if ($stmt === false) throw new RuntimeException($this->db->error);
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $stmt->close();
    }

    public function clearRewards(): void {
        $this->db->query("DELETE FROM daily_rewards");
    }

    // ── 월 초기화 ────────────────────────────────────────────

    public function getLastResetMonth(): string {
        $result = $this->db->query("SELECT setting_value FROM daily_settings WHERE setting_key='last_reset_month'");
        if ($result === false || $result->num_rows === 0) return '';
        $row = $result->fetch_assoc();
        $result->free();
        return $row['setting_value'] ?? '';
    }

    public function setLastResetMonth(string $month): void {
        $this->db->query("
            INSERT INTO daily_settings (setting_key, setting_value) VALUES ('last_reset_month', '{$this->db->real_escape_string($month)}')
            ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)
        ");
    }

    public function resetOldCheckHistory(): void {
        $this->db->query("DELETE FROM daily_check_history WHERE DATE_FORMAT(check_date, '%Y-%m') != DATE_FORMAT(NOW(), '%Y-%m')");
    }

    /** 이번 달 출석일 수 반환 */
    public function getMonthCheckedCount(string $name): int {
        $stmt = $this->db->prepare(
            "SELECT COUNT(*) AS cnt FROM daily_check_history
             WHERE player_name=? AND DATE_FORMAT(check_date,'%Y-%m')=DATE_FORMAT(NOW(),'%Y-%m')"
        );
        if ($stmt === false) return 0;
        $stmt->bind_param('s', $name);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return (int) ($row['cnt'] ?? 0);
    }

    public function close(): void {
        $this->db->close();
    }
}
