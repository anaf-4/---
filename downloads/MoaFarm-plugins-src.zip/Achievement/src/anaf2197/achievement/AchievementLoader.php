<?php
declare(strict_types=1);

namespace anaf2197\achievement;

use muqsit\invmenu\InvMenu;
use muqsit\invmenu\InvMenuHandler;
use muqsit\invmenu\transaction\InvMenuTransaction;
use muqsit\invmenu\transaction\InvMenuTransactionResult;
use muqsit\invmenu\type\InvMenuTypeIds;
use pocketmine\inventory\Inventory;
use pocketmine\item\StringToItemParser;
use pocketmine\item\Item;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\scheduler\ClosureTask;
use pocketmine\Server;
use pocketmine\utils\SingletonTrait;
use anaf2197\achievement\command\AchievementAdminCommand;
use anaf2197\achievement\command\AchievementCommand;
use anaf2197\achievement\form\AchievementCategoryForm;
use anaf2197\achievement\form\AchievementPlayerDetailForm;
use anaf2197\advancedprefix\AdvancedPrefix;
use anaf2197\deliveryapi\DeliveryAPI;
use anaf2197\lib\color\ServerColor;

final class AchievementLoader extends PluginBase {

    use SingletonTrait;

    public static string $prefix;

    private \mysqli $db;

    /** @var PlayerAchievement[] lower_name => PlayerAchievement */
    private array $playerCache = [];

    /** @var Achievement[] id => Achievement */
    private array $achievements = [];

    /** @var string[] IDs that have a row in achievement_definitions */
    private array $customIds = [];

    /** @var string[] IDs that are in DB but NOT in YML (truly admin-created, deletable) */
    private array $dbOnlyIds = [];

    /** @var array<string, Item[]> achievementId => Item[] */
    private array $rewardItems = [];

    private const TYPE_LABELS = [
        Achievement::TYPE_MINING       => '채광',
        Achievement::TYPE_HUNTING      => '사냥',
        Achievement::TYPE_ECONOMY      => '경제',
        Achievement::TYPE_GUILD        => '길드',
        Achievement::TYPE_FISHING      => '낚시',
        Achievement::TYPE_RECOMMEND    => '추천',
        Achievement::TYPE_EXCAVATION   => '발굴',
        Achievement::TYPE_LOGGING      => '벌목',
        Achievement::TYPE_FARMING      => '농사',
        Achievement::TYPE_QUEST        => '퀘스트',
        Achievement::TYPE_MARRIAGE     => '결혼',
        Achievement::TYPE_AUCTION      => '경매장',
        Achievement::TYPE_ATTENDANCE   => '출석',
        Achievement::TYPE_PARTY        => '파티',
        Achievement::TYPE_LEVEL        => '레벨',
        Achievement::TYPE_PLAYTIME     => '플레이타임',
        Achievement::TYPE_TRADE        => '거래',
        Achievement::TYPE_COLLECT      => '수집',
        Achievement::TYPE_CRAFT        => '제작',
        Achievement::TYPE_FISHING_RARE => '낚시(레어)',
        Achievement::TYPE_RUNE         => '룬',
        Achievement::TYPE_UPGRADE        => '강화',
        Achievement::TYPE_ENFORCE_LEVEL  => '강화 레벨',
    ];

    // ─── 공통 MySQL 설정 로드 ─────────────────────────────────────────────

    private function loadMysqlConfig(): array {
        $sharedPath = $this->getServer()->getDataPath() . 'plugins/mysql_shared.yml';
        if (file_exists($sharedPath)) {
            $shared = new \pocketmine\utils\Config($sharedPath);
            $cfg = $shared->get('mysql', null);
            if (is_array($cfg)) return $cfg;
        }
        return (array) $this->getConfig()->get('mysql', []);
    }

    // ─── 생명주기 ────────────────────────────────────────────────────────────

    protected function onLoad(): void {
        self::setInstance($this);
        ServerColor::setPrefix($this, '업적');
    }

    protected function onEnable(): void {
        $this->saveDefaultConfig();
        if (!$this->connectDb()) return;
        $this->initTables();
        $this->saveResource('achievements.yml', false);
        $this->loadAchievements();
        $this->loadRewardItems();

        $pm = $this->getServer()->getPluginManager();
        $pm->registerEvents(new AchievementListener(), $this);

        // EconomyAPI: 돈 획득 업적
        if ($pm->getPlugin('EconomyAPI') !== null) {
            $pm->registerEvent(
                \anaf2197\economyapi\event\AddMoneyEvent::class,
                function (\anaf2197\economyapi\event\AddMoneyEvent $event): void {
                    $player = Server::getInstance()->getPlayerExact($event->getPlayer());
                    if ($player instanceof Player) {
                        $this->addProgress($player, Achievement::TYPE_ECONOMY, (int) $event->getAmount());
                    }
                },
                \pocketmine\event\EventPriority::NORMAL,
                $this
            );
        }

        // Fishing: 낚시 업적
        if ($pm->getPlugin('Fishing') !== null) {
            $pm->registerEvent(
                \anaf2197\fishing\event\FishingEvent::class,
                function (\anaf2197\fishing\event\FishingEvent $event): void {
                    $this->addProgress($event->getPlayer(), Achievement::TYPE_FISHING);
                },
                \pocketmine\event\EventPriority::NORMAL,
                $this
            );
        }

        // AuctionHouse: 경매 거래 업적 (#38)
        if ($pm->getPlugin('AuctionHouse') !== null) {
            $pm->registerEvent(
                \anaf2197\auctionhouse\event\BuyAuctionItemEvent::class,
                function (\anaf2197\auctionhouse\event\BuyAuctionItemEvent $event): void {
                    if (!$event->isCancelled()) {
                        $this->addProgress($event->getPlayer(), Achievement::TYPE_AUCTION);
                    }
                },
                \pocketmine\event\EventPriority::MONITOR,
                $this
            );
        }

        // AdvancedLevel: 레벨 업적 (#1)
        if ($pm->getPlugin('AdvancedLevel') !== null) {
            $pm->registerEvent(
                \anaf2197\advancedlevel\event\LevelUpEvent::class,
                function (\anaf2197\advancedlevel\event\LevelUpEvent $event): void {
                    $level = $event->getNewLevel();
                    $pa    = $this->getPlayerAchievement($event->getPlayer());
                    if ($pa === null) return;
                    $cur = $pa->getProgress(Achievement::TYPE_LEVEL);
                    if ($level > $cur) {
                        $this->addProgress($event->getPlayer(), Achievement::TYPE_LEVEL, $level - $cur);
                    }
                },
                \pocketmine\event\EventPriority::MONITOR,
                $this
            );
        }

        // PlayerTrade: 거래 업적은 PlayerTrade::executeTrade()에서 직접 addProgress() 호출
        // (TradeCompleteEvent 클래스가 없으므로 registerEvent 사용 불가)

        // RuneSystem: 룬 장착 업적은 RuneSystem RuneForm::handleConfirm()에서 직접 addProgress() 호출
        // (RuneEngraveEvent 클래스가 없으므로 registerEvent 사용 불가)

        // UpgradeTools: 강화 업적은 UpgradeTools CheckUpgradeForm::handleResponse()에서 직접 addProgress() 호출
        // (UpgradeSuccessEvent 클래스가 없으므로 registerEvent 사용 불가)

        // Collector: 수집 업적은 Collection::complete()에서 직접 addProgress() 호출
        // (CollectItemEvent 클래스가 없으므로 registerEvent 사용 불가)

        // 아이템 제작 업적 (#6)
        $pm->registerEvent(
            \pocketmine\event\inventory\CraftItemEvent::class,
            function (\pocketmine\event\inventory\CraftItemEvent $event): void {
                if (!$event->isCancelled()) {
                    $this->addProgress($event->getTransaction()->getSource(), Achievement::TYPE_CRAFT);
                }
            },
            \pocketmine\event\EventPriority::MONITOR,
            $this
        );

        // Fishing: 레어 낚시 업적은 Fisherman::stop()에서 TIER_L 감지 후 직접 addProgress() 호출
        // (FishingRareEvent 클래스가 없으므로 registerEvent 사용 불가)

        // Guild: 길드 가입 업적 (#32)
        if ($pm->getPlugin('Guild') !== null) {
            $pm->registerEvent(
                \anaf2197\guild\event\JoinGuildEvent::class,
                function (\anaf2197\guild\event\JoinGuildEvent $event): void {
                    $player = Server::getInstance()->getPlayerExact($event->getPlayer());
                    if ($player instanceof Player) {
                        $this->addProgress($player, Achievement::TYPE_GUILD);
                    }
                },
                \pocketmine\event\EventPriority::MONITOR,
                $this
            );
        }

        // PlayTime: 플레이타임 업적 (로그아웃 시 총 시간 동기화) (#2)
        if ($pm->getPlugin('PlayTime') !== null) {
            $pm->registerEvent(
                \pocketmine\event\player\PlayerQuitEvent::class,
                function (\pocketmine\event\player\PlayerQuitEvent $event): void {
                    $player  = $event->getPlayer();
                    $seconds = \anaf2197\playtime\PlayTime::getInstance()->getPlayTime($player);
                    $hours   = (int) ($seconds / 3600);
                    if ($hours <= 0) return;
                    $pa  = $this->getPlayerAchievement($player);
                    if ($pa === null) return;
                    $cur = $pa->getProgress(Achievement::TYPE_PLAYTIME);
                    if ($hours > $cur) {
                        $this->addProgress($player, Achievement::TYPE_PLAYTIME, $hours - $cur);
                    }
                },
                \pocketmine\event\EventPriority::MONITOR,
                $this
            );
        }

        $cmdMap = $this->getServer()->getCommandMap();
        $cmdMap->registerAll(strtolower($this->getName()), [
            new AchievementCommand(),
            new AchievementAdminCommand(),
            new \anaf2197\achievement\command\AchievementPointsCommand(),
            new \anaf2197\achievement\command\AchievementShopPriceCommand(),
            new \anaf2197\achievement\command\HallOfFameCommand(),
        ]);

        // 명예의 전당 NPC 엔티티 등록
        \pocketmine\entity\EntityFactory::getInstance()->register(
            \anaf2197\achievement\entity\HallOfFameNPC::class,
            function (\pocketmine\world\World $world, \pocketmine\nbt\tag\CompoundTag $nbt): \anaf2197\achievement\entity\HallOfFameNPC {
                return new \anaf2197\achievement\entity\HallOfFameNPC(\pocketmine\entity\EntityDataHelper::parseLocation($nbt, $world), $nbt);
            },
            ['moafarm:hall_of_fame_npc']
        );

        if (!InvMenuHandler::isRegistered()) {
            InvMenuHandler::register($this);
        }
    }

    protected function onDisable(): void {
        if (isset($this->db)) {
            foreach (array_keys($this->playerCache) as $key) {
                $this->savePlayerData($key);
            }
            $this->playerCache = [];
            $this->saveRewardItems();
            $this->db->close();
        }
    }

    // ─── MySQL ───────────────────────────────────────────────────────────────

    private function connectDb(): bool {
        $cfg    = $this->loadMysqlConfig();
        $host   = (string) ($cfg['host'] ?? '127.0.0.1');
        $port   = (int) ($cfg['port'] ?? 3306);
        $user   = (string) ($cfg['user'] ?? 'root');
        $pass   = (string) ($cfg['password'] ?? '');
        $dbName = (string) ($cfg['database'] ?? 'moafarm');

        try {
            $this->db = new \mysqli($host, $user, $pass, $dbName, $port);
        } catch (\mysqli_sql_exception $e) {
            $this->getLogger()->error('MySQL 연결 실패: ' . $e->getMessage());
            $this->getServer()->getPluginManager()->disablePlugin($this);
            return false;
        }
        if ($this->db->connect_error) {
            $this->getLogger()->error('MySQL 연결 실패: ' . $this->db->connect_error);
            $this->getServer()->getPluginManager()->disablePlugin($this);
            return false;
        }
        $this->db->set_charset('utf8mb4');
        return true;
    }

    private function ensureConnected(): void {
        try {
            if (!@$this->db->ping()) $this->connectDb();
        } catch (\Throwable) {
            $this->connectDb();
        }
    }

    private function initTables(): void {
        // 업적 포인트 테이블 (#29)
        $this->db->query('CREATE TABLE IF NOT EXISTS achievement_points (
            player VARCHAR(100) NOT NULL PRIMARY KEY,
            points INT NOT NULL DEFAULT 0
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');

        // 업적상점 가격 오버라이드 테이블 (#29)
        $this->db->query('CREATE TABLE IF NOT EXISTS achievement_shop_prices (
            item_index INT NOT NULL PRIMARY KEY,
            cost INT NOT NULL DEFAULT 0
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');

        $this->db->query('CREATE TABLE IF NOT EXISTS achievement_progress (
            player VARCHAR(100) NOT NULL,
            type VARCHAR(50) NOT NULL,
            value BIGINT NOT NULL DEFAULT 0,
            PRIMARY KEY (player, type)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');

        $this->db->query('CREATE TABLE IF NOT EXISTS achievement_completed (
            player VARCHAR(100) NOT NULL,
            achievement_id VARCHAR(100) NOT NULL,
            completed_at INT NOT NULL DEFAULT 0,
            PRIMARY KEY (player, achievement_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');

        $this->db->query('CREATE TABLE IF NOT EXISTS achievement_reward_items (
            achievement_id VARCHAR(100) NOT NULL PRIMARY KEY,
            items TEXT NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');

        $this->db->query('CREATE TABLE IF NOT EXISTS achievement_definitions (
            id VARCHAR(100) NOT NULL PRIMARY KEY,
            name VARCHAR(200) NOT NULL,
            description TEXT NOT NULL,
            type VARCHAR(50) NOT NULL,
            target BIGINT NOT NULL DEFAULT 1,
            reward_money BIGINT NOT NULL DEFAULT 0,
            reward_prefix VARCHAR(200) NOT NULL DEFAULT "",
            rarity TINYINT NOT NULL DEFAULT 0
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');

        // 서버 최초 달성 기록 테이블
        $this->db->query('CREATE TABLE IF NOT EXISTS server_firsts (
            achievement_key VARCHAR(100) NOT NULL PRIMARY KEY,
            player_name     VARCHAR(64)  NOT NULL,
            achieved_at     TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');

        // 기존 테이블에 rarity 컬럼 추가 (없을 때만)
        try {
            $this->db->query('ALTER TABLE achievement_definitions ADD COLUMN rarity TINYINT NOT NULL DEFAULT 0');
        } catch (\mysqli_sql_exception) { /* 이미 존재 */ }
        // completed_at 컬럼 추가
        try {
            $this->db->query('ALTER TABLE achievement_completed ADD COLUMN completed_at INT NOT NULL DEFAULT 0');
        } catch (\mysqli_sql_exception) { /* 이미 존재 */ }
    }

    // ─── 업적 정의 로드 ──────────────────────────────────────────────────────

    private function loadAchievements(): void {
        $ymlIds = [];
        $config = new \pocketmine\utils\Config($this->getDataFolder() . 'achievements.yml');
        foreach ($config->get('achievements', []) as $id => $data) {
            $description = (string) ($data['description'] ?? '');
            if ($description === '') {
                $description = Achievement::autoDescription($data['type'], (int) ($data['target'] ?? 1));
            }
            $this->achievements[$id] = new Achievement(
                $id,
                $data['name'],
                $description,
                $data['type'],
                (int) $data['target'],
                (int) ($data['reward_money'] ?? 0),
                (string) ($data['reward_prefix'] ?? ''),
                (int) ($data['rarity'] ?? Achievement::RARITY_COMMON),
                (string) ($data['reward_title'] ?? ''),
            );
            $ymlIds[] = $id;
        }

        $result = $this->db->query('SELECT * FROM achievement_definitions');
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $id          = $row['id'];
                $description = $row['description'];
                if ($description === '') {
                    $description = Achievement::autoDescription($row['type'], (int) $row['target']);
                }
                $this->achievements[$id] = new Achievement(
                    $id,
                    $row['name'],
                    $description,
                    $row['type'],
                    (int) $row['target'],
                    (int) $row['reward_money'],
                    $row['reward_prefix'],
                    (int) ($row['rarity'] ?? 0),
                );
                $this->customIds[] = $id;
                if (!in_array($id, $ymlIds, true)) {
                    $this->dbOnlyIds[] = $id;
                }
            }
        }
    }

    // ─── 업적 정의 관리 ──────────────────────────────────────────────────────

    public function saveDefinition(Achievement $achievement): void {
        $this->ensureConnected();
        $stmt = $this->db->prepare('REPLACE INTO achievement_definitions
            (id, name, description, type, target, reward_money, reward_prefix, rarity)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->bind_param('ssssiisi',
            $achievement->id, $achievement->name, $achievement->description,
            $achievement->type, $achievement->target, $achievement->rewardMoney,
            $achievement->rewardPrefix, $achievement->rarity
        );
        $stmt->execute();
        $stmt->close();

        $this->achievements[$achievement->id] = $achievement;
        if (!in_array($achievement->id, $this->customIds, true)) $this->customIds[] = $achievement->id;
        if (!in_array($achievement->id, $this->dbOnlyIds, true)) $this->dbOnlyIds[] = $achievement->id;
    }

    public function deleteDefinition(string $id): bool {
        if (!in_array($id, $this->dbOnlyIds, true)) return false;

        $this->ensureConnected();
        foreach (['achievement_definitions', 'achievement_completed', 'achievement_reward_items'] as $table) {
            $col  = $table === 'achievement_completed' ? 'achievement_id' : 'id';
            $stmt = $this->db->prepare("DELETE FROM {$table} WHERE {$col} = ?");
            $stmt->bind_param('s', $id);
            $stmt->execute();
            $stmt->close();
        }

        unset($this->achievements[$id], $this->rewardItems[$id]);
        $this->customIds = array_values(array_filter($this->customIds, fn($v) => $v !== $id));
        $this->dbOnlyIds = array_values(array_filter($this->dbOnlyIds, fn($v) => $v !== $id));
        return true;
    }

    public function isCustomAchievement(string $id): bool {
        return in_array($id, $this->customIds, true);
    }

    public function isDbOnlyAchievement(string $id): bool {
        return in_array($id, $this->dbOnlyIds, true);
    }

    public function getAchievement(string $id): ?Achievement {
        return $this->achievements[$id] ?? null;
    }

    public function getAchievementName(string $id): ?string {
        return $this->achievements[$id]?->name ?? null;
    }

    public function getTypeLabel(string $type): string {
        return self::TYPE_LABELS[$type] ?? $type;
    }

    /** @return Achievement[] */
    public function getAchievements(): array {
        return $this->achievements;
    }

    // ─── 검색 ────────────────────────────────────────────────────────────────

    /** @return Achievement[] */
    public function searchAchievements(string $keyword): array {
        $kw = mb_strtolower($keyword);
        return array_filter($this->achievements, fn(Achievement $a) =>
            mb_strpos(mb_strtolower($a->name), $kw) !== false ||
            mb_strpos(mb_strtolower($a->description), $kw) !== false
        );
    }

    // ─── 리더보드 ─────────────────────────────────────────────────────────────

    /** @return array<string, int> player => 달성 수 (내림차순) */
    public function getTopAchievers(int $n = 10): array {
        $this->ensureConnected();
        $stmt = $this->db->prepare(
            'SELECT player, COUNT(*) AS cnt FROM achievement_completed GROUP BY player ORDER BY cnt DESC LIMIT ?'
        );
        $stmt->bind_param('i', $n);
        $stmt->execute();
        $result = $stmt->get_result();
        $out = [];
        while ($row = $result->fetch_assoc()) {
            $out[$row['player']] = (int) $row['cnt'];
        }
        $stmt->close();
        return $out;
    }

    // ─── 보상 아이템 ─────────────────────────────────────────────────────────

    private function loadRewardItems(): void {
        $this->ensureConnected();
        $result = $this->db->query('SELECT achievement_id, items FROM achievement_reward_items');
        if (!$result) return;
        while ($row = $result->fetch_assoc()) {
            $strings = json_decode($row['items'], true) ?? [];
            $items = [];
            foreach ($strings as $s) {
                try { $items[] = \anaf2197\lib\itemparser\ItemParser::fromString($s); } catch (\Throwable) {}
            }
            if (!empty($items)) $this->rewardItems[$row['achievement_id']] = $items;
        }
    }

    private function saveRewardItems(): void {
        $this->ensureConnected();
        foreach ($this->rewardItems as $id => $items) {
            $this->saveRewardItemsForId($id);
        }
    }

    private function saveRewardItemsForId(string $id): void {
        $this->ensureConnected();
        $items   = $this->rewardItems[$id] ?? [];
        $strings = json_encode(array_values(array_map(
            fn(Item $i) => \anaf2197\lib\itemparser\ItemParser::toString($i), $items
        )));
        $stmt = $this->db->prepare('REPLACE INTO achievement_reward_items (achievement_id, items) VALUES (?, ?)');
        $stmt->bind_param('ss', $id, $strings);
        $stmt->execute();
        $stmt->close();
    }

    // ─── 플레이어 데이터 ─────────────────────────────────────────────────────

    public function loadPlayer(Player $player): void {
        $key = strtolower($player->getName());
        if (isset($this->playerCache[$key])) return;

        $this->ensureConnected();
        $progress = [];
        $stmt = $this->db->prepare('SELECT type, value FROM achievement_progress WHERE player = ?');
        $stmt->bind_param('s', $key);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $progress[$row['type']] = (int) $row['value'];
        }
        $stmt->close();

        $completed = [];
        $stmt = $this->db->prepare('SELECT achievement_id FROM achievement_completed WHERE player = ?');
        $stmt->bind_param('s', $key);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $completed[] = $row['achievement_id'];
        }
        $stmt->close();

        $this->playerCache[$key] = new PlayerAchievement($key, $progress, $completed);
    }

    public function savePlayer(Player $player): void {
        $key = strtolower($player->getName());
        $this->savePlayerData($key);
        unset($this->playerCache[$key]);
    }

    private function savePlayerData(string $key): void {
        $pa = $this->playerCache[$key] ?? null;
        if ($pa === null) return;

        $this->ensureConnected();
        $this->db->begin_transaction();
        try {
            $stmt = $this->db->prepare('REPLACE INTO achievement_progress (player, type, value) VALUES (?, ?, ?)');
            foreach ($pa->getAllProgress() as $type => $value) {
                $stmt->bind_param('ssi', $key, $type, $value);
                $stmt->execute();
            }
            $stmt->close();

            $now  = time();
            $stmt = $this->db->prepare('INSERT IGNORE INTO achievement_completed (player, achievement_id, completed_at) VALUES (?, ?, ?)');
            foreach ($pa->getCompleted() as $achievementId) {
                $stmt->bind_param('ssi', $key, $achievementId, $now);
                $stmt->execute();
            }
            $stmt->close();

            $this->db->commit();
        } catch (\Throwable $e) {
            $this->db->rollback();
            $this->getLogger()->error('업적 데이터 저장 실패 (' . $key . '): ' . $e->getMessage());
        }
    }

    public function getPlayerAchievement(Player $player): ?PlayerAchievement {
        return $this->playerCache[strtolower($player->getName())] ?? null;
    }

    public function initPlayerAchievement(Player $player): void {
        $this->loadPlayer($player);
    }

    // ─── 진행도 처리 ─────────────────────────────────────────────────────────

    public function addProgress(Player $player, string $type, int $amount = 1): void {
        $data = $this->getPlayerAchievement($player);
        if (!$data instanceof PlayerAchievement) return;

        $oldProgress     = $data->getProgress($type);
        $data->addProgress($type, $amount);
        $currentProgress = $data->getProgress($type);

        foreach ($this->achievements as $achievement) {
            if ($achievement->type !== $type) continue;
            if ($data->isCompleted($achievement->id)) continue;

            if ($currentProgress >= $achievement->target) {
                $data->markCompleted($achievement->id);
                $this->savePlayerData(strtolower($player->getName()));
                $this->deliverReward($player, $achievement);
            } else {
                $t      = max(1, $achievement->target);
                $oldPct = (int) min(100, $oldProgress / $t * 100);
                $newPct = (int) min(100, $currentProgress / $t * 100);
                if ($oldPct < 90 && $newPct >= 90) {
                    $player->sendMessage(self::$prefix . '"§f' . $achievement->name . '§r" §e90%§8 달성! 거의 완료됐어요!');
                } elseif ($oldPct < 50 && $newPct >= 50) {
                    $player->sendMessage(self::$prefix . '"§f' . $achievement->name . '§r" §a50%§8 달성!');
                }
            }
        }
    }

    /** 플레이어의 TYPE_RECOMMEND 진행도를 총 추천 횟수에 맞게 동기화 */
    public function syncRecommendProgress(Player $player, int $totalVotes): void {
        $data = $this->getPlayerAchievement($player);
        if ($data === null) return;
        $current = $data->getProgress(Achievement::TYPE_RECOMMEND);
        if ($totalVotes > $current) {
            $this->addProgress($player, Achievement::TYPE_RECOMMEND, $totalVotes - $current);
        }
    }

    private function deliverReward(Player $player, Achievement $achievement): void {
        $items   = $this->rewardItems[$achievement->id] ?? [];
        $mailBox = DeliveryAPI::getInstance()->getMailBox($player);
        if ($mailBox !== null) {
            $money = $achievement->rewardMoney > 0 ? $achievement->rewardMoney : null;
            $mailBox->new('§6[업적] §f' . $achievement->name, $items, $money, '업적 시스템');
        }

        // AdvancedPrefix 칭호 지급
        if ($achievement->rewardPrefix !== '' && class_exists(AdvancedPrefix::class)) {
            $pp = AdvancedPrefix::getInstance()->getPlayerPrefix($player);
            if ($pp !== null && !$pp->hasPrefix($achievement->rewardPrefix)) {
                $pp->addPrefix($achievement->rewardPrefix);
                $player->sendMessage(self::$prefix . '새 칭호를 획득했습니다: §r' . $achievement->rewardPrefix);
            }
        }

        // TitleCollection 칭호 자동 해금 (#14, #34)
        if (($achievement->rewardTitle ?? '') !== '' && class_exists(\anaf2197\titlecollection\TitleCollectionLoader::class)) {
            \anaf2197\titlecollection\TitleCollectionLoader::getInstance()->grantTitle($player, $achievement->rewardTitle);
        }

        // 업적 포인트 지급 (#29)
        $points = Achievement::getRarityPoints($achievement->rarity);
        $this->addPoints(strtolower($player->getName()), $points);
        $player->sendMessage(self::$prefix . '§e+' . $points . '포인트 §8획득! (업적 상점: §f/업적상점§8)');

        // 희귀도에 따른 타이틀 색상
        $rarityColor = Achievement::getRarityColor($achievement->rarity);
        $rarityLabel = Achievement::getRarityLabel($achievement->rarity);

        // LEGENDARY 특수 연출 (#43)
        if ($achievement->rarity === Achievement::RARITY_LEGENDARY) {
            $pos = $player->getPosition();
            $world = $player->getWorld();
            $world->addParticle($pos, new \pocketmine\world\particle\TotemParticle());
            $world->addSound($pos->asVector3(), new \pocketmine\world\sound\TotemUseSound());
            $player->sendTitle('§6§l전설 달성!', '§r§f' . $achievement->name, 10, 60, 20);
        } else {
            $player->sendTitle($rarityColor . '§l업적 달성!', '§r§f' . $achievement->name . ' ' . $rarityLabel);
        }

        $player->sendMessage(self::$prefix . '§l§6[업적 달성] §r§f' . $achievement->name . ' ' . $rarityLabel . ' §8— 보상이 우편함으로 전송됐습니다.');

        // 레어 이상: 서버 전체 방송
        if ($achievement->rarity >= Achievement::RARITY_RARE) {
            $server = Server::getInstance();
            $server->broadcastMessage(' ');

            // 서버 최초 달성 여부 확인 및 특별 메시지
            $isFirst = $this->checkAndMarkFirst($achievement->id, $player->getName());
            if ($isFirst) {
                $server->broadcastMessage('§l§e★ 서버 최초 달성 ★');
                $server->broadcastMessage('§e§l' . $player->getName() . ' §r§6님이 서버 최초로 §f"' . $achievement->name . '"§6 업적을 달성했습니다!');
            } else {
                $server->broadcastMessage($rarityColor . '§l업적 달성 §r' . $rarityLabel . ' §f' . $player->getName() . '§8 님이 §f"' . $achievement->name . '"§8 업적을 달성했습니다!');
            }

            $server->broadcastMessage(' ');
        }

        // WeeklyRanking 경제 보너스
        if (class_exists(\anaf2197\weeklyranking\WeeklyRankingLoader::class)) {
            $bonus = Achievement::getRarityEconomyBonus($achievement->rarity);
            \anaf2197\weeklyranking\WeeklyRankingLoader::getInstance()->addScore(
                \anaf2197\weeklyranking\WeeklyRankingLoader::CAT_ECONOMY,
                $player->getName(),
                $bonus
            );
        }

        // DailyMission 진행도 알림
        if (class_exists(\anaf2197\dailymission\DailyMissionLoader::class)) {
            \anaf2197\dailymission\DailyMissionLoader::getInstance()->onAchievementComplete($player);
        }
    }

    // ─── 서버 최초 달성 ─────────────────────────────────────────────────────

    /** 해당 achievement_key로 서버 최초 달성이면 DB에 기록하고 true 반환. 이미 기록 있으면 false */
    public function checkAndMarkFirst(string $key, string $playerName): bool {
        $this->ensureConnected();
        $stmt = $this->db->prepare('SELECT player_name FROM server_firsts WHERE achievement_key = ?');
        $stmt->bind_param('s', $key);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($row !== null) return false; // 이미 달성자 있음

        $stmt = $this->db->prepare('INSERT IGNORE INTO server_firsts (achievement_key, player_name) VALUES (?, ?)');
        $stmt->bind_param('ss', $key, $playerName);
        $stmt->execute();
        $affected = $stmt->affected_rows;
        $stmt->close();
        return $affected > 0;
    }

    /** 서버 최초 달성 기록 전체 반환 [{achievement_key, player_name, achieved_at}] */
    public function getServerFirsts(): array {
        $this->ensureConnected();
        $result = $this->db->query('SELECT achievement_key, player_name, achieved_at FROM server_firsts ORDER BY achieved_at ASC');
        if (!$result) return [];
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        $result->free();
        return $rows;
    }

    // ─── 업적 포인트 (#29) ──────────────────────────────────────────────────

    public function addPoints(string $playerKey, int $amount): void {
        $this->ensureConnected();
        $stmt = $this->db->prepare('INSERT INTO achievement_points (player, points) VALUES (?, ?)
            ON DUPLICATE KEY UPDATE points = points + ?');
        if ($stmt === false) {
            $this->getLogger()->error('addPoints prepare 실패: ' . $this->db->error);
            return;
        }
        $stmt->bind_param('sii', $playerKey, $amount, $amount);
        if (!$stmt->execute()) {
            $this->getLogger()->error('addPoints execute 실패: ' . $stmt->error);
        }
        $stmt->close();
    }

    public function getPoints(string $playerKey): int {
        $this->ensureConnected();
        $stmt = $this->db->prepare('SELECT points FROM achievement_points WHERE player = ?');
        $stmt->bind_param('s', $playerKey);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return (int) ($row['points'] ?? 0);
    }

    public function spendPoints(string $playerKey, int $amount): bool {
        $current = $this->getPoints($playerKey);
        if ($current < $amount) return false;
        $this->ensureConnected();
        $stmt = $this->db->prepare('UPDATE achievement_points SET points = points - ? WHERE player = ? AND points >= ?');
        $stmt->bind_param('isi', $amount, $playerKey, $amount);
        $stmt->execute();
        $affected = $stmt->affected_rows;
        $stmt->close();
        return $affected > 0;
    }

    // ─── 업적상점 가격 오버라이드 (#29) ─────────────────────────────────────

    /** @return array<int,int> item_index => cost */
    public function getShopPriceOverrides(): array {
        $this->ensureConnected();
        $result = $this->db->query('SELECT item_index, cost FROM achievement_shop_prices');
        $out = [];
        if ($result !== false) {
            foreach ($result->fetch_all(MYSQLI_ASSOC) as $row) {
                $out[(int) $row['item_index']] = (int) $row['cost'];
            }
        }
        return $out;
    }

    public function setShopPrice(int $index, int $cost): void {
        $this->ensureConnected();
        $stmt = $this->db->prepare('INSERT INTO achievement_shop_prices (item_index, cost) VALUES (?, ?)
            ON DUPLICATE KEY UPDATE cost = ?');
        if ($stmt === false) {
            $this->getLogger()->error('setShopPrice prepare 실패: ' . $this->db->error);
            return;
        }
        $stmt->bind_param('iii', $index, $cost, $cost);
        if (!$stmt->execute()) {
            $this->getLogger()->error('setShopPrice execute 실패: ' . $stmt->error);
        }
        $stmt->close();
    }

    public function getPointsLeaderboard(int $limit = 10): array {
        $this->ensureConnected();
        $stmt = $this->db->prepare('SELECT player, points FROM achievement_points ORDER BY points DESC LIMIT ?');
        $stmt->bind_param('i', $limit);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        return $rows;
    }

    // ─── 관리자 기능 ─────────────────────────────────────────────────────────

    public function forceGrant(string $playerName, string $achievementId, Player $admin): void {
        $achievement = $this->achievements[$achievementId] ?? null;
        if ($achievement === null) {
            $admin->sendMessage(self::$prefix . '§c존재하지 않는 업적 ID: ' . $achievementId);
            return;
        }

        $key    = strtolower($playerName);
        $online = Server::getInstance()->getPlayerExact($playerName);

        if ($online instanceof Player) {
            $data = $this->getPlayerAchievement($online);
            if ($data !== null && $data->isCompleted($achievementId)) {
                $admin->sendMessage(self::$prefix . '§c' . $playerName . '님은 이미 해당 업적을 달성했습니다.');
                return;
            }
            if ($data !== null) {
                $data->markCompleted($achievementId);
                $this->savePlayerData($key);
            }
            $this->deliverReward($online, $achievement);
        } else {
            $this->ensureConnected();
            $now  = time();
            $stmt = $this->db->prepare('INSERT IGNORE INTO achievement_completed (player, achievement_id, completed_at) VALUES (?, ?, ?)');
            $stmt->bind_param('ssi', $key, $achievementId, $now);
            $stmt->execute();
            $affected = $stmt->affected_rows;
            $stmt->close();

            if ($affected === 0) {
                $admin->sendMessage(self::$prefix . '§c' . $playerName . '님은 이미 해당 업적을 달성했습니다. (오프라인)');
                return;
            }

            $mailBox = DeliveryAPI::getInstance()->getMailBox($key);
            if ($mailBox !== null) {
                $items = $this->rewardItems[$achievementId] ?? [];
                $money = $achievement->rewardMoney > 0 ? $achievement->rewardMoney : null;
                $mailBox->new('§6[업적] §f' . $achievement->name, $items, $money, '업적 시스템');
            }
        }

        $admin->sendMessage(self::$prefix . '§a' . $playerName . '님에게 "' . $achievement->name . '" 업적을 지급했습니다.');
    }

    public function resetPlayerAchievements(string $playerName, Player $admin): void {
        $key = strtolower($playerName);
        $this->ensureConnected();

        foreach (['achievement_progress', 'achievement_completed'] as $table) {
            $stmt = $this->db->prepare("DELETE FROM {$table} WHERE player = ?");
            $stmt->bind_param('s', $key);
            $stmt->execute();
            $stmt->close();
        }

        unset($this->playerCache[$key]);
        $online = Server::getInstance()->getPlayerExact($playerName);
        if ($online instanceof Player) $this->loadPlayer($online);

        $admin->sendMessage(self::$prefix . '§a' . $playerName . '님의 업적 데이터를 초기화했습니다.');
    }

    // ─── GUI ─────────────────────────────────────────────────────────────────

    public function openAchievementCategoryForm(Player $player): void {
        $data = $this->getPlayerAchievement($player);
        $player->sendForm(new AchievementCategoryForm($this->achievements, $data));
    }

    public function openAchievementGui(Player $player, ?string $typeFilter = null): void {
        $data = $this->getPlayerAchievement($player);
        if (!$data instanceof PlayerAchievement) return;

        $menu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
        $menu->setName($typeFilter !== null
            ? '§l§6업적: ' . $this->getTypeLabel($typeFilter)
            : '§l§6전체 업적');

        $inv     = $menu->getInventory();
        $slotMap = [];
        $slot    = 0;

        foreach ($this->achievements as $achievement) {
            if ($typeFilter !== null && $achievement->type !== $typeFilter) continue;

            $completed = $data->isCompleted($achievement->id);
            $progress  = $data->getProgress($achievement->type);
            $pct       = min(100, (int) ($progress / max(1, $achievement->target) * 100));
            $filled    = (int) ($pct / 5);
            $bar       = '§a' . str_repeat('█', $filled) . '§8' . str_repeat('█', 20 - $filled);

            $rarityColor = Achievement::getRarityColor($achievement->rarity);
            $rarityLabel = Achievement::getRarityLabel($achievement->rarity);

            if ($completed) {
                $iconName = Achievement::getCompletedIcon($achievement->rarity);
                $icon     = StringToItemParser::getInstance()->parse($iconName) ?? VanillaItems::GOLD_INGOT();
                $icon->setCustomName('§r§l' . $rarityColor . $achievement->name . ' ' . $rarityLabel . ' §a[달성!]');
            } else {
                $icon = VanillaItems::BOOK();
                $icon->setCustomName('§r§l§8' . $achievement->name . ' ' . $rarityLabel);
            }

            $lore = [
                ' ',
                '§r§f' . $achievement->description,
                ' ',
                '§r§8진행도',
                '§r' . $bar . ' §f' . $pct . '%',
                '§r§8' . number_format($progress) . ' / ' . number_format($achievement->target),
                ' ',
                '§r§8보상금: §e' . number_format($achievement->rewardMoney) . '원',
            ];
            if ($achievement->rewardPrefix !== '') {
                $lore[] = '§r§8칭호: §r' . $achievement->rewardPrefix;
            }
            if (!empty($this->rewardItems[$achievement->id] ?? [])) {
                $names = array_map(fn(Item $i) => $i->getName(), $this->rewardItems[$achievement->id]);
                $lore[] = '§r§8아이템: §f' . implode(', ', $names);
            }
            $lore[] = ' ';
            $lore[] = '§r§8클릭하면 상세 정보를 확인할 수 있습니다.';
            $icon->setLore($lore);

            $slotMap[$slot] = $achievement;
            $inv->setItem($slot++, $icon);
            if ($slot >= 54) break;
        }

        $menu->setListener(function (InvMenuTransaction $t) use ($slotMap, $typeFilter): InvMenuTransactionResult {
            $slot        = $t->getAction()->getSlot();
            $achievement = $slotMap[$slot] ?? null;
            if ($achievement !== null) {
                $p    = $t->getPlayer();
                $data = $this->getPlayerAchievement($p);
                $p->removeCurrentWindow();
                $this->getScheduler()->scheduleDelayedTask(new ClosureTask(
                    function () use ($p, $achievement, $data, $typeFilter): void {
                        if ($p->isConnected()) {
                            $p->sendForm(new AchievementPlayerDetailForm($achievement, $data, $typeFilter));
                        }
                    }
                ), 1);
            }
            return $t->discard();
        });

        $menu->send($player);
    }

    public function openRewardGuiForAchievement(Player $player, string $achievementId): void {
        $achievement = $this->achievements[$achievementId] ?? null;
        if ($achievement === null) return;

        $menu = InvMenu::create(InvMenuTypeIds::TYPE_CHEST);
        $menu->setName('§l§c보상 설정: §f' . $achievement->name);

        $inv = $menu->getInventory();
        foreach ($this->rewardItems[$achievementId] ?? [] as $i => $item) {
            if ($i >= 27) break;
            $inv->setItem($i, $item);
        }

        $menu->setListener(fn(InvMenuTransaction $t): InvMenuTransactionResult => $t->continue($t->getOut(), $t->getIn()));

        $menu->setInventoryCloseListener(function (Player $player, Inventory $inventory) use ($achievementId, $achievement): void {
            $items = array_values($inventory->getContents());
            if (!empty($items)) {
                $this->rewardItems[$achievementId] = $items;
            } else {
                unset($this->rewardItems[$achievementId]);
            }
            $this->saveRewardItemsForId($achievementId);
            $player->sendMessage(self::$prefix . '"' . $achievement->name . '" 보상 아이템을 저장했습니다.');

            $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function () use ($player, $achievement): void {
                if ($player->isConnected()) {
                    $player->sendForm(new \anaf2197\achievement\form\AchievementDetailForm($achievement));
                }
            }), 1);
        });

        $menu->send($player);
    }
}
