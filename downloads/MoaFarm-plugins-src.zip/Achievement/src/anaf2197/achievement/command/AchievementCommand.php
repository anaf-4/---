<?php
declare(strict_types=1);

namespace anaf2197\achievement\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use anaf2197\achievement\AchievementLoader;
use anaf2197\achievement\form\AchievementRankingForm;
use anaf2197\achievement\form\AchievementSearchForm;

final class AchievementCommand extends Command {

    public function __construct() {
        parent::__construct('업적', '업적 목록을 확인합니다.', '/업적 [랭킹|검색 <키워드>]', ['achievement']);
        $this->setPermission('achievement.use');
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if (!$sender instanceof Player) {
            $sender->sendMessage('§c플레이어만 사용 가능합니다.');
            return;
        }

        $loader = AchievementLoader::getInstance();
        $sub    = strtolower($args[0] ?? '');

        switch ($sub) {
            case '랭킹':
                $sender->sendForm(new AchievementRankingForm($loader->getTopAchievers(10), count($loader->getAchievements())));
                break;
            case '검색':
                if (isset($args[1])) {
                    $keyword = implode(' ', array_slice($args, 1));
                    $results = $loader->searchAchievements($keyword);
                    $pa      = $loader->getPlayerAchievement($sender);
                    $sender->sendForm(new AchievementSearchForm($keyword, $results, $pa));
                } else {
                    $sender->sendForm(new AchievementSearchForm('', [], null));
                }
                break;
            default:
                $loader->openAchievementCategoryForm($sender);
                break;
        }
    }
}
