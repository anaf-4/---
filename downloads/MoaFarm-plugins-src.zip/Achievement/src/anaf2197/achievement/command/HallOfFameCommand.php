<?php

declare(strict_types=1);

namespace anaf2197\achievement\command;

use anaf2197\achievement\entity\HallOfFameNPC;
use anaf2197\achievement\form\HallOfFameForm;
use anaf2197\achievement\AchievementLoader;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\EntityFactory;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use pocketmine\world\World;

final class HallOfFameCommand extends Command {

    public function __construct() {
        parent::__construct('명예의전당', '명예의 전당을 확인합니다.', '/명예의전당', ['halloffame']);
        $this->setPermission(DefaultPermissions::ROOT_USER);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if (!$this->testPermission($sender)) return;

        if (!$sender instanceof Player) {
            $sender->sendMessage('§c플레이어만 사용 가능합니다.');
            return;
        }

        // /명예의전당 npc — 현재 위치에 NPC 소환 (관리자 전용)
        if (isset($args[0]) && $args[0] === 'npc') {
            if (!$sender->hasPermission(DefaultPermissions::ROOT_OPERATOR)) {
                $sender->sendMessage(AchievementLoader::$prefix . '권한이 없습니다.');
                return;
            }
            $nbt = EntityDataHelper::createBaseNBT($sender->getPosition());
            $npc = new HallOfFameNPC($sender->getPosition(), $nbt);
            $npc->spawnToAll();
            $sender->sendMessage(AchievementLoader::$prefix . '명예의 전당 NPC가 소환되었습니다.');
            return;
        }

        $sender->sendForm(new HallOfFameForm());
    }
}
