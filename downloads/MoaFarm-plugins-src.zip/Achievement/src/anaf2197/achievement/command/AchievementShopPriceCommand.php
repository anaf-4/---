<?php
declare(strict_types=1);

namespace anaf2197\achievement\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\achievement\AchievementLoader;
use anaf2197\synthesisprice\SynthesisPrice;

/**
 * /업적포인트상점가격 <가격> — 손에 든 아이템의 업적 포인트 상점가를 설정합니다.
 *
 * 상점/상인은 /createshop, /샵키퍼소환 으로 그대로 만들고,
 * 이 명령어로 해당 상품의 "업적 포인트" 구매가만 별도로 설정합니다.
 */
final class AchievementShopPriceCommand extends Command {

    public function __construct() {
        parent::__construct(
            '업적포인트상점가격',
            '손에 든 아이템의 업적 포인트 상점가를 설정합니다.',
            '/업적포인트상점가격 <가격>',
            ['achievementshopprice', 'ach상점가격']
        );
        $this->setPermission(DefaultPermissions::ROOT_OPERATOR);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if (!$sender instanceof Player) {
            $sender->sendMessage('§c플레이어만 사용 가능합니다.');
            return;
        }

        if (!$this->testPermission($sender)) return;

        if (!class_exists(SynthesisPrice::class)) {
            $sender->sendMessage(AchievementLoader::$prefix . '§cSynthesisPrice 플러그인이 필요합니다.');
            return;
        }

        $price = $args[0] ?? null;
        if ($price === null || !is_numeric($price)) {
            $sender->sendMessage(AchievementLoader::$prefix . '§8사용법: /업적포인트상점가격 <가격> §f- 손에 든 아이템 기준');
            return;
        }

        $price = (int) $price;
        if ($price < 0) {
            $sender->sendMessage(AchievementLoader::$prefix . '§c가격은 0 이상이어야 합니다.');
            return;
        }

        $item = $sender->getInventory()->getItemInHand();
        if ($item->isNull()) {
            $sender->sendMessage(AchievementLoader::$prefix . '§c공기의 가격은 설정할 수 없습니다.');
            return;
        }

        // 업적 포인트 상점은 구매 전용이므로 판매가는 -1 로 고정
        SynthesisPrice::getInstance()->getAchievement()->setPrice($item, [$price, -1]);

        $sender->sendMessage(AchievementLoader::$prefix . '§a' . $item->getName() . '§r§8 의 업적 포인트 상점가를 §e' . $price . 'P§8로 설정했습니다.');
    }
}
