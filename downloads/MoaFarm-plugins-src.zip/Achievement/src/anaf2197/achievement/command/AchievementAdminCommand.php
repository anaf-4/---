<?php
declare(strict_types=1);

namespace anaf2197\achievement\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\achievement\AchievementLoader;
use anaf2197\achievement\form\AchievementEditForm;
use anaf2197\achievement\form\AchievementManageForm;

final class AchievementAdminCommand extends Command {

    public function __construct() {
        parent::__construct(
            '업적관리',
            '업적 관리 명령어',
            '/업적관리 [목록|추가|보상설정|지급|초기화]',
            []
        );
        $this->setPermission(DefaultPermissions::ROOT_OPERATOR);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if (!$this->testPermission($sender)) return;

        $sub = $args[0] ?? '';

        switch ($sub) {
            case '목록':
                if (!$sender instanceof Player) { $sender->sendMessage('§c플레이어만 사용 가능합니다.'); return; }
                $sender->sendForm(new AchievementManageForm(AchievementLoader::getInstance()->getAchievements()));
                break;

            case '추가':
                if (!$sender instanceof Player) { $sender->sendMessage('§c플레이어만 사용 가능합니다.'); return; }
                $sender->sendForm(new AchievementEditForm(null));
                break;

            case '보상설정':
                if (!$sender instanceof Player) { $sender->sendMessage('§c플레이어만 사용 가능합니다.'); return; }
                AchievementLoader::getInstance()->openAdminRewardGui($sender);
                break;

            case '지급':
                // /업적관리 지급 <플레이어> <업적ID>
                if (count($args) < 3) {
                    $sender->sendMessage(AchievementLoader::$prefix . '§c사용법: /업적관리 지급 <플레이어> <업적ID>');
                    return;
                }
                if (!$sender instanceof Player) { $sender->sendMessage('§c플레이어만 사용 가능합니다.'); return; }
                AchievementLoader::getInstance()->forceGrant($args[1], $args[2], $sender);
                break;

            case '초기화':
                // /업적관리 초기화 <플레이어>
                if (count($args) < 2) {
                    $sender->sendMessage(AchievementLoader::$prefix . '§c사용법: /업적관리 초기화 <플레이어>');
                    return;
                }
                if (!$sender instanceof Player) { $sender->sendMessage('§c플레이어만 사용 가능합니다.'); return; }
                AchievementLoader::getInstance()->resetPlayerAchievements($args[1], $sender);
                break;

            case '포인트지급':
                // /업적관리 포인트지급 <플레이어> <포인트>
                if (count($args) < 3) {
                    $sender->sendMessage(AchievementLoader::$prefix . '§c사용법: /업적관리 포인트지급 <플레이어> <포인트>');
                    return;
                }
                $targetName = $args[1];
                $amount     = (int) $args[2];
                if ($amount === 0) {
                    $sender->sendMessage(AchievementLoader::$prefix . '§c포인트는 0이 될 수 없습니다.');
                    return;
                }
                $key = strtolower($targetName);
                AchievementLoader::getInstance()->addPoints($key, $amount);
                $sender->sendMessage(AchievementLoader::$prefix . '§a' . $targetName . '님에게 §e' . $amount . '포인트§a를 지급했습니다.');
                $online = \pocketmine\Server::getInstance()->getPlayerExact($targetName);
                if ($online instanceof Player) {
                    $online->sendMessage(AchievementLoader::$prefix . '§e' . $amount . '포인트§8를 지급받았습니다! (업적 상점: §f/업적상점§8)');
                }
                break;

            default:
                $sender->sendMessage(AchievementLoader::$prefix . '사용법:');
                $sender->sendMessage('§8/업적관리 목록 §f— 업적 목록 보기 및 관리');
                $sender->sendMessage('§8/업적관리 추가 §f— 새 업적 추가');
                $sender->sendMessage('§8/업적관리 보상설정 §f— 전체 보상 아이템 설정');
                $sender->sendMessage('§8/업적관리 지급 <플레이어> <업적ID> §f— 업적 강제 지급');
                $sender->sendMessage('§8/업적관리 포인트지급 <플레이어> <포인트> §f— 업적 포인트 지급');
                $sender->sendMessage('§8/업적관리 초기화 <플레이어> §f— 플레이어 업적 초기화');
                break;
        }
    }
}
