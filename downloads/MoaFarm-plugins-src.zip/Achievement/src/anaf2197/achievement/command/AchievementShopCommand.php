<?php
declare(strict_types=1);

namespace anaf2197\achievement\command;

use muqsit\invmenu\InvMenu;
use muqsit\invmenu\transaction\InvMenuTransaction;
use muqsit\invmenu\transaction\InvMenuTransactionResult;
use muqsit\invmenu\type\InvMenuTypeIds;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\form\Form;
use pocketmine\item\Item;
use pocketmine\player\Player;
use pocketmine\scheduler\ClosureTask;
use anaf2197\achievement\AchievementLoader;
use anaf2197\deliveryapi\DeliveryAPI;
use anaf2197\advancedprefix\AdvancedPrefix;
use anaf2197\servercore\item\ServerItems;

/**
 * /업적상점 — 업적 포인트로 보상 구매 (#29)
 * ShopKeeper 스타일의 상자(GUI) 형식 상점
 */
final class AchievementShopCommand extends Command {

    /** @var array[] 상점 아이템 정의 [{name, description, cost, type(prefix/money/item), value, icon}] */
    private static array $shopItems = [];

    public static function getShopItems(): array {
        if (!empty(self::$shopItems)) return self::$shopItems;

        self::$shopItems = [
            [
                'name'        => '§e경험치 룰렛',
                'description' => '경험치 룰렛권 x5 지급',
                'cost'        => 20,
                'type'        => 'item',
                'value'       => 'ROLL_EXP',
                'amount'      => 5,
                'icon'        => 'ROLL_EXP',
            ],
            [
                'name'        => '§b[업적 장인]§8 칭호',
                'description' => '[업적 장인] 칭호 획득',
                'cost'        => 50,
                'type'        => 'prefix',
                'value'       => '§b[업적 장인]',
                'icon'        => 'NAMETAG_PREFIX',
            ],
            [
                'name'        => '§a소액 보상',
                'description' => '돈 100,000원 지급',
                'cost'        => 30,
                'type'        => 'money',
                'value'       => 100000,
                'icon'        => 'MONEY_SACK',
            ],
            [
                'name'        => '§e[행운아]§8 칭호',
                'description' => '[행운아] 칭호 획득',
                'cost'        => 80,
                'type'        => 'prefix',
                'value'       => '§e[행운아]',
                'icon'        => 'NAMETAG_PREFIX',
            ],
            [
                'name'        => '§d중액 보상',
                'description' => '돈 500,000원 지급',
                'cost'        => 100,
                'type'        => 'money',
                'value'       => 500000,
                'icon'        => 'MONEY_SACK',
            ],
            [
                'name'        => '§5[전설적 업적가]§8 칭호',
                'description' => '[전설적 업적가] 칭호 획득 (300포인트 필요)',
                'cost'        => 300,
                'type'        => 'prefix',
                'value'       => '§5[전설적 업적가]',
                'icon'        => 'NAMETAG_PREFIX',
            ],
            [
                'name'        => '§6고액 보상',
                'description' => '돈 2,000,000원 지급',
                'cost'        => 200,
                'type'        => 'money',
                'value'       => 2000000,
                'icon'        => 'MONEY_SACK',
            ],
        ];

        return self::$shopItems;
    }

    /** 관리자가 /업적포인트상점가격 으로 설정한 가격 오버라이드를 적용한 상점 아이템 목록 */
    public static function getEffectiveShopItems(): array {
        $items     = self::getShopItems();
        $overrides = AchievementLoader::getInstance()->getShopPriceOverrides();

        foreach ($overrides as $index => $cost) {
            if (isset($items[$index])) {
                $items[$index]['cost'] = $cost;
            }
        }

        return $items;
    }

    public function __construct() {
        parent::__construct('업적상점', '업적 포인트로 보상 구매', '/업적상점', ['achievementshop', 'ach상점']);
        $this->setPermission('achievement.use');
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if (!$sender instanceof Player) {
            $sender->sendMessage('§c플레이어만 사용 가능합니다.');
            return;
        }

        self::openShopGui($sender);
    }

    /** SHOP 테마 GUI(§b)로 업적 상점을 엽니다. (#29, 기존 ShopKeeper와 동일한 "도트" UI 적용) */
    public static function openShopGui(Player $player): void {
        $loader = AchievementLoader::getInstance();
        $key    = strtolower($player->getName());
        $pts    = $loader->getPoints($key);
        $items  = self::getEffectiveShopItems();

        // §b: 인벤토리 UI 리소스팩에서 "SHOP" 테마 배경을 적용시키는 예약 타이틀
        $menu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
        $menu->setName('§b');

        $inv     = $menu->getInventory();
        $slotMap = [];

        foreach ($items as $i => $item) {
            if ($i >= 53) break;

            $icon = self::resolveIcon($item['icon']);
            $icon->setCustomName('§r' . $item['name']);

            $canBuy = $pts >= $item['cost'];
            $lore = [
                ' ',
                '§r§f' . $item['description'],
                ' ',
                '§r§8필요 포인트: ' . ($canBuy ? '§a' : '§c') . $item['cost'] . 'P',
                ' ',
                $canBuy ? '§r§e클릭하여 구매' : '§r§c포인트가 부족합니다',
            ];
            $icon->setLore($lore);

            $slotMap[$i] = $item;
            $inv->setItem($i, $icon);
        }

        // 보유 포인트 안내 아이템 (마지막 슬롯)
        $infoIcon = self::resolveIcon('STAT_COIN');
        $infoIcon->setCustomName('§r§e보유 업적 포인트');
        $infoIcon->setLore([' ', '§r§f' . number_format($pts) . 'P']);
        $inv->setItem(53, $infoIcon);

        $menu->setListener(function (InvMenuTransaction $t) use ($slotMap): InvMenuTransactionResult {
            $slot = $t->getAction()->getSlot();
            $item = $slotMap[$slot] ?? null;
            $p    = $t->getPlayer();

            if ($item !== null) {
                $p->removeCurrentWindow();
                AchievementLoader::getInstance()->getScheduler()->scheduleDelayedTask(new ClosureTask(
                    function () use ($p, $item): void {
                        if ($p->isConnected()) {
                            $p->sendForm(self::buildConfirmForm($item));
                        }
                    }
                ), 1);
            }

            return $t->discard();
        });

        $menu->send($player);
    }

    /** ServerCore의 "도트" 커스텀 아이콘을 가져옵니다. (#29) */
    private static function resolveIcon(string $key): Item {
        if (class_exists(ServerItems::class)) {
            if (method_exists(ServerItems::class, $key)) {
                return ServerItems::$key();
            }
            return ServerItems::BOX();
        }
        return \pocketmine\item\VanillaItems::PAPER();
    }

    private static function buildConfirmForm(array $item): Form {
        return new class($item) implements Form {
            public function __construct(private array $item) {}

            public function jsonSerialize(): array {
                return [
                    'type'    => 'modal',
                    'title'   => '§l구매 확인',
                    'content' => $this->item['name'] . "\n§f" . $this->item['description'] . "\n \n§e비용: §f" . $this->item['cost'] . '포인트',
                    'button1' => '§a구매',
                    'button2' => '§c취소',
                ];
            }

            public function handleResponse(Player $player, $data): void {
                if (!$data) {
                    // 취소 시 상점 GUI로 복귀
                    AchievementLoader::getInstance()->getScheduler()->scheduleDelayedTask(new ClosureTask(
                        function () use ($player): void {
                            if ($player->isConnected()) {
                                AchievementShopCommand::openShopGui($player);
                            }
                        }
                    ), 1);
                    return;
                }

                $loader = AchievementLoader::getInstance();
                $prefix = AchievementLoader::$prefix;
                $key    = strtolower($player->getName());

                if (!$loader->spendPoints($key, $this->item['cost'])) {
                    $player->sendMessage($prefix . '§c포인트가 부족합니다.');
                    return;
                }

                $type  = $this->item['type'];
                $value = $this->item['value'];

                if ($type === 'money') {
                    if (class_exists(DeliveryAPI::class)) {
                        $mailBox = DeliveryAPI::getInstance()->getMailBox($player);
                        $mailBox?->new('§6[업적상점] §f' . $this->item['name'], [], (int) $value, '업적 상점');
                    }
                } elseif ($type === 'item') {
                    if (class_exists(DeliveryAPI::class)) {
                        $reward = AchievementShopCommand::resolveIcon((string) $value);
                        $reward->setCount((int) ($this->item['amount'] ?? 1));
                        $mailBox = DeliveryAPI::getInstance()->getMailBox($player);
                        $mailBox?->new('§6[업적상점] §f' . $this->item['name'], [$reward], null, '업적 상점');
                    }
                } elseif ($type === 'prefix') {
                    if (class_exists(AdvancedPrefix::class)) {
                        $pp = AdvancedPrefix::getInstance()->getPlayerPrefix($player);
                        if ($pp !== null) {
                            if ($pp->hasPrefix((string) $value)) {
                                // 이미 보유 중 → 환불
                                $loader->addPoints($key, $this->item['cost']);
                                $player->sendMessage($prefix . '§c이미 보유 중인 칭호입니다. 포인트를 환불했습니다.');
                                return;
                            }
                            $pp->addPrefix((string) $value);
                        }
                    }
                }

                $remaining = $loader->getPoints($key);
                $player->sendMessage($prefix . '§a구매 완료! §f' . $this->item['name'] . ' §8(남은 포인트: §e' . $remaining . '§8)');

                // 구매 후 갱신된 상점 GUI로 복귀
                $loader->getScheduler()->scheduleDelayedTask(new ClosureTask(
                    function () use ($player): void {
                        if ($player->isConnected()) {
                            AchievementShopCommand::openShopGui($player);
                        }
                    }
                ), 1);
            }
        };
    }
}
