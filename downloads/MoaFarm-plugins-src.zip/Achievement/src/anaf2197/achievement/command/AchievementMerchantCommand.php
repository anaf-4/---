<?php
declare(strict_types=1);

namespace anaf2197\achievement\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\player\Player;
use anaf2197\achievement\AchievementLoader;
use anaf2197\lib\skinparser\SkinParser;
use anaf2197\shopkeeper\entity\ShopKeeperEntity;
use anaf2197\shopkeeper\ShopKeeperLoader;
use anaf2197\shopkeeper\ShopObject;

/**
 * /업적상인소환 — ShopKeeper(/createshop)와 연동하여 업적 포인트 상점 NPC를 소환합니다.
 */
final class AchievementMerchantCommand extends Command {

    private const SHOP_LABEL = '업적상점';

    public function __construct() {
        parent::__construct('업적상인소환', '업적 포인트 상점 NPC를 소환합니다.', '/업적상인소환', ['summonachievementmerchant']);
        $this->setPermission('achievement.admin');
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if (!$sender instanceof Player) {
            $sender->sendMessage('§c플레이어만 사용 가능합니다.');
            return;
        }

        if (!class_exists(ShopKeeperLoader::class)) {
            $sender->sendMessage(AchievementLoader::$prefix . '§cShopKeeper 플러그인이 필요합니다.');
            return;
        }

        $shopLoader = ShopKeeperLoader::getInstance();

        // /createshop과 연동: 프리셋이 없으면 자동 생성
        $shopObject = $shopLoader->getShop(self::SHOP_LABEL);
        if (!$shopObject instanceof ShopObject) {
            $shopObject = new ShopObject(self::SHOP_LABEL, false, [[]]);
            $shopLoader->createShop(self::SHOP_LABEL, $shopObject);
            $sender->sendMessage(AchievementLoader::$prefix . '§8"' . self::SHOP_LABEL . '" 상점 프리셋을 생성했습니다.');
        }

        $location = $sender->getLocation();
        $shopkeeper = new ShopKeeperEntity($location, CompoundTag::create()
            ->setTag('Rotation', new ListTag([new FloatTag($location->getYaw()), new FloatTag($location->getPitch())]))
            ->setString('shopLabel', self::SHOP_LABEL)
            ->setString('skin', implode(':', SkinParser::toArray($sender->getSkin()))));
        $shopkeeper->spawnToAll();
        $shopkeeper->setNameTag("§l§6업적 상인\n§r§f클릭하여 상점 열기");

        $sender->sendMessage(AchievementLoader::$prefix . '§a업적 상인을 소환했습니다.');
    }
}
