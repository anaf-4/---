<?php
declare(strict_types=1);

namespace anaf2197\achievement\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use anaf2197\achievement\AchievementLoader;

/**
 * /업적포인트 — 자신의 업적 포인트를 확인합니다.
 */
final class AchievementPointsCommand extends Command {

    public function __construct() {
        parent::__construct('업적포인트', '내 업적 포인트를 확인합니다.', '/업적포인트', ['achievementpoints', 'ach포인트']);
        $this->setPermission('achievement.use');
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if (!$sender instanceof Player) {
            $sender->sendMessage('§c플레이어만 사용 가능합니다.');
            return;
        }

        $loader = AchievementLoader::getInstance();
        $key    = strtolower($sender->getName());
        $pts    = $loader->getPoints($key);

        $sender->sendMessage(AchievementLoader::$prefix . '§f현재 보유 업적 포인트: §e' . number_format($pts) . 'P');
        $sender->sendMessage(AchievementLoader::$prefix . '§8업적 상점에서 사용해보세요! §f(/업적상점)');
    }
}
