<?php
declare(strict_types=1);

namespace anaf2197\achievement;

use pocketmine\block\Block;
use pocketmine\block\VanillaBlocks;
use pocketmine\entity\Monster;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDeathEvent;
use pocketmine\event\EventPriority;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\player\Player;
use anaf2197\guild\event\JoinGuildEvent;

final class AchievementListener implements Listener {

    // ─── 블록 타입 판별 ──────────────────────────────────────────────────────

    private static function isOre(Block $block): bool {
        $name = strtolower($block->getName());
        return str_contains($name, 'ore') || $name === 'ancient debris';
    }

    private static function isLog(Block $block): bool {
        $name = strtolower($block->getName());
        return str_contains($name, 'log') || str_contains($name, 'stem')
            || str_contains($name, 'wood') || str_contains($name, 'hyphae');
    }

    private static function isCrop(Block $block): bool {
        $name = strtolower($block->getName());
        return in_array($name, ['wheat', 'carrots', 'potatoes', 'beetroots', 'nether wart'], true)
            || str_contains($name, 'melon') || str_contains($name, 'pumpkin stem')
            || str_contains($name, 'cactus') || str_contains($name, 'sugar cane');
    }

    // ─── 이벤트 핸들러 ───────────────────────────────────────────────────────

    public function onPlayerJoin(PlayerJoinEvent $event): void {
        AchievementLoader::getInstance()->loadPlayer($event->getPlayer());
    }

    public function onPlayerQuit(PlayerQuitEvent $event): void {
        AchievementLoader::getInstance()->savePlayer($event->getPlayer());
    }

    /**
     * @handleCancelled true
     */
    public function onBlockBreak(BlockBreakEvent $event): void {
        $block  = $event->getBlock();
        $player = $event->getPlayer();
        $loader = AchievementLoader::getInstance();

        if ($event->isCancelled()) {
            // 울타리 위 잠수광질 블록만 예외 처리
            if ($this->isMineFenceBelow($block) && (self::isOre($block) || self::isStone($block))) {
                $loader->addProgress($player, Achievement::TYPE_MINING);
            }
            return;
        }

        if (self::isOre($block)) {
            $loader->addProgress($player, Achievement::TYPE_MINING);
        } elseif (self::isLog($block)) {
            $loader->addProgress($player, Achievement::TYPE_LOGGING);
        } elseif (self::isCrop($block)) {
            $loader->addProgress($player, Achievement::TYPE_FARMING);
        }
    }

    private static function isStone(Block $block): bool {
        $name = strtolower($block->getName());
        return $name === 'stone' || $name === 'cobblestone';
    }

    private static function isMineFenceBelow(Block $block): bool {
        $below = $block->getPosition()->getWorld()->getBlock($block->getPosition()->down());
        $name  = strtolower($below->getName());
        return $name === strtolower(VanillaBlocks::CRIMSON_FENCE()->getName())
            || $name === strtolower(VanillaBlocks::WARPED_FENCE()->getName());
    }

    public function onEntityDeath(EntityDeathEvent $event): void {
        $entity = $event->getEntity();
        if (!$entity instanceof Monster) return;

        $cause = $entity->getLastDamageCause();
        if (!$cause instanceof EntityDamageByEntityEvent) return;
        $damager = $cause->getDamager();
        if (!$damager instanceof Player) return;

        AchievementLoader::getInstance()->addProgress($damager, Achievement::TYPE_HUNTING);
    }

    public function onJoinGuild(JoinGuildEvent $event): void {
        $player = \pocketmine\Server::getInstance()->getPlayerExact($event->getPlayer());
        if (!$player instanceof Player) return;
        AchievementLoader::getInstance()->addProgress($player, Achievement::TYPE_GUILD);
    }
}
