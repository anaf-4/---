<?php

declare(strict_types=1);

namespace anaf2197\achievement\entity;

use anaf2197\achievement\form\HallOfFameForm;
use pocketmine\entity\Human;
use pocketmine\entity\Location;
use pocketmine\entity\Skin;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\player\Player;

final class HallOfFameNPC extends Human {

    public function __construct(Location $location, CompoundTag $nbt) {
        // 기본 스킨 (Steve)
        $skinData = str_repeat("\xff", 64 * 64 * 4);
        $skin = new Skin('HallOfFameNPC', $skinData, '', 'geometry.humanoid.custom', '');
        parent::__construct($location, $skin, $nbt);

        $this->setNameTag('§l§6🏆 명예의 전당');
        $this->setNameTagVisible(true);
        $this->setNameTagAlwaysVisible(true);
        $this->setNoClientPredictions();
    }

    public function getName(): string {
        return '명예의 전당';
    }

    public function onInteract(Player $player, \pocketmine\math\Vector3 $clickPos): bool {
        $player->sendForm(new HallOfFameForm());
        return true;
    }

    protected function onAttack(EntityDamageEvent $event): void {
        $event->cancel();
    }

    public function attack(EntityDamageEvent $event): void {
        $event->cancel();
    }

    public function saveNBT(): CompoundTag {
        $nbt = parent::saveNBT();
        $nbt->setString('HallOfFameNPC', '1');
        return $nbt;
    }
}
