<?php
declare(strict_types=1);

namespace anaf2197\achievement;

final class Achievement {

    // ─── 업적 타입 ───────────────────────────────────────────────────────────
    public const TYPE_MINING       = 'MINING';
    public const TYPE_HUNTING      = 'HUNTING';
    public const TYPE_ECONOMY      = 'ECONOMY';
    public const TYPE_GUILD        = 'GUILD';
    public const TYPE_FISHING      = 'FISHING';
    public const TYPE_RECOMMEND    = 'RECOMMEND';
    public const TYPE_EXCAVATION   = 'EXCAVATION';
    public const TYPE_LOGGING      = 'LOGGING';
    public const TYPE_FARMING      = 'FARMING';
    public const TYPE_QUEST        = 'QUEST';
    public const TYPE_MARRIAGE     = 'MARRIAGE';
    public const TYPE_AUCTION      = 'AUCTION';
    public const TYPE_ATTENDANCE   = 'ATTENDANCE';
    public const TYPE_PARTY        = 'PARTY';       // 파티 참여
    // 신규 타입
    public const TYPE_LEVEL        = 'LEVEL';       // AdvancedLevel 레벨업
    public const TYPE_PLAYTIME     = 'PLAYTIME';    // 플레이타임(시간)
    public const TYPE_TRADE        = 'TRADE';       // PlayerTrade 거래
    public const TYPE_COLLECT      = 'COLLECT';     // Collector 수집
    public const TYPE_CRAFT        = 'CRAFT';       // 아이템 제작
    public const TYPE_FISHING_RARE = 'FISHING_RARE'; // 낚시 레어 아이템
    public const TYPE_RUNE          = 'RUNE';          // RuneSystem 룬 각인
    public const TYPE_UPGRADE       = 'UPGRADE';       // UpgradeTools 강화 성공
    public const TYPE_ENFORCE_LEVEL = 'ENFORCE_LEVEL'; // Enforce 강화 최고 달성 레벨

    // ─── 희귀도 ──────────────────────────────────────────────────────────────
    public const RARITY_COMMON    = 0;
    public const RARITY_RARE      = 1;
    public const RARITY_EPIC      = 2;
    public const RARITY_LEGENDARY = 3;

    public static function getRarityLabel(int $rarity): string {
        return match ($rarity) {
            self::RARITY_RARE      => '§b[레어]',
            self::RARITY_EPIC      => '§5[에픽]',
            self::RARITY_LEGENDARY => '§6[전설]',
            default                => '§8[일반]',
        };
    }

    public static function getRarityColor(int $rarity): string {
        return match ($rarity) {
            self::RARITY_LEGENDARY => '§6',
            self::RARITY_EPIC      => '§5',
            self::RARITY_RARE      => '§b',
            default                => '§8',
        };
    }

    public static function getCompletedIcon(int $rarity): string {
        return match ($rarity) {
            self::RARITY_LEGENDARY => 'nether_star',
            self::RARITY_EPIC      => 'diamond',
            self::RARITY_RARE      => 'gold_ingot',
            default                => 'gold_block',
        };
    }

    public static function getRarityEconomyBonus(int $rarity): int {
        return match ($rarity) {
            self::RARITY_LEGENDARY => 50000,
            self::RARITY_EPIC      => 15000,
            self::RARITY_RARE      => 5000,
            default                => 1000,
        };
    }

    /** 업적 달성 시 지급할 업적 포인트 (#29) */
    public static function getRarityPoints(int $rarity): int {
        return match ($rarity) {
            self::RARITY_LEGENDARY => 100,
            self::RARITY_EPIC      => 40,
            self::RARITY_RARE      => 15,
            default                => 5,
        };
    }

    public static function autoDescription(string $type, int $target): string {
        $label = match ($type) {
            self::TYPE_MINING       => '채광',
            self::TYPE_HUNTING      => '몹 사냥',
            self::TYPE_ECONOMY      => '돈 획득',
            self::TYPE_GUILD        => '길드 가입',
            self::TYPE_FISHING      => '낚시',
            self::TYPE_RECOMMEND    => '서버 추천',
            self::TYPE_EXCAVATION   => '발굴',
            self::TYPE_LOGGING      => '벌목',
            self::TYPE_FARMING      => '농사 수확',
            self::TYPE_QUEST        => '퀘스트 완료',
            self::TYPE_MARRIAGE     => '결혼',
            self::TYPE_AUCTION      => '경매장 거래',
            self::TYPE_ATTENDANCE   => '출석 체크',
            self::TYPE_PARTY        => '파티 참여',
            self::TYPE_LEVEL        => '레벨 달성',
            self::TYPE_PLAYTIME     => '플레이타임(시간)',
            self::TYPE_TRADE        => '플레이어 거래',
            self::TYPE_COLLECT      => '아이템 수집',
            self::TYPE_CRAFT        => '아이템 제작',
            self::TYPE_FISHING_RARE => '낚시 레어 획득',
            self::TYPE_RUNE          => '룬 각인',
            self::TYPE_UPGRADE       => '강화 성공',
            self::TYPE_ENFORCE_LEVEL => '강화 달성 레벨',
            default                  => '활동',
        };
        return $label . ' ' . number_format($target) . '회 달성';
    }

    public function __construct(
        public readonly string $id,
        public readonly string $name,
        public readonly string $description,
        public readonly string $type,
        public readonly int    $target,
        public readonly int    $rewardMoney  = 0,
        public readonly string $rewardPrefix = '',
        public readonly int    $rarity       = self::RARITY_COMMON,
        public readonly string $rewardTitle  = '',  // TitleCollection 자동 해금 (#14)
    ) {}
}
