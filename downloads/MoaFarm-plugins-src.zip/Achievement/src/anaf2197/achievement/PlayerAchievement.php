<?php
declare(strict_types=1);

namespace anaf2197\achievement;

final class PlayerAchievement implements \JsonSerializable {

    public function __construct(
        private string $name,
        private array  $progress  = [],  // ['MINING' => 500, ...]
        private array  $completed = []   // ['mining_100', ...]
    ) {}

    public function getName(): string {
        return $this->name;
    }

    public function getProgress(string $type): int {
        return $this->progress[$type] ?? 0;
    }

    public function addProgress(string $type, int $amount = 1): void {
        $this->progress[$type] = ($this->progress[$type] ?? 0) + $amount;
    }

    public function isCompleted(string $achievementId): bool {
        return in_array($achievementId, $this->completed, true);
    }

    public function markCompleted(string $achievementId): void {
        if (!$this->isCompleted($achievementId)) {
            $this->completed[] = $achievementId;
        }
    }

    public function getCompleted(): array {
        return $this->completed;
    }

    public function getAllProgress(): array {
        return $this->progress;
    }

    public function jsonSerialize(): array {
        return [$this->name, $this->progress, $this->completed];
    }

    public static function jsonDeserialize(array $data): self {
        return new self($data[0], $data[1] ?? [], $data[2] ?? []);
    }
}
