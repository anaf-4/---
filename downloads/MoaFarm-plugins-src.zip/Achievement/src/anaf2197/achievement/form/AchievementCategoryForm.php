<?php
declare(strict_types=1);

namespace anaf2197\achievement\form;

use pocketmine\form\Form;
use pocketmine\player\Player;
use anaf2197\achievement\Achievement;
use anaf2197\achievement\AchievementLoader;
use anaf2197\achievement\PlayerAchievement;

final class AchievementCategoryForm implements Form {

    private const TYPE_LABELS = [
        Achievement::TYPE_MINING    => '채광',
        Achievement::TYPE_HUNTING   => '사냥',
        Achievement::TYPE_ECONOMY   => '경제',
        Achievement::TYPE_GUILD     => '길드',
        Achievement::TYPE_FISHING   => '낚시',
        Achievement::TYPE_RECOMMEND => '추천',
    ];

    /** @var string[] type list matching button indices */
    private array $typeList = [];
    private array $buttons  = [];

    public function __construct(
        private array $achievements,
        private ?PlayerAchievement $playerData
    ) {
        $byType = [];
        foreach ($this->achievements as $a) {
            $byType[$a->type][] = $a;
        }

        foreach (self::TYPE_LABELS as $type => $label) {
            if (!isset($byType[$type])) continue;
            $list      = $byType[$type];
            $completed = array_filter($list, fn($a) => $this->playerData?->isCompleted($a->id) ?? false);
            $this->buttons[]  = ['text' => $label . ' §8(' . count($completed) . '/' . count($list) . ' 달성)'];
            $this->typeList[] = $type;
        }

        // 기타 타입
        foreach ($byType as $type => $list) {
            if (isset(self::TYPE_LABELS[$type])) continue;
            $completed = array_filter($list, fn($a) => $this->playerData?->isCompleted($a->id) ?? false);
            $this->buttons[]  = ['text' => $type . ' §8(' . count($completed) . '/' . count($list) . ')'];
            $this->typeList[] = $type;
        }

        $totalCompleted = count(array_filter($this->achievements, fn($a) => $this->playerData?->isCompleted($a->id) ?? false));
        $this->buttons[]  = ['text' => '§f전체 보기 §8(' . $totalCompleted . '/' . count($this->achievements) . ')'];
        $this->typeList[] = '__all__';
    }

    public function jsonSerialize(): array {
        return [
            'type'    => 'form',
            'title'   => '§l§6업적',
            'content' => '§8확인할 업적 분야를 선택하세요.',
            'buttons' => $this->buttons,
        ];
    }

    public function handleResponse(Player $player, $data): void {
        if ($data === null) return;
        $type = $this->typeList[(int) $data] ?? '__all__';
        AchievementLoader::getInstance()->openAchievementGui($player, $type === '__all__' ? null : $type);
    }
}
