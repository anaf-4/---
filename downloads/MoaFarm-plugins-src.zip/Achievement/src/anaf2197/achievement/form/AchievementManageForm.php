<?php
declare(strict_types=1);

namespace anaf2197\achievement\form;

use pocketmine\form\Form;
use pocketmine\player\Player;
use anaf2197\achievement\Achievement;
use anaf2197\achievement\AchievementLoader;

final class AchievementManageForm implements Form {

    /** @param Achievement[] $achievements */
    public function __construct(private array $achievements) {}

    public function jsonSerialize(): array {
        $buttons = [];
        foreach ($this->achievements as $a) {
            $typeLabel = match ($a->type) {
                Achievement::TYPE_MINING  => '채광',
                Achievement::TYPE_HUNTING => '사냥',
                Achievement::TYPE_GUILD   => '길드',
                Achievement::TYPE_ECONOMY => '경제',
                default                   => $a->type,
            };
            $buttons[] = ['text' => '§l' . $a->name . PHP_EOL . '§r§8' . $typeLabel . ' | 목표: ' . number_format($a->target)];
        }
        $buttons[] = ['text' => '§l§a+ 새 업적 추가'];

        return [
            'type'    => 'form',
            'title'   => '§l 업적 관리',
            'content' => '§8관리할 업적을 선택하거나 새로 추가하세요.\n§8총 ' . count($this->achievements) . '개의 업적',
            'buttons' => $buttons,
        ];
    }

    public function handleResponse(Player $player, $data): void {
        if ($data === null) return;
        $list = array_values($this->achievements);
        if ($data < count($list)) {
            $player->sendForm(new AchievementDetailForm($list[$data]));
        } else {
            $player->sendForm(new AchievementEditForm(null));
        }
    }
}
