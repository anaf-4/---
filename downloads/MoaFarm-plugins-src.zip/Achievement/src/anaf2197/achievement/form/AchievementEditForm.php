<?php
declare(strict_types=1);

namespace anaf2197\achievement\form;

use pocketmine\form\Form;
use pocketmine\player\Player;
use anaf2197\achievement\Achievement;
use anaf2197\achievement\AchievementLoader;

final class AchievementEditForm implements Form {

    private const TYPES = [
        Achievement::TYPE_MINING,
        Achievement::TYPE_HUNTING,
        Achievement::TYPE_GUILD,
        Achievement::TYPE_ECONOMY,
    ];

    private const TYPE_LABELS = ['채광 (MINING)', '사냥 (HUNTING)', '길드 (GUILD)', '경제 (ECONOMY)'];

    public function __construct(private ?Achievement $achievement) {}

    public function jsonSerialize(): array {
        $a = $this->achievement;
        $typeIdx = $a !== null ? (array_search($a->type, self::TYPES, true) ?: 0) : 0;

        $content = [];

        // 추가 모드에서만 ID 입력
        if ($a === null) {
            $content[] = [
                'type'    => 'input',
                'text'    => '업적 ID (영문·숫자·_만 사용, 예: economy_500000)',
                'default' => '',
            ];
        }

        $content[] = ['type' => 'input', 'text' => '업적 이름', 'default' => $a?->name ?? ''];
        $content[] = ['type' => 'input', 'text' => '설명', 'default' => $a?->description ?? ''];
        $content[] = [
            'type'    => 'dropdown',
            'text'    => '업적 타입',
            'options' => self::TYPE_LABELS,
            'default' => $typeIdx,
        ];
        $content[] = ['type' => 'input', 'text' => '목표값 (숫자)', 'default' => (string) ($a?->target ?? 100)];
        $content[] = ['type' => 'input', 'text' => '보상금 (원, 0=미지급)', 'default' => (string) ($a?->rewardMoney ?? 0)];
        $content[] = ['type' => 'input', 'text' => '보상 칭호 (없으면 빈칸)', 'default' => $a?->rewardPrefix ?? ''];

        return [
            'type'    => 'custom_form',
            'title'   => '§l ' . ($a !== null ? '업적 편집: ' . $a->name : '새 업적 추가'),
            'content' => $content,
        ];
    }

    public function handleResponse(Player $player, $data): void {
        if (!is_array($data)) return;

        $loader = AchievementLoader::getInstance();
        $a      = $this->achievement;
        $isEdit = $a !== null;

        // ID 처리
        if (!$isEdit) {
            $id = trim((string) array_shift($data));
            if ($id === '' || !preg_match('/^[a-zA-Z0-9_]+$/', $id)) {
                $player->sendMessage(AchievementLoader::$prefix . '§cID는 영문·숫자·_만 사용할 수 있습니다.');
                $player->sendForm(new AchievementEditForm(null));
                return;
            }
            if ($loader->getAchievement($id) !== null) {
                $player->sendMessage(AchievementLoader::$prefix . '§c이미 존재하는 업적 ID입니다: ' . $id);
                $player->sendForm(new AchievementEditForm(null));
                return;
            }
        } else {
            $id = $a->id;
        }

        $name        = trim((string) ($data[0] ?? ''));
        $description = trim((string) ($data[1] ?? ''));
        $typeIdx     = (int) ($data[2] ?? 0);
        $target      = (int) ($data[3] ?? 1);
        $rewardMoney = (int) ($data[4] ?? 0);
        $rewardPrefix = trim((string) ($data[5] ?? ''));

        if ($name === '' || $description === '' || $target <= 0) {
            $player->sendMessage(AchievementLoader::$prefix . '§c이름, 설명, 목표값을 올바르게 입력해주세요. (목표값 > 0)');
            $player->sendForm(new AchievementEditForm($a));
            return;
        }

        $type        = self::TYPES[$typeIdx] ?? Achievement::TYPE_MINING;
        $achievement = new Achievement($id, $name, $description, $type, $target, $rewardMoney, $rewardPrefix);
        $loader->saveDefinition($achievement);

        $verb = $isEdit ? '수정' : '추가';
        $player->sendMessage(AchievementLoader::$prefix . '업적을 ' . $verb . '했습니다: §f' . $name);
        $player->sendForm(new AchievementManageForm($loader->getAchievements()));
    }
}
