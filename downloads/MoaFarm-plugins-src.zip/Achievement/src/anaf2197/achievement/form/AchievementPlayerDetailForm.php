<?php
declare(strict_types=1);

namespace anaf2197\achievement\form;

use pocketmine\form\Form;
use pocketmine\player\Player;
use anaf2197\achievement\Achievement;
use anaf2197\achievement\AchievementLoader;
use anaf2197\achievement\PlayerAchievement;

final class AchievementPlayerDetailForm implements Form {

    private const TYPE_LABELS = [
        Achievement::TYPE_MINING    => '채광',
        Achievement::TYPE_HUNTING   => '사냥',
        Achievement::TYPE_ECONOMY   => '경제',
        Achievement::TYPE_GUILD     => '길드',
        Achievement::TYPE_FISHING   => '낚시',
        Achievement::TYPE_RECOMMEND => '추천',
    ];

    public function __construct(
        private Achievement       $achievement,
        private ?PlayerAchievement $playerData,
        private ?string            $returnType = null
    ) {}

    public function jsonSerialize(): array {
        $a         = $this->achievement;
        $progress  = $this->playerData?->getProgress($a->type) ?? 0;
        $completed = $this->playerData?->isCompleted($a->id) ?? false;
        $pct       = min(100, (int) ($progress / max(1, $a->target) * 100));
        $filled    = (int) ($pct / 5);
        $bar       = '§a' . str_repeat('█', $filled) . '§8' . str_repeat('█', 20 - $filled);

        $typeLabel = self::TYPE_LABELS[$a->type] ?? $a->type;

        $lines = [
            ' ',
            '§8설명: §f' . $a->description,
            '§8분야: ' . $typeLabel,
            ' ',
            '§8진행도',
            '§r' . $bar . ' §f' . $pct . '%',
            '§r§8' . number_format($progress) . ' / ' . number_format($a->target),
            ' ',
            '§8보상금: §e' . number_format($a->rewardMoney) . '원',
        ];
        if ($a->rewardPrefix !== '') {
            $lines[] = '§8칭호: §r' . $a->rewardPrefix;
        }
        $lines[] = ' ';
        $lines[] = $completed ? '§a달성 완료!' : '§c미달성';
        $lines[] = ' ';

        return [
            'type'    => 'form',
            'title'   => '§l ' . $a->name,
            'content' => implode(PHP_EOL, $lines),
            'buttons' => [['text' => '← 업적 목록으로']],
        ];
    }

    public function handleResponse(Player $player, $data): void {
        $loader = AchievementLoader::getInstance();
        if ($this->returnType !== null) {
            $loader->openAchievementGui($player, $this->returnType);
        } else {
            $loader->openAchievementCategoryForm($player);
        }
    }
}
