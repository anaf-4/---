<?php
declare(strict_types=1);

namespace anaf2197\achievement\form;

use pocketmine\form\Form;
use pocketmine\player\Player;

final class AchievementRankingForm implements Form {

    /** @param array<string,int> $topAchievers player => count */
    public function __construct(
        private readonly array $topAchievers,
        private readonly int   $totalAchievements,
    ) {}

    public function jsonSerialize(): array {
        $rankColors = ['§6', '§8', '§c'];
        $lines      = [];
        $rank       = 1;
        foreach ($this->topAchievers as $player => $count) {
            $color   = $rankColors[$rank - 1] ?? '§f';
            $lines[] = $color . $rank . '위 §f' . $player . ' §8| §e' . $count . '/' . $this->totalAchievements . '개';
            $rank++;
        }
        if (empty($lines)) {
            $lines[] = '§8아직 데이터가 없습니다.';
        }

        return [
            'type'    => 'form',
            'title'   => '§l§6업적 달성 랭킹 TOP 10',
            'content' => implode("\n", $lines),
            'buttons' => [['text' => '§8닫기']],
        ];
    }

    public function handleResponse(Player $player, mixed $data): void {}
}
