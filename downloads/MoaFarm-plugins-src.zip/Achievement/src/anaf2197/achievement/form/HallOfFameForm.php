<?php

declare(strict_types=1);

namespace anaf2197\achievement\form;

use anaf2197\achievement\AchievementLoader;
use pocketmine\form\Form;
use pocketmine\player\Player;

final class HallOfFameForm implements Form {

    public function jsonSerialize(): array {
        $lines = ['§l§6[ 🏆 명예의 전당 ]', ' '];

        // ── 강화 순위 ───────────────────────────────────────
        if (class_exists(\anaf2197\Enforce\Enforce::class)) {
            $rows = \anaf2197\Enforce\Enforce::getDB()->getEnforceRanking(3);
            $lines[] = '§l§c⚔ 강화 TOP 3';
            if (empty($rows)) {
                $lines[] = ' §8기록 없음';
            } else {
                $medals = ['§e1위', '§72위', '§63위'];
                foreach ($rows as $i => $row) {
                    $lines[] = ' ' . ($medals[$i] ?? '§f' . ($i + 1) . '위') . ' §f' . $row['player_name'] . ' §a' . $row['max_level'] . '강';
                }
            }
            $lines[] = ' ';
        }

        // ── 위상 순위 ───────────────────────────────────────
        if (class_exists(\anaf2197\advancedlevel\AdvancedLevel::class)) {
            $phaseRanking = \anaf2197\advancedlevel\AdvancedLevel::getInstance()->getAllPhaseRanking();
            $top3 = array_slice($phaseRanking, 0, 3, true);
            $lines[] = '§l§5🌟 위상 TOP 3';
            if (empty($top3)) {
                $lines[] = ' §8기록 없음';
            } else {
                $medals = ['§e1위', '§72위', '§63위'];
                $i = 0;
                foreach ($top3 as $name => $phaseObj) {
                    $phase = $phaseObj instanceof \anaf2197\advancedlevel\PlayerPhase ? $phaseObj->getPhase() : 0;
                    $phaseName = \anaf2197\advancedlevel\PhaseConfig::getPhaseName($phase);
                    $lines[] = ' ' . ($medals[$i] ?? '§f') . ' §f' . $name . ' §d위상 ' . $phase . ' §8(' . $phaseName . ')';
                    $i++;
                }
            }
            $lines[] = ' ';
        }

        // ── 주간 경제 랭킹 ─────────────────────────────────
        if (class_exists(\anaf2197\weeklyranking\WeeklyRankingLoader::class)) {
            $wr   = \anaf2197\weeklyranking\WeeklyRankingLoader::getInstance();
            $top3 = $wr->getTopN(\anaf2197\weeklyranking\WeeklyRankingLoader::CAT_ECONOMY, 3);
            $lines[] = '§l§e💰 이번 주 수입 TOP 3';
            if (empty($top3)) {
                $lines[] = ' §8기록 없음';
            } else {
                $medals = ['§e1위', '§72위', '§63위'];
                $i = 0;
                foreach ($top3 as $name => $score) {
                    $lines[] = ' ' . ($medals[$i] ?? '§f') . ' §f' . $name . ' §e' . number_format($score) . '원';
                    $i++;
                }
            }
            $lines[] = ' ';
        }

        // ── 서버 최초 달성 ─────────────────────────────────
        $firsts = AchievementLoader::getInstance()->getServerFirsts();
        if (!empty($firsts)) {
            $lines[] = '§l§b★ 서버 최초 달성자';
            $recentFirst = array_slice(array_reverse($firsts), 0, 5);
            foreach ($recentFirst as $row) {
                $achName = AchievementLoader::getInstance()->getAchievementName($row['achievement_key']) ?? $row['achievement_key'];
                $date    = substr($row['achieved_at'], 5, 5); // MM-DD
                $lines[] = ' §f' . $row['player_name'] . ' §8- §e' . $achName . ' §8(' . $date . ')';
            }
        }

        return [
            'type'    => 'form',
            'title'   => '§l§6명예의 전당',
            'content' => implode("\n", $lines),
            'buttons' => [['text' => '§a확인']],
        ];
    }

    public function handleResponse(Player $player, $data): void {}
}
