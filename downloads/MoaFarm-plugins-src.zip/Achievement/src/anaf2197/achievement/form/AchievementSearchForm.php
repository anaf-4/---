<?php
declare(strict_types=1);

namespace anaf2197\achievement\form;

use pocketmine\form\Form;
use pocketmine\player\Player;
use anaf2197\achievement\Achievement;
use anaf2197\achievement\AchievementLoader;
use anaf2197\achievement\PlayerAchievement;

/**
 * 업적 검색 결과 폼.
 * 키워드가 빈 문자열이면 검색어 입력 창을 먼저 보여준다.
 */
final class AchievementSearchForm implements Form {

    /** @param Achievement[] $results */
    public function __construct(
        private readonly string             $keyword,
        private readonly array              $results,
        private readonly ?PlayerAchievement $pa,
    ) {}

    public function jsonSerialize(): array {
        if ($this->keyword === '') {
            return [
                'type'    => 'custom_form',
                'title'   => '§l§8업적 검색',
                'content' => [
                    ['type' => 'input', 'text' => '검색어를 입력하세요', 'placeholder' => '업적 이름 또는 설명...'],
                ],
            ];
        }

        $buttons = [];
        $loader  = AchievementLoader::getInstance();
        foreach ($this->results as $achievement) {
            $completed = $this->pa?->isCompleted($achievement->id) ?? false;
            $pct       = 0;
            if (!$completed && $this->pa !== null) {
                $progress = $this->pa->getProgress($achievement->type);
                $pct      = min(100, (int) ($progress / max(1, $achievement->target) * 100));
            }
            $label = ($completed ? '§a' : '§8') . Achievement::getRarityLabel($achievement->rarity) . ' §f' . $achievement->name;
            $label .= $completed ? '' : " §8({$pct}%)";
            $buttons[] = ['text' => $label];
        }

        if (empty($buttons)) {
            $buttons[] = ['text' => '§c결과 없음'];
        }

        return [
            'type'    => 'form',
            'title'   => '§l§8업적 검색: §f' . $this->keyword,
            'content' => '§8검색 결과: §f' . count($this->results) . '개',
            'buttons' => $buttons,
        ];
    }

    public function handleResponse(Player $player, mixed $data): void {
        if ($data === null) return;
        $loader = AchievementLoader::getInstance();

        // 검색어 입력 창
        if ($this->keyword === '') {
            $keyword = trim($data[0] ?? '');
            if ($keyword === '') {
                $loader->openAchievementCategoryForm($player);
                return;
            }
            $results = $loader->searchAchievements($keyword);
            $pa      = $loader->getPlayerAchievement($player);
            $player->sendForm(new self($keyword, $results, $pa));
            return;
        }

        // 결과 클릭
        if (!is_int($data)) return;
        $achievement = array_values($this->results)[$data] ?? null;
        if ($achievement === null) return;

        $pa = $loader->getPlayerAchievement($player);
        $player->sendForm(new AchievementPlayerDetailForm($achievement, $pa, null));
    }
}
