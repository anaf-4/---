<?php
declare(strict_types=1);

namespace anaf2197\achievement\form;

use pocketmine\form\Form;
use pocketmine\player\Player;
use anaf2197\achievement\Achievement;
use anaf2197\achievement\AchievementLoader;

final class AchievementDetailForm implements Form {

    public function __construct(private Achievement $achievement) {}

    public function jsonSerialize(): array {
        $a = $this->achievement;
        $loader = AchievementLoader::getInstance();

        $typeLabel = match ($a->type) {
            Achievement::TYPE_MINING  => '채광 (MINING)',
            Achievement::TYPE_HUNTING => '사냥 (HUNTING)',
            Achievement::TYPE_GUILD   => '길드 (GUILD)',
            Achievement::TYPE_ECONOMY => '경제 (ECONOMY)',
            default                   => $a->type,
        };

        $isDbOnly = $loader->isDbOnlyAchievement($a->id);
        $isCustom = $loader->isCustomAchievement($a->id);

        $sourceLabel = match (true) {
            $isDbOnly => '§a관리자 추가 (삭제 가능)',
            $isCustom => '§e기본 업적 (관리자 수정됨)',
            default   => '§8achievements.yml',
        };

        return [
            'type'    => 'form',
            'title'   => '§l ' . $a->name,
            'content' => implode(PHP_EOL, [
                ' ',
                '§8설명: ' . $a->description,
                '§8타입: §e' . $typeLabel,
                '§8목표: §f' . number_format($a->target),
                '§8보상금: §6' . number_format($a->rewardMoney) . '원',
                '§8보상 칭호: §r' . ($a->rewardPrefix ?: '§8없음'),
                '§8출처: ' . $sourceLabel,
                ' ',
            ]),
            'buttons' => [
                ['text' => '§l업적 정보 편집'],
                ['text' => '§l보상 아이템 설정'],
                $isDbOnly
                    ? ['text' => '§l§c삭제']
                    : ['text' => '§8삭제 불가 (YML 기반 업적)'],
                ['text' => '§r← 목록으로'],
            ],
        ];
    }

    public function handleResponse(Player $player, $data): void {
        if ($data === null) return;
        $loader = AchievementLoader::getInstance();
        match ((int) $data) {
            0 => $player->sendForm(new AchievementEditForm($this->achievement)),
            1 => $loader->openRewardGuiForAchievement($player, $this->achievement->id),
            2 => $loader->isDbOnlyAchievement($this->achievement->id)
                    ? $player->sendForm(new AchievementDeleteConfirmForm($this->achievement))
                    : $player->sendMessage(AchievementLoader::$prefix . '§cYML 기반 업적은 삭제할 수 없습니다. achievements.yml을 직접 수정하세요.'),
            3 => $player->sendForm(new AchievementManageForm($loader->getAchievements())),
            default => null,
        };
    }
}
