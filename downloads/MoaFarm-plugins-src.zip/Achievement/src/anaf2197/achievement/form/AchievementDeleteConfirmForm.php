<?php
declare(strict_types=1);

namespace anaf2197\achievement\form;

use pocketmine\form\Form;
use pocketmine\player\Player;
use anaf2197\achievement\Achievement;
use anaf2197\achievement\AchievementLoader;

final class AchievementDeleteConfirmForm implements Form {

    public function __construct(private Achievement $achievement) {}

    public function jsonSerialize(): array {
        return [
            'type'    => 'modal',
            'title'   => '§l 업적 삭제 확인',
            'content' => '"§c' . $this->achievement->name . '§r" 업적을 삭제하시겠습니까?' . PHP_EOL . PHP_EOL
                . '§8이 업적에 대한 모든 플레이어의 진행도와 달성 기록도 함께 삭제됩니다.',
            'button1' => '§c삭제',
            'button2' => '취소',
        ];
    }

    public function handleResponse(Player $player, $data): void {
        $loader = AchievementLoader::getInstance();
        if ($data === true) {
            $loader->deleteDefinition($this->achievement->id);
            $player->sendMessage(AchievementLoader::$prefix . '"' . $this->achievement->name . '" 업적을 삭제했습니다.');
        }
        $player->sendForm(new AchievementManageForm($loader->getAchievements()));
    }
}
