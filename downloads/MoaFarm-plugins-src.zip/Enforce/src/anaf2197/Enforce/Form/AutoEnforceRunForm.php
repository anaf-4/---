<?php

declare(strict_types=1);

namespace anaf2197\Enforce\Form;

use anaf2197\Enforce\Enforce;
use anaf2197\Enforce\Util\MinUtil;
use anaf2197\economyapi\EconomyAPI;
use anaf2197\equipment\EquipmentLoader;
use anaf2197\equipment\ToolProperties;
use anaf2197\equipment\ToolTypes;
use pocketmine\form\Form;
use pocketmine\item\Item;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;

/**
 * 자동 강화 확인 + 실행 폼
 * mode: 'target' = 목표 레벨까지 / 'count' = N회 시도
 */
final class AutoEnforceRunForm implements Form
{
    private int $startLevel;

    public function __construct(
        private readonly Item   $item,
        private readonly string $mode,
        private readonly int    $value
    ) {
        $this->startLevel = $item->getNamedTag()->getInt('enforce.level', 0);
    }

    public function jsonSerialize(): array
    {
        $desc = $this->mode === 'target'
            ? "목표 §e{$this->value}강§f 달성까지 자동 강화"
            : "최대 §e{$this->value}회§f 자동 강화 시도";

        $price     = Enforce::getPriceForLevel($this->startLevel);
        $runeCount = Enforce::getRuneCount($this->startLevel);
        $runeName  = implode('/', array_map(fn($i) => $i->getName(), Enforce::getRuneItems()));
        $per       = Enforce::getSuccessRate($this->startLevel);

        $brk      = Enforce::getBreakRandForLevel($this->startLevel);
        $costLine = '§f1회당 비용: §e' . number_format($price) . '원'
            . ($runeCount > 0 ? ' + §d' . $runeName . ' ' . $runeCount . '개' : '');

        return [
            'type'    => 'modal',
            'title'   => '§l자동 강화 확인',
            'content' => implode("\n", [
                ' ',
                '§f현재 레벨: §a' . $this->startLevel . '강',
                $desc,
                ' ',
                $costLine,
                '§f현재 레벨 성공 확률: §e' . $per . '% §8| 파괴 확률: §c' . $brk . '%',
                ' ',
                '§c※ 실패 시 레벨 하락 및 파괴 가능',
                '§c※ 돈·룬 부족 시 자동 중단',
                '§c※ 장비 파괴 시 즉시 중단',
                ' ',
            ]),
            'button1' => '§l자동 강화 시작',
            'button2' => '§l취소',
        ];
    }

    public function handleResponse(Player $player, $data): void
    {
        if (!$data) return;

        $item = clone $this->item;
        $nbt  = $item->getNamedTag();

        $level      = $this->startLevel;
        $originName = $nbt->getString('enforce.name', $item->getName());

        $tags      = $nbt->getCompoundTag(EquipmentLoader::TAG_EQUIPMENT);
        $isWeapon  = $tags->getString(ToolTypes::TAG_TYPE) === 'equipment.weapon';
        $atk       = $tags->getInt(ToolProperties::STAT_ATK, 0);
        $def       = $tags->getInt(ToolProperties::STAT_DEF, 0);

        $attempts  = 0;
        $successes = 0;
        $fails     = 0;
        $destroyed = false;
        $stopReason = '';

        $limit = $this->mode === 'target' ? 999 : $this->value;

        while ($attempts < $limit) {
            if ($level >= Enforce::MAX_LEVEL) {
                $stopReason = '최대 레벨 달성';
                break;
            }
            if ($this->mode === 'target' && $level >= $this->value) {
                $stopReason = '목표 레벨 달성';
                break;
            }

            $price     = Enforce::getPriceForLevel($level);
            $per       = Enforce::getSuccessRate($level);
            $runeCount = Enforce::getRuneCount($level);

            // 돈 확인
            if (EconomyAPI::getInstance()->getMoney($player) < $price) {
                $stopReason = '돈 부족';
                break;
            }

            // 룬 확인
            $runeTemplate = null;
            if ($runeCount > 0) {
                $runeTemplate = Enforce::findAvailableRune($player, $runeCount);
                if ($runeTemplate === null) {
                    $stopReason = '룬 부족';
                    break;
                }
            }

            // 소모
            EconomyAPI::getInstance()->reduceMoney($player, $price);
            if ($runeTemplate !== null) {
                $player->getInventory()->removeItem($runeTemplate);
            }

            $attempts++;
            $pityData = Enforce::getEffectiveSuccessRate($player->getName(), $level);
            $per      = $pityData['effective'];
            $rand     = rand(1, 100);

            if ($rand <= $per) {
                // 성공
                if ($level === 0) {
                    $nbt->setString('enforce.name', $originName);
                }
                $level++;
                $successes++;
                $nbt->setInt('enforce.level', $level);

                if ($isWeapon) {
                    $atk++;
                    EquipmentLoader::getInstance()->setEquipmentOption($item, ToolProperties::STAT_ATK, $atk);
                } else {
                    $def++;
                    EquipmentLoader::getInstance()->setEquipmentOption($item, ToolProperties::STAT_DEF, $def);
                }
                $item->setCustomName($originName . ' §r§o§8[' . $level . '강]');
                Enforce::log($player->getName(), $originName, $level - 1, $level, 'success');
                Enforce::resetPity($player->getName());

            } else {
                // 실패
                $fails++;
                Enforce::incrementPity($player->getName());

                // 파괴 판정 (레벨별 파괴 확률)
                if (rand(1, 100) <= Enforce::getBreakRandForLevel($level)) {
                    Enforce::log($player->getName(), $originName, $level, 0, 'destroy');
                    Enforce::resetPity($player->getName());
                    $destroyed  = true;
                    $stopReason = '장비 파괴';
                    break;
                }

                // 레벨 하락
                if ($level > 0) {
                    $level--;
                    $nbt->setInt('enforce.level', $level);

                    if ($isWeapon) {
                        $atk--;
                        EquipmentLoader::getInstance()->setEquipmentOption($item, ToolProperties::STAT_ATK, $atk);
                    } else {
                        $def--;
                        EquipmentLoader::getInstance()->setEquipmentOption($item, ToolProperties::STAT_DEF, $def);
                    }

                    if ($level === 0) {
                        $nbt->removeTag('enforce.level');
                        $nbt->removeTag('enforce.name');
                        $item->setCustomName($originName);
                    } else {
                        $item->setCustomName($originName . ' §r§o§8[' . $level . '강]');
                    }
                }
            }
        }

        // 아이템 적용
        if ($destroyed) {
            $player->getInventory()->setItemInHand(VanillaItems::AIR());
        } else {
            $player->getInventory()->setItemInHand($item);
        }

        // 결과 출력
        $player->sendMessage('');
        $player->sendMessage(MinUtil::ChatPrefix . '§l자동 강화 완료!');
        $player->sendMessage(MinUtil::ChatPrefix
            . '총 시도: §f' . $attempts . '회'
            . ' §8| 성공: §a' . $successes . '회'
            . ' §8| 실패: §c' . $fails . '회');
        if (!$destroyed) {
            $player->sendMessage(MinUtil::ChatPrefix
                . '시작: §8' . $this->startLevel . '강 §f→ §a최종: ' . $level . '강');
        } else {
            $player->sendMessage(MinUtil::ChatPrefix . '§4장비가 파괴되었습니다.');
        }
        if ($stopReason !== '' && $stopReason !== '목표 레벨 달성' && $stopReason !== '최대 레벨 달성') {
            $player->sendMessage(MinUtil::ChatPrefix . '§c중단 사유: ' . $stopReason);
        }
        $player->sendMessage('');
    }
}
