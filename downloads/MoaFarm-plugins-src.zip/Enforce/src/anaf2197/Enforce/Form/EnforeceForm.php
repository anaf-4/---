<?php

declare(strict_types=1);

namespace anaf2197\Enforce\Form;

use anaf2197\Enforce\Enforce;
use anaf2197\Enforce\Form\AutoEnforceForm;
use anaf2197\Enforce\Util\MinUtil;
use pocketmine\form\Form;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use anaf2197\economyapi\EconomyAPI;
use anaf2197\equipment\EquipmentLoader;
use anaf2197\equipment\ToolProperties;
use anaf2197\equipment\ToolTypes;

final class EnforeceForm implements Form
{
	public function jsonSerialize(): array
	{
		return [
			'type'    => 'custom_form',
			'title'   => '§l강화',
			'content' => [
				['type' => 'label', 'text' =>
					"강화 아이템은 현재 손의 아이템으로 진행됩니다.\n"
					. "성공 시 장비가 1강 업그레이드 됩니다.\n"
					. "§c실패 시 장비의 강화가 내려가거나 낮은 확률로 파괴됩니다.\n"
					. "§e강화 레벨에 따라 성공 확률과 룬 소모량이 다릅니다.\n"
					. "§b강화 보호권이 있으면 안전 강화 선택 시 실패해도 부작용이 없습니다."
				],
				MinUtil::makeDropdown('강화 종류를 선택하세요', ['일반 강화', '안전 강화', '자동 강화']),
			]
		];
	}

	public function handleResponse(Player $player, $data): void
	{
		if ($data === null) return;

		$money = EconomyAPI::getInstance()->getMoney($player);
		$item  = $player->getInventory()->getItemInHand();

		// ── 기본 유효성 검사 ──────────────────────────────────
		if ($item->isNull()) {
			$player->sendMessage(MinUtil::ChatPrefix . '손에 아이템을 들고 사용해주세요.');
			return;
		}
		if (!EquipmentLoader::getInstance()->isEquipment($item)) {
			$player->sendMessage(MinUtil::ChatPrefix . '장비만 강화할 수 있습니다.');
			return;
		}

		$nametag     = $item->getNamedTag();
		$level       = $nametag->getInt('enforce.level', 0);
		$origin_name = $nametag->getString('enforce.name', $item->getName());
		$mode        = (int)$data[1]; // 0=일반, 1=안전, 2=자동
		$is_safe     = ($mode === 1);
		$max_level   = Enforce::MAX_LEVEL;

		// ── 자동 강화 분기 ────────────────────────────────────
		if ($mode === 2) {
			if ($level >= $max_level) {
				$player->sendMessage(MinUtil::ChatPrefix . "장비가 이미 최대 레벨({$max_level}강)입니다.");
				return;
			}
			$player->sendForm(new AutoEnforceForm($item));
			return;
		}

		if ($level >= $max_level) {
			$player->sendMessage(MinUtil::ChatPrefix . "장비의 강화는 {$max_level}강까지만 가능합니다.");
			return;
		}

		// ── 현재 레벨에 맞는 확률/룬소모량 (보험 보정 적용) ──────
		$pityData  = Enforce::getEffectiveSuccessRate($player->getName(), $level);
		$per       = $pityData['effective'];
		$pityBonus = $pityData['bonus'];
		$runeCount = Enforce::getRuneCount($level);
		$price     = Enforce::getPriceForLevel($level);

		if ($money < $price) {
			$player->sendMessage(MinUtil::ChatPrefix . "돈이 부족합니다. (필요: " . $price . "원)");
			return;
		}

		// ── 룬 보유 확인 (소모량 0이면 건너뜀) ─────────────────
		$runeTemplate = null;
		if ($runeCount > 0) {
			$runeTemplate = Enforce::findAvailableRune($player, $runeCount);

			if ($runeTemplate === null) {
				$runeNames = implode(', ', array_map(fn($i) => $i->getName(), Enforce::getRuneItems()));
				$player->sendMessage(MinUtil::ChatPrefix . "룬이 부족합니다. (필요: {$runeCount}개 | 사용 가능한 룬: {$runeNames})");
				return;
			}
		}

		// ── 안전 강화: 보호권 확인 ────────────────────────────
		if ($is_safe) {
			if (Enforce::isSafe($player)) {
				$player->sendMessage(MinUtil::ChatPrefix . '강화 보호권이 소모되었습니다.');
				$player->getInventory()->removeItem(Enforce::getProtectItem());
			} else {
				$player->sendMessage(MinUtil::ChatPrefix . '강화 보호권이 없습니다.');
				return;
			}
		}

		// ── 장비 스탯 읽기 ────────────────────────────────────
		$tags      = $item->getNamedTag()->getCompoundTag(EquipmentLoader::TAG_EQUIPMENT);
		$is_weapon = $tags->getString(ToolTypes::TAG_TYPE) === 'equipment.weapon';
		$atk       = $tags->getInt(ToolProperties::STAT_ATK, 0);
		$def       = $tags->getInt(ToolProperties::STAT_DEF, 0);

		// ── 공통 소모: 골드 + 룬 ─────────────────────────────
		EconomyAPI::getInstance()->reduceMoney($player, $price);
		if ($runeTemplate !== null) {
			$player->getInventory()->removeItem($runeTemplate);
		}

		$rand = rand(1, 100);

		// ── 강화 실패 ─────────────────────────────────────────
		if ($rand > $per) {
			$fails = Enforce::incrementPity($player->getName());
			$pityMsg = $pityBonus > 0 ? " §d[보험 +{$pityBonus}% 적용 중]" : '';
			$player->sendMessage(MinUtil::ChatPrefix . "§c강화 실패! §8(확률: {$per}% | 파괴: " . Enforce::getBreakRandForLevel($level) . "% | 연속 실패: §e{$fails}§8회){$pityMsg}");

			if ($is_safe) {
				Enforce::log($player->getName(), $origin_name, $level, $level, 'fail');
				return;
			}

			// 파괴 판정 (레벨별 파괴 확률 적용)
			if (rand(1, 100) <= Enforce::getBreakRandForLevel($level)) {
				Enforce::log($player->getName(), $origin_name, $level, 0, 'destroy');
				Enforce::resetPity($player->getName());
				$player->sendMessage(MinUtil::ChatPrefix . '§4장비가 파괴되었습니다.');
				$player->getInventory()->setItemInHand(VanillaItems::AIR());
				return;
			}

			// 강화 레벨 하락
			if ($level <= 0) {
				Enforce::log($player->getName(), $origin_name, $level, $level, 'fail');
				return;
			}
			$level--;
			$nametag->setInt('enforce.level', $level);

			if ($is_weapon) {
				EquipmentLoader::getInstance()->setEquipmentOption($item, ToolProperties::STAT_ATK, $atk - 1);
			} else {
				EquipmentLoader::getInstance()->setEquipmentOption($item, ToolProperties::STAT_DEF, $def - 1);
			}

			if ($level === 0) {
				$nametag->removeTag('enforce.level');
				$nametag->removeTag('enforce.name');
				$item->setCustomName($origin_name);
			} else {
				$item->setCustomName($origin_name . ' §r§o§8[' . $level . '강]');
			}
			Enforce::log($player->getName(), $origin_name, $level + 1, $level, 'fail');
			$player->sendMessage(MinUtil::ChatPrefix . "장비의 강화가 1강 내려갔습니다. (현재: {$level}강)");
			$player->getInventory()->setItemInHand($item);
			return;
		}

		// ── 강화 성공 ─────────────────────────────────────────
		if ($level === 0) {
			$nametag->setString('enforce.name', $origin_name);
		}
		$level++;
		$nametag->setInt('enforce.level', $level);

		if ($is_weapon) {
			EquipmentLoader::getInstance()->setEquipmentOption($item, ToolProperties::STAT_ATK, $atk + 1);
		} else {
			EquipmentLoader::getInstance()->setEquipmentOption($item, ToolProperties::STAT_DEF, $def + 1);
		}

		$item->setCustomName($origin_name . ' §r§o§8[' . $level . '강]');
		Enforce::log($player->getName(), $origin_name, $level - 1, $level, 'success');
		Enforce::resetPity($player->getName());
		$player->sendMessage(MinUtil::ChatPrefix . "§a강화 성공! §8(현재: {$level}강 | 성공 확률: {$per}%)");
		$player->getInventory()->setItemInHand($item);

		// 업적 연동: 강화 달성 레벨 최고 기록 갱신
		if (class_exists(\anaf2197\achievement\AchievementLoader::class)) {
			$al  = \anaf2197\achievement\AchievementLoader::getInstance();
			$pa  = $al->getPlayerAchievement($player);
			$cur = $pa?->getProgress(\anaf2197\achievement\Achievement::TYPE_ENFORCE_LEVEL) ?? 0;
			if ($level > $cur) {
				$al->addProgress($player, \anaf2197\achievement\Achievement::TYPE_ENFORCE_LEVEL, $level - $cur);
			}
			// 강화 성공 횟수 업적도 연동
			$al->addProgress($player, \anaf2197\achievement\Achievement::TYPE_UPGRADE);
		}
	}
}