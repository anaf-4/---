<?php

declare(strict_types=1);

namespace anaf2197\Enforce\Form;

use anaf2197\Enforce\Enforce;
use anaf2197\Enforce\Util\MinUtil;
use pocketmine\form\Form;
use pocketmine\item\Item;
use pocketmine\player\Player;

/**
 * 자동 강화 설정 폼
 * 모드 0: 목표 레벨까지 시도
 * 모드 1: N회 시도
 */
final class AutoEnforceForm implements Form
{
    private int $currentLevel;

    public function __construct(private readonly Item $item)
    {
        $this->currentLevel = $item->getNamedTag()->getInt('enforce.level', 0);
    }

    public function jsonSerialize(): array
    {
        $max = Enforce::MAX_LEVEL;
        return [
            'type'    => 'custom_form',
            'title'   => '§l자동 강화 설정',
            'content' => [
                [
                    'type' => 'label',
                    'text' => implode("\n", [
                        ' ',
                        '§f현재 강화 레벨: §e' . $this->currentLevel . '강 §8/ §f' . $max . '강',
                        ' ',
                        '§c※ 자동 강화는 일반 강화만 지원합니다.',
                        '§c※ 실패 시 레벨이 내려가거나 장비가 파괴될 수 있습니다.',
                        '§c※ 파괴 시 즉시 중단됩니다.',
                        ' ',
                    ])
                ],
                [
                    'type'    => 'dropdown',
                    'text'    => '§f강화 모드',
                    'options' => ['목표 레벨까지 시도', 'N회 시도'],
                    'default' => 0,
                ],
                [
                    'type'        => 'input',
                    'text'        => '§f목표 레벨 (모드1) 또는 시도 횟수 (모드2)',
                    'placeholder' => '숫자 입력',
                    'default'     => (string)$max,
                ],
            ],
        ];
    }

    public function handleResponse(Player $player, $data): void
    {
        if (!is_array($data)) return;

        $mode  = (int)($data[1] ?? 0);
        $value = (int)($data[2] ?? 0);

        if ($value <= 0) {
            $player->sendMessage(MinUtil::ChatPrefix . '올바른 값을 입력해주세요.');
            return;
        }

        if ($mode === 0) {
            $target = min($value, Enforce::MAX_LEVEL);
            if ($target <= $this->currentLevel) {
                $player->sendMessage(MinUtil::ChatPrefix . '이미 목표 레벨 이상입니다.');
                return;
            }
            $player->sendForm(new AutoEnforceRunForm($this->item, 'target', $target));
        } else {
            $player->sendForm(new AutoEnforceRunForm($this->item, 'count', $value));
        }
    }
}
