<?php

declare(strict_types=1);

namespace anaf2197\Enforce\Form;

use anaf2197\Enforce\Enforce;
use pocketmine\form\Form;
use pocketmine\player\Player;

final class EnforceRankingForm implements Form {

    private string $content = '';

    public static function build(): self {
        $form = new self();
        $rows = Enforce::getDB()->getEnforceRanking(10);

        if (empty($rows)) {
            $form->content = '§8아직 강화 기록이 없습니다.';
            return $form;
        }

        $lines = ['§l§6[ 강화 명예의 전당 TOP 10 ]', ' '];

        $medals = ['§e1위', '§72위', '§63위'];

        foreach ($rows as $i => $row) {
            $rank      = $i + 1;
            $prefix    = $medals[$i] ?? "§f{$rank}위";
            $name      = $row['player_name'];
            $maxLv     = (int)$row['max_level'];
            $total     = (int)$row['total_attempts'];
            $successes = (int)$row['successes'];
            $destroys  = (int)$row['destroys'];
            $rate      = $total > 0 ? round($successes / $total * 100, 1) : 0;

            $lines[] = $prefix . ' §f' . $name;
            $lines[] = '    §a최고 ' . $maxLv . '강  §8시도 ' . $total . '회  §a성공 ' . $successes . '  §c파괴 ' . $destroys . '  §e' . $rate . '%%';
            $lines[] = ' ';
        }

        $form->content = implode("\n", $lines);
        return $form;
    }

    public function jsonSerialize(): array {
        return [
            'type'    => 'form',
            'title'   => '§l§6강화 순위',
            'content' => $this->content ?: '§8데이터를 불러오는 중...',
            'buttons' => [
                ['text' => '§a확인'],
            ],
        ];
    }

    public function handleResponse(Player $player, $data): void {}
}
