<?php

declare(strict_types=1);

namespace anaf2197\Enforce\Form;

use anaf2197\Enforce\Enforce;
use anaf2197\Enforce\Util\MinUtil;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\transaction\InvMenuTransaction;
use muqsit\invmenu\transaction\InvMenuTransactionResult;
use muqsit\invmenu\type\InvMenuTypeIds;
use pocketmine\block\utils\DyeColor;
use pocketmine\block\VanillaBlocks;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;

/**
 * 강화에 소모될 룬 아이템을 InvMenu GUI로 설정 (여러 종류 등록 가능, 강화 시 택1 소모)
 *
 * 레이아웃 (더블 체스트 54칸):
 *   [19~25] 룬 아이템 배치 슬롯 (최대 7종, 현재 등록된 룬으로 미리 채워짐)
 *   [31] 저장 버튼
 *   [33] 기본값으로 초기화
 *   [40] 취소 버튼
 */
final class RuneItemMenu
{
	private const RUNE_SLOTS = [19, 20, 21, 22, 23, 24, 25];

	public static function open(Player $player): void
	{
		$invMenu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
		$invMenu->setName('§l강화 룬 아이템 설정');

		$inv     = $invMenu->getInventory();
		$barrier = VanillaBlocks::BARRIER()->asItem()->setCustomName('§r ');

		for ($i = 0; $i < 54; $i++) {
			$inv->setItem($i, $barrier);
		}

		// 안내 라벨
		$info = VanillaBlocks::BOOKSHELF()->asItem()
			->setCustomName('§r§l§f강화 룬 설정 안내')
			->setLore([
				'§r§8아래 슬롯에 룬으로 사용할 아이템을 배치하세요.',
				'§r§8최대 ' . count(self::RUNE_SLOTS) . '종까지 등록 가능합니다.',
				'§r§8강화 시 등록된 룬 중 보유한 것을 자동으로 소모합니다.',
			]);
		$inv->setItem(4, $info);

		// 룬 아이템 배치 슬롯 (현재 등록된 룬으로 미리 채움)
		$currentRunes = Enforce::getRuneItems();
		foreach (self::RUNE_SLOTS as $idx => $slot) {
			$rune = $currentRunes[$idx] ?? null;
			$inv->setItem($slot, $rune !== null ? clone $rune : VanillaItems::AIR());
		}

		// 저장 버튼
		$saveBtn = VanillaBlocks::STAINED_GLASS()->setColor(DyeColor::GREEN())->asItem()
			->setCustomName('§r§l§a저장')
			->setLore(['§r§8배치된 아이템들을 강화 룬으로 저장합니다.', '§r§8비워두면 기본 룬으로 초기화됩니다.']);
		$inv->setItem(31, $saveBtn);

		// 기본값으로 초기화 버튼
		$resetBtn = VanillaBlocks::STAINED_GLASS()->setColor(DyeColor::LIGHT_GRAY())->asItem()
			->setCustomName('§r§l§8기본값으로 초기화')
			->setLore(['§r§8기본 룬 아이템(루나리스의 룬)으로 초기화합니다.']);
		$inv->setItem(33, $resetBtn);

		// 취소 버튼
		$cancelBtn = VanillaBlocks::STAINED_GLASS()->setColor(DyeColor::RED())->asItem()
			->setCustomName('§r§l§c취소');
		$inv->setItem(40, $cancelBtn);

		$invMenu->setListener(function (InvMenuTransaction $transaction): InvMenuTransactionResult {
			$slot   = $transaction->getAction()->getSlot();
			$player = $transaction->getPlayer();
			$inv    = $transaction->getAction()->getInventory();

			// 룬 아이템 배치 슬롯만 자유롭게 허용
			if (in_array($slot, self::RUNE_SLOTS, true)) {
				return $transaction->continue();
			}

			// 저장
			if ($slot === 31) {
				$items = [];
				foreach (self::RUNE_SLOTS as $runeSlot) {
					$item = $inv->getItem($runeSlot);
					if ($item->isNull()) continue;

					$clone = clone $item;
					$clone->setCount(1);

					$duplicate = false;
					foreach ($items as $existing) {
						if ($existing->equals($clone, true, false)) {
							$duplicate = true;
							break;
						}
					}
					if (!$duplicate) $items[] = $clone;
				}

				Enforce::setRuneItems($items);

				if (count($items) > 0) {
					$names = implode(', ', array_map(fn($i) => $i->getName(), $items));
					$player->sendMessage(MinUtil::ChatPrefix . "§a강화 룬이 §f{$names}§a(으)로 설정되었습니다. (총 " . count($items) . "종)");
				} else {
					$player->sendMessage(MinUtil::ChatPrefix . '§8룬 아이템이 기본값(루나리스의 룬)으로 초기화되었습니다.');
				}

				$player->removeCurrentWindow();
				return $transaction->discard();
			}

			// 기본값으로 초기화
			if ($slot === 33) {
				Enforce::setRuneItems([]);
				$player->sendMessage(MinUtil::ChatPrefix . '§8룬 아이템이 기본값(루나리스의 룬)으로 초기화되었습니다.');
				$player->removeCurrentWindow();
				return $transaction->discard();
			}

			// 취소
			if ($slot === 40) {
				$player->removeCurrentWindow();
				return $transaction->discard();
			}

			return $transaction->discard();
		});

		$invMenu->setInventoryCloseListener(function (Player $player, \pocketmine\inventory\Inventory $inv): void {
			// 창 닫힐 때 룬 슬롯에 남아있는 아이템을 인벤토리로 반환
			foreach (self::RUNE_SLOTS as $slot) {
				$item = $inv->getItem($slot);
				if (!$item->isNull()) {
					$player->getInventory()->addItem($item);
				}
			}
		});

		$invMenu->send($player);
	}
}
