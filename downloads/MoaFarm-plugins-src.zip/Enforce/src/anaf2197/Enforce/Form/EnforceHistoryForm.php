<?php

declare(strict_types=1);

namespace anaf2197\Enforce\Form;

use anaf2197\Enforce\Enforce;
use pocketmine\form\Form;
use pocketmine\player\Player;

final class EnforceHistoryForm implements Form {

    public function jsonSerialize(): array {
        return [
            'type'    => 'form',
            'title'   => '§l§6강화 이력',
            'content' => $this->buildContent(),
            'buttons' => [
                ['text' => '§a확인'],
            ],
        ];
    }

    private function buildContent(): string {
        // Form이 플레이어 없이 jsonSerialize 되므로 빈 문자열로 초기화,
        // 실제 데이터는 withPlayer()로 주입
        return $this->content ?? '§8이력을 불러오는 중...';
    }

    private string $content = '';

    public static function forPlayer(Player $player): self {
        $form  = new self();
        $name  = strtolower($player->getName());
        $logs  = Enforce::getPlayerLogs($name, 15);
        $stats = Enforce::getDB()->getPlayerStats($name);

        $resultLabel = [
            'success' => '§a성공',
            'fail'    => '§e실패',
            'destroy' => '§c파괴',
        ];

        $lines = [];

        // ── 투자 통계 섹션 ────────────────────────────────────
        if (!empty($stats) && (int)($stats['total_attempts'] ?? 0) > 0) {
            $maxLv     = (int)($stats['max_level'] ?? 0);
            $total     = (int)($stats['total_attempts'] ?? 0);
            $successes = (int)($stats['successes'] ?? 0);
            $destroys  = (int)($stats['destroys'] ?? 0);
            $rate      = $total > 0 ? round($successes / $total * 100, 1) : 0;

            // 누적 소모 비용 계산 (레벨별 시도 횟수 기반)
            $totalCost = 0;
            foreach ($logs as $row) {
                $totalCost += Enforce::getPriceForLevel((int)$row['from_level']);
            }

            $lines[] = '§l§e[ 나의 강화 통계 ]';
            $lines[] = ' §f최고 달성: §a' . $maxLv . '강';
            $lines[] = ' §f총 시도: §f' . $total . '회  §a성공: ' . $successes . '회  §c파괴: ' . $destroys . '회';
            $lines[] = ' §f성공률: §e' . $rate . '%%';
            $lines[] = ' §f이력 내 소모: §e' . number_format($totalCost) . '원';
            $lines[] = ' ';
            $lines[] = '§l§8[ 최근 강화 이력 ]';
        }

        if (empty($logs)) {
            $lines[] = '§8강화 이력이 없습니다.';
        } else {
            foreach ($logs as $row) {
                $res   = $resultLabel[$row['result']] ?? '§8?';
                $from  = (int)$row['from_level'];
                $to    = (int)$row['to_level'];
                $arrow = $row['result'] === 'success' ? '§a→ §f' . $to . '강' : ($row['result'] === 'destroy' ? '§c파괴' : '§e→ §f' . $to . '강');
                $date  = substr($row['created_at'], 5, 11);
                $lines[] = $res . ' §e' . $row['item_name'] . ' §8' . $from . '강 ' . $arrow . '  §8(' . $date . ')';
            }
        }

        $form->content = implode("\n", $lines);
        return $form;
    }

    public function handleResponse(Player $player, $data): void {}
}
