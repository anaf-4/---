<?php

declare(strict_types=1);

namespace anaf2197\Enforce\Form;

use anaf2197\Enforce\Enforce;
use anaf2197\Enforce\Util\MinUtil;
use pocketmine\form\Form;
use pocketmine\player\Player;
use anaf2197\Enforce\Form\RuneItemMenu;

/**
 * 강화 관리 폼 — 2단계 구성
 *   1단계: 기본 설정(보호권·룬·보험) + 편집할 구간 선택
 *   2단계: 선택한 구간의 레벨별 비용 / 성공확률 / 룬소모량 / 파괴확률 편집
 */
final class EnforeceManagerForm implements Form
{
	private const GROUP_SIZE = 5; // 한 번에 편집할 레벨 수

	/** 2단계 폼인지 여부와 시작 레벨을 기억 */
	private bool $isLevelEdit;
	private int  $startLevel;

	public function __construct(bool $isLevelEdit = false, int $startLevel = 0)
	{
		$this->isLevelEdit = $isLevelEdit;
		$this->startLevel  = $startLevel;
	}

	public function jsonSerialize(): array
	{
		if ($this->isLevelEdit) {
			return $this->buildLevelEditForm();
		}
		return $this->buildMainForm();
	}

	// ── 1단계: 기본 설정 폼 ────────────────────────────────
	private function buildMainForm(): array
	{
		$max    = Enforce::MAX_LEVEL;
		$groups = [];
		for ($i = 0; $i < $max; $i += self::GROUP_SIZE) {
			$end      = min($i + self::GROUP_SIZE - 1, $max - 1);
			$groups[] = "{$i}강 → " . ($end + 1) . '강 구간';
		}

		$runeItems   = Enforce::getRuneItems();
		$runePreview = implode(', ', array_map(fn($i) => $i->getName(), $runeItems));

		return [
			'type'    => 'custom_form',
			'title'   => '§l강화 관리',
			'content' => [
				['type' => 'label', 'text' => MinUtil::FormPrefix . '강화 보호권은 손에 든 아이템으로 설정됩니다. (공기일 시 없음)'],
				['type' => 'label', 'text' => MinUtil::FormPrefix . "현재 룬 아이템: §e{$runePreview}"],
				MinUtil::makeToggle('룬 아이템 변경 (GUI 열기, 여러 개 등록 가능)', false),
				['type' => 'label', 'text' => MinUtil::FormPrefix . '§d──── 강화 보험(천장) 설정 ────'],
				MinUtil::makeInput('연속 실패 보정 시작 횟수', (string)Enforce::getPityThreshold(), (string)Enforce::getPityThreshold()),
				MinUtil::makeInput('초과 실패 1회당 성공률 보정 (%)', (string)Enforce::getPityBonus(), (string)Enforce::getPityBonus()),
				['type' => 'label', 'text' => MinUtil::FormPrefix . '§d──── 레벨별 설정 ────'],
				MinUtil::makeDropdown('레벨별 비용/확률/룬소모량을 편집할 구간', $groups, 0),
				MinUtil::makeToggle('레벨별 설정 편집 열기', false),
			]
		];
	}

	// ── 2단계: 레벨별 비용 + 성공확률 + 룬소모량 + 파괴확률 편집 폼 ────────────
	private function buildLevelEditForm(): array
	{
		$content = [
			['type' => 'label', 'text' => "§l{$this->startLevel}강 ~ " . ($this->startLevel + self::GROUP_SIZE - 1) . "강 구간 편집\n§r§8(각 행 = 해당 강 → 다음 강 시도 시 적용)"],
		];

		for ($i = $this->startLevel; $i < $this->startLevel + self::GROUP_SIZE && $i < Enforce::MAX_LEVEL; $i++) {
			$price = Enforce::getPriceForLevel($i);
			$rate  = Enforce::getSuccessRate($i);
			$runes = Enforce::getRuneCount($i);
			$brk   = Enforce::getBreakRandForLevel($i);
			$content[] = ['type' => 'label', 'text' => "§e▶ {$i}강 → " . ($i + 1) . "강"];
			$content[] = MinUtil::makeInput("  강화 비용 (원)", (string)$price, (string)$price);
			$content[] = MinUtil::makeInput("  성공 확률 (%)", (string)$rate, (string)$rate);
			$content[] = MinUtil::makeInput("  룬 소모량", (string)$runes, (string)$runes);
			$content[] = MinUtil::makeInput("  파괴 확률 (%)", (string)$brk, (string)$brk);
		}

		return [
			'type'    => 'custom_form',
			'title'   => '§l레벨별 강화 설정',
			'content' => $content,
		];
	}

	public function handleResponse(Player $player, $data): void
	{
		if ($data === null) return;

		if ($this->isLevelEdit) {
			$this->handleLevelEdit($player, $data);
		} else {
			$this->handleMain($player, $data);
		}
	}

	// ── 1단계 처리 ─────────────────────────────────────────
	private function handleMain(Player $player, array $data): void
	{
		// $data[0] = label (보호권 안내, skip)
		// $data[1] = label (현재 룬 아이템, skip)
		$openRuneUI     = (bool)$data[2];
		// $data[3] = label (보험 설정 구분선, skip)
		$pityThreshold  = trim($data[4]);
		$pityBonus      = trim($data[5]);
		// $data[6] = label (레벨별 설정 구분선, skip)
		$groupIdx       = (int)$data[7];
		$openEdit       = (bool)$data[8];
		$protect    = $player->getInventory()->getItemInHand();

		Enforce::setProtect($protect->isNull() ? null : MinUtil::ItemDataSerialize($protect));

		if (is_numeric($pityThreshold) && (int)$pityThreshold >= 0) {
			Enforce::setPityThreshold((int)$pityThreshold);
		}
		if (is_numeric($pityBonus) && (int)$pityBonus >= 0) {
			Enforce::setPityBonus((int)$pityBonus);
		}

		$player->sendMessage(MinUtil::ChatPrefix . "기본 설정 저장 완료. (보험: {$pityThreshold}회 초과 시 +{$pityBonus}%씩)");

		if ($openRuneUI) {
			RuneItemMenu::open($player);
			return;
		}

		if ($openEdit) {
			$startLevel = $groupIdx * self::GROUP_SIZE;
			$player->sendForm(new EnforeceManagerForm(true, $startLevel));
		}
	}

	// ── 2단계 처리 ─────────────────────────────────────────
	private function handleLevelEdit(Player $player, array $data): void
	{
		// content 구조: [0]=label, 그 뒤로 레벨마다 label+input*4 반복
		$prices = Enforce::getPrices();
		$rates  = Enforce::getSuccessRates();
		$counts = Enforce::getRuneCounts();
		$breaks = Enforce::getBreakRands();
		$idx    = 1; // data[0] = 상단 label 스킵

		for ($i = $this->startLevel; $i < $this->startLevel + self::GROUP_SIZE && $i < Enforce::MAX_LEVEL; $i++) {
			// $idx = label (스킵), $idx+1 = 강화비용, $idx+2 = 성공확률, $idx+3 = 룬소모량, $idx+4 = 파괴확률
			$priceVal = trim((string)($data[$idx + 1] ?? ''));
			$rateVal  = trim((string)($data[$idx + 2] ?? ''));
			$runeVal  = trim((string)($data[$idx + 3] ?? ''));
			$brkVal   = trim((string)($data[$idx + 4] ?? ''));
			$idx += 5;

			if (!is_numeric($priceVal) || !is_numeric($rateVal) || !is_numeric($runeVal) || !is_numeric($brkVal)) {
				$player->sendMessage(MinUtil::ChatPrefix . "{$i}강 설정값이 올바르지 않습니다. (숫자만 입력)");
				return;
			}

			$price = (int)$priceVal;
			$rate  = (int)$rateVal;
			$rune  = (int)$runeVal;
			$brk   = (int)$brkVal;

			if ($price < 0) {
				$player->sendMessage(MinUtil::ChatPrefix . "{$i}강 강화 비용은 0 이상이어야 합니다.");
				return;
			}
			if ($rate < 0 || $rate > 100) {
				$player->sendMessage(MinUtil::ChatPrefix . "{$i}강 성공 확률은 0~100 사이여야 합니다.");
				return;
			}
			if ($rune < 0) {
				$player->sendMessage(MinUtil::ChatPrefix . "{$i}강 룬 소모량은 0 이상이어야 합니다.");
				return;
			}
			if ($brk < 0 || $brk > 100) {
				$player->sendMessage(MinUtil::ChatPrefix . "{$i}강 파괴 확률은 0~100 사이여야 합니다.");
				return;
			}

			$prices[$i] = $price;
			$rates[$i]  = $rate;
			$counts[$i] = $rune;
			$breaks[$i] = $brk;
		}

		Enforce::setPrices($prices);
		Enforce::setSuccessRates($rates);
		Enforce::setRuneCounts($counts);
		Enforce::setBreakRands($breaks);

		$end = min($this->startLevel + self::GROUP_SIZE - 1, Enforce::MAX_LEVEL - 1);
		$player->sendMessage(MinUtil::ChatPrefix . "{$this->startLevel}강 ~ {$end}강 구간 설정이 저장되었습니다.");
	}
}
