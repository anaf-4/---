<?php

declare(strict_types=1);

namespace anaf2197\Enforce;

use anaf2197\Enforce\Command\EnforceCommand;
use anaf2197\Enforce\Command\EnforceManagerCommand;
use anaf2197\Enforce\Command\EnforceRankCommand;
use anaf2197\Enforce\db\EnforceDB;
use anaf2197\Enforce\Util\MinUtil;
use anaf2197\servercore\item\ItemDesign;
use anaf2197\servercore\item\ItemTypes;
use anaf2197\servercore\item\ServerItems;
use pocketmine\item\Item;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;

final class Enforce extends PluginBase
{
    public const MAX_LEVEL = 30;

    /**
     * 레벨별 기본값 (1강 → 2강 ... 30강 → 31강 순서, index 0~29)
     * 약 한 달 간 천천히 30강까지 진행하도록 설계된 곡선
     */
    public const DEFAULT_PRICES = [
        20000,   24000,   30000,   36000,   44000,
        54000,   66000,   80000,   96000,   116000,
        140000,  170000,  200000,  240000,  290000,
        350000,  420000,  500000,  600000,  720000,
        860000,  1000000, 1160000, 1340000, 1540000,
        1760000, 2000000, 2300000, 2640000, 3000000,
    ];

    public const DEFAULT_SUCCESS_RATES = [
        95, 93, 90, 88, 85,
        82, 79, 76, 73, 70,
        66, 62, 58, 54, 50,
        46, 42, 38, 35, 32,
        29, 26, 23, 20, 18,
        16, 14, 12, 10, 8,
    ];

    public const DEFAULT_RUNE_COUNTS = [
        1, 1, 1, 1, 2,
        2, 2, 2, 2, 3,
        3, 3, 3, 4, 4,
        4, 5, 5, 5, 6,
        6, 6, 7, 7, 8,
        8, 9, 9, 10, 10,
    ];

    public const DEFAULT_BREAK_RANDS = [
        0, 0, 0, 0, 1,
        1, 1, 1, 2, 2,
        2, 3, 3, 3, 4,
        4, 5, 5, 6, 6,
        7, 8, 9, 10, 11,
        12, 13, 14, 15, 16,
    ];

    private static self      $instance;
    private static EnforceDB $db;

    protected function onEnable(): void
    {
        self::$instance = $this;
        $this->saveDefaultConfig();
        $cfg = $this->getConfig()->get('database', []);

        try {
            self::$db = new EnforceDB(
                $cfg['host']     ?? 'localhost',
                (int)($cfg['port']     ?? 3306),
                $cfg['username'] ?? 'root',
                $cfg['password'] ?? '',
                $cfg['database'] ?? 'moafarm'
            );
            $this->getLogger()->info('강화 DB 연결 완료');
        } catch (\Throwable $e) {
            $this->getLogger()->error('강화 DB 연결 실패: ' . $e->getMessage());
            $this->getServer()->getPluginManager()->disablePlugin($this);
            return;
        }

        $this->getServer()->getCommandMap()->registerAll('enforce', [
            new EnforceCommand(),
            new EnforceManagerCommand(),
            new EnforceRankCommand(),
        ]);
    }

    public static function getInstance(): self
    {
        return self::$instance;
    }

    public static function getDB(): EnforceDB
    {
        return self::$db;
    }

    // ── 레벨별 강화 비용 ───────────────────────────────────
    public static function getPrices(): array
    {
        return self::$db->getPrices(self::MAX_LEVEL, self::DEFAULT_PRICES);
    }

    /** $level = 현재 강화 레벨 (0 ~ MAX_LEVEL-1) */
    public static function getPriceForLevel(int $level): int
    {
        $default = self::DEFAULT_PRICES[$level] ?? 50000;
        return self::$db->getPriceForLevel($level, $default);
    }

    public static function setPrices(array $prices): void
    {
        self::$db->setPrices($prices);
    }

    // ── 레벨별 파괴 확률 ───────────────────────────────────
    /** $level = 현재 강화 레벨 (0 ~ MAX_LEVEL-1) */
    public static function getBreakRandForLevel(int $level): int
    {
        $default = self::DEFAULT_BREAK_RANDS[$level] ?? 10;
        return self::$db->getBreakRandForLevel($level, $default);
    }

    public static function getBreakRands(): array
    {
        $result = [];
        for ($i = 0; $i < self::MAX_LEVEL; $i++) {
            $result[$i] = self::getBreakRandForLevel($i);
        }
        return $result;
    }

    public static function setBreakRands(array $rands): void
    {
        self::$db->setBreakRands($rands);
    }

    // ── 레벨별 성공 확률 ───────────────────────────────────
    public static function getSuccessRates(): array
    {
        $result = [];
        for ($i = 0; $i < self::MAX_LEVEL; $i++) {
            $result[$i] = self::getSuccessRate($i);
        }
        return $result;
    }

    public static function getSuccessRate(int $level): int
    {
        $default = self::DEFAULT_SUCCESS_RATES[$level] ?? max(5, 70 - $level * 2);
        return self::$db->getSuccessRate($level, $default);
    }

    public static function setSuccessRates(array $rates): void
    {
        self::$db->setSuccessRates($rates);
    }

    // ── 레벨별 룬 소모량 ───────────────────────────────────
    public static function getRuneCounts(): array
    {
        $result = [];
        for ($i = 0; $i < self::MAX_LEVEL; $i++) {
            $result[$i] = self::getRuneCount($i);
        }
        return $result;
    }

    public static function getRuneCount(int $level): int
    {
        $default = self::DEFAULT_RUNE_COUNTS[$level] ?? (1 + intdiv($level, 5));
        return self::$db->getRuneCount($level, $default);
    }

    public static function setRuneCounts(array $counts): void
    {
        self::$db->setRuneCounts($counts);
    }

    // ── 강화석(룬) 아이템 (복수 등록, 택1 사용) ──────────────
    /** @return Item[] */
    public static function getRuneItems(): array
    {
        $data = self::$db->getRuneItemsData();
        if ($data !== null) {
            try {
                $list = json_decode($data, true);
                if (is_array($list) && count($list) > 0) {
                    $items = [];
                    foreach ($list as $serialized) {
                        $items[] = MinUtil::ItemDataDeserialize($serialized);
                    }
                    return $items;
                }
            } catch (\Throwable) {}
        }
        // 기본 룬 아이템 (DB에 미설정 시)
        $item = ServerItems::minseo_rune();
        ItemDesign::setItemDesign(
            $item,
            ItemTypes::UNIQUE,
            '루나리스의 룬',
            ['강화 시 소모되는 강화석입니다.'],
        );
        return [$item];
    }

    /** @param Item[] $items */
    public static function setRuneItems(array $items): void
    {
        self::$db->setRuneItems($items);
    }

    /** 플레이어가 보유한 등록된 룬 중 사용 가능한 것을 찾아 개수를 설정한 템플릿으로 반환 */
    public static function findAvailableRune(Player $player, int $count): ?Item
    {
        foreach (self::getRuneItems() as $rune) {
            $template = clone $rune;
            $template->setCount($count);
            if ($player->getInventory()->contains($template)) {
                return $template;
            }
        }
        return null;
    }

    // ── 강화 보호권 ────────────────────────────────────────
    public static function getProtect(): ?string
    {
        return self::$db->getProtect();
    }

    public static function getProtectItem(): ?Item
    {
        $data = self::getProtect();
        if ($data === null) return null;
        return MinUtil::ItemDataDeserialize($data);
    }

    public static function setProtect(?string $protect): void
    {
        self::$db->setProtect($protect);
    }

    public static function isSafe(Player $player): bool
    {
        $item = self::getProtectItem();
        if ($item === null) return false;
        return $player->getInventory()->contains($item);
    }

    // ── 강화 보험 설정 ─────────────────────────────────────
    /** 연속 실패 몇 번부터 보정 시작 (기본 5) */
    public static function getPityThreshold(): int
    {
        return (int)(self::$db->get('pity_threshold') ?? 5);
    }

    public static function setPityThreshold(int $v): void
    {
        self::$db->set('pity_threshold', (string)$v);
    }

    /** 임계치 초과 실패 1회당 성공률 보정치 % (기본 10) */
    public static function getPityBonus(): int
    {
        return (int)(self::$db->get('pity_bonus') ?? 10);
    }

    public static function setPityBonus(int $v): void
    {
        self::$db->set('pity_bonus', (string)$v);
    }

    /** 플레이어의 연속 실패 횟수 포함 실제 성공 확률 반환 */
    public static function getEffectiveSuccessRate(string $playerName, int $level): array
    {
        $base      = self::getSuccessRate($level);
        $fails     = self::$db->getPityFails($playerName);
        $threshold = self::getPityThreshold();
        $bonus     = max(0, ($fails - $threshold)) * self::getPityBonus();
        $effective = min(100, $base + $bonus);
        return ['base' => $base, 'bonus' => $bonus, 'effective' => $effective, 'fails' => $fails];
    }

    public static function incrementPity(string $playerName): int
    {
        return self::$db->incrementPity($playerName);
    }

    public static function resetPity(string $playerName): void
    {
        self::$db->resetPity($playerName);
    }

    // ── 강화 이력 로그 ─────────────────────────────────────
    public static function log(
        string $playerName,
        string $itemName,
        int    $fromLevel,
        int    $toLevel,
        string $result
    ): void {
        self::$db->addLog($playerName, $itemName, $fromLevel, $toLevel, $result);
    }

    public static function getPlayerLogs(string $playerName, int $limit = 15): array {
        return self::$db->getPlayerLogs($playerName, $limit);
    }

    public static function getRecentLogs(int $limit = 50): array {
        return self::$db->getRecentLogs($limit);
    }

    protected function onDisable(): void
    {
        if (isset(self::$db)) {
            self::$db->close();
        }
    }
}
