<?php

declare(strict_types=1);

namespace anaf2197\Enforce\Command;

use anaf2197\Enforce\Form\EnforceRankingForm;
use anaf2197\Enforce\Util\MinUtil;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;

final class EnforceRankCommand extends Command
{
    public function __construct()
    {
        parent::__construct('강화순위', '서버 강화 명예의 전당을 확인합니다.', '/강화순위');
        $this->setPermission(DefaultPermissions::ROOT_USER);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void
    {
        if (!$this->testPermission($sender)) return;

        if (!$sender instanceof Player) {
            $sender->sendMessage(MinUtil::ChatPrefix . '플레이어만 사용할 수 있습니다.');
            return;
        }

        $sender->sendForm(EnforceRankingForm::build());
    }
}
