<?php

declare(strict_types=1);

namespace anaf2197\Enforce\Command;

use anaf2197\Enforce\Enforce;
use anaf2197\Enforce\Form\EnforeceForm;
use anaf2197\Enforce\Form\EnforceHistoryForm;
use anaf2197\Enforce\Util\MinUtil;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;

final class EnforceCommand extends Command
{
	public function __construct()
	{
		parent::__construct('강화', '장비를 더 강력하게 강화합니다.', '/강화 | /강화 룬 지급 <플레이어> <수량> | /강화 보호권 지급 <플레이어> <수량>');
		$this->setPermission(DefaultPermissions::ROOT_USER);
	}

	public function execute(CommandSender $sender, string $commandLabel, array $args): void
	{
		if (!$this->testPermission($sender)) return;

		// /강화 룬 지급 <플레이어> <수량>
		// /강화 보호권 지급 <플레이어> <수량>
		if (isset($args[0]) && in_array($args[0], ['룬', '보호권'], true)) {
			if (!$sender->hasPermission(DefaultPermissions::ROOT_OPERATOR)) {
				$sender->sendMessage(MinUtil::ChatPrefix . '권한이 없습니다.');
				return;
			}

			$subType = $args[0];

			if (!isset($args[1]) || $args[1] !== '지급') {
				$sender->sendMessage(MinUtil::ChatPrefix . "사용법: /강화 {$subType} 지급 <플레이어> <수량>");
				return;
			}

			$targetName = $args[2] ?? null;
			$amount     = isset($args[3]) ? (int)$args[3] : 0;

			if ($targetName === null) {
				$sender->sendMessage(MinUtil::ChatPrefix . "사용법: /강화 {$subType} 지급 <플레이어> <수량>");
				return;
			}
			if ($amount <= 0) {
				$sender->sendMessage(MinUtil::ChatPrefix . '수량은 1 이상이어야 합니다.');
				return;
			}

			$target = $sender->getServer()->getPlayerByPrefix($targetName);
			if ($target === null) {
				$sender->sendMessage(MinUtil::ChatPrefix . "플레이어 '{$targetName}'을(를) 찾을 수 없습니다.");
				return;
			}

			if ($subType === '룬') {
				$giveItem = clone Enforce::getRuneItems()[0];
				$giveItem->setCount($amount);
			} else {
				$protectItem = Enforce::getProtectItem();
				if ($protectItem === null) {
					$sender->sendMessage(MinUtil::ChatPrefix . '강화 보호권 아이템이 설정되어 있지 않습니다. /강화관리 에서 먼저 설정해주세요.');
					return;
				}
				$giveItem = clone $protectItem;
				$giveItem->setCount($amount);
			}

			$target->getInventory()->addItem($giveItem);
			$target->sendMessage(MinUtil::ChatPrefix . "{$subType} {$amount}개를 지급받았습니다.");
			$sender->sendMessage(MinUtil::ChatPrefix . "{$target->getName()}에게 {$subType} {$amount}개를 지급했습니다.");
			return;
		}

		if (!$sender instanceof Player) {
			$sender->sendMessage(MinUtil::ChatPrefix . '플레이어만 사용할 수 있습니다.');
			return;
		}

		if (isset($args[0]) && $args[0] === '이력') {
			$sender->sendForm(EnforceHistoryForm::forPlayer($sender));
			return;
		}

		$sender->sendForm(new EnforeceForm());
	}
}