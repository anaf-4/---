<?php

declare(strict_types=1);

namespace anaf2197\Enforce\Command;

use anaf2197\Enforce\Form\EnforeceManagerForm;
use anaf2197\Enforce\Util\MinUtil;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;

final class EnforceManagerCommand extends Command
{
	public function __construct()
	{
		parent::__construct('강화관리', '장비 가격, 아이템을 관리합니다.');
		$this->setPermission(DefaultPermissions::ROOT_OPERATOR);
	}

	public function execute(CommandSender $sender, string $commandLabel, array $args): void
	{
		if (!$sender instanceof Player) {
			$sender->sendMessage(MinUtil::ChatPrefix . '플레이어만 사용할 수 있습니다.');
			return;
		}
		if (!$this->testPermission($sender)) return;
		$sender->sendForm(new EnforeceManagerForm());
	}
}