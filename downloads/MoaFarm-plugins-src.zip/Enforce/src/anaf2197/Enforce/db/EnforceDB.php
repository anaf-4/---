<?php

declare(strict_types=1);

namespace anaf2197\Enforce\db;

use anaf2197\Enforce\Util\MinUtil;
use mysqli;
use pocketmine\item\Item;
use RuntimeException;

/**
 * enforce_settings  — key/value 형태로 강화 설정 전체 저장
 *   setting_key  : 'price' | 'break_rand' | 'protect' | 'rune_items'
 *                  | 'success_rate_{level}' | 'rune_count_{level}'
 *   setting_value: TEXT
 *
 * 단일 테이블로 관리해 스키마 변경 없이 항목을 자유롭게 추가 가능
 */
final class EnforceDB
{
    private mysqli $db;

    /** 인메모리 캐시 [key => value] */
    private array $cache = [];

    public function __construct(
        string $host,
        int    $port,
        string $user,
        string $pass,
        string $dbName
    ) {
        $this->db = new mysqli($host, $user, $pass, $dbName, $port);
        if ($this->db->connect_errno) {
            throw new RuntimeException('EnforceDB 연결 실패: ' . $this->db->connect_error);
        }
        $this->db->set_charset('utf8mb4');
        $this->createTable();
        $this->loadAll();
    }

    private function createTable(): void
    {
        $this->db->query("
            CREATE TABLE IF NOT EXISTS enforce_settings (
                setting_key   VARCHAR(64)  NOT NULL,
                setting_value TEXT         DEFAULT NULL,
                PRIMARY KEY (setting_key)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE IF NOT EXISTS enforce_pity (
                player_name   VARCHAR(64) NOT NULL,
                consecutive_fails INT     NOT NULL DEFAULT 0,
                PRIMARY KEY (player_name)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE IF NOT EXISTS enforce_log (
                id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                player_name VARCHAR(64)  NOT NULL,
                item_name   VARCHAR(128) NOT NULL,
                from_level  TINYINT      NOT NULL,
                to_level    TINYINT      NOT NULL,
                result      ENUM('success','fail','destroy') NOT NULL,
                created_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_player (player_name),
                INDEX idx_created (created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
    }

    // ── 강화 보험 (Pity) ─────────────────────────────────────

    /** 연속 실패 횟수 반환 */
    public function getPityFails(string $playerName): int
    {
        $stmt = $this->db->prepare("SELECT consecutive_fails FROM enforce_pity WHERE player_name=?");
        if ($stmt === false) return 0;
        $stmt->bind_param('s', $playerName);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return (int)($row['consecutive_fails'] ?? 0);
    }

    /** 연속 실패 횟수 +1 */
    public function incrementPity(string $playerName): int
    {
        $stmt = $this->db->prepare("
            INSERT INTO enforce_pity (player_name, consecutive_fails) VALUES (?, 1)
            ON DUPLICATE KEY UPDATE consecutive_fails = consecutive_fails + 1
        ");
        if ($stmt === false) return 0;
        $stmt->bind_param('s', $playerName);
        $stmt->execute();
        $stmt->close();
        return $this->getPityFails($playerName);
    }

    /** 연속 실패 횟수 초기화 (성공 / 파괴 시) */
    public function resetPity(string $playerName): void
    {
        $stmt = $this->db->prepare("
            INSERT INTO enforce_pity (player_name, consecutive_fails) VALUES (?, 0)
            ON DUPLICATE KEY UPDATE consecutive_fails = 0
        ");
        if ($stmt === false) return;
        $stmt->bind_param('s', $playerName);
        $stmt->execute();
        $stmt->close();
    }

    // ── 강화 이력 로그 ────────────────────────────────────────

    public function addLog(
        string $playerName,
        string $itemName,
        int    $fromLevel,
        int    $toLevel,
        string $result      // 'success' | 'fail' | 'destroy'
    ): void {
        $stmt = $this->db->prepare("
            INSERT INTO enforce_log (player_name, item_name, from_level, to_level, result)
            VALUES (?, ?, ?, ?, ?)
        ");
        if ($stmt === false) return;
        $stmt->bind_param('ssiis', $playerName, $itemName, $fromLevel, $toLevel, $result);
        $stmt->execute();
        $stmt->close();
    }

    /**
     * 최근 로그 조회
     * @return array [['player_name', 'item_name', 'from_level', 'to_level', 'result', 'created_at'], ...]
     */
    public function getRecentLogs(int $limit = 50): array
    {
        $stmt = $this->db->prepare(
            "SELECT player_name, item_name, from_level, to_level, result, created_at
             FROM enforce_log ORDER BY id DESC LIMIT ?"
        );
        if ($stmt === false) return [];
        $stmt->bind_param('i', $limit);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        return $rows;
    }

    /** 플레이어별 최근 로그 */
    public function getPlayerLogs(string $playerName, int $limit = 20): array
    {
        $stmt = $this->db->prepare(
            "SELECT item_name, from_level, to_level, result, created_at
             FROM enforce_log WHERE player_name=? ORDER BY id DESC LIMIT ?"
        );
        if ($stmt === false) return [];
        $stmt->bind_param('si', $playerName, $limit);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        return $rows;
    }

    private function loadAll(): void
    {
        $result = $this->db->query("SELECT setting_key, setting_value FROM enforce_settings");
        if ($result === false) return;
        while ($row = $result->fetch_assoc()) {
            $this->cache[$row['setting_key']] = $row['setting_value'];
        }
        $result->free();
    }

    // ── 기본 get/set ──────────────────────────────────────────

    public function get(string $key, ?string $default = null): ?string
    {
        return $this->cache[$key] ?? $default;
    }

    public function set(string $key, ?string $value): void
    {
        $this->cache[$key] = $value;
        $stmt = $this->db->prepare("
            INSERT INTO enforce_settings (setting_key, setting_value)
            VALUES (?, ?)
            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)
        ");
        if ($stmt === false) return;
        $stmt->bind_param('ss', $key, $value);
        $stmt->execute();
        $stmt->close();
    }

    // ── 레벨별 강화 비용 ─────────────────────────────────────

    public function getPriceForLevel(int $level, int $default): int
    {
        return (int)($this->get("price_{$level}") ?? $default);
    }

    public function setPriceForLevel(int $level, int $price): void
    {
        $this->set("price_{$level}", (string)$price);
    }

    /** @param array<int,int> $prices */
    public function setPrices(array $prices): void
    {
        foreach ($prices as $level => $price) {
            $this->setPriceForLevel((int)$level, (int)$price);
        }
    }

    /** @param array<int,int> $defaults */
    public function getPrices(int $maxLevel, array $defaults): array
    {
        $result = [];
        for ($i = 0; $i < $maxLevel; $i++) {
            $result[$i] = $this->getPriceForLevel($i, $defaults[$i] ?? 50000);
        }
        return $result;
    }

    // ── 레벨별 파괴 확률 ─────────────────────────────────────

    /** $level = 현재 강화 레벨 (0 ~ MAX_LEVEL-1). 미설정 시 $default 사용 */
    public function getBreakRandForLevel(int $level, int $default): int
    {
        $val = $this->get("break_rand_{$level}");
        if ($val !== null) return (int)$val;
        return $default;
    }

    public function setBreakRandForLevel(int $level, int $rand): void
    {
        $this->set("break_rand_{$level}", (string)$rand);
    }

    /** @param array<int,int> $rands */
    public function setBreakRands(array $rands): void
    {
        foreach ($rands as $level => $rand) {
            $this->setBreakRandForLevel((int)$level, (int)$rand);
        }
    }

    /** @return array<int,int> */
    public function getBreakRands(int $maxLevel, int $globalDefault): array
    {
        $result = [];
        for ($i = 0; $i < $maxLevel; $i++) {
            $result[$i] = $this->getBreakRandForLevel($i, $globalDefault);
        }
        return $result;
    }

    // ── 보호권 아이템 ────────────────────────────────────────

    public function getProtect(): ?string
    {
        return $this->get('protect');
    }

    public function setProtect(?string $data): void
    {
        $this->set('protect', $data);
    }

    // ── 룬 아이템 (복수 등록, 택1 사용) ─────────────────────────

    public function getRuneItemsData(): ?string
    {
        return $this->get('rune_items');
    }

    /** @param Item[] $items */
    public function setRuneItems(array $items): void
    {
        if (count($items) === 0) {
            $this->set('rune_items', null);
            return;
        }
        $serialized = array_map(fn(Item $item) => MinUtil::ItemDataSerialize($item), $items);
        $this->set('rune_items', json_encode($serialized));
    }

    // ── 레벨별 성공 확률 ─────────────────────────────────────

    public function getSuccessRate(int $level, int $default): int
    {
        return (int)($this->get("success_rate_{$level}") ?? $default);
    }

    public function setSuccessRate(int $level, int $rate): void
    {
        $this->set("success_rate_{$level}", (string)$rate);
    }

    /** @param array<int,int> $rates */
    public function setSuccessRates(array $rates): void
    {
        foreach ($rates as $level => $rate) {
            $this->setSuccessRate((int)$level, (int)$rate);
        }
    }

    // ── 레벨별 룬 소모량 ─────────────────────────────────────

    public function getRuneCount(int $level, int $default): int
    {
        return (int)($this->get("rune_count_{$level}") ?? $default);
    }

    public function setRuneCount(int $level, int $count): void
    {
        $this->set("rune_count_{$level}", (string)$count);
    }

    /** @param array<int,int> $counts */
    public function setRuneCounts(array $counts): void
    {
        foreach ($counts as $level => $count) {
            $this->setRuneCount((int)$level, (int)$count);
        }
    }

    // ── 강화 랭킹 / 투자 통계 ─────────────────────────────────

    /** 서버 강화 랭킹 — 플레이어별 최고 강화 달성 레벨 TOP N */
    public function getEnforceRanking(int $limit = 10): array
    {
        $stmt = $this->db->prepare("
            SELECT player_name,
                   MAX(to_level)             AS max_level,
                   COUNT(*)                  AS total_attempts,
                   SUM(result='success')     AS successes,
                   SUM(result='destroy')     AS destroys
            FROM enforce_log
            GROUP BY player_name
            ORDER BY max_level DESC, successes DESC
            LIMIT ?
        ");
        if ($stmt === false) return [];
        $stmt->bind_param('i', $limit);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        return $rows;
    }

    /** 플레이어 누적 투자 통계 */
    public function getPlayerStats(string $playerName): array
    {
        $stmt = $this->db->prepare("
            SELECT MAX(to_level)          AS max_level,
                   COUNT(*)               AS total_attempts,
                   SUM(result='success')  AS successes,
                   SUM(result='fail')     AS fails,
                   SUM(result='destroy')  AS destroys
            FROM enforce_log
            WHERE player_name = ?
        ");
        if ($stmt === false) return [];
        $stmt->bind_param('s', $playerName);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc() ?? [];
        $stmt->close();
        return $row;
    }

    // ─────────────────────────────────────────────────────────

    public function close(): void
    {
        $this->db->close();
    }
}
