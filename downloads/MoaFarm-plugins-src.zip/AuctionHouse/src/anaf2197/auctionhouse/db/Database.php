<?php

declare(strict_types=1);

namespace anaf2197\auctionhouse\db;

use mysqli;
use pocketmine\item\Item;
use pocketmine\nbt\BigEndianNbtSerializer;
use pocketmine\nbt\TreeRoot;
use RuntimeException;

final class Database {

    private mysqli $db;

    private string $host;
    private int $port;
    private string $user;
    private string $pass;
    private string $dbName;

    public function __construct(string $host, int $port, string $user, string $pass, string $dbName) {
        $this->host   = $host;
        $this->port   = $port;
        $this->user   = $user;
        $this->pass   = $pass;
        $this->dbName = $dbName;
        $this->connect();
        $this->initTables();
    }

    private function connect(): void {
        $this->db = new mysqli($this->host, $this->user, $this->pass, $this->dbName, $this->port);
        if ($this->db->connect_errno) {
            throw new RuntimeException('AuctionHouse DB 연결 실패: ' . $this->db->connect_error);
        }
        $this->db->set_charset('utf8mb4');
    }

    private function initTables(): void {
        $this->db->query("
            CREATE TABLE IF NOT EXISTS auction_items (
                id         VARCHAR(64)  NOT NULL,
                owner      VARCHAR(64)  NOT NULL,
                price      INT          NOT NULL,
                item_data  MEDIUMBLOB   NOT NULL,
                close_time INT          NOT NULL,
                PRIMARY KEY (id),
                INDEX idx_owner (owner),
                INDEX idx_close_time (close_time)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
    }

    /** 전체 경매 아이템 로드 → [id => ['id','owner','price','item_data','close_time']] */
    public function loadAll(): array {

        $result = $this->db->query("SELECT id, owner, price, item_data, close_time FROM auction_items");
        if ($result === false) return [];

        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[$row['id']] = $row;
        }
        $result->free();
        return $data;
    }

    /** 아이템 등록 */
    public function insert(string $id, string $owner, int $price, string $itemData, int $closeTime): void {

        $stmt = $this->db->prepare("
            INSERT INTO auction_items (id, owner, price, item_data, close_time)
            VALUES (?, ?, ?, ?, ?)
        ");
        if ($stmt === false) throw new RuntimeException($this->db->error);
        $stmt->bind_param('ssiis', $id, $owner, $price, $itemData, $closeTime);
        $stmt->execute();
        $stmt->close();
    }

    /** 아이템 삭제 */
    public function delete(string $id): void {

        $stmt = $this->db->prepare("DELETE FROM auction_items WHERE id=?");
        if ($stmt === false) throw new RuntimeException($this->db->error);
        $stmt->bind_param('s', $id);
        $stmt->execute();
        $stmt->close();
    }

    public static function serializeItem(Item $item): string {
        return base64_encode((new BigEndianNbtSerializer())->write(
            new TreeRoot($item->nbtSerialize())
        ));
    }

    public static function deserializeItem(string $data): Item {
        return Item::nbtDeserialize((new BigEndianNbtSerializer())->read(
            base64_decode($data)
        )->mustGetCompoundTag());
    }

    public function close(): void {
        $this->db->close();
    }
}
