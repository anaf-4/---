<?php

declare(strict_types=1);

namespace anaf2197\auctionhouse;

use muqsit\invmenu\InvMenu;
use muqsit\invmenu\InvMenuHandler;
use muqsit\invmenu\transaction\InvMenuTransaction;
use muqsit\invmenu\transaction\InvMenuTransactionResult;
use muqsit\invmenu\type\InvMenuTypeIds;
use pocketmine\block\utils\DyeColor;
use pocketmine\block\VanillaBlocks;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;
use anaf2197\auctionhouse\command\AuctionHouseCommand;
use anaf2197\auctionhouse\command\RegisterItemCommand;
use anaf2197\auctionhouse\db\Database;
use anaf2197\deliveryapi\DeliveryAPI;
use anaf2197\economyapi\EconomyAPI;
use anaf2197\lib\color\ServerColor;
use anaf2197\lib\timeparser\TimeParser;
use anaf2197\servercore\item\ServerItems;
use anaf2197\synthesisprice\SynthesisPrice;

final class AuctionHouseLoader extends PluginBase {

    public static string $prefix;

    private Database $database;
    /** @var AuctionItem[] */
    private array $items = [];

    use SingletonTrait;

    protected function onLoad(): void {
        self::setInstance($this);
        ServerColor::setPrefix($this, '거래소');
    }

    protected function onEnable(): void {
        $this->saveDefaultConfig();
        $cfg = $this->getConfig()->get('database');

        try {
            $this->database = new Database(
                $cfg['host'],
                (int) $cfg['port'],
                $cfg['username'],
                $cfg['password'],
                $cfg['database']
            );
        } catch (\Throwable $e) {
            $this->getLogger()->error('DB 연결 실패 - 플러그인을 비활성화합니다: ' . $e->getMessage());
            $this->getServer()->getPluginManager()->disablePlugin($this);
            return;
        }

        $this->loadFromDB();
        $this->getLogger()->info("=== 거래소 데이터 로드 완료 (DB): " . count($this->items) . "개 ===");

        $this->getServer()->getCommandMap()->registerAll(strtolower($this->getName()), [
            new AuctionHouseCommand(),
            new RegisterItemCommand()
        ]);

        if (!InvMenuHandler::isRegistered()) {
            InvMenuHandler::register($this);
        }
    }

    protected function onDisable(): void {
        $this->database?->close();
        $this->getLogger()->info("=== AuctionHouse DB 연결 종료 ===");
    }

    private function migrateFromJson(): void {
        $dataDir = $this->getDataFolder();
        if (!is_dir($dataDir)) return;

        $files = glob($dataDir . '*.json') ?: [];
        if (empty($files)) return;

        $this->getLogger()->info("=== 기존 경매소 JSON 파일 발견 - DB 마이그레이션 시작 ===");
        $count = 0;
        foreach ($files as $file) {
            $arr = json_decode(file_get_contents($file), true);
            if (!is_array($arr) || count($arr) < 5) continue;
            [$id, $owner, $price, $itemStr, $closeTime] = $arr;
            try {
                $item = \anaf2197\lib\itemparser\ItemParser::fromString($itemStr);
                $d = (new AuctionItem($id, $owner, (int)$price, $item, (int)$closeTime))->toDBData();
                $this->database->insert($d['id'], $d['owner'], $d['price'], $d['item_data'], $d['close_time']);
                $count++;
            } catch (\Throwable $e) {
                $this->getLogger()->warning("경매 아이템 마이그레이션 실패 ({$id}): " . $e->getMessage());
            }
            rename($file, $file . '.migrated_' . date('Ymd_His'));
        }
        $this->getLogger()->info("=== 마이그레이션 완료: 경매 {$count}개 ===");
    }

    private function loadFromDB(): void {
        $this->migrateFromJson();
        foreach ($this->database->loadAll() as $row) {
            try {
                $item = AuctionItem::fromDBRow($row);
                $this->items[$item->getId()] = $item;
            } catch (\Throwable $e) {
                $this->getLogger()->warning("경매 아이템 로드 실패 (id={$row['id']}): " . $e->getMessage());
            }
        }
    }

    public function registerItem(AuctionItem $auctionItem): void {
        $this->items[$auctionItem->getId()] = $auctionItem;
        $d = $auctionItem->toDBData();
        $this->database->insert($d['id'], $d['owner'], $d['price'], $d['item_data'], $d['close_time']);
    }

    public function unregisterItem(string $id): void {
        unset($this->items[$id]);
        $this->database->delete($id);
    }

    public function buyItem(Player $player, string $id, int $count): void {
        $auctionItem = $this->getAuctionItem($id);
        $this->unregisterItem($id);
        if ($auctionItem instanceof AuctionItem) {
            DeliveryAPI::getInstance()->getMailBox($player)?->new(
                '거래소 구매: ' . $auctionItem->getItem()->getName(),
                [$auctionItem->getItem()->setCount($count)]
            );
        }
    }

    public function returnItem(string $id): void {
        $auctionItem = $this->getAuctionItem($id);
        if (!($auctionItem instanceof AuctionItem)) return;

        // 우편함 존재 여부를 먼저 확인 — null이면 아이템을 삭제하지 않고 보존
        $mailBox = DeliveryAPI::getInstance()->getMailBox($auctionItem->getOwner());
        if ($mailBox === null) {
            $this->getLogger()->warning(
                '[거래소] 아이템 반환 실패 - 우편함 없음 → DB에 보존합니다.'
                . ' owner=' . $auctionItem->getOwner()
                . ' item=' . $auctionItem->getItem()->getName()
                . ' id=' . $id
            );
            return;
        }

        $this->unregisterItem($id);
        $mailBox->new('거래소 아이템 회수', [$auctionItem->getItem()]);
    }

    private function returnItems(): void {
        // 루프 중 unset 충돌 방지를 위해 ID 목록을 미리 복사
        $snapshot = array_keys($this->items);
        foreach ($snapshot as $id) {
            $auctionItem = $this->items[$id] ?? null;
            if ($auctionItem !== null && $auctionItem->isClosed()) {
                $this->returnItem($id);
            }
        }
    }

    public function getAuctionItem(string $id): ?AuctionItem {
        return $this->items[$id] ?? null;
    }

    public function getAll(): array {
        return $this->items;
    }

    public function getItemsByPage(int $page): array {
        if ($page <= 0) return [];
        $this->returnItems();
        $result = [];
        for ($i = ($page * 45) - 45; $i < $page * 45; $i++) {
            $auctionItem = array_values($this->items)[$i] ?? null;
            if ($auctionItem !== null) {
                $result[] = $auctionItem;
            }
        }
        return $result;
    }

    public function getItemsByWord(string $word): array {
        $result = [];
        foreach ($this->items as $auctionItem) {
            if ($auctionItem->isClosed()) {
                $this->returnItem($auctionItem->getId());
            } else {
                if (strpos($auctionItem->getItem()->getName(), $word) !== false) {
                    $result[] = $auctionItem;
                }
            }
        }
        return $result;
    }

    public function sendAuctionHouse(Player $player, ?string $keyword = null): void {
        $invMenu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
        $invMenu->setName('§n');
        $this->reloadMenu($invMenu->getInventory(), $player, 1, $keyword);
        $invMenu->setListener(function (InvMenuTransaction $transaction) use ($invMenu, $keyword): InvMenuTransactionResult {
            $action     = $transaction->getAction();
            $sourceItem = $action->getSourceItem();
            $namedtag   = $sourceItem->getNamedTag();
            $player     = $transaction->getPlayer();
            $page       = $namedtag->getInt('page', 1);
            $inventory  = $action->getInventory();

            switch ($action->getSlot()) {
                case 45:
                    if (!$sourceItem->isNull()) {
                        $this->reloadMenu($inventory, $player, $page - 1);
                    }
                    break;

                case 49:
                    break;

                case 53:
                    if (!$sourceItem->isNull()) {
                        $this->reloadMenu($inventory, $player, $page + 1);
                    }
                    break;

                default:
                    $id          = $namedtag->getString('auction', '');
                    $auctionItem = AuctionHouseLoader::getInstance()->getAuctionItem($id);
                    if ($auctionItem instanceof AuctionItem && !$auctionItem->isOwner($player)) {
                        $player->removeCurrentWindow();
                        $invMenu_b = InvMenu::create(InvMenuTypeIds::TYPE_CHEST);
                        $invMenu_b->setName('거래소 구매 확정');
                        $inventory = $invMenu_b->getInventory();
                        $inventory->setItem(11, VanillaBlocks::STAINED_GLASS()->setColor(DyeColor::RED())->asItem()
                            ->setCustomName('§r§l§c구매 취소하기')->setLore([' ', '§r§8터치하여 거래소 메뉴로 이동']));
                        $inventory->setItem(13, $auctionItem->getItem());
                        if (EconomyAPI::getInstance()->getMoney($player) >= $auctionItem->getPrice()) {
                            $inventory->setItem(15, VanillaBlocks::STAINED_GLASS()->setColor(DyeColor::GREEN())->asItem()
                                ->setCustomName('§r§l§a구매 확정하기')->setLore([' ', '§r§8터치하여 아이템 구매']));
                        }
                        $invMenu_b->setListener(function (InvMenuTransaction $transaction) use ($invMenu, $auctionItem, $keyword): InvMenuTransactionResult {
                            $action = $transaction->getAction();
                            $player = $transaction->getPlayer();
                            switch ($action->getSlot()) {
                                case 11:
                                    $player->removeCurrentWindow();
                                    $this->reloadMenu($invMenu->getInventory(), $player, 1, $keyword);
                                    $invMenu->send($player);
                                    break;

                                case 15:
                                    // 창 열고 나서 이미 팔렸는지 재확인
                                    if (!($this->getAuctionItem($auctionItem->getId()) instanceof AuctionItem)) {
                                        $player->sendMessage(AuctionHouseLoader::$prefix . '이미 판매된 아이템입니다.');
                                        $player->removeCurrentWindow();
                                        break;
                                    }
                                    $economyData = EconomyAPI::getInstance()->getEconomyData($player);
                                    if ($economyData->getMoney() >= ($price = $auctionItem->getPrice())) {
                                        if ($auctionItem->buy($player)) {
                                            $economyData->reduceMoney($price, '거래소에서 아이템 구매');
                                        }
                                        $player->removeCurrentWindow();
                                    }
                                    break;
                            }
                            return $transaction->discard();
                        });
                        $invMenu_b->send($player);
                    } else {
                        $player->sendMessage(AuctionHouseLoader::$prefix . '등록한 아이템을 돌려받았습니다.');
                        $player->removeCurrentWindow();
                        AuctionHouseLoader::getInstance()->returnItem($id);
                    }
            }
            return $transaction->discard();
        });
        $invMenu->send($player);
    }

    private function reloadMenu(Inventory $inventory, Player $player, int $page = 1, ?string $keyword = null): void {
        $inventory->clearAll();
        if (is_null($keyword)) {
            if (!empty($this->getItemsByPage($page + 1))) {
                $right_arrow = ServerItems::RIGHT_ARROW();
                $right_arrow->getNamedTag()->setInt('page', $page);
                $inventory->setItem(53, $right_arrow->setCustomName('§r§l§f다음 페이지')
                    ->setLore([' ', '§r§8현재: ' . $page . '쪽', '§r§8터치하여 다음 페이지로 이동']));
            }
            if (!empty($this->getItemsByPage($page - 1))) {
                $left_arrow = ServerItems::LEFT_ARROW();
                $left_arrow->getNamedTag()->setInt('page', $page);
                $inventory->setItem(45, $left_arrow->setCustomName('§r§l§f이전 페이지')
                    ->setLore([' ', '§r§8현재: ' . $page . '쪽', '§r§8터치하여 이전 페이지로 이동']));
            }
            $items = AuctionHouseLoader::getInstance()->getItemsByPage($page);
        } else {
            $items = AuctionHouseLoader::getInstance()->getItemsByWord($keyword);
        }

        $inventory->setItem(49, ServerItems::TRANSPARENT()->setCustomName('§r§l§f거래소 사용법')->setLore([' ',
            '§r§8물건 등록 - /거래소등록 [가격]',
            '§r§8물건 찾기 - /거래소 [키워드]',
            '§r§8평균 시세 확인 - /평균시세'
        ]));

        $prcObject = SynthesisPrice::getInstance()->getAuction();
        $contents  = array_map(function (AuctionItem $auctionItem) use ($player, $prcObject): Item {
            $item = clone $auctionItem->getItem();
            $item->getNamedTag()->setString('auction', $auctionItem->getId());
            $lore = $auctionItem->isOwner($player)
                ? [' ', '§r§c터치하여 회수', '§r§f판매가: ' . EconomyAPI::koreanWonFormat($auctionItem->getPrice()), ' ']
                : [
                    ' ', '§r§b- - - - - - - - - - - - -', ' ',
                    '§r§f주인: ' . $auctionItem->getOwner(),
                    '§r§f판매 갯수: ' . $auctionItem->getItem()->getCount() . '개',
                    '§r§f판매가: ' . EconomyAPI::koreanWonFormat($auctionItem->getPrice()),
                    '§r§f남은 시간: ' . TimeParser::koreanTimeFormat($auctionItem->getCloseTime() - time()),
                    '§r§f평균 시세: ' . ($prcObject->getAveragePrice($item) ?? '데이터 부족'),
                    ' ', '§r§b- - - - - - - - - - - - -'
                ];
            return $item->setLore(array_merge($item->getLore(), $lore));
        }, $items);

        foreach ($contents as $i => $item) {
            $inventory->setItem($i, $item);
        }
    }
}
