<?php

declare(strict_types=1);

namespace anaf2197\auctionhouse;

use pocketmine\item\Item;
use pocketmine\player\Player;
use pocketmine\Server;
use anaf2197\auctionhouse\db\Database;
use anaf2197\auctionhouse\event\BuyAuctionItemEvent;
use anaf2197\deliveryapi\DeliveryAPI;

final class AuctionItem {

    public function __construct(
        private string $id,
        private string $owner,
        private int    $price,
        private Item   $item,
        private int    $closeTime
    ) {}

    public function isClosed(): bool {
        return time() > $this->closeTime;
    }

    public function getId(): string { return $this->id; }

    public function isOwner(Player $player): bool {
        return strtolower($this->owner) === strtolower($player->getName());
    }

    public function getOwner(): string { return $this->owner; }
    public function getPrice(): int    { return $this->price; }
    public function getItem(): Item    { return $this->item; }
    public function getCloseTime(): int { return $this->closeTime; }

    private function canBuy(): bool {
        return AuctionHouseLoader::getInstance()->getAuctionItem($this->id) instanceof AuctionItem;
    }

    public function buy(Player $player): bool {
        if ($this->canBuy()) {
            $event = new BuyAuctionItemEvent($this, $player);
            $count = $event->getAuctionItem()->getItem()->getCount();
            $event->call();
            if (!$event->isCancelled()) {
                AuctionHouseLoader::getInstance()->buyItem($player, $this->id, $count);
                DeliveryAPI::getInstance()->getMailBox($this->owner)?->new(
                    '구매자:' . $player->getName() . '거래소 판매금: ' . $this->item->getName(),
                    [],
                    $this->price
                );
                if (($owner = Server::getInstance()->getPlayerExact($this->owner)) instanceof Player) {
                    $owner->sendMessage(AuctionHouseLoader::$prefix . $player->getName() . '님께서 거래소 아이템을 구매했습니다! 우편함을 확인해보세요.');
                }
                $player->sendMessage(AuctionHouseLoader::$prefix . '거래소에서 아이템을 구매했습니다.');
                return true;
            }
        }
        return false;
    }

    /** DB 저장용 직렬화 */
    public function toDBData(): array {
        return [
            'id'         => $this->id,
            'owner'      => $this->owner,
            'price'      => $this->price,
            'item_data'  => Database::serializeItem($this->item),
            'close_time' => $this->closeTime,
        ];
    }

    /** DB 데이터에서 복원 */
    public static function fromDBRow(array $row): self {
        return new self(
            $row['id'],
            $row['owner'],
            (int) $row['price'],
            Database::deserializeItem($row['item_data']),
            (int) $row['close_time']
        );
    }
}
