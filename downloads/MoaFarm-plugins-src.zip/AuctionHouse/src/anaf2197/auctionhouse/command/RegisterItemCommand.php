<?php

namespace anaf2197\auctionhouse\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\item\VanillaItems;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\auctionhouse\AuctionHouseLoader;
use anaf2197\auctionhouse\AuctionItem;
use anaf2197\servercore\CoreLoader;

final class RegisterItemCommand extends Command {

    public function __construct() {
        parent::__construct('거래소등록', '거래소에 물품을 올립니다.', null, ['거래소물품등록', '거래소올리기', '거래소물품올리기']);
        $this->setPermission(DefaultPermissions::ROOT_USER);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($sender instanceof Player) {
            if ($this->testPermission($sender)) {
                $price = array_shift($args);
                if (trim((string)$price) !== '') {
                    $inventory = $sender->getInventory();
                    $item = $inventory->getItemInHand();
                    if (!$item->isNull()) {
                        if (is_numeric($price)) {
                            $price = intval(abs($price));
                            if ($price <= 0) {
                                $sender->sendMessage(AuctionHouseLoader::$prefix . '가격은 1원 이상이어야 합니다.');
                                return;
                            }
                            $id = CoreLoader::getRandomStr(16);
                            AuctionHouseLoader::getInstance()->registerItem(new AuctionItem($id, $sender->getName(), $price, $item, time() + 60 * 60 * 24 * 2));
                            $inventory->setItemInHand(VanillaItems::AIR());
                            $sender->sendMessage(AuctionHouseLoader::$prefix . '거래소에 아이템을 등록했습니다.');
                            $sender->sendMessage(AuctionHouseLoader::$prefix . '등록된 아이템은 48시간 내로 팔리지 않은경우 우편함으로 지급됩니다.');
                        } else {
                            $sender->sendMessage(AuctionHouseLoader::$prefix . '가격은 숫자로 입력해야합니다.');
                        }
                    } else {
                        $sender->sendMessage(AuctionHouseLoader::$prefix . '공기는 거래소에 등록할 수 없습니다.');
                    }
                } else {
                    $sender->sendMessage(AuctionHouseLoader::$prefix . '/거래소등록 [가격] - 손에 들고있는 아이템을 거래소에 올립니다.');
                }
            }
        }
    }
}