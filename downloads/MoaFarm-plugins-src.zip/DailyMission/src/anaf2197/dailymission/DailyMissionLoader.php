<?php
declare(strict_types=1);

namespace anaf2197\dailymission;

use pocketmine\entity\Monster;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDeathEvent;
use pocketmine\event\EventPriority;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\scheduler\ClosureTask;
use pocketmine\utils\SingletonTrait;
use anaf2197\deliveryapi\DeliveryAPI;
use anaf2197\lib\color\ServerColor;

final class DailyMissionLoader extends PluginBase implements Listener {

    use SingletonTrait;

    public static string $prefix;

    private \mysqli $db;

    private function loadMysqlConfig(): array {
        $sharedPath = $this->getServer()->getDataPath() . 'plugins/mysql_shared.yml';
        if (file_exists($sharedPath)) {
            $shared = new \pocketmine\utils\Config($sharedPath);
            $cfg    = $shared->get('mysql', null);
            if (is_array($cfg)) return $cfg;
        }
        return (array) $this->getConfig()->get('mysql', []);
    }

    protected function onLoad(): void {
        self::setInstance($this);
        ServerColor::setPrefix($this, '일일미션');
    }

    protected function onEnable(): void {
        $this->saveDefaultConfig();
        if (!$this->connectDb()) return;
        $this->initTables();
        $this->seedDefaultTemplates();

        $pm = $this->getServer()->getPluginManager();
        $pm->registerEvents($this, $this);

        if ($pm->getPlugin('Fishing') !== null) {
            $pm->registerEvent(
                \anaf2197\fishing\event\FishingEvent::class,
                function (\anaf2197\fishing\event\FishingEvent $event): void {
                    $this->addProgress($event->getPlayer(), 'FISHING');
                },
                EventPriority::NORMAL,
                $this
            );
        }

        $cmdMap = $this->getServer()->getCommandMap();
        $cmdMap->register(strtolower($this->getName()), new \anaf2197\dailymission\command\DailyMissionCommand());
        $cmdMap->register(strtolower($this->getName()), new \anaf2197\dailymission\command\DailyMissionAdminCommand());
    }

    protected function onDisable(): void {
        if (isset($this->db)) $this->db->close();
    }

    // ─── MySQL ───────────────────────────────────────────────────────────────

    private function connectDb(): bool {
        $cfg    = $this->loadMysqlConfig();
        $host   = (string) ($cfg['host'] ?? '127.0.0.1');
        $port   = (int) ($cfg['port'] ?? 3306);
        $user   = (string) ($cfg['user'] ?? 'root');
        $pass   = (string) ($cfg['password'] ?? '');
        $dbName = (string) ($cfg['database'] ?? 'moafarm');
        try {
            $this->db = new \mysqli($host, $user, $pass, $dbName, $port);
        } catch (\mysqli_sql_exception $e) {
            $this->getLogger()->error('MySQL 연결 실패: ' . $e->getMessage());
            $this->getServer()->getPluginManager()->disablePlugin($this);
            return false;
        }
        if ($this->db->connect_error) {
            $this->getLogger()->error('MySQL 연결 실패: ' . $this->db->connect_error);
            $this->getServer()->getPluginManager()->disablePlugin($this);
            return false;
        }
        $this->db->set_charset('utf8mb4');
        return true;
    }

    private function ensureConnected(): void {
        try { if (!@$this->db->ping()) $this->connectDb(); } catch (\Throwable) { $this->connectDb(); }
    }

    private function initTables(): void {
        $this->db->query('CREATE TABLE IF NOT EXISTS dm_templates (
            id INT AUTO_INCREMENT PRIMARY KEY,
            label VARCHAR(200) NOT NULL,
            type VARCHAR(50) NOT NULL,
            target INT NOT NULL DEFAULT 1,
            reward_money INT NOT NULL DEFAULT 0,
            difficulty TINYINT NOT NULL DEFAULT 1,
            active TINYINT(1) NOT NULL DEFAULT 1
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
        try { $this->db->query('ALTER TABLE dm_templates ADD COLUMN difficulty TINYINT NOT NULL DEFAULT 1'); } catch (\mysqli_sql_exception) {}

        $this->db->query('CREATE TABLE IF NOT EXISTS dm_assignments (
            player VARCHAR(100) NOT NULL,
            mission_date DATE NOT NULL,
            template_id INT NOT NULL,
            completed TINYINT(1) NOT NULL DEFAULT 0,
            PRIMARY KEY (player, mission_date, template_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');

        $this->db->query('CREATE TABLE IF NOT EXISTS dm_progress (
            player VARCHAR(100) NOT NULL,
            mission_date DATE NOT NULL,
            template_id INT NOT NULL,
            progress INT NOT NULL DEFAULT 0,
            PRIMARY KEY (player, mission_date, template_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
    }

    private function seedDefaultTemplates(): void {
        $result = $this->db->query('SELECT COUNT(*) AS cnt FROM dm_templates');
        $row    = $result->fetch_assoc();
        if ((int) $row['cnt'] > 0) return;

        // [label, type, target, reward_money, difficulty(1=쉬움/2=보통/3=어려움)]
        $defaults = [
            ['채광 50개',        'MINING',     50,   5000, 1],
            ['채광 200개',       'MINING',    200,  15000, 2],
            ['채광 500개',       'MINING',    500,  40000, 3],
            ['몹 30마리 처치',   'HUNTING',    30,   5000, 1],
            ['몹 100마리 처치',  'HUNTING',   100,  15000, 2],
            ['몹 300마리 처치',  'HUNTING',   300,  40000, 3],
            ['낚시 20회',        'FISHING',    20,   5000, 1],
            ['낚시 80회',        'FISHING',    80,  15000, 2],
            ['낚시 200회',       'FISHING',   200,  40000, 3],
            ['발굴 10회',        'EXCAVATION', 10,   5000, 1],
            ['발굴 50회',        'EXCAVATION', 50,  15000, 2],
            ['발굴 150회',       'EXCAVATION',150,  40000, 3],
            ['나무 100개 벌목',  'LOGGING',   100,   5000, 1],
            ['나무 400개 벌목',  'LOGGING',   400,  15000, 2],
            ['퀘스트 2개 완료',  'QUEST',       2,  10000, 2],
            ['퀘스트 5개 완료',  'QUEST',       5,  30000, 3],
            ['출석 체크',        'ATTENDANCE',  1,   3000, 1],
        ];

        $stmt = $this->db->prepare('INSERT INTO dm_templates (label, type, target, reward_money, difficulty) VALUES (?, ?, ?, ?, ?)');
        foreach ($defaults as [$label, $type, $target, $money, $diff]) {
            $stmt->bind_param('ssiii', $label, $type, $target, $money, $diff);
            $stmt->execute();
        }
        $stmt->close();
    }

    // ─── 미션 배정 ───────────────────────────────────────────────────────────

    private function ensureAssigned(string $playerKey): void {
        $today = date('Y-m-d');
        $this->ensureConnected();

        $stmt = $this->db->prepare('SELECT COUNT(*) AS cnt FROM dm_assignments WHERE player = ? AND mission_date = ?');
        $stmt->bind_param('ss', $playerKey, $today);
        $stmt->execute();
        $cnt = (int) $stmt->get_result()->fetch_assoc()['cnt'];
        $stmt->close();
        if ($cnt > 0) return;

        // 난이도별 1개씩 배정 (1=쉬움, 2=보통, 3=어려움)
        $ids = [];
        foreach ([1, 2, 3] as $diff) {
            $stmt = $this->db->prepare('SELECT id FROM dm_templates WHERE active = 1 AND difficulty = ? ORDER BY RAND() LIMIT 1');
            $stmt->bind_param('i', $diff);
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if ($row !== null) {
                $ids[] = (int) $row['id'];
            }
        }
        // fallback: 부족하면 랜덤으로 채우기
        $need = 3 - count($ids);
        if ($need > 0) {
            $existing = implode(',', array_map('intval', array_merge($ids, [0])));
            $result   = $this->db->query(
                "SELECT id FROM dm_templates WHERE active = 1 AND id NOT IN ($existing) ORDER BY RAND() LIMIT $need"
            );
            if ($result) {
                while ($row = $result->fetch_assoc()) $ids[] = (int) $row['id'];
            }
        }

        $stmt = $this->db->prepare('INSERT IGNORE INTO dm_assignments (player, mission_date, template_id) VALUES (?, ?, ?)');
        foreach ($ids as $id) {
            $stmt->bind_param('ssi', $playerKey, $today, $id);
            $stmt->execute();
        }
        $stmt->close();
    }

    // ─── 진행도 처리 ─────────────────────────────────────────────────────────

    public function addProgress(Player $player, string $type, int $amount = 1): void {
        $key   = strtolower($player->getName());
        $today = date('Y-m-d');
        $this->ensureConnected();
        $this->ensureAssigned($key);

        // 이 플레이어의 오늘 미션 중 해당 타입이면서 미완료인 것
        $stmt = $this->db->prepare(
            'SELECT a.template_id, t.target, t.label, t.reward_money,
                    COALESCE(p.progress, 0) AS progress
             FROM dm_assignments a
             JOIN dm_templates t ON a.template_id = t.id
             LEFT JOIN dm_progress p ON p.player = a.player AND p.mission_date = a.mission_date AND p.template_id = a.template_id
             WHERE a.player = ? AND a.mission_date = ? AND t.type = ? AND a.completed = 0'
        );
        $stmt->bind_param('sss', $key, $today, $type);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        foreach ($rows as $row) {
            $tid      = (int) $row['template_id'];
            $target   = (int) $row['target'];
            $newProg  = min($target, (int) $row['progress'] + $amount);

            // 진행도 업데이트
            $stmt = $this->db->prepare(
                'INSERT INTO dm_progress (player, mission_date, template_id, progress) VALUES (?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE progress = VALUES(progress)'
            );
            $stmt->bind_param('ssii', $key, $today, $tid, $newProg);
            $stmt->execute();
            $stmt->close();

            // 완료 체크
            if ($newProg >= $target) {
                $this->completeMission($player, $key, $today, $tid, $row['label'], (int) $row['reward_money']);
            }
        }
    }

    private function completeMission(Player $player, string $key, string $today, int $tid, string $label, int $money): void {
        $this->ensureConnected();
        $stmt = $this->db->prepare('UPDATE dm_assignments SET completed = 1 WHERE player = ? AND mission_date = ? AND template_id = ?');
        $stmt->bind_param('ssi', $key, $today, $tid);
        $stmt->execute();
        $stmt->close();

        $player->sendTitle('§a§l미션 완료!', '§r§f' . $label, 10, 40, 10);
        $player->sendMessage(self::$prefix . '§a[미션 완료] §f' . $label . ' §8— §e' . number_format($money) . '원 §8우편함으로 지급됩니다!');

        if (class_exists(DeliveryAPI::class)) {
            $mailBox = DeliveryAPI::getInstance()->getMailBox($player);
            $mailBox?->new('§a[일일미션] §f' . $label, [], $money > 0 ? $money : null, '일일 미션');
        }

        // 오늘 모든 미션 완료 시 추가 보너스
        $this->checkAllComplete($player, $key, $today);
    }

    private function checkAllComplete(Player $player, string $key, string $today): void {
        $stmt = $this->db->prepare(
            'SELECT COUNT(*) AS total, SUM(completed) AS done FROM dm_assignments WHERE player = ? AND mission_date = ?'
        );
        $stmt->bind_param('ss', $key, $today);
        $stmt->execute();
        $row  = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ((int) $row['done'] >= (int) $row['total'] && (int) $row['total'] > 0) {
            $player->sendMessage(self::$prefix . '§6§l오늘 모든 미션을 완료했습니다! 보너스 §e10,000원§6 지급!');
            if (class_exists(DeliveryAPI::class)) {
                $mailBox = DeliveryAPI::getInstance()->getMailBox($player);
                $mailBox?->new('§6[일일미션] 전체 완료 보너스!', [], 10000, '일일 미션');
            }
        }
    }

    // 업적 달성 알림 (Achievement에서 호출)
    public function onAchievementComplete(Player $player): void {
        // 미래 확장 가능 (현재 빈 구현)
    }

    // ─── 공개 API ────────────────────────────────────────────────────────────

    /** @return array[] [{template_id, label, type, target, reward_money, progress, completed}] */
    public function getTodayMissions(Player $player): array {
        $key   = strtolower($player->getName());
        $today = date('Y-m-d');
        $this->ensureConnected();
        $this->ensureAssigned($key);

        $stmt = $this->db->prepare(
            'SELECT a.template_id, t.label, t.type, t.target, t.reward_money, t.difficulty, a.completed,
                    COALESCE(p.progress, 0) AS progress
             FROM dm_assignments a
             JOIN dm_templates t ON a.template_id = t.id
             LEFT JOIN dm_progress p ON p.player = a.player AND p.mission_date = a.mission_date AND p.template_id = a.template_id
             WHERE a.player = ? AND a.mission_date = ?
             ORDER BY t.difficulty ASC, a.template_id'
        );
        $stmt->bind_param('ss', $key, $today);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        return $rows;
    }

    public function getAllTemplates(): array {
        $this->ensureConnected();
        $result = $this->db->query('SELECT * FROM dm_templates ORDER BY id');
        return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    }

    public function addTemplate(string $label, string $type, int $target, int $money, int $difficulty = 1): void {
        $this->ensureConnected();
        $diff = max(1, min(3, $difficulty));
        $stmt = $this->db->prepare('INSERT INTO dm_templates (label, type, target, reward_money, difficulty) VALUES (?, ?, ?, ?, ?)');
        $stmt->bind_param('ssiii', $label, $type, $target, $money, $diff);
        $stmt->execute();
        $stmt->close();
    }

    public function deleteTemplate(int $id): void {
        $this->ensureConnected();
        $stmt = $this->db->prepare('UPDATE dm_templates SET active = 0 WHERE id = ?');
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $stmt->close();
    }

    // ─── 이벤트 리스너 ───────────────────────────────────────────────────────

    public function onPlayerJoin(PlayerJoinEvent $event): void {
        $this->ensureAssigned(strtolower($event->getPlayer()->getName()));
    }

    public function onBlockBreak(BlockBreakEvent $event): void {
        if ($event->isCancelled()) return;
        $block  = $event->getBlock();
        $name   = strtolower($block->getName());
        $player = $event->getPlayer();

        if (str_contains($name, 'ore') || $name === 'ancient debris') {
            $this->addProgress($player, 'MINING');
            // GuildMission / GuildQuest 연동
            if (class_exists(\anaf2197\guildmission\GuildMissionLoader::class)) {
                \anaf2197\guildmission\GuildMissionLoader::getInstance()->addContrib($player, 'MINING');
            }
            if (class_exists(\anaf2197\guildquest\GuildQuestLoader::class)) {
                \anaf2197\guildquest\GuildQuestLoader::getInstance()->addProgress($player, 'MINING');
            }
        } elseif (str_contains($name, 'log') || str_contains($name, 'stem') || str_contains($name, 'hyphae')) {
            $this->addProgress($player, 'LOGGING');
            if (class_exists(\anaf2197\guildmission\GuildMissionLoader::class)) {
                \anaf2197\guildmission\GuildMissionLoader::getInstance()->addContrib($player, 'LOGGING');
            }
            if (class_exists(\anaf2197\guildquest\GuildQuestLoader::class)) {
                \anaf2197\guildquest\GuildQuestLoader::getInstance()->addProgress($player, 'LOGGING');
            }
        } elseif (in_array($name, ['wheat', 'carrots', 'potatoes', 'beetroots', 'nether wart'], true)) {
            $this->addProgress($player, 'FARMING');
            if (class_exists(\anaf2197\guildmission\GuildMissionLoader::class)) {
                \anaf2197\guildmission\GuildMissionLoader::getInstance()->addContrib($player, 'FARMING');
            }
        }
    }

    public function onEntityDeath(EntityDeathEvent $event): void {
        $entity = $event->getEntity();
        if (!$entity instanceof Monster) return;
        $cause  = $entity->getLastDamageCause();
        if (!$cause instanceof EntityDamageByEntityEvent) return;
        $damager = $cause->getDamager();
        if (!$damager instanceof Player) return;
        $this->addProgress($damager, 'HUNTING');
        // GuildMission / GuildQuest 연동
        if (class_exists(\anaf2197\guildmission\GuildMissionLoader::class)) {
            \anaf2197\guildmission\GuildMissionLoader::getInstance()->addContrib($damager, 'HUNTING');
        }
        if (class_exists(\anaf2197\guildquest\GuildQuestLoader::class)) {
            \anaf2197\guildquest\GuildQuestLoader::getInstance()->addProgress($damager, 'HUNTING');
        }
    }
}
