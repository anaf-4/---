<?php
declare(strict_types=1);

namespace anaf2197\dailymission\form;

use pocketmine\form\Form;
use pocketmine\player\Player;

/**
 * /일일미션 — 오늘의 일일 미션을 폼(GUI)으로 표시
 */
final class DailyMissionForm implements Form {

    /** @param array<int, array<string, mixed>> $missions */
    public function __construct(private array $missions) {}

    public function jsonSerialize(): array {
        return [
            'type'    => 'form',
            'title'   => '§l§6오늘의 일일 미션 §r§8(' . date('Y-m-d') . ')',
            'content' => $this->buildContent(),
            'buttons' => [
                ['text' => '§a확인'],
            ],
        ];
    }

    private function buildContent(): string {
        if (empty($this->missions)) {
            return '§8배정된 미션이 없습니다.';
        }

        $diffLabel = [1 => '§a[쉬움]', 2 => '§e[보통]', 3 => '§c[어려움]'];
        $lines     = [];
        $completed = 0;

        foreach ($this->missions as $i => $m) {
            $progress = (int) $m['progress'];
            $target   = (int) $m['target'];
            $done     = (bool) $m['completed'];
            $diff     = (int) ($m['difficulty'] ?? 1);
            $dlabel   = $diffLabel[$diff] ?? '§8[?]';
            $pct      = $target > 0 ? min(100, (int) ($progress / $target * 100)) : 100;
            $filled   = (int) ($pct / 10);
            $bar      = '§a' . str_repeat('█', $filled) . '§8' . str_repeat('█', 10 - $filled);

            if ($done) {
                $lines[] = '§a' . $dlabel . ' §e' . $m['label'] . ' §a[완료!]';
                $completed++;
            } else {
                $lines[] = $dlabel . ' §e' . $m['label'];
                $lines[] = '  ' . $bar . ' §f' . number_format($progress) . ' / ' . number_format($target)
                    . '  §8(보상: §6' . number_format((int) $m['reward_money']) . '원§8)';
            }
            $lines[] = ' ';
        }

        $total = count($this->missions);
        $lines[] = '§8완료: §a' . $completed . ' §8/ §f' . $total
            . ($completed >= $total ? '  §6§l전체 완료 보너스 지급됨!' : '');

        return implode("\n", $lines);
    }

    public function handleResponse(Player $player, $data): void {}
}
