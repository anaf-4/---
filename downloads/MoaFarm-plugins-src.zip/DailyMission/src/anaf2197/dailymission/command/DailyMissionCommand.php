<?php
declare(strict_types=1);

namespace anaf2197\dailymission\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use anaf2197\dailymission\DailyMissionLoader;
use anaf2197\dailymission\form\DailyMissionForm;

final class DailyMissionCommand extends Command {

    public function __construct() {
        parent::__construct('일일미션', '오늘의 일일 미션을 확인합니다.', '/일일미션', ['dailymission', 'dm']);
        $this->setPermission('dailymission.use');
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if (!$sender instanceof Player) {
            $sender->sendMessage('§c플레이어만 사용 가능합니다.');
            return;
        }

        $loader   = DailyMissionLoader::getInstance();
        $missions = $loader->getTodayMissions($sender);

        $sender->sendForm(new DailyMissionForm($missions));
    }
}
