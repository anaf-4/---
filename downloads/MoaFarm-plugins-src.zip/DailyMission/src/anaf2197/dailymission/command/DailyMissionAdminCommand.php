<?php
declare(strict_types=1);

namespace anaf2197\dailymission\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use anaf2197\dailymission\DailyMissionLoader;

final class DailyMissionAdminCommand extends Command {

    public function __construct() {
        parent::__construct('일일미션관리', '일일 미션 템플릿 관리', '/일일미션관리 [추가|목록|삭제 <id>]');
        $this->setPermission('dailymission.admin');
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        $loader = DailyMissionLoader::getInstance();
        $sub    = strtolower($args[0] ?? '');
        $prefix = DailyMissionLoader::$prefix;

        switch ($sub) {
            case '목록':
                $templates = $loader->getAllTemplates();
                $diffLabel = [1 => '쉬움', 2 => '보통', 3 => '어려움'];
                $sender->sendMessage($prefix . '§l미션 템플릿 목록');
                foreach ($templates as $t) {
                    $active = $t['active'] ? '§a[활성]' : '§c[비활성]';
                    $diff   = $diffLabel[(int) ($t['difficulty'] ?? 1)] ?? '?';
                    $sender->sendMessage('§8#' . $t['id'] . ' ' . $active . ' §f' . $t['label'] . ' §8(' . $t['type'] . ' x' . $t['target'] . ', §e' . number_format((int) $t['reward_money']) . '원§8, ' . $diff . ')');
                }
                break;

            case '추가':
                if (!$sender instanceof Player) { $sender->sendMessage('§c플레이어만 사용 가능합니다.'); return; }
                $sender->sendForm(new class($loader, $prefix) implements \pocketmine\form\Form {
                    public function __construct(private DailyMissionLoader $loader, private string $prefix) {}
                    public function jsonSerialize(): array {
                        return [
                            'type'    => 'custom_form',
                            'title'   => '§l§c일일 미션 추가',
                            'content' => [
                                ['type' => 'input',    'text' => '미션 이름', 'placeholder' => '채광 100개'],
                                ['type' => 'dropdown', 'text' => '타입', 'options' => ['MINING', 'HUNTING', 'FISHING', 'EXCAVATION', 'LOGGING', 'FARMING', 'QUEST', 'ATTENDANCE', 'TRADE']],
                                ['type' => 'input',    'text' => '목표 수', 'placeholder' => '100', 'default' => '100'],
                                ['type' => 'input',    'text' => '보상금 (원)', 'placeholder' => '10000', 'default' => '10000'],
                                ['type' => 'dropdown', 'text' => '난이도', 'options' => ['쉬움 (1)', '보통 (2)', '어려움 (3)']],
                            ],
                        ];
                    }
                    public function handleResponse(Player $player, mixed $data): void {
                        if ($data === null) return;
                        $types  = ['MINING', 'HUNTING', 'FISHING', 'EXCAVATION', 'LOGGING', 'FARMING', 'QUEST', 'ATTENDANCE', 'TRADE'];
                        $label  = trim($data[0] ?? '');
                        $type   = $types[(int) ($data[1] ?? 0)] ?? 'MINING';
                        $target = max(1, (int) ($data[2] ?? 1));
                        $money  = max(0, (int) ($data[3] ?? 0));
                        $diff   = (int) ($data[4] ?? 0) + 1; // 0→1, 1→2, 2→3
                        if ($label === '') { $player->sendMessage($this->prefix . '§c이름을 입력하세요.'); return; }
                        $this->loader->addTemplate($label, $type, $target, $money, $diff);
                        $player->sendMessage($this->prefix . '§a미션 템플릿 "' . $label . '"이 추가됐습니다.');
                    }
                });
                break;

            case '삭제':
                $id = (int) ($args[1] ?? 0);
                if ($id <= 0) { $sender->sendMessage('§c사용법: /일일미션관리 삭제 <id>'); return; }
                $loader->deleteTemplate($id);
                $sender->sendMessage($prefix . '§a미션 템플릿 #' . $id . '이 비활성화됐습니다.');
                break;

            default:
                $sender->sendMessage($prefix . '§8사용법: /일일미션관리 [추가|목록|삭제 <id>]');
                break;
        }
    }
}
