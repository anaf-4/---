<?php /** @noinspection PhpUnreachableStatementInspection */

namespace anaf2197\equipment;

use muqsit\invmenu\InvMenuHandler;
use pocketmine\event\EventPriority;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\item\Item;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;
use anaf2197\equipment\command\EquipmentCommand;
use anaf2197\equipment\command\ManageEquipmentCommand;
use anaf2197\lib\color\ServerColor;
use anaf2197\lib\provider\DataProvider;
use anaf2197\lib\provider\ProviderHandler;

final class EquipmentLoader extends PluginBase {

    const TAG_EQUIPMENT = 'equipment';

    use SingletonTrait;

    public static string $prefix;

    private DataProvider $provider;

    protected function onEnable(): void {
        $this->getServer()->getCommandMap()->registerAll(strtolower($this->getName()), [
            new EquipmentCommand(),
            new ManageEquipmentCommand()
        ]);
        $this->getServer()->getPluginManager()->registerEvent(PlayerJoinEvent::class, function (PlayerJoinEvent $event): void {
            $player = $event->getPlayer();
            if (!$this->getPlayerTools($player) instanceof PlayerTools) {
                $this->setPlayerTools(new PlayerTools(strtolower($player->getName()), []));
            }
        }, EventPriority::NORMAL, $this);
        if (!InvMenuHandler::isRegistered()) {
            InvMenuHandler::register($this);
        }
    }

    protected function onLoad(): void {
        self::setInstance($this);
        ServerColor::setPrefix($this, '장비');
        if (!ProviderHandler::isRegistered($this)) {
            ProviderHandler::register($this, PlayerTools::class);
            $this->provider = ProviderHandler::get($this);
        }
    }

    protected function onDisable(): void {
        $this->saveDatabase();
    }

    public function saveDatabase(): void {
        $this->provider->save();
    }

    public function isEquipment(Item $item): bool {
        return $item->getNamedTag()->getTag(self::TAG_EQUIPMENT) instanceof CompoundTag;
    }

    public function setEquipmentOption(Item $item, string $key, string|int $value): void {
        if ($this->isEquipment($item)) {
            $function = is_numeric($value) ? 'setInt' : 'setString';
            $item->getNamedTag()->getCompoundTag(self::TAG_EQUIPMENT)->$function($key, $value);
            $this->setEquipmentLore($item);
        }
    }

    public function setEquipmentLore(Item $item): void {
        $baseTag = $item->getNamedTag()->getCompoundTag(self::TAG_EQUIPMENT);
        if ($baseTag instanceof CompoundTag) {
            $description = [];
            $partMaxKey = 50;
            $statMaxKey = 100;
            foreach ($baseTag->getValue() as $key => $tag) {
                $value = $tag->getValue();
                switch ($key) {
                    case ToolProperties::DESCRIPTION:
                        $description [0] = $value;
                        break;

                    case ToolTypes::TAG_TYPE;
                        $description [1] = ToolTypes::getType2Name($value);
                        break;

                    case ToolProperties::RANK:
                        $description [2] = '§l§' . ToolProperties::getRanks() [$value] . $value;
                        break;

                    case ToolProperties::PROPERTY:
                        $description [5] = '§l§' . str_replace(ToolProperties::getProperties(), ['7', 'f', 'd', 'e', 'c', 'b'], $value) . $value;
                        break;

                    default:
                        if ($key === ToolProperties::LEVEL_LIMIT) {
                            $description [3] = $value;
                        } else if (ToolProperties::getPart2Name($key) !== null) {
                            $partName = [ToolProperties::PART_LIMIT_STR => '§l§cSTR §r§c(근력)§r', ToolProperties::PART_LIMIT_DEX => '§l§bDEX §r§b(민첩)§r', ToolProperties::PART_LIMIT_HEALTH => '§l§aHEALTH §r§a(체력)§r', ToolProperties::PART_LIMIT_INT => '§l§eINT §r§e(지능)§r'] [$key];
                            $description [$partMaxKey] = '§r§f- ' . $partName . '§r§f 제한: ' . $value;
                            $partMaxKey++;
                        } else if (($statName = ToolProperties::getStat2Name($key)) !== null) {
                            if ($key === ToolProperties::STAT_SPEED) $value .= '%';
                            $description [$statMaxKey] = '§r§f' . $statName . ': ' . $value;
                            $statMaxKey++;
                        } else if ($key === ToolProperties::PLAYER_RANK) {
                            $description [4] = $value;
                        }
                }
            }
            $lore = [
                ' ',
                '§r§8' . $description [0],
                ' ',
                '§r§f_ _ _ _ 정보 _ _ _ _',
                '§r§f* 유형: ' . $description [1],
                '§r§f* 등급: ' . $description [2],
                '§r§f* 속성: ' . ($description [5] ?? '없음')
            ];
            if (isset($description [4])) {
                $lore [] = '§r§f* 랭크 제한: ' . $description [4];
            }
            if (isset($description [3])) {
                $lore [] = '§r§f* 레벨 제한: ' . $description [3] . '§l§eLv';
            }
            for ($i = 50; $i < $partMaxKey; $i++) {
                if (isset($description [$i])) {
                    $lore [] = $description [$i];
                } else {
                    break;
                }
            }
            for ($i = 100; $i < $statMaxKey; $i++) {
                if ($i === 100) {
                    $lore [] = ' ';
                    $lore [] = '§r§f_ _ _ _ 스탯 _ _ _ _';
                }
                if (isset($description [$i])) {
                    $lore [] = $description [$i];
                } else {
                    break;
                }
            }
            $lore [] = ' ';
            $item->setLore($lore);
        }
    }

    public function getPlayerTools($player): ?PlayerTools {
        return $this->provider->getObject($player);
    }

    public function setPlayerTools(PlayerTools $playerTools): void {
        $this->provider->setObject($playerTools->getName(), $playerTools);
    }
}