<?php

namespace anaf2197\equipment;

use muqsit\invmenu\InvMenu;
use muqsit\invmenu\transaction\InvMenuTransaction;
use muqsit\invmenu\transaction\InvMenuTransactionResult;
use muqsit\invmenu\type\InvMenuTypeIds;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\player\Player;
use pocketmine\Server;
use anaf2197\advancedlevel\AdvancedLevel;
use anaf2197\lib\itemparser\ItemParser;
use anaf2197\rankapi\RankAPI;
use anaf2197\statusapi\StatusAPI;
use anaf2197\statusapi\StatusManager;

final class PlayerTools implements \JsonSerializable {

    public function __construct(private string $name, protected array $tools) { }

    public function getName(): string {
        return $this->name;
    }

    public function getTools(): array {
        return $this->tools;
    }

    public function setTools(array $tools): void {
        $this->tools = $tools;
        if (($player = Server::getInstance()->getPlayerExact($this->name)) instanceof Player) {
            StatusManager::registerStatus($player, false);
            StatusManager::updateHealthbar($player);
            $status = $this->getStatus();
            $player->sendMessage(EquipmentLoader::$prefix . '장비 데이터가 적용되었습니다.');
            $player->sendMessage(EquipmentLoader::$prefix . '장비 공격력: ' . $status [0]);
            $player->sendMessage(EquipmentLoader::$prefix . '장비 방어력: ' . $status [1]);
            $player->sendMessage(EquipmentLoader::$prefix . '장비 체력: ' . $status [2]);
            $player->sendMessage(EquipmentLoader::$prefix . '장비 이동속도: ' . $status [3] . '%');
        }
    }

    public function getStatus(): array {
        $status = [0, 0, 0, 0];
        foreach ($this->tools as $tool) {
            $status [0] += (int)$this->getOptionValue($tool, ToolProperties::STAT_ATK);
            $status [1] += (int)$this->getOptionValue($tool, ToolProperties::STAT_DEF);
            $status [2] += (int)$this->getOptionValue($tool, ToolProperties::STAT_HEALTH);
            $status [3] += (int)$this->getOptionValue($tool, ToolProperties::STAT_SPEED);
        }
        return $status;
    }

    public function open(Player $player): void {
        $playerLevel = AdvancedLevel::getInstance()->getPlayerLevel($player);
        $playerStatus = StatusAPI::getInstance()->getStatus($player);
        $invMenu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
        $invMenu->setName('§6');
        $invMenu->getInventory()->setContents($this->tools);
        $invMenu->setListener(function (InvMenuTransaction $transaction) use ($playerLevel, $playerStatus): InvMenuTransactionResult {
            $action = $transaction->getAction();
            $item = $action->getTargetItem();
            $discard = $transaction->discard();
            $continue = $transaction->continue();
            if (EquipmentLoader::getInstance()->isEquipment($item)) {
                $levelLimit = $this->getOptionValue($item, ToolProperties::LEVEL_LIMIT);
                if (!is_numeric($levelLimit) or $levelLimit <= $playerLevel->getLevel()) {
                    $rankLimit = $this->getOptionValue($item, ToolProperties::PLAYER_RANK);
                    $rankAPI = RankAPI::getInstance();
                    if ($rankAPI->isRarerThan($rankAPI->getPlayerRank($transaction->getPlayer())->getRank(), RankAPI::getInstance()->getRankById($rankLimit ?? ''))) {
                        foreach (['getStr', 'getDex', 'getHealth', 'getInt'] as $i => $part) {
                            $partLimit = $this->getOptionValue($item, [ToolProperties::PART_LIMIT_STR, ToolProperties::PART_LIMIT_DEX, ToolProperties::PART_LIMIT_HEALTH, ToolProperties::PART_LIMIT_INT][$i]);
                            if (!is_numeric($partLimit) or $playerStatus->$part() >= $partLimit) {
                                if ($action->getSlot() != str_replace(array_keys(ToolTypes::getTypes()), [13, 22, 31, 40, 24], $this->getOptionValue($item, ToolTypes::TAG_TYPE))) {
                                    return $discard;
                                }
                            } else {
                                return $discard;
                            }
                        }
                        return $continue;
                    }
                }
            }
            return $item->isNull() ? $continue : $discard;
        });
        $invMenu->setInventoryCloseListener(function (Player $unused, Inventory $inventory): void {
            $this->setTools($inventory->getContents());
        });
        $invMenu->send($player);
    }

    private function getOptionValue(Item $item, string $key): null|int|string {
        if (EquipmentLoader::getInstance()->isEquipment($item)) {
            return $item->getNamedTag()->getCompoundTag(EquipmentLoader::TAG_EQUIPMENT)->getTag($key)?->getValue();
        }
        return null;
    }

    public function jsonSerialize(): array {
        return [
            $this->name,
            array_map(function (Item $item): string { return ItemParser::toString($item); }, $this->tools)
        ];
    }

    public static function jsonDeserialize(array $data): self {
        return new self ($data [0], array_map(function (string $itemData): Item { return ItemParser::fromString($itemData); }, $data [1]));
    }
}