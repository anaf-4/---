<?php

namespace anaf2197\equipment\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\form\Form;
use pocketmine\item\Durable;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\equipment\EquipmentLoader;
use anaf2197\equipment\ToolProperties;
use anaf2197\equipment\ToolTypes;
use anaf2197\rankapi\RankAPI;

final class ManageEquipmentCommand extends Command {

    public function __construct() {
        parent::__construct('장비관리', '§r§8장비 관리 명령어입니다.', null, ['equipment']);
        $this->setPermission(DefaultPermissions::ROOT_OPERATOR);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args) {
        if ($sender instanceof Player) {
            if ($this->testPermission($sender)) {
                $this->sendMainForm($sender);
            }
        }
    }

    public function sendMainForm(Player $player): void {
        $form = new class($this) implements Form {
            private ManageEquipmentCommand $command;

            public function __construct(ManageEquipmentCommand $command) {
                $this->command = $command;
            }

            public function jsonSerialize(): array {
                return [
                    'type' => 'form',
                    'title' => '§l§6장비 관리',
                    'content' => '§8원하는 작업을 선택해주세요.',
                    'buttons' => [
                        ['text' => "§l§8장비 지정\n§r§8아이템을 장비로 만들기"],
                        ['text' => "§l§8레벨 제한\n§r§8레벨 제한 설정"],
                        ['text' => "§l§8스탯 제한\n§r§8스탯 제한 설정"],
                        ['text' => "§l§8랭크 제한\n§r§8랭크 제한 설정"],
                        ['text' => "§l§8능력치\n§r§8능력치 설정"],
                        ['text' => "§l§8속성\n§r§8속성 설정"],
                        ['text' => "§l§8디자인 최신화\n§r§8장비 디자인 업데이트"]
                    ]
                ];
            }

            public function handleResponse(Player $player, $data): void {
                if ($data === null) return;

                switch ($data) {
                    case 0:
                        $this->command->sendEquipmentTypeForm($player);
                        break;
                    case 1:
                        $this->command->sendLevelLimitForm($player);
                        break;
                    case 2:
                        $this->command->sendStatLimitForm($player);
                        break;
                    case 3:
                        $this->command->sendRankLimitForm($player);
                        break;
                    case 4:
                        $this->command->sendStatValueForm($player);
                        break;
                    case 5:
                        $this->command->sendPropertyForm($player);
                        break;
                    case 6:
                        $this->command->updateDesign($player);
                        break;
                }
            }
        };
        $player->sendForm($form);
    }

    public function sendEquipmentTypeForm(Player $player): void {
        $form = new class implements Form {
            public function jsonSerialize(): array {
                return [
                    'type' => 'custom_form',
                    'title' => '§l§8장비 지정',
                    'content' => [
                        [
                            'type' => 'dropdown',
                            'text' => '§8장비 유형을 선택하세요',
                            'options' => array_values(ToolTypes::getTypes())
                        ],
                        [
                            'type' => 'dropdown',
                            'text' => '§8등급을 선택하세요',
                            'options' => array_keys(ToolProperties::getRanks())
                        ],
                        [
                            'type' => 'input',
                            'text' => '§8장비 설명을 입력하세요',
                            'placeholder' => '설명을 입력하세요'
                        ]
                    ]
                ];
            }

            public function handleResponse(Player $player, $data): void {
                if ($data === null) return;

                $types = array_keys(ToolTypes::getTypes());
                $ranks = array_keys(ToolProperties::getRanks());
                
                $type = $types[$data[0]];
                $rank = $ranks[$data[1]];
                $description = trim($data[2]);

                if ($description === '') {
                    $player->sendMessage(EquipmentLoader::$prefix . '§c설명을 입력해주세요.');
                    return;
                }

                $inventory = $player->getInventory();
                $item = $inventory->getItemInHand();
                
                if ($item->isNull()) {
                    $player->sendMessage(EquipmentLoader::$prefix . '§c손에 아이템을 들어주세요.');
                    return;
                }

                if ($item instanceof Durable) {
                    $item->setUnbreakable();
                }

                $item->getNamedTag()->setTag(
                    EquipmentLoader::TAG_EQUIPMENT,
                    CompoundTag::create()
                        ->setString(ToolProperties::DESCRIPTION, $description)
                        ->setString(ToolTypes::TAG_TYPE, $type)
                        ->setString(ToolProperties::RANK, $rank)
                );
                
                EquipmentLoader::getInstance()->setEquipmentLore($item);
                $inventory->setItemInHand($item);
                
                $player->sendMessage(EquipmentLoader::$prefix . '§a장비가 생성되었습니다.');
                $player->sendMessage(EquipmentLoader::$prefix . '유형: ' . ToolTypes::getType2Name($type));
                $player->sendMessage(EquipmentLoader::$prefix . '등급: ' . $rank);
                $player->sendMessage(EquipmentLoader::$prefix . '설명: ' . $description);
            }
        };
        $player->sendForm($form);
    }

    public function sendLevelLimitForm(Player $player): void {
        $item = $player->getInventory()->getItemInHand();
        if (!EquipmentLoader::getInstance()->isEquipment($item)) {
            $player->sendMessage(EquipmentLoader::$prefix . '§c장비화된 아이템이 아닙니다.');
            return;
        }

        $form = new class implements Form {
            public function jsonSerialize(): array {
                return [
                    'type' => 'custom_form',
                    'title' => '§l§8레벨 제한',
                    'content' => [
                        [
                            'type' => 'input',
                            'text' => '§8레벨 제한을 입력하세요',
                            'placeholder' => '숫자를 입력하세요'
                        ]
                    ]
                ];
            }

            public function handleResponse(Player $player, $data): void {
                if ($data === null) return;

                $value = trim($data[0]);
                if (!is_numeric($value)) {
                    $player->sendMessage(EquipmentLoader::$prefix . '§c숫자를 입력해주세요.');
                    return;
                }

                $inventory = $player->getInventory();
                $item = $inventory->getItemInHand();
                
                $value = abs((int)$value);
                EquipmentLoader::getInstance()->setEquipmentOption($item, ToolProperties::LEVEL_LIMIT, $value);
                $inventory->setItemInHand($item);
                
                $player->sendMessage(EquipmentLoader::$prefix . '§a레벨 제한이 설정되었습니다. (' . $value . ')');
            }
        };
        $player->sendForm($form);
    }

    public function sendStatLimitForm(Player $player): void {
        $item = $player->getInventory()->getItemInHand();
        if (!EquipmentLoader::getInstance()->isEquipment($item)) {
            $player->sendMessage(EquipmentLoader::$prefix . '§c장비화된 아이템이 아닙니다.');
            return;
        }

        $form = new class implements Form {
            public function jsonSerialize(): array {
                return [
                    'type' => 'custom_form',
                    'title' => '§l§8스탯 제한',
                    'content' => [
                        [
                            'type' => 'dropdown',
                            'text' => '§8스탯을 선택하세요',
                            'options' => array_values(ToolProperties::getParts())
                        ],
                        [
                            'type' => 'input',
                            'text' => '§8제한 값을 입력하세요',
                            'placeholder' => '숫자를 입력하세요'
                        ]
                    ]
                ];
            }

            public function handleResponse(Player $player, $data): void {
                if ($data === null) return;

                $parts = array_keys(ToolProperties::getParts());
                $part = $parts[$data[0]];
                $value = trim($data[1]);

                if (!is_numeric($value)) {
                    $player->sendMessage(EquipmentLoader::$prefix . '§c숫자를 입력해주세요.');
                    return;
                }

                $inventory = $player->getInventory();
                $item = $inventory->getItemInHand();
                
                $value = abs((int)$value);
                EquipmentLoader::getInstance()->setEquipmentOption($item, $part, $value);
                $inventory->setItemInHand($item);
                
                $partName = ToolProperties::getPart2Name($part);
                $player->sendMessage(EquipmentLoader::$prefix . '§a스탯 제한이 설정되었습니다.');
                $player->sendMessage(EquipmentLoader::$prefix . '스탯: ' . $partName . ' (' . $value . ')');
            }
        };
        $player->sendForm($form);
    }

    public function sendRankLimitForm(Player $player): void {
        $item = $player->getInventory()->getItemInHand();
        if (!EquipmentLoader::getInstance()->isEquipment($item)) {
            $player->sendMessage(EquipmentLoader::$prefix . '§c장비화된 아이템이 아닙니다.');
            return;
        }

        $form = new class implements Form {
            public function jsonSerialize(): array {
                $ranks = RankAPI::getInstance()->getRanksWithId();
                return [
                    'type' => 'custom_form',
                    'title' => '§l§8랭크 제한',
                    'content' => [
                        [
                            'type' => 'dropdown',
                            'text' => '§8랭크를 선택하세요',
                            'options' => array_values($ranks)
                        ]
                    ]
                ];
            }

            public function handleResponse(Player $player, $data): void {
                if ($data === null) return;

                $ranks = array_values(RankAPI::getInstance()->getRanksWithId());
                $rank = $ranks[$data[0]];

                $inventory = $player->getInventory();
                $item = $inventory->getItemInHand();
                
                EquipmentLoader::getInstance()->setEquipmentOption($item, ToolProperties::PLAYER_RANK, $rank);
                $inventory->setItemInHand($item);
                
                $player->sendMessage(EquipmentLoader::$prefix . '§a랭크 제한이 설정되었습니다. (' . $rank . ')');
            }
        };
        $player->sendForm($form);
    }

    public function sendStatValueForm(Player $player): void {
        $item = $player->getInventory()->getItemInHand();
        if (!EquipmentLoader::getInstance()->isEquipment($item)) {
            $player->sendMessage(EquipmentLoader::$prefix . '§c장비화된 아이템이 아닙니다.');
            return;
        }

        $form = new class implements Form {
            public function jsonSerialize(): array {
                return [
                    'type' => 'custom_form',
                    'title' => '§l§8능력치',
                    'content' => [
                        [
                            'type' => 'dropdown',
                            'text' => '§8능력치를 선택하세요',
                            'options' => array_values(ToolProperties::getStats())
                        ],
                        [
                            'type' => 'input',
                            'text' => '§8능력치 값을 입력하세요',
                            'placeholder' => '숫자를 입력하세요'
                        ]
                    ]
                ];
            }

            public function handleResponse(Player $player, $data): void {
                if ($data === null) return;

                $stats = array_keys(ToolProperties::getStats());
                $stat = $stats[$data[0]];
                $value = trim($data[1]);

                if (!is_numeric($value)) {
                    $player->sendMessage(EquipmentLoader::$prefix . '§c숫자를 입력해주세요.');
                    return;
                }

                $inventory = $player->getInventory();
                $item = $inventory->getItemInHand();
                
                $value = abs((int)$value);
                EquipmentLoader::getInstance()->setEquipmentOption($item, $stat, $value);
                $inventory->setItemInHand($item);
                
                $statName = ToolProperties::getStat2Name($stat);
                $player->sendMessage(EquipmentLoader::$prefix . '§a능력치가 설정되었습니다.');
                $player->sendMessage(EquipmentLoader::$prefix . '능력치: ' . $statName . ' (' . $value . ')');
            }
        };
        $player->sendForm($form);
    }

    public function sendPropertyForm(Player $player): void {
        $item = $player->getInventory()->getItemInHand();
        if (!EquipmentLoader::getInstance()->isEquipment($item)) {
            $player->sendMessage(EquipmentLoader::$prefix . '§c장비화된 아이템이 아닙니다.');
            return;
        }

        $form = new class implements Form {
            public function jsonSerialize(): array {
                return [
                    'type' => 'custom_form',
                    'title' => '§l§8속성',
                    'content' => [
                        [
                            'type' => 'dropdown',
                            'text' => '§8속성을 선택하세요',
                            'options' => ToolProperties::getProperties()
                        ]
                    ]
                ];
            }

            public function handleResponse(Player $player, $data): void {
                if ($data === null) return;

                $properties = ToolProperties::getProperties();
                $property = $properties[$data[0]];

                $inventory = $player->getInventory();
                $item = $inventory->getItemInHand();
                
                EquipmentLoader::getInstance()->setEquipmentOption($item, ToolProperties::PROPERTY, $property);
                $inventory->setItemInHand($item);
                
                $player->sendMessage(EquipmentLoader::$prefix . '§a속성이 설정되었습니다. (' . $property . ')');
            }
        };
        $player->sendForm($form);
    }

    public function updateDesign(Player $player): void {
        $inventory = $player->getInventory();
        $item = $inventory->getItemInHand();
        
        if (!EquipmentLoader::getInstance()->isEquipment($item)) {
            $player->sendMessage(EquipmentLoader::$prefix . '§c장비화된 아이템이 아닙니다.');
            return;
        }

        EquipmentLoader::getInstance()->setEquipmentLore($item);
        $inventory->setItemInHand($item);
        $player->sendMessage(EquipmentLoader::$prefix . '§a장비 디자인이 최신화되었습니다.');
    }
}