<?php

namespace anaf2197\equipment\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\equipment\EquipmentLoader;
use anaf2197\equipment\PlayerTools;

final class EquipmentCommand extends Command {

    public function __construct() {
        parent::__construct('장비', '§r§8장비 착용 명령어입니다.', null, ['equipment']);
        $this->setPermission(DefaultPermissions::ROOT_USER);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args) {
        if ($sender instanceof Player) {
            if ($this->testPermission($sender)) {
                EquipmentLoader::getInstance()->getPlayerTools($sender)->open($sender);
            }
        }
    }
}