<?php

namespace anaf2197\equipment;

class ToolTypes {

    const TAG_TYPE = 'equipment.type';

    const HELMET = 'equipment.helmet';
    const CHESTPLATE = 'equipment.chestplate';
    const LEGGINGS = 'equipment.leggings';
    const BOOTS = 'equipment.boots';
    const WEAPON = 'equipment.weapon';

    public static function getTypes(): array {
        return [self::HELMET => '헬멧', self::CHESTPLATE => '갑옷', self::LEGGINGS => '레깅스', self::BOOTS => '신발', self::WEAPON => '무기'];
    }

    public static function getType2Name(string $type): ?string {
        $types = self::getTypes();
        if (in_array($type, array_keys($types))) {
            return str_replace(array_keys($types), array_values($types), $type);
        }
        return null;
    }

    public static function getName2Type(string $name): ?string {
        $types = self::getTypes();
        if (in_array($name, array_values($types))) {
            return str_replace(array_values($types), array_keys($types), $name);
        }
        return null;
    }
}