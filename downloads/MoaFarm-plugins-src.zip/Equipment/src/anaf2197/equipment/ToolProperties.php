<?php

namespace anaf2197\equipment;

class ToolProperties {

    const LEVEL_LIMIT = 'equipment.levellimit';
    const RANK = 'equipment.rank';
    const DESCRIPTION = 'equipment.description';
    const PART_LIMIT_STR = 'equipment.strlimit';
    const PART_LIMIT_DEX = 'equipment.dexlimit';
    const PART_LIMIT_HEALTH = 'equipment.healthlimit';
    const PART_LIMIT_INT = 'equipment.intlimit';
    const STAT_ATK = 'equipment.atk';
    const STAT_DEF = 'equipment.def';
    const STAT_HEALTH = 'equipment.health';
    const STAT_SPEED = 'equipment.speed';
    const PLAYER_RANK = 'equipment.playerrank';
    const PROPERTY = 'equipment.property';

    public static function getRanks(): array {
        return ['E' => '7', 'D' => 'i', 'B' => 'n', 'A' => 'm', 'S' => 'e', 'S+' => '4', 'L' => 'e', 'L+' => 'g'];
    }

    public static function getParts(): array {
        return [self::PART_LIMIT_STR => 'STR', self::PART_LIMIT_DEX => 'DEX', self::PART_LIMIT_HEALTH => 'HEALTH', self::PART_LIMIT_INT => 'INT'];
    }

    public static function getPart2Name(string $part): ?string {
        $parts = self::getParts();
        if (in_array($part, array_keys($parts))) {
            return str_replace(array_keys($parts), array_values($parts), $part);
        }
        return null;
    }

    public static function getName2Part(string $name): ?string {
        $parts = self::getParts();
        if (in_array($name, array_values($parts))) {
            return str_replace(array_values($parts), array_keys($parts), $name);
        }
        return null;
    }

    public static function getStats(): array {
        return [self::STAT_ATK => '공격력', self::STAT_DEF => '방어력', self::STAT_HEALTH => '체력', self::STAT_SPEED => '이동속도'];
    }

    public static function getProperties(): array {
        return ['어둠', '빛', '시공', '미지', '불', '물'];
    }

    public static function getStat2Name(string $stat): ?string {
        $stats = self::getStats();
        if (in_array($stat, array_keys($stats))) {
            return str_replace(array_keys($stats), array_values($stats), $stat);
        }
        return null;
    }

    public static function getName2Stat(string $name): ?string {
        $stats = self::getStats();
        if (in_array($name, array_values($stats))) {
            return str_replace(array_values($stats), array_keys($stats), $name);
        }
        return null;
    }
}