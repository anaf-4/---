<?php

namespace anaf2197;

use anaf2197\content\effect\EffectContent;
use anaf2197\effect\Effect;
use anaf2197\motion\AngularMotion;
use anaf2197\motion\CircularMotion;
use anaf2197\motion\ClosureMotion;
use anaf2197\motion\DirectionLinearMotion;
use anaf2197\motion\FixedMotion;
use anaf2197\motion\MotionShifter;
use anaf2197\particle\EffectDustParticle;
use anaf2197\particle\EffectSpellParticle;
use anaf2197\shape\BallShape;
use anaf2197\shape\CircleShape;
use anaf2197\shape\PointShape;
use anaf2197\shape\ShapeShifter;
use anaf2197\utils\CircleTypes;
use anaf2197\utils\color\EffectColor;
use anaf2197\utils\color\MixEffectColor;
use anaf2197\utils\color\RandomBrightnessColor;
use anaf2197\utils\color\RandomColor;
use anaf2197\utils\RotationTypes;
use pocketmine\color\Color;
use pocketmine\math\Vector3;
use pocketmine\world\particle\HugeExplodeParticle;
use pocketmine\world\particle\HugeExplodeSeedParticle;

class GrimoireOfAgnesEffect extends Effect {
    private const MAGIC_CIRCLE_RADIUS = 5.7;
    private const MAGIC_CIRCLE_HEIGHT = 10;
    private const EFFECT_LENGTH = 4;

    public function write(EffectContent $content): void {
        $c1 = new CircleShape(self::MAGIC_CIRCLE_RADIUS * 1.2, CircleTypes::CIRCLE_XZ, 8);
        $c1 = ShapeShifter::move($c1->get(),0, self::MAGIC_CIRCLE_HEIGHT, 0);
        $c2 = new CircleShape(self::MAGIC_CIRCLE_RADIUS, CircleTypes::CIRCLE_XZ, 7);
        $c2 = ShapeShifter::move($c2->get(),0, self::MAGIC_CIRCLE_HEIGHT, 0);
        $ball = new BallShape(1.6, 20);
        $ball = ShapeShifter::move($ball->get(), 0, self::MAGIC_CIRCLE_HEIGHT, 0);
        $c3 = new CircleShape(self::MAGIC_CIRCLE_RADIUS * 0.8, CircleTypes::CIRCLE_XZ, 90);
        $c3 = ShapeShifter::move($c3->get(), 0, self::MAGIC_CIRCLE_HEIGHT, 0);
        $c4 = new CircleShape(self::MAGIC_CIRCLE_RADIUS * 0.5, CircleTypes::CIRCLE_XZ, 90);
        $c4 = ShapeShifter::move($c4->get(), 0, self::MAGIC_CIRCLE_HEIGHT, 0);
        $p = ShapeShifter::move((new PointShape())->get(),0, self::MAGIC_CIRCLE_HEIGHT, 0);
        $relay = 0;
        $color1 = new RandomColor(new Color(75, 0, 165), new Color(135, 0, 255));
        $color2 = new RandomBrightnessColor(25, 65);
        $color3 = new RandomColor(new Color(105, 0, 125), new Color(205, 15, 255));
        $color4 = new MixEffectColor($color1, $color2, 0.5);
        $color5 = new MixEffectColor($color3, $color2, 0.7);
        $baseSpellParticle = new EffectSpellParticle($color4, 0.1);
        $particle1 = clone $baseSpellParticle;
        $particle1->setLifetime(0.8);
        $particle1->setMotionSpeed(0.25);
        $particle2 = clone $baseSpellParticle;
        $particle2->setMotionSpeed(0.5);
        $particle2->setMotionDrag(5);
        $particle2->setParticleCount(2);
        $particle2->setEmitterRadius(0.3);
        $particle3 = new EffectSpellParticle($color5, 0.12);
        $particle3->setLifetime(0.8);
        $particle3->setMotionSpeed(0.25);
        $particle4 = new EffectDustParticle (new RandomBrightnessColor(0, 50), 0.17);
        $particle4->setMotionSpeed(2);
        $particle4->setMotionDrag(5);
        $particle4->setParticleCount(5);
        $particle4->setEmitterRadius(0.4);
        $particle5 = clone $particle4;
        $particle5->setMotionSpeed(7);
        $particle5->setEmitterRadius(3);
        $particle5->setLifetime(1);
        $particle5->setParticleCount(2);
        $particle6 = new HugeExplodeSeedParticle();
        $duration = self::EFFECT_LENGTH / 0.25;
        for($count = 0; $count < $duration; $count++) {
            $parallelMove = new ClosureMotion(function ($content, $shapeContent, $time) use ($count) {
                $chord = self::MAGIC_CIRCLE_RADIUS * sqrt(2);
                $offCenter = new Vector3(-(self::MAGIC_CIRCLE_RADIUS * 2 - (self::MAGIC_CIRCLE_RADIUS - $chord * 0.5) * 2), 0, 0);
                $content->put($shapeContent, $offCenter, $time);
            });
            $baseAngularMotion = (new AngularMotion(self::MAGIC_CIRCLE_RADIUS, -360, RotationTypes::ROTATION_YAW, -45, 3))
                ->multi($parallelMove)->get($p, 0.25);
            $baseAngle = 90 * $count;
            $angularMotion1 = MotionShifter::rotate($baseAngularMotion, RotationTypes::ROTATION_YAW, $baseAngle);
            $angularMotion2 = MotionShifter::rotate($baseAngularMotion, RotationTypes::ROTATION_YAW, 180 + $baseAngle);
            $angularMotion3 = MotionShifter::rotate($baseAngularMotion, RotationTypes::ROTATION_YAW, 45 + $baseAngle);
            $angularMotion4 = MotionShifter::rotate($baseAngularMotion, RotationTypes::ROTATION_YAW, 225 + $baseAngle);
            $content->put($particle1, $angularMotion1, $relay);
            $content->put($particle3, $angularMotion2, $relay);
            $content->put($particle3, $angularMotion3, $relay);
            $content->put($particle1, $angularMotion4, $relay);
            $relay += $angularMotion1->getMotionLength();
        }
        $ballDropMotion = new DirectionLinearMotion(new Vector3(0, -1, 0), 6, 0.2);
        $dropMotion = new DirectionLinearMotion(new Vector3(0, -1, 0), 6, 0.08);
        $dropMotion1 = $dropMotion->multi(new CircularMotion(130, RotationTypes::ROTATION_YAW));
        $dropMotion2 = $dropMotion->multi(new CircularMotion(-130, RotationTypes::ROTATION_YAW));
        $circleMotion1 = new CircularMotion(40, RotationTypes::ROTATION_YAW, 0.1);
        $circleMotion2 = new CircularMotion(-40, RotationTypes::ROTATION_YAW, 0.1);
        $dropDuration = self::MAGIC_CIRCLE_HEIGHT/6;
        $spreadDuration = (self::EFFECT_LENGTH - $dropDuration) / 2;
        $spreadCircle = (new CircleShape(1, CircleTypes::CIRCLE_XZ, 7))->get();
        $baseSpreadCircleMotion = new ClosureMotion(function ($content, $shapeContent, $time) use ($spreadDuration) {
            $interval = (self::MAGIC_CIRCLE_RADIUS - 1) / ($spreadDuration / 0.05);
            $shapeContent = ShapeShifter::rescale($shapeContent, 1 + $interval * $time);
            $content->put($shapeContent, null, $time);
        });
        $spreadCircleMotion = (new FixedMotion(0.1))->multi($baseSpreadCircleMotion)->get($spreadCircle, $spreadDuration);
        $spreadCircleMotion1 = MotionShifter::move($spreadCircleMotion, 0, self::MAGIC_CIRCLE_HEIGHT - 0.2, 0);
        $spreadCircleMotion2 = MotionShifter::move($spreadCircleMotion, 0, 0.1, 0);
        $spreadCircleMotion = (new FixedMotion(0.3))->multi($baseSpreadCircleMotion)->get($spreadCircle, $spreadDuration);
        $spreadCircleMotion3 = MotionShifter::move($spreadCircleMotion, 0, 0.1, 0);
        $c5 = ShapeShifter::move($c1, 0, -self::MAGIC_CIRCLE_HEIGHT + 0.1, 0);
        $c6 = ShapeShifter::move($c2, 0, -self::MAGIC_CIRCLE_HEIGHT + 0.1, 0);

        $content->put($particle2, $circleMotion1->get($c1, self::EFFECT_LENGTH));
        $content->put($particle2, $circleMotion2->get($c2, self::EFFECT_LENGTH));
        $content->put($particle1, $circleMotion1->get($c5, self::EFFECT_LENGTH));
        $content->put($particle1, $circleMotion2->get($c6, self::EFFECT_LENGTH));
        $content->put($particle4, $ballDropMotion->get($ball, $dropDuration), 20);
        $content->put($particle4, $spreadCircleMotion1, 20);
        $content->put($particle3, $dropMotion1->get($c3, $dropDuration), 25);
        $content->put($particle1, $dropMotion2->get($c4, $dropDuration), 25);
        $content->put($particle5, $spreadCircleMotion2, floor($dropDuration / 0.05));
        //$content->put($particle6, $spreadCircleMotion3, floor($dropDuration / 0.05));
    }
}