<?php

declare(strict_types=1);

namespace anaf2197;

use anaf2197\content\effect\EffectContent;
use anaf2197\effect\Effect;
use anaf2197\motion\CircularMotion;
use anaf2197\motion\DirectionLinearMotion;
use anaf2197\motion\ExpansionMotion;
use anaf2197\motion\MotionShifter;
use anaf2197\particle\EffectSpell2Particle;
use anaf2197\particle\EffectSpellParticle;
use anaf2197\shape\CircleShape;
use anaf2197\shape\PointShape;
use anaf2197\utils\CircleTypes;
use anaf2197\utils\color\MixEffectColor;
use anaf2197\utils\color\RandomBrightnessColor;
use anaf2197\utils\color\RandomColor;
use anaf2197\utils\RotationTypes;
use anaf2197\utils\Utils;
use pocketmine\color\Color;
use pocketmine\math\Vector3;

class LiberationOfBow extends Effect {
    protected const CIRCLE_EXPANSION_TIME = 10;
    protected const EFFECT_DURATION = 60;
    protected const ARROW_COUNT = 30;
    public function write(EffectContent $content): void {
        $circle1 = new CircleShape(2, CircleTypes::CIRCLE_YZ, 360/8);
        $circle2 = new CircleShape(4, CircleTypes::CIRCLE_YZ, 360/18);
        $expansionTimeToSecond = self::CIRCLE_EXPANSION_TIME * 0.05;
        $expansionMotion1 = new ExpansionMotion(2/$expansionTimeToSecond, 0.0125);
        $expansionMotion2 = new ExpansionMotion(0.25/$expansionTimeToSecond, 0.0125);
        $circleMotion1 = $expansionMotion1->multi(new CircularMotion(20, RotationTypes::ROTATION_ROLL));
        $circleMotion1 = MotionShifter::rotate($circleMotion1->get($circle1->get(), $expansionTimeToSecond), RotationTypes::ROTATION_PITCH, -35);
        $circleMotion1 = MotionShifter::move($circleMotion1, 0, 10, 0);
        $circleMotion2 = $expansionMotion2->multi(new CircularMotion(60, RotationTypes::ROTATION_ROLL));
        $circleMotion2 = MotionShifter::rotate($circleMotion2->get($circle2->get(), $expansionTimeToSecond), RotationTypes::ROTATION_PITCH, -35);
        $circleMotion2 = MotionShifter::move($circleMotion2, 0, 10, 0);
        $circle1Particle = new EffectSpellParticle(new RandomColor(new Color(10, 120, 70), new Color(30, 140, 90)), 0.08, 0.3);
        $circle2Particle = new EffectSpellParticle(new RandomColor(new Color(50, 170, 150), new Color(80, 210, 180)), 0.08, 0.3);
        for($delay = 0; $delay <= self::EFFECT_DURATION; $delay += self::CIRCLE_EXPANSION_TIME) {
            $content->put($circle1Particle, $circleMotion1, $delay+1);
            $content->put($circle2Particle, $circleMotion2, $delay+1);
        }

        $particle = new EffectSpell2Particle(new Color(255, 255, 255), 0.08, 0.3);
        $particle->setParticleCount(7);
        $particle->setEmitterRadius(1);
        $particle->setMotionSpeed(2);
        $expansionTimeToSecond = $expansionTimeToSecond * 1.5;
        $circle3 = new CircleShape(1, CircleTypes::CIRCLE_YZ, 360/4);
        $motion = new ExpansionMotion(5/$expansionTimeToSecond);
        $motion = $motion->multi(new CircularMotion(90 / $expansionTimeToSecond, RotationTypes::ROTATION_ROLL));
        $motion = MotionShifter::rotate($motion->get($circle3->get(), $expansionTimeToSecond), RotationTypes::ROTATION_PITCH, -35);
        $motion = MotionShifter::move($motion, 0, 10, 0);
        $content->put($particle, $motion);

        $colors = [new MixEffectColor(new Color(255, 30, 30), new RandomBrightnessColor(30, 255), 0.7),
            new MixEffectColor(new Color(50, 255, 204), new RandomBrightnessColor(30, 170), 0.7)];
        $pointShape = new PointShape();
        $arrowMotion = new DirectionLinearMotion(new Vector3(1, 0, 0), 15, 0.3);
        for($count = 0; $count < self::ARROW_COUNT; $count++) {
            $arrowParticle = new EffectSpellParticle($colors[mt_rand(0, 1)], 0.08, 0.3);
            $dummyParticle = new EffectSpell2Particle(new Color(255, 255, 255), 0.1, 0.4);
            $dummyParticle->setMotionSpeed(0.5);
            $dummyParticle->setEmitterRadius(0.3);
            $startPointRadian = Utils::random(0, 5);
            $startPointAngle = deg2rad(Utils::random(0, 360));
            $motion = MotionShifter::move($arrowMotion->get($pointShape->get(), 2), 1, cos($startPointAngle) * $startPointRadian, sin($startPointAngle) * $startPointRadian);
            $motion = MotionShifter::rotate($motion, RotationTypes::ROTATION_PITCH, -35);
            $motion = MotionShifter::rotate($motion, mt_rand(1, 2), Utils::random(-10, 10));
            $motion = MotionShifter::move($motion, 0, 10, 0);
            $delay = mt_rand(5, self::EFFECT_DURATION);
            $content->put($arrowParticle, $motion, $delay);
            $content->put($dummyParticle, $motion, $delay + 1);
        }
    }
}