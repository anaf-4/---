<?php

namespace anaf2197;

use anaf2197\content\effect\EffectContent;
use anaf2197\content\motion\MotionContent;
use anaf2197\effect\Effect;
use anaf2197\motion\CircularMotion;
use anaf2197\motion\ClosureMotion;
use anaf2197\particle\EffectSpellParticle;
use anaf2197\shape\CircleShape;
use anaf2197\shape\PointShape;
use anaf2197\shape\ShapeShifter;
use anaf2197\utils\CircleTypes;
use anaf2197\utils\color\RandomColor;
use anaf2197\utils\RotationTypes;
use anaf2197\utils\Utils;
use pocketmine\color\Color;
use pocketmine\world\particle\DustParticle;
use pocketmine\world\particle\ExplodeParticle;

class IceVibrationEffect extends Effect {
    private int $effectLength;
    public function write(EffectContent $content): void {
        $shape = new CircleShape(4, CircleTypes::CIRCLE_XZ, 360/6);
        $shapeContent = $shape->get();
        $motion = new CircularMotion(200, RotationTypes::ROTATION_YAW);
        $subMotion = new ClosureMotion(function ($content, $shapeContent, $time) {
            $shapeContent = ShapeShifter::rescale($shapeContent, 0.5 * (sin((0.05 * $time + 0.5) * M_PI) + 1));
            $content->put($shapeContent, null, $time);
        });
        $motion = $motion->multi($subMotion);
        $particle = new EffectSpellParticle(new RandomColor(new Color(200, 230, 255), new Color(255, 255, 255)), 0.07);
        $content->put($particle, $motion->get($shapeContent, 4));
    }

    public function onPlay(array $playContentData): void {
    }
}