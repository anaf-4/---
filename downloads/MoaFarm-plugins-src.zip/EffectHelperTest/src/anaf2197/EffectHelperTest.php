<?php

namespace anaf2197;

use anaf2197\effect\EffectCenterVector;
use pocketmine\entity\Location;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\item\ItemIds;
use pocketmine\item\ItemTypeIds;
use pocketmine\math\Vector3;
use pocketmine\plugin\PluginBase;

class EffectHelperTest extends PluginBase implements Listener {
    private EffectHelper $effectHelper;
    public function onEnable(): void {
        parent::onEnable();
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->effectHelper = EffectHelper::getInstance();
        EffectHelper::extractEffect(new IceVibrationEffect(),'ice_vibration');
    }

    public function onUseItem(PlayerItemUseEvent $event) {
        $player = $event->getPlayer();
        $pos = $player->getLocation();
        $viewers = [$player];
        switch($event->getItem()->getTypeId()) {
            case ItemTypeIds::SLIMEBALL :
                $centerVector = new EffectCenterVector($pos->asVector3(), $pos->getYaw(), 0);
                $this->effectHelper->getEffectPlayer()->registerEffect(new TestEffect(), $centerVector, $viewers);
                break;
            case ItemTypeIds::DIAMOND :
                $centerVector = new EffectCenterVector($pos->asVector3(), $pos->getYaw(), 0, new Vector3(4, 0.05, 0));
                $this->effectHelper->getEffectPlayer()->registerEffect(new IceVibrationEffect(), $centerVector, $viewers);
                break;
            case ItemTypeIds::BLAZE_ROD :
                $centerVector = new EffectCenterVector($pos->asVector3(), $pos->getYaw(), 0, new Vector3(4, 0.05, 0));
                $this->effectHelper->getEffectPlayer()->registerEffect(new GrimoireOfAgnesEffect(), $centerVector, $viewers);
                $event->cancel();
                break;
            case ItemTypeIds::ARROW :
                $centerVector = new EffectCenterVector($pos->asVector3(), $pos->getYaw(), 0, new Vector3(5, 0.05, 0));
                $this->effectHelper->getEffectPlayer()->registerEffect(new LiberationOfBow(), $centerVector, $viewers);
                break;
            default :
                return;
        }
    }
}