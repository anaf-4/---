<?php

namespace anaf2197;

use anaf2197\content\effect\EffectContent;
use anaf2197\effect\Effect;
use anaf2197\motion\DirectionLinearMotion;
use anaf2197\motion\MotionShifter;
use anaf2197\particle\EffectSpellParticle;
use anaf2197\shape\PointShape;
use anaf2197\shape\ShapeShifter;
use anaf2197\utils\RotationTypes;
use pocketmine\color\Color;
use pocketmine\math\Vector3;

class TestEffect extends Effect {
    public function write(EffectContent $content): void {
        $shapeContent = (new PointShape())->get();
        $shapeContent = ShapeShifter::move($shapeContent, 0, 1, 0);
        $motion = new DirectionLinearMotion(new Vector3(1, 0, 0), 2, 0.25);
        $motion2 = MotionShifter::rotate($motion->get($shapeContent, 3), RotationTypes::ROTATION_YAW, 180);
        $particle = new EffectSpellParticle(new Color(255, 255, 0),0.1);
        $content->put($particle, $motion->get($shapeContent, 2));
        $content->put($particle, $motion2);
    }
}