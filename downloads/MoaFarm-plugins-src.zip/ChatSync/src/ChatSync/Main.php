<?php
declare(strict_types=1);

namespace ChatSync;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\scheduler\ClosureTask;
use anaf2197\servercore\CoreLoader;
use anaf2197\servercore\setting\list\DiscordChat;

class Main extends PluginBase implements Listener {

    // ============================================================
    //  설정 (여기만 수정하세요)
    // ============================================================
    private string $botChatUrl = "http://127.0.0.1:8765/chat";  // 봇으로 채팅 전송
    private int    $pmmpPort   = 8766;                            // PMMP HTTP 서버 포트
    private string $chatPrefix = "§b[디스코드] §f";               // 디코→마크 채팅 앞에 붙는 접두사

    // DB 설정 (auth 테이블 조회용)
    private string $dbHost = "localhost";
    private int    $dbPort = 3306;
    private string $dbUser = "root";
    private string $dbPass = "Berryfore";
    private string $dbName = "discordauth_bot";
    // ============================================================

    /** @var resource|false */
    private $serverSocket = false;

    /** DiscordChat 설정 인스턴스 (캐싱) */
    private DiscordChat $discordChatSetting;

    public function onEnable(): void {
        $this->discordChatSetting = new DiscordChat();
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->startHttpServer();
        $this->getLogger()->info("ChatSync 활성화! PMMP HTTP 포트: {$this->pmmpPort}");
    }

    public function onDisable(): void {
        if ($this->serverSocket !== false) {
            socket_close($this->serverSocket);
        }
    }

    // ── 마크 채팅 감지 → 봇으로 전송 ────────────────────────
    public function onChat(PlayerChatEvent $event): void {
        $player  = $event->getPlayer();
        $message = $event->getMessage();
        $name    = $player->getName();

        // 1. 마크 인증 여부 확인 (auth DB)
        if (!$this->isVerified($name)) {
            return; // 인증 안 된 플레이어는 전송 안 함
        }

        // 2. 플레이어의 디스코드 채팅 연동 설정 확인
        try {
            $playerSettings = CoreLoader::getInstance()->getPlayerSettings($player);
            if ($playerSettings === null || !$playerSettings->getValue($this->discordChatSetting)) {
                return; // 설정 꺼져 있거나 조회 실패 시 전송 안 함
            }
        } catch (\Throwable $e) {
            $this->getLogger()->warning("설정 조회 실패, 채팅 전송 차단: " . $e->getMessage());
            return;
        }

        $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function() use ($name, $message): void {
            $this->sendToBot($name, $message);
        }), 0);
    }

    // ── auth DB에서 인증 여부 확인 ──────────────────────────
    private function isVerified(string $playerName): bool {
        try {
            $db = new \mysqli($this->dbHost, $this->dbUser, $this->dbPass, $this->dbName, $this->dbPort);
            if ($db->connect_error) return false;

            $stmt = $db->prepare("SELECT id FROM auth WHERE player = ? AND verified = 1 LIMIT 1");
            $stmt->bind_param("s", $playerName);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            $db->close();

            return $result !== null;
        } catch (\Throwable $e) {
            $this->getLogger()->warning("인증 확인 오류: " . $e->getMessage());
            return false; // 오류 시 차단
        }
    }

    // ── 봇에 채팅 HTTP POST ───────────────────────────────────
    private function sendToBot(string $player, string $message): void {
        $body = json_encode([
            "player"  => $player,
            "message" => $message,
        ]);

        $ch = curl_init($this->botChatUrl);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $body,
            CURLOPT_HTTPHEADER     => ["Content-Type: application/json"],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 3,
            CURLOPT_CONNECTTIMEOUT => 2,
        ]);
        curl_exec($ch);
        curl_close($ch);
    }

    // ── PMMP 간이 HTTP 서버 (디코→마크 채팅 수신) ────────────
    private function startHttpServer(): void {
        $socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
        if ($socket === false) {
            $this->getLogger()->error("소켓 생성 실패: " . socket_strerror(socket_last_error()));
            return;
        }

        socket_set_option($socket, SOL_SOCKET, SO_REUSEADDR, 1);
        socket_set_nonblock($socket);

        if (!socket_bind($socket, "127.0.0.1", $this->pmmpPort)) {
            $this->getLogger()->error("소켓 바인드 실패: " . socket_strerror(socket_last_error($socket)));
            socket_close($socket);
            return;
        }

        socket_listen($socket, 5);
        $this->serverSocket = $socket;

        $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(function(): void {
            $this->pollSocket();
        }), 1);

        $this->getLogger()->info("HTTP 서버 시작: 127.0.0.1:{$this->pmmpPort}");
    }

    private function pollSocket(): void {
        if ($this->serverSocket === false) return;

        $client = @socket_accept($this->serverSocket);
        if ($client === false) return;

        socket_set_nonblock($client);

        $raw     = "";
        $timeout = microtime(true) + 0.5;
        while (microtime(true) < $timeout) {
            $chunk = @socket_read($client, 4096);
            if ($chunk === false || $chunk === "") break;
            $raw .= $chunk;
            if (str_contains($raw, "\r\n\r\n")) break;
        }

        $body = "";
        if (str_contains($raw, "\r\n\r\n")) {
            $body = substr($raw, strpos($raw, "\r\n\r\n") + 4);
        }

        $data = json_decode($body, true);

        if (isset($data["discord_name"], $data["minecraft_name"], $data["message"])) {
            $discordName   = $data["discord_name"];
            $minecraftName = $data["minecraft_name"];
            $message       = $data["message"];

            // 디코→마크: 연동 설정이 켜진 플레이어에게만 보여줌
            foreach ($this->getServer()->getOnlinePlayers() as $onlinePlayer) {
                $playerSettings = CoreLoader::getInstance()->getPlayerSettings($onlinePlayer);
                if ($playerSettings->getValue($this->discordChatSetting)) {
                    $onlinePlayer->sendMessage(
                        $this->chatPrefix . "§8[{$discordName}] §f{$minecraftName}§8: §f{$message}"
                    );
                }
            }

            $response = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nConnection: close\r\n\r\n{\"success\":true}";
        } else {
            $response = "HTTP/1.1 400 Bad Request\r\nContent-Type: application/json\r\nConnection: close\r\n\r\n{\"success\":false}";
        }

        socket_write($client, $response);
        socket_close($client);
    }
}