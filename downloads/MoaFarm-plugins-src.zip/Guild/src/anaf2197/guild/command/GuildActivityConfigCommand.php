<?php

namespace anaf2197\guild\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\guild\form\GuildActivityConfigForm;

final class GuildActivityConfigCommand extends Command {

    public function __construct() {
        parent::__construct('길드활동량설정', '길드 활동 타입별 활동량 획득치를 설정합니다.', '/길드활동량설정', ['guildactivityconfig']);
        $this->setPermission(DefaultPermissions::ROOT_OPERATOR);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if (!$sender instanceof Player) {
            $sender->sendMessage('§c플레이어만 사용 가능합니다.');
            return;
        }
        if (!$this->testPermission($sender)) return;

        $sender->sendForm(new GuildActivityConfigForm());
    }
}
