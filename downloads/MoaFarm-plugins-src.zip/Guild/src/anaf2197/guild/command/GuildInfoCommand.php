<?php

namespace anaf2197\guild\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\guild\GuildLoader;
use anaf2197\guild\GuildRoles;

class GuildInfoCommand extends Command {

    public function __construct() {
        parent::__construct("길드정보", '길드 정보를 표시합니다.');
        $this->setPermission(DefaultPermissions::ROOT_USER);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$sender instanceof Player) {
            $sender->sendMessage(GuildLoader::$prefix . "이 명령어는 게임 내에서만 사용할 수 있습니다.");
            return true;
        }

        if (count($args) < 1) {
            $sender->sendMessage(GuildLoader::$prefix . '/길드정보 [길드명]');
            return true;
        }

        $guildName = $args[0];
        $guildLoader = GuildLoader::getInstance();
        $guild = $guildLoader->getGuild($guildName);

        if ($guild === null) {
            $sender->sendMessage(GuildLoader::$prefix . "해당 길드는 존재하지 않습니다.");
            return true;
        }

        $owner = $guild->getOwner();
        $subMasters = $guild->getSubMasters();
        $members = $guild->getMemberNames();
        $money = $guild->getMoney();
        $totalMembersCount = count($members) + count($subMasters) + 1;

        $sender->sendMessage("");
        $sender->sendMessage(GuildLoader::$prefix . "길드 이름: " . $guild->getName());
        $sender->sendMessage(GuildLoader::$prefix . "길드장: " . $owner);
        $sender->sendMessage(GuildLoader::$prefix . "간부: " . (empty($subMasters) ? "없음" : implode(", ", $subMasters)));
        $sender->sendMessage(GuildLoader::$prefix . "길드원: " . (empty($members) ? "없음" : implode(", ", $members)) . " (" . $totalMembersCount . "명)");
        $sender->sendMessage(GuildLoader::$prefix . "길드 자금: " . $money . "원");
        $sender->sendMessage("");
        return true;
    }
}
