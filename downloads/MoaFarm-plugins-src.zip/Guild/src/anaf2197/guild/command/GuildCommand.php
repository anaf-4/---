<?php

namespace anaf2197\guild\command;

use pocketmine\permission\DefaultPermissions;
use anaf2197\guild\form\GuildMenuForm;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use anaf2197\guild\GuildLoader;

final class GuildCommand extends Command {

    public function __construct() {
        parent::__construct('길드', '길드 관련 인터페이스를 엽니다.', null, ['guild']);
        $this->setPermission(DefaultPermissions::ROOT_USER);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($sender instanceof Player) {
            $sender->sendForm(new GuildMenuForm($sender));
        }
    }
}