<?php

namespace anaf2197\guild\command;

use pocketmine\permission\DefaultPermissions;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use anaf2197\guild\Guild;
use anaf2197\guild\GuildLoader;
use anaf2197\guild\GuildRoles;

final class GuildChattingCommand extends Command
{

    public function __construct()
    {
        parent::__construct('길드채팅', '길드채팅을 활성화/비활성화 합니다.', null, ['guild']);
        $this->setPermission(DefaultPermissions::ROOT_USER);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void
    {
        if ($sender instanceof Player) {
            $guild = GuildLoader::getInstance()->myGuild($sender);

            if ($guild === null) {
                $sender->sendMessage(GuildLoader::$prefix . '현재 길드에 가입되어 있지 않습니다.');
                return;
            }
            $this->toggleChatting($sender, $guild);
        }
    }
    private function toggleChatting(Player $player, Guild $guild): void {
        if ($guild->toggleChatting($player)) {
            $player->sendMessage(GuildLoader::$prefix . '길드 채팅을 활성화했습니다.');
        } else {
            $player->sendMessage(GuildLoader::$prefix . '길드 채팅을 비활성화했습니다.');
        }
    }
}
