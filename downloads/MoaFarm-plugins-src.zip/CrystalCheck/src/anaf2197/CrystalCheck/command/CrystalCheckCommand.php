<?php

namespace anaf2197\CrystalCheck\command;

use anaf2197\CrystalCheck\CrystalCheckLoader;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\crystalapi\CrystalAPI;
use anaf2197\economyapi\EconomyAPI;

final class CrystalCheckCommand extends Command {

    public function __construct() {
        parent::__construct('크리스탈수표', '크리스탈을 수표로 변경합니다.');
        $this->setPermission(DefaultPermissions::ROOT_OPERATOR);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($sender instanceof Player) {
            if ($this->testPermission($sender)) {
                $amount = array_shift($args);
                if (trim((string)$amount) !== '') {
                    if (is_numeric($amount)) {
                        $amount = abs((int)$amount);
                        if ($amount >= 100) {
                            $crystalData = CrystalAPI::getInstance()->getCrystalManager();
                            if ($crystalData->getCrystal($sender) >= $amount) {
                                $crystalData->reduceCrystal($sender, $amount);
                                $sender->getInventory()->addItem(CrystalCheckLoader::getInstance()->getCheck($amount));
                                $sender->sendMessage(CrystalCheckLoader::$prefix . EconomyAPI::koreanWonFormat($amount) . ' 크리스탈 수표를 발행했습니다.');
                            } else {
                                $sender->sendMessage(CrystalCheckLoader::$prefix . '소지금이 부족합니다.');
                            }
                        } else {
                            $sender->sendMessage(CrystalCheckLoader::$prefix . '수표 금액은 100원 이상이어야 합니다.');
                        }
                    } else {
                        $sender->sendMessage(CrystalCheckLoader::$prefix . '금액은 숫자로 입력해 주세요.');
                    }
                } else {
                    $sender->sendMessage(CrystalCheckLoader::$prefix . '/크리스탈수표 [금액] - 크리스탈을 수표로 변경합니다.');
                }
            }
        }
    }
}