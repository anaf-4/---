<?php

namespace anaf2197\CrystalCheck;

use anaf2197\CrystalCheck\command\CrystalCheckCommand;
use pocketmine\event\EventPriority;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\item\Item;
use pocketmine\nbt\tag\IntTag;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;
use anaf2197\crystalapi\CrystalAPI;
use anaf2197\economyapi\EconomyAPI;
use anaf2197\lib\color\ServerColor;
use anaf2197\servercore\item\ItemDesign;
use anaf2197\servercore\item\ItemTypes;
use anaf2197\servercore\item\ServerItems;

final class CrystalCheckLoader extends PluginBase {

    public const TAG_CHECK = 'tag.CrystalCheck';

    use SingletonTrait;

    public static string $prefix;

    protected function onEnable(): void {
        $this->getServer()->getCommandMap()->register(strtolower($this->getName()), new CrystalCheckCommand());
        $this->getServer()->getPluginManager()->registerEvent(PlayerItemUseEvent::class, function (PlayerItemUseEvent $event): void {
            $item = $event->getItem();
            if (($tag = $item->getNamedTag()->getTag(self::TAG_CHECK)) instanceof IntTag) {
                $amount = $tag->getValue();
                $count = 1;
                $player = $event->getPlayer();
                if ($player->isSneaking()) {
                    $count = $item->getCount();
                    $amount *= $count;
                }
                CrystalAPI::getInstance()->getCrystalManager()->addCrystal($player, $amount);
                $player->sendMessage(self::$prefix . '크리스탈 수표를 §l§a' . $count . '§r§8개 사용했습니다.');
                $player->sendMessage(self::$prefix . '획득한 크리스탈 금액: ' . EconomyAPI::koreanWonFormat($amount));
                $player->getInventory()->removeItem($item->setCount($count));
            }
        }, EventPriority::MONITOR, $this);
    }

    protected function onLoad(): void {
        self::setInstance($this);
        ServerColor::setPrefix($this, '크리스탈');
    }

    public function getCheck(int $amount): Item {
        $item = match (true) {
            $amount < 50000 => ServerItems::BRONZE(),
            50000 <= $amount and $amount < 300000 => ServerItems::SILVER(),
            300000 <= $amount => ServerItems::GOLD()
        };
        ItemDesign::setItemDesign($item, ItemTypes::WEALTH, '크리스탈 수표', [
            '금액: ' . EconomyAPI::koreanWonFormat($amount)
        ], '터치, 전체 사용: 웅크리기 + 터치');
        $item->getNamedTag()->setInt(self::TAG_CHECK, $amount);
        return $item;
    }
}