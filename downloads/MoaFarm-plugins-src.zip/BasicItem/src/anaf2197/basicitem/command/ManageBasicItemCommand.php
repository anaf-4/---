<?php

namespace anaf2197\basicitem\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\basicitem\BasicItemLoader;

final class ManageBasicItemCommand extends Command {

    public function __construct() {
        parent::__construct('기본템관리', '기본템을 관리합니다.');
        $this->setPermission(DefaultPermissions::ROOT_OPERATOR);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($sender instanceof Player) {
            if ($this->testPermission($sender)) {
                BasicItemLoader::getInstance()->getBasicItemManager()->sendManageItemInv($sender);
            }
        }
    }
}