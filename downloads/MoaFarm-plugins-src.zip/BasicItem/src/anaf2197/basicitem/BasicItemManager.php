<?php

namespace anaf2197\basicitem;

use muqsit\invmenu\InvMenu;
use muqsit\invmenu\type\InvMenuTypeIds;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\player\Player;
use anaf2197\lib\itemparser\ItemParser;

final class BasicItemManager implements \JsonSerializable {

    protected array $items;
    protected array $recipients;

    public function __construct(private string $id, array $itemDatas, array $recipients) {
        $this->items = array_map(function (string $itemData): Item {
            return ItemParser::fromString($itemData);
        }, $itemDatas);
        $this->recipients = array_map('strtolower', $recipients);
    }

    public function sendItems(Player $player): void {
        foreach ($this->items as $item) {
            if ($item->isNull()) continue;
            $player->getInventory()->addItem(clone $item);
        }
    }

    public function sendManageItemInv(Player $player): void {
        $invMenu = InvMenu::create(InvMenuTypeIds::TYPE_CHEST);
        $invMenu->setName('기본템 수정');
        $invMenu->getInventory()->setContents($this->items);
        $invMenu->setInventoryCloseListener(function (Player $player, Inventory $inventory): void {
            $contents = $inventory->getContents();
            $this->items = array_values(array_filter($contents, function(Item $item): bool {
                return !$item->isNull();
            }));
            BasicItemLoader::getInstance()->saveDatabase();
            $player->sendMessage(BasicItemLoader::$prefix . '기본템을 수정했습니다.');
        });
        $invMenu->send($player);
    }

    public function isRecipient(string $playerName): bool {
        $playerName = strtolower($playerName);
        return in_array($playerName, $this->recipients, true);
    }

    public function addRecipient(string $playerName): void {
        $playerName = strtolower($playerName);
        if (!$this->isRecipient($playerName)) {
            $this->recipients[] = $playerName;
        }
    }

    public function getRecipients(): array {
        return $this->recipients;
    }

    public function jsonSerialize(): array {
        return [
            $this->id,
            array_map(function (Item $item): string {
                return ItemParser::toString($item);
            }, $this->items),
            $this->recipients
        ];
    }

    public static function jsonDeserialize(array $data): self {
        return new self(...$data);
    }
}