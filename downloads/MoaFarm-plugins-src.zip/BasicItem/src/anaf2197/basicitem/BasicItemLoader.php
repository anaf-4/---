<?php

namespace anaf2197\basicitem;

use muqsit\invmenu\InvMenuHandler;
use pocketmine\event\EventPriority;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;
use anaf2197\basicitem\command\ManageBasicItemCommand;
use anaf2197\lib\provider\DataProvider;
use anaf2197\lib\provider\ProviderHandler;
use anaf2197\lib\color\ServerColor;

final class BasicItemLoader extends PluginBase {

    const DB_BASIC_ITEM = 'basic_items';

    use SingletonTrait;

    public static string $prefix;

    private DataProvider $provider;

    protected function onEnable(): void {
        if (!ProviderHandler::isRegistered($this)) {
            ProviderHandler::register($this, BasicItemManager::class);
            $this->provider = ProviderHandler::get($this);
        }
        if (!$this->provider->getObject(self::DB_BASIC_ITEM) instanceof BasicItemManager) {
            $this->provider->setObject(self::DB_BASIC_ITEM, new BasicItemManager(self::DB_BASIC_ITEM, [], []));
        }
        if (!InvMenuHandler::isRegistered()) {
            InvMenuHandler::register($this);
        }
        $this->getServer()->getPluginManager()->registerEvent(
            PlayerJoinEvent::class,
            function (PlayerJoinEvent $event): void {
                $player = $event->getPlayer();
                $basicItemManager = $this->getBasicItemManager();
                $playerName = strtolower($player->getName());

                if (!$basicItemManager->isRecipient($playerName)) {
                    $basicItemManager->addRecipient($playerName);
                    $basicItemManager->sendItems($player);
                    $this->saveDatabase();
                    $player->sendMessage(BasicItemLoader::$prefix . '기본템이 지급 되었습니다!');
                }
            },
            EventPriority::NORMAL,
            $this
        );
        $this->getServer()->getCommandMap()->register(strtolower($this->getName()), new ManageBasicItemCommand());
    }

    protected function onLoad(): void {
        self::setInstance($this);
        ServerColor::setPrefix($this, '기본템');
    }

    protected function onDisable(): void {
        $this->saveDatabase();
    }

    public function saveDatabase(): void {
        $this->provider->save();
    }

    public function getBasicItemManager(): BasicItemManager {
        return $this->provider->getObject(self::DB_BASIC_ITEM);
    }
}