<?php

namespace anaf2197\advancedprefix\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\advancedprefix\AdvancedPrefix;

final class CheckOriginalCommand extends Command {

    public function __construct() {
        parent::__construct('닉네임확인', '§r§8대상 게이머의 기존 닉네임을 확인합니다.', null, ['checkoriginal']);
        $this->setPermission(DefaultPermissions::ROOT_USER);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($sender instanceof Player) {
            if ($this->testPermission($sender)) {
                $nickname = array_shift($args);
                if (trim((string)$nickname) !== '') {
                    $owner = AdvancedPrefix::getInstance()->getNameExact($nickname);
                    if (is_string($owner)) {
                        $sender->sendMessage(AdvancedPrefix::$prefix . '기존 닉네임: ' . $owner);
                    } else {
                        $sender->sendMessage(AdvancedPrefix::$prefix . '생성되지 않은 한글 닉네임입니다.');
                    }
                } else {
                    $sender->sendMessage(AdvancedPrefix::$prefix . '/닉네임확인 [한글 닉네임] - 대상 게이머의 기존 닉네임을 확인합니다.');
                }
            }
        }
    }
}