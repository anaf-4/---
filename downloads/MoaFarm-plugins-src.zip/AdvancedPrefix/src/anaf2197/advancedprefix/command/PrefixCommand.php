<?php

namespace anaf2197\advancedprefix\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\advancedprefix\AdvancedPrefix;
use anaf2197\advancedprefix\form\SelectFunctionForm;

final class PrefixCommand extends Command {

    public function __construct() {
        parent::__construct('칭호', '§r§8나의 칭호 설정을 관리합니다.', null, ['내칭호', '칭호설정', 'myprefix', 'prefix']);
        $this->setPermission(DefaultPermissions::ROOT_USER);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($sender instanceof Player) {
            if ($this->testPermission($sender)) {
                if (in_array(array_shift($args), ['관리', 'm', 'M'])) {
                    if ($sender->hasPermission(DefaultPermissions::ROOT_OPERATOR)) {
                        $sender->sendForm(new SelectFunctionForm());
                        return;
                    }
                }
                AdvancedPrefix::getInstance()->sendPrefixBox($sender);
            }
        }
    }
}