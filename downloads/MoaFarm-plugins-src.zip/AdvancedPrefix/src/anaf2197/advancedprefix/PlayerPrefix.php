<?php

namespace anaf2197\advancedprefix;

use pocketmine\player\Player;
use pocketmine\Server;
use anaf2197\servercore\CoreLoader;

final class PlayerPrefix implements \JsonSerializable {

    public function __construct(
        private string  $name,
        protected array $prefixes, protected int $nowPrefix,
        protected array $colors, protected int $nowColor,
        protected array $nicknames, protected int $nowNickname) {
    }

    public function getPlayer(): ?Player {
        return Server::getInstance()->getPlayerExact($this->name);
    }

    public function getName(): string {
        return $this->name;
    }

    public function getPrefixes(): array {
        return $this->prefixes;
    }

    public function getPrefix(int $key): ?string {
        return $this->prefixes [$key] ?? null;
    }

    public function getPrefixToKey(string $prefix): ?int {
        return in_array($prefix, $this->prefixes) ? array_search($prefix, $this->prefixes) : null;
    }

    public function hasPrefix(string $prefix): bool {
        return in_array($prefix, $this->prefixes);
    }

    public function addPrefix(string $prefix): void {
        $this->prefixes [] = $prefix;
    }

    public function removePrefix(int $key): void {
        unset ($this->prefixes [$key]);
        $this->prefixes = array_values($this->prefixes);
    }

    public function getNowPrefix(): string {
        return $this->prefixes [$this->nowPrefix] ?? '';
    }

    public function getNowPrefixKey(): int {
        return $this->nowPrefix;
    }

    public function setNowPrefixKey(int $key): void {
        $this->nowPrefix = $key;
    }

    public function getColors(): array {
        return $this->colors;
    }

    public function getColor(int $key): ?string {
        return $this->colors [$key] ?? null;
    }

    public function getColorToKey(string $color): ?int {
        return in_array($color, $this->colors) ? array_search($color, $this->colors) : null;
    }

    public function hasColor(string $color): bool {
        return in_array($color, $this->colors);
    }

    public function addColor(string $color): void {
        $this->colors [] = $color;
    }

    public function removeColor(int $key): void {
        unset ($this->colors [$key]);
    }

    public function getNowColor(): string {
        return $this->colors [$this->nowColor] ?? '';
    }

    public function getNowColorKey(): int {
        return $this->nowColor;
    }

    public function setNowColorKey(int $key): void {
        $this->nowColor = $key;
    }

    public function getNicknames(): array {
        return $this->nicknames;
    }

    public function getNickname(int $key): ?string {
        return $this->nicknames [$key] ?? null;
    }

    public function getNicknameToKey(string $nickname): ?int {
        return in_array($nickname, $this->nicknames) ? array_search($nickname, $this->nicknames) : null;
    }

    public function hasNickname(string $nickname): bool {
        return in_array($nickname, $this->nicknames);
    }

    public function addNickname(string $nickname): void {
        $this->nicknames [] = $nickname;
    }

    public function removeNickname(int $key): void {
        unset ($this->nicknames [$key]);
    }

    public function getNowNickname(): string {
        return $this->nicknames [$this->nowNickname] ?? '';
    }

    public function getNowNicknameKey(): int {
        return $this->nowNickname;
    }

    public function setNowNicknameKey(int $key): void {
        $this->nowNickname = $key;
        if (($player = $this->getPlayer()) instanceof Player) {
            CoreLoader::getInstance()->setNameTag($player);
        }
    }

    public function jsonSerialize(): array {
        return [
            $this->name,
            $this->prefixes, $this->nowPrefix,
            $this->colors, $this->nowColor,
            $this->nicknames, $this->nowNickname
        ];
    }

    public static function jsonDeserialize(array $data): self {
        return new self (... $data);
    }
}