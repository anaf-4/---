<?php

namespace anaf2197\advancedprefix\form;

use pocketmine\form\Form;
use pocketmine\player\Player;
use anaf2197\advancedprefix\AdvancedPrefix;
use anaf2197\advancedprefix\PrefixFunctionTag;
use anaf2197\servercore\item\ItemDesign;
use anaf2197\servercore\item\ItemTypes;
use anaf2197\servercore\item\ServerItems;

final class SelectFunctionForm implements Form {

    public function jsonSerialize(): array {
        return [
            'type' => 'form',
            'title' => '§l 칭호 관리자',
            'content' => ' ',
            'buttons' => array_map(function (array $data): array {
                return ['text' => '§l§0' . $data [0] . PHP_EOL . '§r§8- ' . $data [1] . ' -'];
            }, [
                ['자유 칭호권', '자유 칭호권을 지급받습니다.'],
                ['자유 색챗권', '자유 색챗권을 지급받습니다.'],
                ['자유 한닉권', '자유 한닉권을 지급받습니다.'],
            ])
        ];
    }

    public function handleResponse(Player $player, $data): void {
        if (is_numeric($data)) {
            $function = ['자유 칭호권', '자유 색챗권', '자유 한닉권'][$data];
            $description = ['나만의 칭호를 만들어보세요!', '나만의 채팅 색을 만들어보세요!', '나만의 닉네임을 만들어보세요!'][$data];
            $item = [ServerItems::NAMETAG_PREFIX(), ServerItems::NAMETAG_COLOR(), ServerItems::NAMETAG_NAME()][$data];
            ItemDesign::setItemDesign($item, ItemTypes::DECORATION, $function, [
                $description
            ], '웅크리기 + 터치');
            PrefixFunctionTag::createTag($item->getNamedTag(), $data);
            $player->getInventory()->addItem($item);
            $player->sendMessage(AdvancedPrefix::$prefix . $function . '을 지급받았습니다.');
        }
    }
}