<?php

namespace anaf2197\advancedprefix\form;

use pocketmine\form\Form;
use pocketmine\item\Item;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;
use anaf2197\advancedprefix\AdvancedPrefix;
use anaf2197\advancedprefix\PrefixFunctionTag;
use anaf2197\lib\color\BedrockColor;
use anaf2197\servercore\item\ItemDesign;
use anaf2197\servercore\item\ItemTypes;
use anaf2197\servercore\item\ServerItems;

final class WriteFunctionForm implements Form {

    private string $function;

    public function __construct(private int $functionId, private Item $handItem) {
        if (!in_array($functionId, PrefixFunctionTag::getAll())) {
            throw  new \LogicException('A sent id that is not included in prefix function ids');
        }
        $this->function = ['자유 칭호권', '자유 색챗권', '자유 한닉권'][$functionId];
    }

    public function jsonSerialize(): array {
        return [
            'type' => 'custom_form',
            'title' => '§l§0' . $this->function,
            'content' => [
                [[
                    'type' => 'input',
                    'text' => implode(PHP_EOL, [
                        ' ',
                        '아래에 입력한 칭호가 지급됩니다.',
                        '규칙에 위배되지 않는 모든 방법을 사용하여 자신만의 칭호를 꾸며보세요!',
                        ' ',
                        '§l자유 칭호권 규칙§r',
                        '- 욕설, 비속어 그 외 타인이 불쾌감을 느낄만한 모든 표현을 금지',
                        '- 띄어쓰기 사용시 언더바 (_) 처리됨',
                        '- 12자 이상 불가능 (색코드 포함)',
                        '- 관리자 전용 칭호 금지',
                        ' '
                    ]),
                    'placeholder' => 'ex) 귀여운, 우주최강'
                ], [
                    'type' => 'dropdown',
                    'text' => implode(PHP_EOL, [
                        ' ',
                        '아래에서 선택한 색이 지급됩니다.',
                        ' '
                    ]),
                    'options' => array_values(BedrockColor::getColors()),
                    'default' => 0
                ], [
                    'type' => 'input',
                    'text' => implode(PHP_EOL, [
                        ' ',
                        '아래에 입력한 닉네임이 지급됩니다.',
                        '규칙에 위배되지 않는 모든 방법을 사용하여 자신만의 닉네임을 꾸며보세요!',
                        ' ',
                        '§l자유 한닉권 규칙§r',
                        '- 욕설, 비속어 그 외 타인이 불쾌감을 느낄만한 모든 표현을 금지',
                        '- 띄어쓰기 사용시 언더바 (_) 처리됨',
                        '- 7자 이상 불가능',
                        '- 이미 존재하는 닉네임 불가능',
                        '- 색코드 불가능',
                        '- 특수문자 불가능',
                        '- 한글이 포함되어야함 (사칭 사전방지)',
                        ' '
                    ]),
                    'placeholder' => 'ex) 모아팜, 모12아팜, 모a아팜'
                ]][$this->functionId]
            ]
        ];
    }

    public function handleResponse(Player $player, $data): void {
        if (is_array($data)) {
            $value = array_shift($data);
            switch ($this->functionId) {
                case PrefixFunctionTag::TYPE_PREFIX:
                    $value = str_replace(' ', '_', $value);
                    if (mb_strlen($value, 'UTF-8') < 12) {
                        $item = ServerItems::NAMETAG_PREFIX();
                        ItemDesign::setItemDesign($item, ItemTypes::DECORATION, '칭호권', [
                            '칭호: ' . $value
                        ], '웅크리기 + 터치');
                        PrefixFunctionTag::createTag($item->getNamedTag(), $this->functionId, false, $value);
                        $this->removeItemInHand($player);
                        $player->getInventory()->addItem($item);
                        $player->sendMessage(AdvancedPrefix::$prefix . '[' . $value . '§r§8] 칭호권을 지급받았습니다.');
                    } else {
                        $player->sendMessage(AdvancedPrefix::$prefix . '적절하지 못한 길이입니다.');
                    }
                    break;

                case PrefixFunctionTag::TYPE_CHAT_COLOR:
                    $value = array_values(BedrockColor::getColors())[$value];
                    $item = ServerItems::NAMETAG_COLOR();
                    ItemDesign::setItemDesign($item, ItemTypes::DECORATION, '색챗권', [
                        '색상: ' . $value
                    ], '웅크리기 + 터치');
                    PrefixFunctionTag::createTag($item->getNamedTag(), $this->functionId, false, BedrockColor::getColorCode($value));
                    $this->removeItemInHand($player);
                    $player->getInventory()->addItem($item);
                    $player->sendMessage(AdvancedPrefix::$prefix . '[' . $value . '§r§8] 색챗권을 지급받았습니다.');
                    break;

                case PrefixFunctionTag::TYPE_NICKNAME:
                    $value = TextFormat::clean(str_replace(' ', '_', $value));
                    if (mb_strlen($value, 'UTF-8') < 7) {
                        if (is_string(AdvancedPrefix::getInstance()->getNameExact($value))) {
                            $player->sendMessage(AdvancedPrefix::$prefix . '다른 게이머가 이미 사용 중인 닉네임입니다.');
                        } else {
                            AdvancedPrefix::getInstance()->getPlayerPrefix($player)->addNickname($value);
                            $this->removeItemInHand($player);
                            $player->sendMessage(AdvancedPrefix::$prefix . '[' . $value . '§r§8] 닉네임을 지급받았습니다.');
                        }
                    } else {
                        $player->sendMessage(AdvancedPrefix::$prefix . '적절하지 못한 길이입니다.');
                    }
                    break;
                default:
            }
        }
    }

    private function removeItemInHand(Player $player): void {
        $player->getInventory()->removeItem($this->handItem->setCount(1));
    }
}