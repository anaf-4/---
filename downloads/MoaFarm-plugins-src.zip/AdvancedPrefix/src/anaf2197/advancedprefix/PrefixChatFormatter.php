<?php

namespace anaf2197\advancedprefix;

use anaf2197\Badge\badge\Badge;
use anaf2197\Badge\BadgeLoader;
use pocketmine\player\chat\ChatFormatter;
use anaf2197\rankapi\rank\list\Rank;
use anaf2197\rankapi\RankAPI;

class PrefixChatFormatter implements ChatFormatter {

    public function format(string $username, string $message): string {
        $playerPrefix = AdvancedPrefix::getInstance()->getPlayerPrefix($username);
        $rank = RankAPI::getInstance()->getPlayerRank($username)->getRank();
        $badge = BadgeLoader::getInstance()->getPlayerRank($username)->getRank();
        if ($playerPrefix instanceof PlayerPrefix) {
            return ($badge instanceof Badge ? $badge->getUnicode() . ' ' : '') . ($rank instanceof Rank ? $rank->getUnicode() . ' ' : '') . $playerPrefix->getNowPrefix() . ' §r' . $playerPrefix->getNowNickname() . ' §r§f: §' . $playerPrefix->getNowColor() . $message;
        }
        return '';
    }
}