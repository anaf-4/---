<?php /** @noinspection PhpUnreachableStatementInspection */

namespace anaf2197\advancedprefix;

use muqsit\invmenu\InvMenu;
use muqsit\invmenu\InvMenuHandler;
use muqsit\invmenu\transaction\InvMenuTransaction;
use muqsit\invmenu\transaction\InvMenuTransactionResult;
use muqsit\invmenu\type\InvMenuTypeIds;
use pocketmine\block\VanillaBlocks;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;
use anaf2197\advancedprefix\command\CheckOriginalCommand;
use anaf2197\advancedprefix\command\PrefixCommand;
use anaf2197\lib\color\BedrockColor;
use anaf2197\lib\provider\DataProvider;
use anaf2197\lib\provider\ProviderHandler;
use anaf2197\lib\color\ServerColor;
use anaf2197\servercore\item\ServerItems;

final class AdvancedPrefix extends PluginBase {

    public static string $prefix;

    private DataProvider $provider;

    use SingletonTrait;

    protected function onEnable(): void {
        $this->getServer()->getPluginManager()->registerEvents(new EventListener(), $this);
        $this->getServer()->getCommandMap()->registerAll(strtolower($this->getName()), [
            new CheckOriginalCommand(),
            new PrefixCommand()
        ]);
        if (!InvMenuHandler::isRegistered()) {
            InvMenuHandler::register($this);
        }
    }

    protected function onLoad(): void {
        self::setInstance($this);
        ServerColor::setPrefix($this, '칭호');
        if (!ProviderHandler::isRegistered($this)) {
            ProviderHandler::register($this, PlayerPrefix::class);
            $this->provider = ProviderHandler::get($this);
        }
    }

    protected function onDisable(): void {
        $this->saveDatabase();
    }

    public function saveDatabase(): void {
        $this->provider->save();
    }

    public function getNameByNickName(string $nickName): string|null {
        /** @var PlayerPrefix $object */
        foreach ($this->getAll() as $object) {
            if (strtolower($object->getNowNickname()) == strtolower($nickName)) {
                return $object->getName();
            }
        }
        return null;
    }

    public function setPlayerPrefix(Player $player): void {
        $lower = strtolower($player->getName());
        $this->provider->setObject($player, new PlayerPrefix($lower, [], 0, ['f'], 0, [$player->getName()], 0));
    }

    public function getAll(): array {
        return $this->provider->getAll();
    }

    public function getPlayerPrefix($key): ?PlayerPrefix {
        return $this->provider->getObject($key);
    }

    public function sendPrefixBox(Player $player): void {
        $invMenu = InvMenu::create(InvMenuTypeIds::TYPE_CHEST);
        $invMenu->setName('내 칭호 설정');
        $this->reloadInv($invMenu->getInventory(), $this->getPlayerPrefix($player));
        $invMenu->setListener(function (InvMenuTransaction $transaction): InvMenuTransactionResult {
            $player = $transaction->getPlayer();
            $action = $transaction->getAction();
            $slot = $action->getSlot();
            $inventory = $action->getInventory();
            $playerPrefix = AdvancedPrefix::getInstance()->getPlayerPrefix($player);
            $nextFunctionId = $inventory->getItem(26)->getNamedTag()->getTag('nextFunctionId')->getValue();
            $functionId = (int)$nextFunctionId - 1;
            
            // 도움말 슬롯 추가 (슬롯 18)
            if ($slot === 18) {
                $player->sendMessage(AdvancedPrefix::$prefix . '§l§6칭호 획득 방법');
                $player->sendMessage(AdvancedPrefix::$prefix . '§81. §f/칭호 관리 §8- 관리자 전용 칭호권 지급');
                $player->sendMessage(AdvancedPrefix::$prefix . '§82. §f자유 칭호권 §8- 웅크리기 + 터치로 사용');
                $player->sendMessage(AdvancedPrefix::$prefix . '§83. §f자유 색챗권 §8- 웅크리기 + 터치로 사용');
                $player->sendMessage(AdvancedPrefix::$prefix . '§84. §f자유 한닉권 §8- 웅크리기 + 터치로 사용');
                return $transaction->discard();
            }
            
            if ($slot !== 26) {
                if ($slot !== 25 or $functionId !== PrefixFunctionTag::TYPE_PREFIX) {
                    $function = match ($functionId) {
                        PrefixFunctionTag::TYPE_PREFIX => $playerPrefix->getPrefixes(),
                        PrefixFunctionTag::TYPE_CHAT_COLOR => $playerPrefix->getColors(),
                        PrefixFunctionTag::TYPE_NICKNAME => $playerPrefix->getNicknames()
                    };
                    if (count($function) - 1 >= $slot) {
                        $method = match ($functionId) {
                            PrefixFunctionTag::TYPE_PREFIX => 'setNowPrefixKey',
                            PrefixFunctionTag::TYPE_CHAT_COLOR => 'setNowColorKey',
                            PrefixFunctionTag::TYPE_NICKNAME => 'setNowNicknameKey'
                        };
                        $playerPrefix->$method($slot);
                        $player->removeCurrentWindow();
                    }
                } else {
                    $playerPrefix->setNowPrefixKey(-1);
                    $player->removeCurrentWindow();
                }
            } else {
                $this->reloadInv($inventory, $playerPrefix, $nextFunctionId);
            }
            return $transaction->discard();
        });
        $invMenu->setInventoryCloseListener(function (Player $player, Inventory $unused): void {
            $playerPrefix = AdvancedPrefix::getInstance()->getPlayerPrefix($player);
            $player->sendTitle($playerPrefix->getNowPrefix() . '§l§f -§r§f ' . $playerPrefix->getNowNickname(), '§' . $playerPrefix->getNowColor() . '채팅 색 미리보기');
        });
        $invMenu->send($player);
    }

    private function reloadInv(Inventory $inventory, PlayerPrefix $playerPrefix, int $functionId = 0): void {
        if ($functionId > 2) $functionId = 0;
        $function = match ($functionId) {
            PrefixFunctionTag::TYPE_PREFIX => $playerPrefix->getPrefixes(),
            PrefixFunctionTag::TYPE_CHAT_COLOR => array_map(function (string $colorId): string {
                return BedrockColor::getColorName($colorId);
            }, $playerPrefix->getColors()),
            PrefixFunctionTag::TYPE_NICKNAME => $playerPrefix->getNicknames()
        };
        $contents = array_map(function (string $key) use ($functionId, $playerPrefix): Item {
            $functionName = match ($functionId) {
                PrefixFunctionTag::TYPE_PREFIX => '칭호',
                PrefixFunctionTag::TYPE_CHAT_COLOR => '채팅 색',
                PrefixFunctionTag::TYPE_NICKNAME => '닉네임'
            };
            $now = match ($functionId) {
                PrefixFunctionTag::TYPE_PREFIX => $playerPrefix->getNowPrefix(),
                PrefixFunctionTag::TYPE_CHAT_COLOR => BedrockColor::getColorName($playerPrefix->getNowColor()),
                PrefixFunctionTag::TYPE_NICKNAME => $playerPrefix->getNowNickname()
            };
            $item_frame = VanillaBlocks::ITEM_FRAME()->asItem()->setCustomName($functionName . ': ' . $key);
            if ($now === $key) {
                $item_frame->setLore([' ', '§r§4현재 사용중입니다.']);
            } else {
                $item_frame->setLore([' ', '§r§8터치하여 착용하기']);
            }
            return $item_frame;
        }, $function);
        
        $nextFunctionId = $functionId + 1;
        $nextFunctionName = match ($nextFunctionId) {
            PrefixFunctionTag::TYPE_CHAT_COLOR => '채팅 색',
            PrefixFunctionTag::TYPE_NICKNAME => '한글닉',
            default => '칭호'
        };
        $right_arrow = ServerItems::RIGHT_ARROW()->setCustomName('§r§l§f' . $nextFunctionName . ' 보러가기')->setLore([' ', '§r§8터치하여 보러가기']);
        $right_arrow->getNamedTag()->setInt('nextFunctionId', $nextFunctionId);
        $contents[26] = $right_arrow;
        
        // 도움말 버튼 추가 (슬롯 18)
        $help_item = VanillaBlocks::BOOKSHELF()->asItem()->setCustomName('§r§l§e칭호 획득 방법')->setLore([
            ' ',
            '§r§8터치하여 칭호 얻는 방법 보기',
            ' ',
            '§r§8- /칭호 관리 (관리자 전용)',
            '§r§8- 자유 칭호권 사용',
            '§r§8- 자유 색챗권 사용',
            '§r§8- 자유 한닉권 사용'
        ]);
        $contents[18] = $help_item;
        
        if ($functionId === PrefixFunctionTag::TYPE_PREFIX) {
            $contents[25] = VanillaBlocks::SOUL_TORCH()->asItem()->setCustomName('§r§l§f칭호 해제하기')->setLore([' ', '§r§8터치하여 칭호 해제']);
        }
        
        $inventory->setContents($contents);
    }

    public function getNameExact(string $name): ?string {
        /** @var PlayerPrefix $object */
        foreach ($this->getAll() as $object) {
            if (in_array(strtolower($name), array_map(function (string $data): string {
                return strtolower($data);
            }, $object->getNicknames()))) {
                return $object->getName();
            }
        }
        return null;
    }
}