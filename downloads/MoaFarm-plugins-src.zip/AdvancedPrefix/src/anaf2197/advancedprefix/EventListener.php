<?php

namespace anaf2197\advancedprefix;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\event\player\PlayerJoinEvent;
use anaf2197\advancedprefix\form\WriteFunctionForm;
use anaf2197\lib\color\BedrockColor;

final class EventListener implements Listener {

    public function onPlayerJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        $playerPrefix = AdvancedPrefix::getInstance()->getPlayerPrefix($player);
        if (!$playerPrefix instanceof PlayerPrefix) {
            AdvancedPrefix::getInstance()->setPlayerPrefix($player);
        }
    }

    /* This function moved to -> ChattingRoomLoader <-
     *
     *  public function onPlayerChat(PlayerChatEvent $event): void {
     *
     *
     * $event->setFormatter(new PrefixChatFormatter());
    }*/

    public function onPlayerItemUse(PlayerItemUseEvent $event): void {
        $item = $event->getItem();
        if (is_numeric(($id = PrefixFunctionTag::readFunctionId($item, false)))) {
            $event->cancel();
            $player = $event->getPlayer();
            if ($player->isSneaking()) {
                if (is_string(($value = PrefixFunctionTag::readValue($item, false, $id)))) {
                    $playerPrefix = AdvancedPrefix::getInstance()->getPlayerPrefix($player);
                    $cantAddMethod = ['hasPrefix', 'hasColor'][$id];
                    $function = ['칭호', '채팅 색'][$id];
                    if (!$playerPrefix->$cantAddMethod($value)) {
                        $method = ['addPrefix', 'addColor'][$id];
                        $playerPrefix->$method($value);
                        if ($method === 'addColor'){
                            $value = '§' . $value . BedrockColor::getColorName($value);
                        }
                        $player->getInventory()->removeItem($item->setCount(1));
                        $player->sendMessage(AdvancedPrefix::$prefix . '[' . $value . '§r§8] ' . $function . '(이)가 지급되었습니다.');
                    } else {
                        $player->sendMessage(AdvancedPrefix::$prefix . '이미 보유 중인 ' . $function . '입니다');
                    }
                } else {
                    $player->sendForm(new WriteFunctionForm(PrefixFunctionTag::readFunctionId($item, true), $item));
                }
            }
        }
    }
}