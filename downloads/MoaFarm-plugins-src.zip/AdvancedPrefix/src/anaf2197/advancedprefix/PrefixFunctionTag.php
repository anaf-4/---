<?php

namespace anaf2197\advancedprefix;

use pocketmine\item\Item;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\StringTag;

final class PrefixFunctionTag {

    const TYPE_PREFIX = 0;
    const TYPE_CHAT_COLOR = 1;
    const TYPE_NICKNAME = 2;

    public static function createTag(CompoundTag $nbt, int $id, bool $customizable = true, ?string $value = null): void {
        $nbt->setString(($customizable ? 'prefix.customizable.' : 'prefix.') . $id, $value ?? '');
    }

    public static function readFunctionId(Item $item, bool $customizable): ?int {
        $key = $customizable ? 'prefix.customizable.' : 'prefix.';
        foreach ($item->getNamedTag()->getValue() as $tagName => $tag) {
            if (!$tag instanceof StringTag) continue;
            if (count(($cuttingValue = explode($key, $tagName))) >= 2) return (int)$cuttingValue [1];
        }
        return null;
    }

    public static function readValue(Item $item, bool $customizable, int $id): ?string {
        return $item->getNamedTag()->getTag(($customizable ? 'prefix.customizable.' : 'prefix.') . $id)?->getValue();
    }

    public static function getAll(): array {
        return [
            self::TYPE_PREFIX,
            self::TYPE_CHAT_COLOR,
            self::TYPE_NICKNAME
        ];
    }
}