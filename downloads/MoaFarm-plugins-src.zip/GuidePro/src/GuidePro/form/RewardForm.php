<?php

declare(strict_types=1);

namespace GuidePro\form;

use pocketmine\player\Player;
use pocketmine\inventory\SimpleInventory;
use pocketmine\block\VanillaBlocks;
use pocketmine\item\Item;
use pocketmine\item\VanillaItems;
use GuidePro\Main;

class RewardInventory extends SimpleInventory {
    
    private int $stage;
    private string $ownerName;

    public function __construct(int $stage, string $ownerName) {
        parent::__construct(27); // 27칸 인벤토리
        $this->stage = $stage;
        $this->ownerName = $ownerName;
        
        $this->setupInventory();
    }

    private function setupInventory(): void {
        // 설명 아이템 추가
        $infoItem = VanillaBlocks::YELLOW_STAINED_GLASS_PANE()->asItem();
        $infoItem->setCustomName("§e§l보상 설정 방법");
        $infoItem->setLore([
            "§81. 보상으로 지급할 아이템을",
            "§8   가운데 칸에 넣으세요",
            "§82. 인벤토리를 닫으면 자동으로",
            "§8   보상이 설정됩니다",
            "",
            "§a여러 아이템을 넣으면",
            "§a모두 보상으로 지급됩니다!"
        ]);
        
        // 테두리 장식 (위, 아래, 양옆)
        for ($i = 0; $i < 27; $i++) {
            // 첫 줄과 마지막 줄, 그리고 양옆
            if ($i < 9 || $i >= 18 || $i % 9 === 0 || $i % 9 === 8) {
                $this->setItem($i, $infoItem);
            }
        }
    }

    public function getStage(): int {
        return $this->stage;
    }

    public function getOwnerName(): string {
        return $this->ownerName;
    }
}

class RewardForm {
    
    private static array $openInventories = [];

    public static function openRewardInventory(Player $player, int $stage): void {
        $inventory = new RewardInventory($stage, $player->getName());
        
        self::$openInventories[$player->getName()] = $inventory;
        $player->setCurrentWindow($inventory);
    }

    public static function handleInventoryClose(Player $player): void {
        if (!isset(self::$openInventories[$player->getName()])) {
            return;
        }

        $inventory = self::$openInventories[$player->getName()];
        unset(self::$openInventories[$player->getName()]);

        if (!($inventory instanceof RewardInventory)) {
            return;
        }

        $stage = $inventory->getStage();
        $items = [];

        // 인벤토리에서 아이템 수집 (가운데 칸만, 9~17번 슬롯 중 양 끝 제외)
        for ($i = 9; $i < 18; $i++) {
            // 양 끝 제외
            if ($i % 9 === 0 || $i % 9 === 8) {
                continue;
            }
            
            $item = $inventory->getItem($i);
            
            // 빈 아이템이거나 장식 유리가 아닌 경우만 추가
            if (!$item->isNull() && $item->getTypeId() !== VanillaBlocks::YELLOW_STAINED_GLASS_PANE()->asItem()->getTypeId()) {
                $items[] = $item;
            }
        }

        if (empty($items)) {
            $player->sendMessage("§c아이템을 넣지 않아 보상이 설정되지 않았습니다.");
            return;
        }

        // 보상 설정
        $plugin = Main::getInstance();
        $itemDataArray = [];

        foreach ($items as $item) {
            try {
                $itemDataArray[] = [
                    "id" => $item->getTypeId(),
                    "name" => $item->getName(),
                    "count" => $item->getCount(),
                    "nbt" => base64_encode((new \pocketmine\nbt\BigEndianNbtSerializer())->write(new \pocketmine\nbt\tag\CompoundTag("", [$item->nbtSerialize()])))
                ];
            } catch (\Exception $e) {
                $plugin->getLogger()->error("아이템 직렬화 오류: " . $e->getMessage());
            }
        }

        if (empty($itemDataArray)) {
            $player->sendMessage("§c보상 설정 중 오류가 발생했습니다.");
            return;
        }

        $rewardData = [
            "type" => "item",
            "items" => $itemDataArray
        ];

        $plugin->getGuideManager()->setReward($stage, $rewardData);
        
        $player->sendMessage("§a보상이 설정되었습니다!");
        $player->sendMessage("§e단계: §f$stage");
        $player->sendMessage("§e아이템 개수: §f" . count($items) . "개");
    }

    public static function isRewardInventory(string $playerName): bool {
        return isset(self::$openInventories[$playerName]);
    }

    public static function getRewardInventory(string $playerName): ?RewardInventory {
        return self::$openInventories[$playerName] ?? null;
    }

    public static function removeRewardInventory(string $playerName): void {
        unset(self::$openInventories[$playerName]);
    }
}