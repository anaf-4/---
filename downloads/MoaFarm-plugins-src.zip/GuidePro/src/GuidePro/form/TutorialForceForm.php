<?php
declare(strict_types=1);

namespace GuidePro\form;

use pocketmine\form\Form;
use pocketmine\player\Player;
use GuidePro\Main;

class TutorialForceForm implements Form {

    public function __construct(private string $content, private int $stage) {}

    public static function send(Player $player): void {
        $guideManager = Main::getInstance()->getGuideManager();
        $stage        = $guideManager->getCurrentStage($player);
        $quest        = $guideManager->getQuestInfo($stage);
        $maxStage     = $guideManager->getMaxStage();

        if ($quest === null) {
            $player->sendTitle('§l§a튜토리얼 완료!', '§r§e스타터 아이템을 확인하세요!', 10, 60, 20);
            $player->sendMessage('§a§l[길라잡이] §r§e모든 튜토리얼을 완료했습니다! 축하합니다!');
            return;
        }

        $lines = [
            '§e진행도: §f' . $stage . ' §8/ §f' . $maxStage . ' §8단계',
            ' ',
            '§l§f' . $quest['title'],
            '§r§8' . $quest['description'],
        ];

        // 진행 중인 타입별 진행도 표시
        $type = $quest['type'] ?? '';
        if ($type === 'jump') {
            $data     = Main::getInstance()->getPlayerData();
            $progress = $data->getNested($player->getName() . '.progress.' . $stage . '.default', 0);
            $lines[]  = ' ';
            $lines[]  = '§a진행도: §e' . $progress . ' §8/ §e' . $quest['requirement'];
        } elseif ($type === 'break') {
            $data      = Main::getInstance()->getPlayerData();
            $progress  = $data->getNested($player->getName() . '.progress.' . $stage . '.default', 0);
            $required  = is_array($quest['requirement']) ? ($quest['requirement']['amount'] ?? 0) : $quest['requirement'];
            $lines[]   = ' ';
            $lines[]   = '§a진행도: §e' . $progress . ' §8/ §e' . $required;
        } elseif ($type === 'sell') {
            $data      = Main::getInstance()->getPlayerData();
            $progress  = $data->getNested($player->getName() . '.progress.' . $stage . '.default', 0);
            $required  = is_array($quest['requirement']) ? ($quest['requirement']['amount'] ?? 0) : $quest['requirement'];
            $lines[]   = ' ';
            $lines[]   = '§a판매 진행도: §e' . $progress . ' §8/ §e' . $required;
        }

        $lines[] = ' ';
        $lines[] = '§r§a퀘스트를 완료하면 자동으로 다음 단계로 넘어갑니다.';
        $lines[] = '§r§8모든 단계 완료 시 §e스타터 아이템§8이 지급됩니다!';

        $player->sendForm(new self(implode("\n", $lines), $stage));
    }

    public function jsonSerialize(): array {
        return [
            'type'    => 'modal',
            'title'   => '§l§a길라잡이 튜토리얼',
            'content' => $this->content,
            'button1' => '§a확인!',
            'button2' => '§8닫기',
        ];
    }

    public function handleResponse(Player $player, $data): void {
        if ($data !== 0) {
            $guideManager = Main::getInstance()->getGuideManager();
            $stage        = $guideManager->getCurrentStage($player);
            $quest        = $guideManager->getQuestInfo($stage);
            if ($quest !== null) {
                $player->sendMessage('§a§l[길라잡이] §r§8현재 퀘스트: §f[' . $stage . '단계] ' . $quest['title']);
                $player->sendMessage('§8' . $quest['description']);
            }
        }
    }
}
