<?php

declare(strict_types=1);

namespace GuidePro\form;

use pocketmine\player\Player;
use pocketmine\form\Form;
use pocketmine\item\Item;
use GuidePro\Main;

class AdminForm implements Form {

    private $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function jsonSerialize(): array {
        return [
            "type" => "form",
            "title" => "§l§c길라잡이 관리",
            "content" => "§e관리 메뉴를 선택하세요",
            "buttons" => [
                [
                    "text" => "§l§a퀘스트 추가\n§r§8새로운 퀘스트 생성"
                ],
                [
                    "text" => "§l§e보상 설정\n§r§8퀘스트 보상 수정"
                ],
                [
                    "text" => "§l§b퀘스트 목록\n§r§8모든 퀘스트 보기"
                ],
                [
                    "text" => "§l§6플레이어 초기화\n§r§8진행도 리셋"
                ],
                [
                    "text" => "§l§c닫기\n§r§8나가기"
                ]
            ]
        ];
    }

    public function handleResponse(Player $player, $data): void {
        if ($data === null) {
            return;
        }

        switch ($data) {
            case 0: // 퀘스트 추가
                $this->showAddQuestForm($player);
                break;
            case 1: // 보상 설정
                $this->showRewardStageSelectForm($player);
                break;
            case 2: // 퀘스트 목록
                $this->showQuestList($player);
                break;
            case 3: // 플레이어 초기화
                $this->showResetForm($player);
                break;
            case 4: // 닫기
                break;
        }
    }

    private function showAddQuestForm(Player $player): void {
        $form = [
            "type" => "custom_form",
            "title" => "§l§a퀘스트 추가",
            "content" => [
                [
                    "type" => "input",
                    "text" => "단계 번호",
                    "placeholder" => "예: 1"
                ],
                [
                    "type" => "input",
                    "text" => "퀘스트 제목",
                    "placeholder" => "예: 첫 번째 퀘스트"
                ],
                [
                    "type" => "input",
                    "text" => "퀘스트 설명",
                    "placeholder" => "예: 채팅으로 안녕하세요를 입력해주세요"
                ],
                [
                    "type" => "dropdown",
                    "text" => "퀘스트 타입",
                    "options" => ["chat", "jump", "command", "buy", "sell", "break"]
                ],
                [
                    "type" => "input",
                    "text" => "요구사항",
                    "placeholder" => "chat: 텍스트 / jump: 숫자 / command: 명령어"
                ],
                [
                    "type" => "input",
                    "text" => "요구 개수 (sell, break 타입만)",
                    "placeholder" => "숫자 또는 비워두기"
                ]
            ]
        ];

        $player->sendForm(new class($form, $this->plugin) implements Form {
            private $form;
            private $plugin;
            
            public function __construct($form, $plugin) {
                $this->form = $form;
                $this->plugin = $plugin;
            }
            
            public function jsonSerialize(): array {
                return $this->form;
            }
            
            public function handleResponse(Player $player, $data): void {
                if ($data === null) {
                    return;
                }

                $stage = (int)$data[0];
                $title = $data[1];
                $description = $data[2];
                $typeIndex = $data[3];
                $requirement = $data[4];
                $amount = $data[5];

                $types = ["chat", "jump", "command", "buy", "sell", "break"];
                $type = $types[$typeIndex];

                if (empty($data[0]) || empty($data[1]) || empty($data[2]) || empty($data[4])) {
                    $player->sendMessage("§c필수 항목을 모두 입력해주세요!");
                    return;
                }

                // sell, break 타입은 배열로 처리
                if (($type === "sell" || $type === "break") && !empty($amount)) {
                    $requirement = [
                        ($type === "sell" ? "item" : "block") => $requirement,
                        "amount" => (int)$amount
                    ];
                } elseif ($type === "jump") {
                    $requirement = (int)$requirement;
                }

                $this->plugin->getGuideManager()->setQuest($stage, $title, $description, $type, $requirement);
                $player->sendMessage("§a퀘스트가 추가되었습니다! (단계: $stage)");
            }
        });
    }

    // ===== 보상 설정: 단계 선택 Form =====
        private function showRewardStageSelectForm(Player $player): void {
        $form = [
            "type" => "custom_form",
            "title" => "§l§e보상 설정",
            "content" => [
                [
                    "type" => "input",
                    "text" => "단계 번호를 입력하세요",
                    "placeholder" => "예: 1"
                ]
            ]
        ];

        $player->sendForm(new class($form, $this->plugin) implements Form {
            private $form;
            private $plugin;
            
            public function __construct($form, $plugin) {
                $this->form = $form;
                $this->plugin = $plugin;
            }
            
            public function jsonSerialize(): array {
                return $this->form;
            }
            
            public function handleResponse(Player $player, $data): void {
                if ($data === null) {
                    return;
                }

                $stage = (int)$data[0];

                if (empty($data[0])) {
                    $player->sendMessage("§c단계 번호를 입력해주세요!");
                    return;
                }

                // 퀘스트가 존재하는지 확인
                $quest = $this->plugin->getGuideManager()->getQuestInfo($stage);
                if ($quest === null) {
                    $player->sendMessage("§c단계 $stage 퀘스트가 존재하지 않습니다.");
                    return;
                }

                // 인벤토리 GUI 열기
                \GuidePro\form\RewardForm::openRewardInventory($player, $stage);
            }
        });
    }

    private function showQuestList(Player $player): void {
        $config = $this->plugin->getConfig();
        $quests = $config->get("quests", []);

        $content = "§e등록된 퀘스트 목록:\n\n";
        
        if (empty($quests)) {
            $content .= "§8등록된 퀘스트가 없습니다.";
        } else {
            ksort($quests);
            foreach ($quests as $stage => $quest) {
                $content .= "§a단계 $stage: §f" . $quest["title"] . "\n";
                $content .= "§8타입: §e" . $quest["type"] . "\n";
                
                if (is_array($quest["requirement"])) {
                    if (isset($quest["requirement"]["item"])) {
                        $content .= "§8요구사항: §e" . $quest["requirement"]["item"] . " x" . $quest["requirement"]["amount"] . "\n";
                    } elseif (isset($quest["requirement"]["block"])) {
                        $content .= "§8요구사항: §e" . $quest["requirement"]["block"] . " x" . $quest["requirement"]["amount"] . "\n";
                    }
                } else {
                    $content .= "§8요구사항: §e" . $quest["requirement"] . "\n";
                }
                
                if (isset($quest["reward"])) {
                    if ($quest["reward"]["type"] === "item") {
                        $content .= "§8보상: §e" . $quest["reward"]["name"] . " x" . $quest["reward"]["count"] . "\n";
                    } else {
                        $content .= "§8보상: §e" . $quest["reward"]["value"] . "\n";
                    }
                }
                $content .= "\n";
            }
        }

        $form = [
            "type" => "modal",
            "title" => "§l§b퀘스트 목록",
            "content" => $content,
            "button1" => "§a확인",
            "button2" => "§c닫기"
        ];

        $player->sendForm(new class($form) implements Form {
            private $form;
            
            public function __construct($form) {
                $this->form = $form;
            }
            
            public function jsonSerialize(): array {
                return $this->form;
            }
            
            public function handleResponse(Player $player, $data): void {
            }
        });
    }

    private function showResetForm(Player $player): void {
        $form = [
            "type" => "custom_form",
            "title" => "§l§6플레이어 초기화",
            "content" => [
                [
                    "type" => "input",
                    "text" => "플레이어 이름",
                    "placeholder" => "초기화할 플레이어 이름"
                ]
            ]
        ];

        $player->sendForm(new class($form, $this->plugin) implements Form {
            private $form;
            private $plugin;
            
            public function __construct($form, $plugin) {
                $this->form = $form;
                $this->plugin = $plugin;
            }
            
            public function jsonSerialize(): array {
                return $this->form;
            }
            
            public function handleResponse(Player $player, $data): void {
                if ($data === null) {
                    return;
                }

                $targetName = $data[0];

                if (empty($targetName)) {
                    $player->sendMessage("§c플레이어 이름을 입력해주세요!");
                    return;
                }

                $playerData = $this->plugin->getPlayerData();
                
                if ($playerData->exists($targetName)) {
                    $playerData->set($targetName, [
                        "current_stage" => 1,
                        "completed_stages" => [],
                        "progress" => [],
                        "quest_data" => []
                    ]);
                    $this->plugin->savePlayerData();
                    $player->sendMessage("§a$targetName 플레이어의 진행도가 초기화되었습니다!");
                } else {
                    $player->sendMessage("§c해당 플레이어를 찾을 수 없습니다!");
                }
            }
        });
    }

    public static function send(Player $player): void {
        if (!$player->hasPermission("guidepro.admin")) {
            $player->sendMessage("§c권한이 없습니다.");
            return;
        }
        
        $plugin = Main::getInstance();
        $player->sendForm(new self($plugin));
    }
}