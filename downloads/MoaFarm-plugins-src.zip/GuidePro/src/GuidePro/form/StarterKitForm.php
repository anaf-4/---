<?php
declare(strict_types=1);

namespace GuidePro\form;

use muqsit\invmenu\InvMenu;
use muqsit\invmenu\InvMenuHandler;
use muqsit\invmenu\transaction\InvMenuTransaction;
use muqsit\invmenu\transaction\InvMenuTransactionResult;
use muqsit\invmenu\type\InvMenuTypeIds;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\player\Player;
use GuidePro\Main;

class StarterKitForm {

    public static function open(Player $player): void {
        if (!InvMenuHandler::isRegistered()) {
            InvMenuHandler::register(Main::getInstance());
        }

        $menu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
        $menu->setName('§l§a스타터킷 설정 (신규 유저 지급 아이템)');

        // 현재 설정된 스타터킷 아이템 불러오기
        $items = self::loadItems();
        $inv   = $menu->getInventory();
        foreach ($items as $i => $item) {
            if ($i >= 54) break;
            $inv->setItem($i, $item);
        }

        $menu->setListener(fn(InvMenuTransaction $t): InvMenuTransactionResult => $t->continue($t->getOut(), $t->getIn()));

        $menu->setInventoryCloseListener(function (Player $player, Inventory $inventory): void {
            $items = [];
            foreach ($inventory->getContents() as $item) {
                if (!$item->isNull()) {
                    $items[] = $item;
                }
            }
            self::saveItems($items);
            $player->sendMessage('§a§l[길라잡이] §r스타터킷 아이템이 저장됐습니다. §8(총 §f' . count($items) . '§8개)');
        });

        $menu->send($player);
    }

    /** @return Item[] */
    private static function loadItems(): array {
        $path = Main::getInstance()->getDataFolder() . 'starter_kit.json';
        if (!file_exists($path)) return [];

        $items = [];
        foreach (json_decode(file_get_contents($path), true) ?? [] as $str) {
            try {
                $items[] = \anaf2197\lib\itemparser\ItemParser::fromString($str);
            } catch (\Throwable) {}
        }
        return $items;
    }

    /** @param Item[] $items */
    private static function saveItems(array $items): void {
        $data = [];
        foreach ($items as $item) {
            try {
                $data[] = \anaf2197\lib\itemparser\ItemParser::toString($item);
            } catch (\Throwable) {}
        }
        file_put_contents(
            Main::getInstance()->getDataFolder() . 'starter_kit.json',
            json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
        );
    }
}
