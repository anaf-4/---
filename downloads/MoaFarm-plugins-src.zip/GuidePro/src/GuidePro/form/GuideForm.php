<?php

declare(strict_types=1);

namespace GuidePro\form;

use pocketmine\player\Player;
use pocketmine\form\Form;
use GuidePro\Main;

class GuideForm implements Form {

    private $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function jsonSerialize(): array {
        $player = null; // 이 부분은 sendForm 메서드에서 처리됩니다
        
        return [
            "type" => "form",
            "title" => "§l§a길라잡이",
            "content" => "",
            "buttons" => [
                [
                    "text" => "§l§e현재 퀘스트 확인\n§r§8내 진행 상황 보기"
                ],
                [
                    "text" => "§l§b완료한 퀘스트\n§r§8달성 기록 보기"
                ],
                [
                    "text" => "§l§c닫기\n§r§8나가기"
                ]
            ]
        ];
    }

    public function handleResponse(Player $player, $data): void {
        if ($data === null) {
            return;
        }

        switch ($data) {
            case 0: // 현재 퀘스트 확인
                $this->showCurrentQuest($player);
                break;
            case 1: // 완료한 퀘스트
                $this->showCompletedQuests($player);
                break;
            case 2: // 닫기
                break;
        }
    }

    private function showCurrentQuest(Player $player): void {
        $guideManager = $this->plugin->getGuideManager();
        $currentStage = $guideManager->getCurrentStage($player);
        $quest = $guideManager->getQuestInfo($currentStage);

        if ($quest === null) {
            $content = "§a§l모든 퀘스트를 완료했습니다!\n\n§r§e축하합니다!";
        } else {
            $content = "§e현재 단계: §f$currentStage\n\n";
            $content .= "§a퀘스트: §f" . $quest["title"] . "\n";
            $content .= "§8" . $quest["description"] . "\n\n";
            
            // 진행도 표시
            if ($quest["type"] === "jump") {
                $data = $this->plugin->getPlayerData();
                $progress = $data->getNested($player->getName() . ".progress.$currentStage", 0);
                $content .= "§a진행도: §e$progress§a/§e" . $quest["requirement"];
            } elseif ($quest["type"] === "chat") {
                $content .= "§8요구사항: §f" . $quest["requirement"];
            }
        }

        $form = [
            "type" => "modal",
            "title" => "§l§a현재 퀘스트",
            "content" => $content,
            "button1" => "§a확인",
            "button2" => "§c닫기"
        ];

        $player->sendForm(new class($form) implements Form {
            private $form;
            
            public function __construct($form) {
                $this->form = $form;
            }
            
            public function jsonSerialize(): array {
                return $this->form;
            }
            
            public function handleResponse(Player $player, $data): void {
            }
        });
    }

    private function showCompletedQuests(Player $player): void {
        $data = $this->plugin->getPlayerData();
        $completed = $data->getNested($player->getName() . ".completed_stages", []);

        $content = "§e완료한 퀘스트 목록:\n\n";
        
        if (empty($completed)) {
            $content .= "§8아직 완료한 퀘스트가 없습니다.";
        } else {
            foreach ($completed as $stage) {
                $quest = $this->plugin->getGuideManager()->getQuestInfo($stage);
                if ($quest !== null) {
                    $content .= "§a§f단계 $stage: " . $quest["title"] . "\n";
                }
            }
            $content .= "\n§e총 완료: §a" . count($completed) . "개";
        }

        $form = [
            "type" => "modal",
            "title" => "§l§b완료한 퀘스트",
            "content" => $content,
            "button1" => "§a확인",
            "button2" => "§c닫기"
        ];

        $player->sendForm(new class($form) implements Form {
            private $form;
            
            public function __construct($form) {
                $this->form = $form;
            }
            
            public function jsonSerialize(): array {
                return $this->form;
            }
            
            public function handleResponse(Player $player, $data): void {
            }
        });
    }

    public static function send(Player $player): void {
        $plugin = Main::getInstance();
        $player->sendForm(new self($plugin));
    }
}