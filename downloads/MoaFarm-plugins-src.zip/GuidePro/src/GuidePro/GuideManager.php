<?php

declare(strict_types=1);

namespace GuidePro;

use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\block\Block;
use pocketmine\item\Item;
use pocketmine\nbt\tag\CompoundTag;

class GuideManager {

    private $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    // 현재 단계 가져오기
    public function getCurrentStage(Player $player): int {
        $data = $this->plugin->getPlayerData();
        $name = $player->getName();
        
        if ($data->exists($name)) {
            return $data->getNested($name . ".current_stage", 1);
        }
        return 1;
    }

    // 퀘스트 정보 가져오기
    public function getQuestInfo(int $stage): ?array {
        $quests = $this->plugin->getConfig()->get('quests', []);
        return $quests[$stage] ?? null;
    }

    // 진행도 가져오기
    private function getProgress(Player $player, int $stage, string $key = "default"): int {
        $data = $this->plugin->getPlayerData();
        $name = $player->getName();
        return $data->getNested($name . ".progress.$stage.$key", 0);
    }

    // 진행도 설정
    private function setProgress(Player $player, int $stage, int $value, string $key = "default"): void {
        $data = $this->plugin->getPlayerData();
        $name = $player->getName();
        $data->setNested($name . ".progress.$stage.$key", $value);
        $this->plugin->savePlayerData();
    }

    // 퀘스트 데이터 가져오기
    private function getQuestData(Player $player, int $stage, string $key): mixed {
        $data = $this->plugin->getPlayerData();
        $name = $player->getName();
        return $data->getNested($name . ".quest_data.$stage.$key", null);
    }

    // 퀘스트 데이터 설정
    private function setQuestData(Player $player, int $stage, string $key, mixed $value): void {
        $data = $this->plugin->getPlayerData();
        $name = $player->getName();
        $data->setNested($name . ".quest_data.$stage.$key", $value);
        $this->plugin->savePlayerData();
    }

    // 1. 채팅 퀘스트 체크
    public function checkChatQuest(Player $player, string $message): void {
        $currentStage = $this->getCurrentStage($player);
        $quest = $this->getQuestInfo($currentStage);
        
        if ($quest === null) return;
        
        if ($quest["type"] === "chat" && trim($message) === trim($quest["requirement"])) {
            $this->completeQuest($player, $currentStage);
        }
    }

    // 2. 점프 퀘스트 체크
    public function checkJumpQuest(Player $player): void {
        $currentStage = $this->getCurrentStage($player);
        $quest = $this->getQuestInfo($currentStage);
        
        if ($quest === null) return;
        
        if (($quest["type"] ?? '') === "jump") {
            $progress = $this->getProgress($player, $currentStage) + 1;
            $this->setProgress($player, $currentStage, $progress);
            $required = (int)($quest["requirement"] ?? 1);
            $player->sendMessage('§a점프 진행도: §e' . $progress . '§a/§e' . $required);
            if ($progress >= $required) {
                $this->completeQuest($player, $currentStage);
            }
        }
    }

    // 3. 명령어 실행 퀘스트 체크
    public function checkCommandQuest(Player $player, string $command): void {
        $currentStage = $this->getCurrentStage($player);
        $quest = $this->getQuestInfo($currentStage);
        
        if ($quest === null) return;
        
        if ($quest["type"] === "command") {
            $requiredCommand = $quest["requirement"];
            
            // 명령어 비교 (슬래시 제거)
            $command = ltrim($command, "/");
            $requiredCommand = ltrim($requiredCommand, "/");
            
            if (stripos($command, $requiredCommand) === 0) {
                $this->completeQuest($player, $currentStage);
            }
        }
    }

    // 4. 아이템 구매 퀘스트 체크
    public function checkBuyQuest(Player $player, string $itemName): void {
        $currentStage = $this->getCurrentStage($player);
        $quest = $this->getQuestInfo($currentStage);
        
        if ($quest === null) return;
        
        if ($quest["type"] === "buy") {
            if (stripos($itemName, $quest["requirement"]) !== false || 
                stripos($quest["requirement"], $itemName) !== false) {
                $this->completeQuest($player, $currentStage);
            }
        }
    }

    // 5. 블록 파괴 퀘스트 체크
    public function checkBlockBreakQuest(Player $player, Block $block): void {
        $currentStage = $this->getCurrentStage($player);
        $quest = $this->getQuestInfo($currentStage);
        
        if ($quest === null) return;
        
        if ($quest["type"] === "break") {
            $blockName = $block->getName();
            $requiredBlock = $quest["requirement"]["block"];
            $requiredAmount = $quest["requirement"]["amount"];
            
            // 블록 이름 비교
            if (stripos($blockName, $requiredBlock) !== false ||
                stripos($requiredBlock, $blockName) !== false) {

                $progress = $this->getProgress($player, $currentStage);
                $progress++;
                $this->setProgress($player, $currentStage, $progress);

                $player->sendMessage("§a진행도: §e{$progress}§a/§e{$requiredAmount}");

                if ($progress >= $requiredAmount) {
                    $this->completeQuest($player, $currentStage);
                }
            }
        }
    }

    // 6. 아이템 판매 퀘스트 체크
    public function checkSellQuest(Player $player, string $itemName, int $amount): void {
        $currentStage = $this->getCurrentStage($player);
        $quest = $this->getQuestInfo($currentStage);
        
        if ($quest === null) return;
        
        if ($quest["type"] === "sell") {
            $requiredItem = $quest["requirement"]["item"];
            $requiredAmount = $quest["requirement"]["amount"];
            
            // 아이템 이름 비교
            if (stripos($itemName, $requiredItem) !== false || 
                stripos($requiredItem, $itemName) !== false) {
                
                $progress = $this->getProgress($player, $currentStage);
                $progress += $amount;
                $this->setProgress($player, $currentStage, $progress);
                
                $player->sendMessage("§a판매 진행도: §e{$progress}§a/§e{$requiredAmount}");
                
                if ($progress >= $requiredAmount) {
                    $this->completeQuest($player, $currentStage);
                }
            }
        }
    }

    // 7. 복합 퀘스트 체크 (채굴 + 판매)
    public function checkMineAndSellQuest(Player $player, string $itemName, int $amount): void {
        $currentStage = $this->getCurrentStage($player);
        $quest = $this->getQuestInfo($currentStage);
        
        if ($quest === null) return;
        
        if ($quest["type"] === "mine_and_sell") {
            $requiredItem = $quest["requirement"]["item"];
            $requiredAmount = $quest["requirement"]["amount"];
            
            // 먼저 채굴이 완료되었는지 확인
            $mined = $this->getQuestData($player, $currentStage, "mined");
            
            if ($mined >= $requiredAmount) {
                // 이제 판매 체크
                if (stripos($itemName, $requiredItem) !== false || 
                    stripos($requiredItem, $itemName) !== false) {
                    
                    $progress = $this->getProgress($player, $currentStage, "sold");
                    $progress += $amount;
                    $this->setProgress($player, $currentStage, $progress, "sold");
                    
                    $player->sendMessage("§a판매 진행도: §e{$progress}§a/§e{$requiredAmount}");
                    
                    if ($progress >= $requiredAmount) {
                        $this->completeQuest($player, $currentStage);
                    }
                }
            }
        }
    }

    // 최대 단계 수 반환
    public function getMaxStage(): int {
        $quests = $this->plugin->getConfig()->get('quests', []);
        return empty($quests) ? 0 : max(array_keys($quests));
    }

    // 튜토리얼 완료 여부
    public function isTutorialComplete(Player $player): bool {
        return $this->getQuestInfo($this->getCurrentStage($player)) === null;
    }

    // 스타터킷 지급
    public function giveStarterKit(Player $player): void {
        $path  = $this->plugin->getDataFolder() . 'starter_kit.json';
        if (!file_exists($path)) return;

        $raw   = json_decode(file_get_contents($path), true) ?? [];
        $items = [];
        foreach ($raw as $str) {
            try {
                $items[] = \anaf2197\lib\itemparser\ItemParser::fromString($str);
            } catch (\Throwable) {}
        }
        if (empty($items)) return;

        $leftover = $player->getInventory()->addItem(...$items);
        if (!empty($leftover)) {
            foreach ($leftover as $item) {
                $player->getWorld()->dropItem($player->getPosition(), $item);
            }
            $player->sendMessage('§c[길라잡이] 인벤토리 공간이 부족해 일부 아이템이 드롭됐습니다.');
        }
        $player->sendMessage('§a§l[길라잡이] §r§e스타터 아이템이 지급됐습니다! 즐거운 플레이 되세요!');
    }

    // 퀘스트 완료 처리
    public function completeQuest(Player $player, int $stage): void {
        $name = $player->getName();
        $data = $this->plugin->getPlayerData();

        // 완료된 단계에 추가
        $completed = $data->getNested($name . ".completed_stages", []);
        if (!in_array($stage, $completed)) {
            $completed[] = $stage;
            $data->setNested($name . ".completed_stages", $completed);
        }

        // 다음 단계로 이동
        $nextStage = $stage + 1;
        $data->setNested($name . ".current_stage", $nextStage);

        // 진행도 초기화
        $data->setNested($name . ".progress.$stage", []);
        $data->setNested($name . ".quest_data.$stage", []);

        $this->plugin->savePlayerData();

        // 단계별 보상 지급
        $quest = $this->getQuestInfo($stage);
        if ($quest !== null && isset($quest["reward"])) {
            $this->giveReward($player, $quest["reward"]);
        }

        // 다음 퀘스트 정보 표시
        $nextQuest = $this->getQuestInfo($nextStage);
        if ($nextQuest !== null) {
            $player->sendTitle('§l§a퀘스트 완료!', '§r§e' . $stage . '단계 클리어!', 10, 50, 20);
            $player->sendMessage("§a§l[길라잡이] §r§e§l" . $stage . "단계 퀘스트를 완료했습니다!");
            $player->sendMessage("§a다음 단계: §e{$nextStage}단계 §8— §f" . $nextQuest["title"]);
            $player->sendMessage("§8" . $nextQuest["description"]);
            $player->sendMessage("§8§o/길라잡이 명령어로 진행 상황을 확인할 수 있습니다.");
        } else {
            // 모든 단계 완료 → 스타터킷 지급
            $player->sendTitle('§l§a튜토리얼 완료! ', '§r§e스타터 아이템을 확인하세요!', 10, 80, 20);
            $player->sendMessage("§a§l[길라잡이] §r§6§l모든 퀘스트를 완료했습니다! 축하합니다! ");
            $this->giveStarterKit($player);
            $this->plugin->cancelReminderTask($player->getName());
        }
    }

    // 보상 지급
        private function giveReward(Player $player, $reward): void {
        if (!is_array($reward)) return;
        
        if ($reward["type"] === "command") {
            $command = str_replace("{player}", $player->getName(), $reward["value"]);
            // 현재 이벤트 처리 중 dispatchCommand를 호출하면 CommandEvent가 즉시 재발생하여
            // 스택이 꼬이므로, 다음 틱에 실행하도록 지연시킴
            $this->plugin->getScheduler()->scheduleDelayedTask(
                new \pocketmine\scheduler\ClosureTask(function() use ($command): void {
                    $server = Server::getInstance();
                    $consoleSender = new \pocketmine\console\ConsoleCommandSender(
                        $server,
                        $server->getLanguage()
                    );
                    $server->dispatchCommand($consoleSender, $command);
                }),
                1
            );
            $player->sendMessage("§a보상이 지급되었습니다!");
        } elseif ($reward["type"] === "item") {
            try {
                $items = $reward["items"] ?? [];
                $givenCount = 0;
                
                foreach ($items as $itemData) {
                    // NBT 데이터 복원
                    $nbt = base64_decode($itemData["nbt"]);
                    $tag = (new \pocketmine\nbt\BigEndianNbtSerializer())->read($nbt)->mustGetCompoundTag();
                    
                    // 아이템 생성
                    $item = \pocketmine\item\Item::nbtDeserialize($tag->getTag("") ?? new \pocketmine\nbt\tag\CompoundTag());
                    $item->setCount($itemData["count"]);
                    
                    // 인벤토리에 추가
                    if ($player->getInventory()->canAddItem($item)) {
                        $player->getInventory()->addItem($item);
                        $givenCount++;
                    } else {
                        $player->sendMessage("§c인벤토리 공간이 부족합니다!");
                        return;
                    }
                }
                
                if ($givenCount > 0) {
                    $player->sendMessage("§a보상 아이템 " . $givenCount . "개가 지급되었습니다!");
                }
            } catch (\Exception $e) {
                $player->sendMessage("§c보상 지급 중 오류가 발생했습니다.");
                $this->plugin->getLogger()->error("보상 지급 오류: " . $e->getMessage());
            }
        }
    }

    // 퀘스트 설정
    public function setQuest(int $stage, string $title, string $description, string $type, $requirement): void {
        $config = $this->plugin->getConfig();
        $quests = $config->get('quests', []);
        $quests[$stage] = [
            'title'       => $title,
            'description' => $description,
            'type'        => $type,
            'requirement' => $requirement,
            'reward'      => ['type' => 'command', 'value' => 'give {player} diamond 1'],
        ];
        $config->set('quests', $quests);
        $config->save();
        $this->plugin->reloadConfig();
    }

    // 보상 설정 (아이템 또는 명령어)
    public function setReward(int $stage, $reward): void {
        $config = $this->plugin->getConfig();
        $quests = $config->get('quests', []);
        if (!isset($quests[$stage])) return;

        $quests[$stage]['reward'] = is_array($reward)
            ? $reward
            : ['type' => 'command', 'value' => $reward];
        $config->set('quests', $quests);
        $config->save();
        $this->plugin->reloadConfig();
    }
}