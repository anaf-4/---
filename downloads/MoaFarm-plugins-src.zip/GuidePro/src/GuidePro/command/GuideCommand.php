<?php
declare(strict_types=1);

namespace GuidePro\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use GuidePro\Main;
use GuidePro\form\TutorialForceForm;

class GuideCommand extends Command {

    public function __construct(private Main $plugin) {
        parent::__construct('길라잡이', '길라잡이 퀘스트를 확인합니다', '/길라잡이');
        $this->setPermission('guidepro.use');
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$sender instanceof Player) {
            $sender->sendMessage('§c게임 내에서만 사용 가능합니다.');
            return false;
        }

        TutorialForceForm::send($sender);
        return true;
    }
}
