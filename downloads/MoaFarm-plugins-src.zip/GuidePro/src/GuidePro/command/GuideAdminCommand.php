<?php

declare(strict_types=1);

namespace GuidePro\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\item\Item;
use pocketmine\nbt\tag\CompoundTag;
use GuidePro\Main;
use GuidePro\form\AdminForm;
use GuidePro\form\RewardForm;
use GuidePro\form\StarterKitForm;

class GuideAdminCommand extends Command {

    private $plugin;

    public function __construct(Main $plugin) {
        parent::__construct("길라잡이관리", "길라잡이 퀘스트를 관리합니다", "/길라잡이관리 [도움말|UI]");
        $this->setPermission("guidepro.admin");
        $this->plugin = $plugin;
        $this->setAliases(["가이드관리", "guideadmin"]);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$sender->hasPermission("guidepro.admin")) {
            $sender->sendMessage("§c권한이 없습니다.");
            return false;
        }

        // 인자가 없으면 도움말 표시
        if (empty($args)) {
            $this->showHelp($sender);
            return true;
        }

        // 스타터킷 설정 GUI
        if ($args[0] === '스타터아이템' || $args[0] === 'starterkit') {
            if (!$sender instanceof Player) {
                $sender->sendMessage('§c게임 내에서만 사용 가능합니다.');
                return false;
            }
            StarterKitForm::open($sender);
            return true;
        }

        // UI/Form 열기
        if ($args[0] === "UI" || $args[0] === "ui" || $args[0] === "폼") {
            if (!$sender instanceof Player) {
                $sender->sendMessage("§c게임 내에서만 사용 가능합니다.");
                return false;
            }
            AdminForm::send($sender);
            return true;
        }

        // 도움말
        if ($args[0] === "도움말" || $args[0] === "help") {
            $this->showHelp($sender);
            return true;
        }

        // 퀘스트 설정
        if ($args[0] === "퀘스트" && isset($args[1]) && $args[1] === "설정") {
            return $this->setQuest($sender, $args);
        }

        // 보상 설정 (GUI 인벤토리)
        if ($args[0] === "보상" && isset($args[1]) && $args[1] === "설정") {
            if (!$sender instanceof Player) {
                $sender->sendMessage("§c게임 내에서만 사용 가능합니다.");
                return false;
            }
            
            if (!isset($args[2])) {
                $sender->sendMessage("§c사용법: /길라잡이관리 보상 설정 <단계>");
                return false;
            }

            $stage = (int)$args[2];
            $quest = $this->plugin->getGuideManager()->getQuestInfo($stage);
            
            if ($quest === null) {
                $sender->sendMessage("§c단계 $stage 퀘스트가 존재하지 않습니다.");
                return false;
            }

            // GUI 인벤토리 열기
            RewardForm::openRewardInventory($sender, $stage);
            return true;
        }

        // 보상 삭제
        if ($args[0] === "보상" && isset($args[1]) && $args[1] === "삭제") {
            if (!isset($args[2])) {
                $sender->sendMessage("§c사용법: /길라잡이관리 보상 삭제 <단계>");
                return false;
            }

            $stage = (int)$args[2];
            return $this->deleteReward($sender, $stage);
        }

        // 퀘스트 목록
        if ($args[0] === "목록" || $args[0] === "리스트") {
            $this->showQuestList($sender);
            return true;
        }

        // 퀘스트 삭제
        if ($args[0] === "퀘스트" && isset($args[1]) && $args[1] === "삭제") {
            return $this->deleteQuest($sender, $args);
        }

        // 플레이어 초기화
        if ($args[0] === "초기화" || $args[0] === "리셋") {
            return $this->resetPlayer($sender, $args);
        }

        // 플레이어 정보 확인
        if ($args[0] === "정보" || $args[0] === "info") {
            return $this->showPlayerInfo($sender, $args);
        }

        $sender->sendMessage("§c올바른 명령어가 아닙니다. §e/길라잡이관리 도움말 §c을 입력하세요.");
        return false;
    }

    private function showHelp(CommandSender $sender): void {
        $sender->sendMessage("§a§l=== 길라잡이 관리 명령어 ===");
        $sender->sendMessage("§e/길라잡이관리 UI §8- GUI로 관리");
        $sender->sendMessage("§e/길라잡이관리 스타터아이템 §8- 신규 유저 스타터킷 아이템 설정 (9×6 GUI)");
        $sender->sendMessage("");
        $sender->sendMessage("§6[ 퀘스트 설정 ]");
        $sender->sendMessage("§e채팅: §f/길라잡이관리 퀘스트 설정 <단계> chat <텍스트> <제목> <설명>");
        $sender->sendMessage("§e점프: §f/길라잡이관리 퀘스트 설정 <단계> jump <횟수> <제목> <설명>");
        $sender->sendMessage("§e명령어: §f/길라잡이관리 퀘스트 설정 <단계> command <명령어> <제목> <설명>");
        $sender->sendMessage("§e구매: §f/길라잡이관리 퀘스트 설정 <단계> buy <아이템명> <제목> <설명>");
        $sender->sendMessage("§e판매: §f/길라잡이관리 퀘스트 설정 <단계> sell <아이템명> <개수> <제목> <설명>");
        $sender->sendMessage("");
        $sender->sendMessage("§6[ 보상 설정 ]");
        $sender->sendMessage("§e/길라잡이관리 보상 설정 <단계> §8- GUI에 아이템을 넣어서 보상 설정");
        $sender->sendMessage("§e/길라잡이관리 보상 삭제 <단계> §8- 보상 삭제");
        $sender->sendMessage("");
        $sender->sendMessage("§6[ 기타 ]");
        $sender->sendMessage("§e/길라잡이관리 목록 §8- 전체 퀘스트 목록");
        $sender->sendMessage("§e/길라잡이관리 퀘스트 삭제 <단계> §8- 퀘스트 삭제");
        $sender->sendMessage("§e/길라잡이관리 초기화 <플레이어> §8- 플레이어 진행도 초기화");
        $sender->sendMessage("§e/길라잡이관리 정보 <플레이어> §8- 플레이어 정보 확인");
    }

    private function setQuest(CommandSender $sender, array $args): bool {
        // 기본 사용법
        if (count($args) < 5) {
            $sender->sendMessage("§c=== 퀘스트 설정 사용법 ===");
            $sender->sendMessage("§e채팅: §f/길라잡이관리 퀘스트 설정 <단계> chat <텍스트> <제목> <설명>");
            $sender->sendMessage("§e점프: §f/길라잡이관리 퀘스트 설정 <단계> jump <횟수> <제목> <설명>");
            $sender->sendMessage("§e명령어: §f/길라잡이관리 퀘스트 설정 <단계> command <명령어> <제목> <설명>");
            $sender->sendMessage("§e구매: §f/길라잡이관리 퀘스트 설정 <단계> buy <아이템명> <제목> <설명>");
            $sender->sendMessage("§e판매: §f/길라잡이관리 퀘스트 설정 <단계> sell <아이템명> <개수> <제목> <설명>");
            return false;
        }

        $stage = (int)$args[2];
        $questType = strtolower($args[3]);
        
        // 타입별 처리
        switch ($questType) {
            case "chat":
                if (count($args) < 7) {
                    $sender->sendMessage("§c사용법: /길라잡이관리 퀘스트 설정 <단계> chat <텍스트> <제목> <설명>");
                    return false;
                }
                $requirement = $args[4];
                $title = $args[5];
                $description = implode(" ", array_slice($args, 6));
                break;
                
            case "jump":
                if (count($args) < 7) {
                    $sender->sendMessage("§c사용법: /길라잡이관리 퀘스트 설정 <단계> jump <횟수> <제목> <설명>");
                    return false;
                }
                if (!is_numeric($args[4])) {
                    $sender->sendMessage("§cjump 타입은 숫자를 입력해야 합니다.");
                    return false;
                }
                $requirement = (int)$args[4];
                $title = $args[5];
                $description = implode(" ", array_slice($args, 6));
                break;
                
            case "command":
                if (count($args) < 7) {
                    $sender->sendMessage("§c사용법: /길라잡이관리 퀘스트 설정 <단계> command <명령어> <제목> <설명>");
                    return false;
                }
                $requirement = $args[4];
                $title = $args[5];
                $description = implode(" ", array_slice($args, 6));
                break;
                
            case "buy":
                if (count($args) < 7) {
                    $sender->sendMessage("§c사용법: /길라잡이관리 퀘스트 설정 <단계> buy <아이템명> <제목> <설명>");
                    return false;
                }
                $requirement = $args[4];
                $title = $args[5];
                $description = implode(" ", array_slice($args, 6));
                break;
                
            case "sell":
                if (count($args) < 8) {
                    $sender->sendMessage("§c사용법: /길라잡이관리 퀘스트 설정 <단계> sell <아이템명> <개수> <제목> <설명>");
                    return false;
                }
                if (!is_numeric($args[5])) {
                    $sender->sendMessage("§csell 타입의 개수는 숫자를 입력해야 합니다.");
                    return false;
                }
                $requirement = [
                    "item" => $args[4],
                    "amount" => (int)$args[5]
                ];
                $title = $args[6];
                $description = implode(" ", array_slice($args, 7));
                break;
                
            case "break":
                if (count($args) < 8) {
                    $sender->sendMessage("§c사용법: /길라잡이관리 퀘스트 설정 <단계> break <블록명> <개수> <제목> <설명>");
                    return false;
                }
                if (!is_numeric($args[5])) {
                    $sender->sendMessage("§cbreak 타입의 개수는 숫자를 입력해야 합니다.");
                    return false;
                }
                $requirement = [
                    "block" => $args[4],
                    "amount" => (int)$args[5]
                ];
                $title = $args[6];
                $description = implode(" ", array_slice($args, 7));
                break;
                
            default:
                $sender->sendMessage("§c올바른 타입이 아닙니다. (chat, jump, command, buy, sell, break)");
                return false;
        }

        $this->plugin->getGuideManager()->setQuest($stage, $title, $description, $questType, $requirement);
        $sender->sendMessage("§a퀘스트가 설정되었습니다!");
        $sender->sendMessage("§e단계: §f$stage");
        $sender->sendMessage("§e제목: §f$title");
        $sender->sendMessage("§e타입: §f$questType");
        return true;
    }

    // 보상 삭제
    private function deleteReward(CommandSender $sender, int $stage): bool {
        $quest = $this->plugin->getGuideManager()->getQuestInfo($stage);
        if ($quest === null) {
            $sender->sendMessage("§c단계 $stage 퀘스트가 존재하지 않습니다.");
            return false;
        }

        $config = $this->plugin->getConfig();
        $quests = $config->get("quests", []);
        
        if (isset($quests[$stage])) {
            unset($quests[$stage]["reward"]);
            $config->set("quests", $quests);
            $config->save();
            $this->plugin->reloadConfig();
            
            $sender->sendMessage("§a단계 $stage의 보상이 삭제되었습니다.");
            return true;
        }

        return false;
    }

    private function showQuestList(CommandSender $sender): void {
        $config = $this->plugin->getConfig();
        $quests = $config->get("quests", []);

        $sender->sendMessage("§a§l=== 등록된 퀘스트 목록 ===");
        
        if (empty($quests)) {
            $sender->sendMessage("§8등록된 퀘스트가 없습니다.");
            return;
        }

        ksort($quests);
        
        foreach ($quests as $stage => $quest) {
            $sender->sendMessage("§e─────────────────────────");
            $sender->sendMessage("§a단계 $stage: §f" . $quest["title"]);
            $sender->sendMessage("§8설명: §f" . $quest["description"]);
            $sender->sendMessage("§8타입: §e" . $quest["type"]);
            
            if (is_array($quest["requirement"])) {
                if (isset($quest["requirement"]["item"])) {
                    $sender->sendMessage("§8요구사항: §e" . $quest["requirement"]["item"] . " x" . $quest["requirement"]["amount"]);
                } elseif (isset($quest["requirement"]["block"])) {
                    $sender->sendMessage("§8요구사항: §e" . $quest["requirement"]["block"] . " x" . $quest["requirement"]["amount"]);
                }
            } else {
                $sender->sendMessage("§8요구사항: §e" . $quest["requirement"]);
            }
            
            if (isset($quest["reward"])) {
                if (is_array($quest["reward"])) {
                    if ($quest["reward"]["type"] === "item") {
                        $itemCount = count($quest["reward"]["items"] ?? []);
                        $sender->sendMessage("§8보상: §e아이템 " . $itemCount . "개");
                    } elseif (isset($quest["reward"]["value"])) {
                        $sender->sendMessage("§8보상: §e" . $quest["reward"]["value"]);
                    }
                }
            }
        }
        $sender->sendMessage("§e─────────────────────────");
        $sender->sendMessage("§a총 §f" . count($quests) . "§a개의 퀘스트");
    }

    private function deleteQuest(CommandSender $sender, array $args): bool {
        if (count($args) < 3) {
            $sender->sendMessage("§c사용법: /길라잡이관리 퀘스트 삭제 <단계>");
            return false;
        }

        $stage = (int)$args[2];
        $config = $this->plugin->getConfig();
        $quests = $config->get("quests", []);

        if (!isset($quests[$stage])) {
            $sender->sendMessage("§c단계 $stage 퀘스트가 존재하지 않습니다.");
            return false;
        }

        unset($quests[$stage]);
        $config->set("quests", $quests);
        $config->save();
        $this->plugin->reloadConfig();

        $sender->sendMessage("§a단계 $stage 퀘스트가 삭제되었습니다.");
        return true;
    }

    private function resetPlayer(CommandSender $sender, array $args): bool {
        if (count($args) < 2) {
            $sender->sendMessage("§c사용법: /길라잡이관리 초기화 <플레이어>");
            return false;
        }

        $targetName = $args[1];
        $playerData = $this->plugin->getPlayerData();

        if (!$playerData->exists($targetName)) {
            $sender->sendMessage("§c해당 플레이어의 데이터를 찾을 수 없습니다.");
            return false;
        }

        $playerData->set($targetName, [
            "current_stage" => 1,
            "completed_stages" => [],
            "progress" => [],
            "quest_data" => []
        ]);
        $this->plugin->savePlayerData();

        $sender->sendMessage("§a$targetName 플레이어의 진행도가 초기화되었습니다!");
        return true;
    }

    private function showPlayerInfo(CommandSender $sender, array $args): bool {
        if (count($args) < 2) {
            $sender->sendMessage("§c사용법: /길라잡이관리 정보 <플레이어>");
            return false;
        }

        $targetName = $args[1];
        $playerData = $this->plugin->getPlayerData();

        if (!$playerData->exists($targetName)) {
            $sender->sendMessage("§c해당 플레이어의 데이터를 찾을 수 없습니다.");
            return false;
        }

        $data = $playerData->get($targetName);
        $currentStage = $data["current_stage"] ?? 1;
        $completed = $data["completed_stages"] ?? [];
        $progress = $data["progress"] ?? [];

        $sender->sendMessage("§a§l=== $targetName 정보 ===");
        $sender->sendMessage("§e현재 단계: §f$currentStage");
        $sender->sendMessage("§e완료한 퀘스트: §f" . count($completed) . "개");
        
        if (!empty($completed)) {
            $sender->sendMessage("§e완료 목록: §f" . implode(", ", $completed));
        }

        $quest = $this->plugin->getGuideManager()->getQuestInfo($currentStage);
        if ($quest !== null) {
            $sender->sendMessage("§e현재 퀘스트: §f" . $quest["title"]);
            
            if (isset($progress[$currentStage])) {
                $currentProgress = $progress[$currentStage];
                
                if (is_array($currentProgress)) {
                    foreach ($currentProgress as $key => $value) {
                        $sender->sendMessage("§e진행도 ($key): §f$value");
                    }
                } else {
                    if ($quest["type"] === "jump") {
                        $sender->sendMessage("§e진행도: §f$currentProgress/" . $quest["requirement"]);
                    } elseif ($quest["type"] === "sell" && is_array($quest["requirement"])) {
                        $sender->sendMessage("§e진행도: §f$currentProgress/" . $quest["requirement"]["amount"]);
                    }
                }
            }
        }

        return true;
    }
}