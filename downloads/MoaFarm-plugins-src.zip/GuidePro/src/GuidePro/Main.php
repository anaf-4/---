<?php
declare(strict_types=1);

namespace GuidePro;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\server\CommandEvent;
use pocketmine\event\player\PlayerJumpEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\inventory\InventoryCloseEvent;
use anaf2197\fishing\event\FishingEvent;
use pocketmine\utils\Config;
use GuidePro\command\GuideCommand;
use GuidePro\command\GuideAdminCommand;
use GuidePro\form\RewardForm;

class Main extends PluginBase implements Listener {

    private static self $instance;
    private GuideManager $guideManager;
    private Config $config;
    private Config $playerData;

    public function onEnable(): void {
        self::$instance = $this;

        $this->saveDefaultConfig();
        $this->config = $this->getConfig();

        @mkdir($this->getDataFolder());
        $this->playerData = new Config($this->getDataFolder() . 'players.yml', Config::YAML);

        $this->guideManager = new GuideManager($this);

        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getServer()->getCommandMap()->register('guide', new GuideCommand($this));
        $this->getServer()->getCommandMap()->register('guideadmin', new GuideAdminCommand($this));

        $this->getLogger()->info('§a길라잡이 플러그인이 활성화되었습니다!');
    }

    public function onDisable(): void {
        $this->savePlayerData();
        $this->getLogger()->info('§c길라잡이 플러그인이 비활성화되었습니다!');
    }

    public static function getInstance(): self {
        return self::$instance;
    }

    public function getGuideManager(): GuideManager {
        return $this->guideManager;
    }

    public function getPlayerData(): Config {
        return $this->playerData;
    }

    public function savePlayerData(): void {
        $this->playerData->save();
    }

    // GuideManager에서 호출 — 완료 시 리마인더 정리 (현재는 no-op)
    public function cancelReminderTask(string $playerName): void {}

    // ─── 이벤트 핸들러 ───────────────────────────────────────────────────

    public function onJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        $name   = $player->getName();

        $isNew = !$this->playerData->exists($name);

        if ($isNew) {
            $this->playerData->set($name, [
                'current_stage'    => 1,
                'completed_stages' => [],
                'progress'         => [],
                'quest_data'       => []
            ]);
            $this->savePlayerData();

            // 신규 유저 환영 메시지 (폼 강제 오픈 없음)
            $player->sendMessage('§a§l[길라잡이] §r§f모아팜에 오신 것을 환영합니다!');
            $player->sendMessage('§8§o/길라잡이 명령어로 튜토리얼을 진행하고 스타터 아이템을 받아보세요!');
        }
    }

    public function onQuit(PlayerQuitEvent $event): void {}

    /**
     * @handleCancelled true
     */
    public function onChat(PlayerChatEvent $event): void {
        $this->guideManager->checkChatQuest($event->getPlayer(), $event->getMessage());
    }

    public function onCommandEvent(CommandEvent $event): void {
        $sender = $event->getSender();
        if (!$sender instanceof \pocketmine\player\Player) return;
        $this->guideManager->checkCommandQuest($sender, $event->getCommand());
    }

    public function onJump(PlayerJumpEvent $event): void {
        $this->guideManager->checkJumpQuest($event->getPlayer());
    }

    /**
     * @handleCancelled true
     */
    public function onBlockBreak(BlockBreakEvent $event): void {
        $this->guideManager->checkBlockBreakQuest($event->getPlayer(), $event->getBlock());
    }

    public function onFishCatch(FishingEvent $event): void {
        $player = $event->getPlayer();
        $item   = $event->getItem();
        $this->guideManager->checkSellQuest($player, $item->getName(), $item->getCount());
    }

    public function onInventoryClose(InventoryCloseEvent $event): void {
        $player = $event->getPlayer();
        if (RewardForm::isRewardInventory($player->getName())) {
            RewardForm::handleInventoryClose($player);
        }
    }

    // ─── 외부 연동 메서드 ────────────────────────────────────────────────

    public function checkCommandQuest(string $playerName, string $command): void {
        $player = $this->getServer()->getPlayerExact($playerName);
        if ($player !== null) {
            $this->guideManager->checkCommandQuest($player, $command);
        }
    }

    public function checkSellQuest(string $playerName, string $itemName, int $amount): void {
        $player = $this->getServer()->getPlayerExact($playerName);
        if ($player !== null) {
            $this->guideManager->checkSellQuest($player, $itemName, $amount);
        }
    }

    public function checkBuyQuest(string $playerName, string $itemName): void {
        $player = $this->getServer()->getPlayerExact($playerName);
        if ($player !== null) {
            $this->guideManager->checkBuyQuest($player, $itemName);
        }
    }
}
