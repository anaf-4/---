<?php

namespace anaf2197\chattingroom;

use pocketmine\player\Player;

final class RoomProperties implements \JsonSerializable {

    public function __construct(private bool $visible, private ?int $max, private bool $application, private array $applicants) { }

    public function isVisible(): bool {
        return $this->visible;
    }

    public function setVisible(bool $visible): void {
        $this->visible = $visible;
    }

    public function isApplication(): bool {
        return $this->application;
    }

    public function setApplication(bool $application): void {
        $this->application = $application;
    }

    public function existedApplicant(Player $applicant): bool {
        return in_array($applicant->getName(), $this->applicants);
    }

    public function getApplicants(): array {
        return $this->applicants;
    }

    public function addApplicant(Player $applicant): void {
        $this->applicants [] = $applicant->getName();
    }

    public function removeApplicant(string $applicant): void {
        unset($this->applicants [array_search($applicant, $this->applicants)]);
    }

    public function setMaxPlayers(?int $max): void {
        $this->max = $max;
    }

    public function getMaxPlayers(): ?int {
        return $this->max;
    }

    public function jsonSerialize(): array {
        return [$this->visible, $this->max, $this->application, $this->applicants];
    }

    public static function jsonDeserialize(array $data): self {
        return new self (... $data);
    }
}