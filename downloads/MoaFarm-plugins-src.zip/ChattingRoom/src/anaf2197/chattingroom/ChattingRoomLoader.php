<?php

declare(strict_types=1);

namespace anaf2197\chattingroom;

use anaf2197\IslandChat\IslandChat;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\InvMenuHandler;
use muqsit\invmenu\transaction\InvMenuTransaction;
use muqsit\invmenu\transaction\InvMenuTransactionResult;
use muqsit\invmenu\type\InvMenuTypeIds;
use pocketmine\block\VanillaBlocks;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\item\Item;
use pocketmine\item\VanillaItems;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\Server;
use pocketmine\utils\SingletonTrait;
use anaf2197\advancedprefix\AdvancedPrefix;
use anaf2197\advancedprefix\PrefixChatFormatter;
use anaf2197\chattingroom\command\ChattingRoomCommand;
use anaf2197\chattingroom\form\CreateRoomForm;
use anaf2197\chattingroom\form\RoomFunctionsForm;
use anaf2197\economyapi\EconomyAPI;
use anaf2197\guild\Guild;
use anaf2197\guild\GuildLoader;
use anaf2197\lib\provider\DataProvider;
use anaf2197\lib\provider\ProviderHandler;
use anaf2197\lib\color\ServerColor;
use anaf2197\socialnetwork\SocialNetworkLoader;

final class ChattingRoomLoader extends PluginBase implements Listener {

    public const DEFAULT_CHANNEL = 'ALL';

    public static string $prefix;

    private DataProvider $provider;

    use SingletonTrait;

    protected function onEnable(): void {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getServer()->getCommandMap()->register(strtolower($this->getName()), new ChattingRoomCommand());
        if (!$this->getDefaultRoom() instanceof ChattingRoom) {
            $this->createRoom(self::DEFAULT_CHANNEL, '');
        }
        if (!InvMenuHandler::isRegistered()) {
            InvMenuHandler::register($this);
        }
    }

    protected function onDisable(): void {
        $this->saveDatabase();
    }

    public function saveDatabase(): void {
        $this->provider->save();
    }

    protected function onLoad(): void {
        self::setInstance($this);
        ServerColor::setPrefix($this, '채팅방');
        if (!ProviderHandler::isRegistered($this)) {
            ProviderHandler::register($this, ChattingRoom::class);
            $this->provider = ProviderHandler::get($this);
        }
    }

    public function getAll(bool $clear = true): array {
        if ($clear) $this->deleteClosedRooms();
        return $this->provider->getAll();
    }

    public function getDefaultRoom(): ?ChattingRoom {
        return $this->getRoom(self::DEFAULT_CHANNEL);
    }

    public function getRoom(string $id): ?ChattingRoom {
        return $this->provider->getObject($id);
    }

    public function createRoom(string $id, string $owner, array $players = [], ?int $timeLimint = null, ?RoomProperties $properties = null): void {
        $this->provider->setObject($id, new ChattingRoom($id, false, $owner, $players, $timeLimint, $properties ?? new RoomProperties(true, null, false, [])));
    }

    public function deleteClosedRooms(): void {
        /** @var ChattingRoom $chattingroom */
        foreach ($this->getAll(false) as $chattingroom) {
            if ($chattingroom->isClosed()) {
                $this->provider->deleteObject($chattingroom->getId());
            }
        }
    }

    public function joinRoom(string $id, Player $player, bool $quitOthers = true): void {
        $chattingroom = $this->getRoom($id);
        if (!$chattingroom->can($player)) {
            if ($quitOthers) {
                foreach ($this->getRoomsByPlayer($player) as $other) {
                    $other->quit($player);
                }
                $chattingroom->join($player);
            }
        }
    }

    /*public function quitRoom(string $id, Player $player): void {
        if (($chattingroom = $this->provider->getObject($id)) instanceof ChattingRoom) {
            if ($chattingroom->can($player)) {
                $chattingroom->quit($player);
            }
        }
    }*/

    public function getVisibleRooms(bool $inclueDefault = true, bool $clear = true): array {
        return array_filter(array_values($this->getAll($clear)), function (ChattingRoom $chattingroom) use ($inclueDefault): bool {
            return $chattingroom->getProperties()->isVisible() and ($inclueDefault or $chattingroom->getId() !== ChattingRoomLoader::DEFAULT_CHANNEL);
        });
    }

    public function getRoomsByPlayer(Player $player, bool $clear = true): array {
        return array_filter(array_values($this->getAll($clear)), function (ChattingRoom $chattingroom) use ($player): bool {
            return $chattingroom->can($player);
        });
    }

    public function getRoomsByOwner(Player $player, bool $clear = true): array {
        return array_filter(array_values($this->getAll($clear)), function (ChattingRoom $chattingroom) use ($player): bool {
            return $chattingroom->isOwner($player);
        });
    }

    public function loudspeaker(string $str, ?Player $player = null): void {
        if (!is_null($player)) {
            Server::getInstance()->broadcastMessage(ServerColor::toCode(true) . '▐§r§f ' . AdvancedPrefix::getInstance()->getPlayerPrefix($player)?->getNowNickname() . ': ' . $str);
        } else {
            Server::getInstance()->broadcastMessage(ServerColor::toCode(true) . '▐§r§f ' . $str);
        }
    }

    public function sendChattingRoom(Player $player): void {
        $invMenu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
        $invMenu->setName('채팅방 목록');
        $rooms = ChattingRoomLoader::getInstance()->getVisibleRooms(false);
        $contents = array_map(function (ChattingRoom $chattingroom) use ($player): Item {
            $icon = VanillaBlocks::ENDER_CHEST()->asItem()->setCustomName('§r§l§f' . $chattingroom->getId());
            $properties = $chattingroom->getProperties();
            $maxPlayers = $properties->getMaxPlayers();
            $lore = [' ', '§r§8' . count($chattingroom->getPlayers()) . (is_null($maxPlayers) ? '' : ' / ' . $maxPlayers . ' ') . '명이 접속중입니다.'];
            if (!$chattingroom->isOwner($player)) $lore [] = '§r§8주인: ' . $chattingroom->getOwner() . PHP_EOL; else $lore [] = PHP_EOL . '§r§b터치하여 관리';
            if ($properties->isApplication()) $lore [] = '§r§b이 채널은 신청제를 사용합니다.';
            if ($chattingroom->can($player)) $lore [] = '§r§4이미 접속 중인 채팅방입니다.';
            $icon->setLore($lore);
            return $icon;
        }, array_values($rooms));
        $icon = VanillaBlocks::LANTERN()->asItem()->setCustomName('§r§l§f전체 채팅 채널 입장');
        $defaultroom = ChattingRoomLoader::getInstance()->getDefaultRoom();
        if ($defaultroom->can($player)) $icon->setLore([' ', '§r§4이미 접속 중인 채팅방입니다.']);
        $contents [53] = $icon;
        $contents [45] = VanillaItems::NETHER_STAR()->setCustomName('§r§l§f새 채널 만들기')->setLore([' ', '§r§8터치하여 새 채널 만들기']);
        $invMenu->getInventory()->setContents($contents);
        $invMenu->setListener(function (InvMenuTransaction $transaction): InvMenuTransactionResult {
            $slot = $transaction->getAction()->getSlot();
            $player = $transaction->getPlayer();
            $player->removeCurrentWindow();
            switch ($slot) {
                case 45:
                    $rooms = ChattingRoomLoader::getInstance()->getAll();
                    if (count($rooms) < 37) {
                        $ownedRooms = ChattingRoomLoader::getInstance()->getRoomsByOwner($player);
                        if (empty($ownedRooms) or $player->hasPermission(DefaultPermissions::ROOT_OPERATOR)) {
                            return $transaction->discard()->then(function(Player $player) : void{
                                $player->sendForm(new CreateRoomForm($player));
                            });
                        } else {
                            var_dump(2);
                            $player->sendMessage(ChattingRoomLoader::$prefix . '현재 소유한 채팅방을 제거하고 다시 시도해주세요.');
                        }
                    } else {
                        $player->sendMessage(ChattingRoomLoader::$prefix . '너무 많은 채팅방이 생성되어있습니다.');
                    }
                    break;

                case 53:
                    $slot = -1;

                default:
                    $slot++;
                    $rooms = ChattingRoomLoader::getInstance()->getVisibleRooms();
                    /** @var ChattingRoom $chattingroom */
                    if (!is_null(($chattingroom = array_values($rooms) [$slot] ?? null))) {
                        if (!$chattingroom->isOwner($player)) {
                            if (!$chattingroom->can($player)) {
                                $ownedRooms = ChattingRoomLoader::getInstance()->getRoomsByOwner($player);
                                $isOp = $player->hasPermission(DefaultPermissions::ROOT_OPERATOR);
                                if (empty($ownedRooms) or $isOp) {
                                    $properties = $chattingroom->getProperties();
                                    if ($properties->getMaxPlayers() ?? PHP_INT_MAX > count($chattingroom->getPlayers())) {
                                        if (!$properties->isApplication() or $isOp) {
                                            ChattingRoomLoader::getInstance()->joinRoom($chattingroom->getId(), $player, !$isOp);
                                            $player->sendMessage(ChattingRoomLoader::$prefix . '해당 채팅방에 입장하셨습니다!');
                                        } else {
                                            if (!$properties->existedApplicant($player)) {
                                                $properties->addApplicant($player);
                                                $player->sendMessage(ChattingRoomLoader::$prefix . '해당 채팅방에 참가 신청을 보냈습니다.');
                                            } else {
                                                $properties->removeApplicant($player->getName());
                                                $player->sendMessage(ChattingRoomLoader::$prefix . '보낸 참가 신청을 철회했습니다.');
                                            }
                                        }
                                    } else {
                                        $player->sendMessage(ChattingRoomLoader::$prefix . '꽉찬 채팅방입니다.');
                                    }
                                } else {
                                    $player->sendMessage(ChattingRoomLoader::$prefix . '현재 소유한 채팅방을 제거하고 다시 시도해주세요.');
                                }
                            } else if ($chattingroom->getId() !== ChattingRoomLoader::DEFAULT_CHANNEL) {
                                $chattingroom->quit($player);
                                ChattingRoomLoader::getInstance()->joinRoom(ChattingRoomLoader::DEFAULT_CHANNEL, $player);
                                $player->sendMessage(ChattingRoomLoader::$prefix . '채팅방에서 나와 전체채널로 이동했습니다.');
                            } else {
                                $player->sendMessage(ChattingRoomLoader::$prefix . '이미 접속 중인 채팅방입니다.');
                            }
                        } else if ($chattingroom->getId() !== ChattingRoomLoader::DEFAULT_CHANNEL) {
                            return $transaction->discard()->then(function(Player $player) use($chattingroom) : void{
                                $player->sendForm(new RoomFunctionsForm($chattingroom));
                            });
                        }
                    } else {
                        $player->sendMessage(ChattingRoomLoader::$prefix . '존재하지 않는 채팅방입니다.');
                    }
            }
            return $transaction->discard();
        });
        $invMenu->send($player);
    }

    public function onPlayerChat(PlayerChatEvent $event): void {
        $message = $event->getMessage();
        $player = $event->getPlayer();
        $event->cancel();
        if (mb_substr($message, 0, 2, 'UTF-8') !== '@@') {
            $profile = SocialNetworkLoader::getInstance()->getProfile($player);
            $guild = GuildLoader::getInstance()->myGuild($player);
            if(isset(IslandChat::$islandChat[$player->getName()])) {
                IslandChat::broadcast($message, $player);
                return;
            }
            if ($guild instanceof Guild) {
                if ($guild->isChattingPlayer($player)) {
                    $guild->broadcast($message, $player);
                    return;
                }
            }
            $format = (new PrefixChatFormatter())->format($player->getName(), $message);
            if (($chattingWith = $profile->getChattingWith()) !== null) {
                $format = '§8(개인)§r ' . AdvancedPrefix::getInstance()->getPlayerPrefix($player)?->getNowNickname() . '-> ' . AdvancedPrefix::getInstance()->getPlayerPrefix($chattingWith)?->getNowNickname() . ' : ' . $message;
                Server::getInstance()->broadcastMessage($format, array_filter(Server::getInstance()->getOnlinePlayers(), function (Player $target) use ($player, $chattingWith): bool {
                    return in_array(strtolower($target->getName()), [strtolower($player->getName()), strtolower($chattingWith)]) or $target->hasPermission(DefaultPermissions::ROOT_OPERATOR);
                }));
                $logger = true;
            } else {
                $rooms = $this->getRoomsByPlayer($player);
                $isOp = $player->hasPermission(DefaultPermissions::ROOT_OPERATOR);
                $recipients = $isOp ? null : [];
                $logger = is_array($recipients);
                if (is_array($recipients)) {
                    foreach (Server::getInstance()->getOps()->getAll(true) as $op) {
                        $recipients [] = strtolower($op);
                    }
                    /** @var ChattingRoom $chattingroom */
                    foreach ($rooms as $chattingroom) {
                        foreach ($chattingroom->getPlayers() as $recipient) {
                            if (!in_array($recipient, $recipients)) $recipients [] = strtolower($recipient);
                        }
                    }
                }
                Server::getInstance()->broadcastMessage($format, is_array($recipients) ? array_filter(Server::getInstance()->getOnlinePlayers(), function (Player $target) use ($recipients): bool {
                    return in_array(strtolower($target->getName()), $recipients);
                }) : null);
            }
            if ($logger) {
                Server::getInstance()->getLogger()->info($format);
            }
        } else {
            if (EconomyAPI::getInstance()->getMoney($player) >= 10000) {
                EconomyAPI::getInstance()->reduceMoney($player, 10000, '확성기 사용');
                $this->loudspeaker($message, $player);
            } else {
                $player->sendMessage(ChattingRoomLoader::$prefix . '돈이 부족하여 확성기를 사용할 수 없습니다.');
            }
        }
    }

    public function onPlayerJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        if (empty($this->getRoomsByPlayer($player))) {
            $this->getDefaultRoom()->join($player, false);
        }
    }
}