<?php

namespace anaf2197\chattingroom\form;

use pocketmine\form\Form;
use pocketmine\player\Player;
use anaf2197\chattingroom\ChattingRoom;
use anaf2197\chattingroom\ChattingRoomLoader;

final class CloseRoomForm implements Form {

    public function __construct(private ChattingRoom $chattingroom) { }

    public function jsonSerialize(): array {
        return [
            'type' => 'modal',
            'title' => '§l§0 ' . $this->chattingroom->getId(),
            'content' => PHP_EOL . '채팅방을 삭제하시면 되돌릴 수 없습니다, 정말 삭제하시겠습니까?' . PHP_EOL . ' ',
            'button1' => '§l네,§r 삭제하겠습니다.',
            'button2' => '§l아니요,§r 취소하겠습니다.'
        ];
    }

    public function handleResponse(Player $player, $data): void {
        if ($data) {
            $this->chattingroom->setClosed(true);
            $player->sendMessage(ChattingRoomLoader::$prefix . '§a' . $this->chattingroom->getId() . '§8 채팅방을 삭제했습니다.');
        } else {
            $player->sendMessage(ChattingRoomLoader::$prefix . '채팅방 삭제를 취소하셨습니다.');
        }
    }
}