<?php

namespace anaf2197\chattingroom\form;

use pocketmine\form\Form;
use pocketmine\player\Player;
use anaf2197\chattingroom\ChattingRoom;

final class RoomFunctionsForm implements Form {

    private array $buttons = [];

    public function __construct(private ChattingRoom $chattingroom) {
        $this->buttons [] = ['채팅방 설정', '채팅방 설정을 확인합니다.', function (Player $player): void {
            $player->sendForm(new RoomSettingsForm($this->chattingroom));
        }];
        $this->buttons [] = ['채팅방 제거', '채팅방을 제거합니다.', function (Player $player): void {
            $player->sendForm(new CloseRoomForm($this->chattingroom));
        }];
        if ($chattingroom->getProperties()->isApplication()) {
            $this->buttons [] = ['참가 신청 관리', '참가 신청을 관리합니다.', function (Player $player): void {
                $player->sendForm(new AcceptRequestForm($this->chattingroom));
            }];
        }
    }

    public function jsonSerialize(): array {
        return [
            'type' => 'form',
            'title' => '§l§0 ' . $this->chattingroom->getId(),
            'content' => ' ',
            'buttons' => array_map(function (array $data): array {
                return ['text' => '§l§0' . $data [0] . PHP_EOL . '§r§8- ' . $data [1] . ' -'];
            }, $this->buttons)
        ];
    }

    public function handleResponse(Player $player, $data): void {
        if (is_numeric($data)) {
            ($this->buttons [$data] [2])($player);
        }
    }
}