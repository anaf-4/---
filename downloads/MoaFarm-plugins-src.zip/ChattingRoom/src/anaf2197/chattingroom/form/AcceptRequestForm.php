<?php

namespace anaf2197\chattingroom\form;

use pocketmine\form\Form;
use pocketmine\player\Player;
use pocketmine\Server;
use anaf2197\chattingroom\ChattingRoom;
use anaf2197\chattingroom\ChattingRoomLoader;

final class AcceptRequestForm implements Form {

    public function __construct(private ChattingRoom $chattingroom) { }

    public function jsonSerialize(): array {
        return [
            'type' => 'custom_form',
            'title' => '§l§0 ' . $this->chattingroom->getId(),
            'content' => [
                [
                    'type' => 'dropdown',
                    'text' => PHP_EOL . '신청자를 선택해주십시오.' . PHP_EOL . ' ',
                    'options' => $this->chattingroom->getProperties()->getApplicants(),
                    'default' => 0
                ],
                [
                    'type' => 'label',
                    'text' => ' '
                ],
                [
                    'type' => 'toggle',
                    'text' => '§l-§r 거절 / 승락',
                    'default' => true
                ]
            ]
        ];
    }

    public function handleResponse(Player $player, $data): void {
        if (is_array($data)) {
            $chattingroom = $this->chattingroom;
            $properties = $chattingroom->getProperties();
            $applicant = array_values($properties->getApplicants()) [array_shift($data)] ?? null;
            if (is_string($applicant)) {
                if ($data [1]) {
                    if (count($chattingroom->getPlayers()) < $properties->getMaxPlayers() ?? PHP_INT_MAX) {
                        if (($aplObject = Server::getInstance()->getPlayerExact($applicant)) instanceof Player) {
                            $chattingroom->join($aplObject);
                            $player->sendMessage(ChattingRoomLoader::$prefix . '§a' . $applicant . '§8 님의 참가 신청을 승락했습니다.');
                        }
                    } else {
                        $player->sendMessage(ChattingRoomLoader::$prefix . '채팅방의 인원이 가득 찼습니다.');
                    }
                } else {
                    $properties->removeApplicant($applicant);
                    $player->sendMessage(ChattingRoomLoader::$prefix . '해당 참가 신청을 거절했습니다.');
                }
            } else {
                $player->sendMessage(ChattingRoomLoader::$prefix . '존재하지 않는 데이터입니다.');
            }
        }
    }
}