<?php

namespace anaf2197\chattingroom\form;

use pocketmine\form\Form;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\chattingroom\ChattingRoom;
use anaf2197\chattingroom\ChattingRoomLoader;
use anaf2197\chattingroom\RoomProperties;
use anaf2197\economyapi\EconomyAPI;

final class CreateRoomForm implements Form {

    public function __construct(private Player $player) { }

    public function jsonSerialize(): array {
        return [
            'type' => 'custom_form',
            'title' => '§l§0 채팅방 생성',
            'content' => [
                [
                    'type' => 'input',
                    'text' => PHP_EOL . '채팅방 이름' . PHP_EOL . ' ',
                    'default' => $this->player->getName() . '님의 채팅방'
                ],
                [
                    'type' => 'input',
                    'text' => implode(PHP_EOL, [
                        ' ',
                        '최대 입장 가능 인원 §l(방장 제외)§r',
                        '0 이하 입력시 무한으로 처리됩니다.',
                        ' '
                    ]),
                    'default' => '0'
                ],
                [
                    'type' => 'slider',
                    'text' => PHP_EOL . '채팅방 이용 시간 (1시간 - 3만원)' . PHP_EOL . ' ',
                    'min' => 1, 'max' => 48,
                    'step' => 1,
                    'default' => 12
                ],
                [
                    'type' => 'label',
                    'text' => ' '
                ],
                [
                    'type' => 'toggle',
                    'text' => '§l-§r 채팅방 전체 공개',
                    'default' => true
                ],
                [
                    'type' => 'toggle',
                    'text' => '§l-§r 참가신청 활성화',
                    'default' => false
                ],
                [
                    'type' => 'toggle',
                    'text' => '§l-§r 채팅방 홍보 (5천원)',
                    'default' => false
                ],
                [
                    'type' => 'label',
                    'text' => ' '
                ]
            ]
        ];
    }

    public function handleResponse(Player $player, $data): void {
        if (is_array($data)) {
            if (trim($data [0]) !== '') {
                if (is_numeric($data [1])) {
                    $data [2] = (int)$data [2];
                    $data [1] = (int)$data [1];
                    if (EconomyAPI::getInstance()->getMoney($player) >= ($price = $data [2] * 10000)) {
                        if (ChattingRoomLoader::getInstance()->getRoom($data [0]) instanceof ChattingRoom) {
                            $player->sendMessage(ChattingRoomLoader::$prefix . '이미 존재하는 이름입니다.');
                        } else {
                            EconomyAPI::getInstance()->reduceMoney($player, $price, '채팅방 생성');
                            ChattingRoomLoader::getInstance()->createRoom($data [0], $player->getName(), [], time() + $data [2] * 60 * 60, new RoomProperties($data [4], $data [1] > 0 ? $data [1] : null, $data [5], []));
                            $player->sendMessage(ChattingRoomLoader::$prefix . '성공적으로 채팅방을 생성했습니다!');
                            if (!$player->hasPermission(DefaultPermissions::ROOT_OPERATOR)) {
                                ChattingRoomLoader::getInstance()->getDefaultRoom()->quit($player);
                            }
                            if ($data [6]) {
                                if (EconomyAPI::getInstance()->getMoney($player) >= 5000) {
                                    EconomyAPI::getInstance()->reduceMoney($player, 5000, '채팅방 홍보');
                                    ChattingRoomLoader::getInstance()->loudspeaker('[ ' . $data [0] . '§r ] 채팅방이 생성되었습니다!');
                                } else {
                                    $player->sendMessage(ChattingRoomLoader::$prefix . '돈이 부족하여 채팅방 홍보에 실패했습니다.');
                                }
                            }
                        }
                    } else {
                        $player->sendMessage(ChattingRoomLoader::$prefix . '돈이 부족합니다.');
                    }
                } else {
                    $player->sendMessage(ChattingRoomLoader::$prefix . '인원 제한은 숫자로 입력해주세요.');
                }
            } else {
                $player->sendMessage(ChattingRoomLoader::$prefix . '채팅방 이름을 확인해주세요.');
            }
        }
    }
}