<?php

namespace anaf2197\chattingroom\form;

use pocketmine\form\Form;
use pocketmine\player\Player;
use anaf2197\chattingroom\ChattingRoom;
use anaf2197\chattingroom\ChattingRoomLoader;

final class RoomSettingsForm implements Form {

    public function __construct(private ChattingRoom $chattingroom) { }

    public function jsonSerialize(): array {
        $properties = $this->chattingroom->getProperties();
        return [
            'type' => 'custom_form',
            'title' => '§l§0 ' . $this->chattingroom->getId(),
            'content' => [
                [
                    'type' => 'input',
                    'text' => implode(PHP_EOL, [
                        ' ',
                        '최대 입장 가능 인원 §l(방장 제외)§r',
                        '0 이하 입력시 무한으로 처리됩니다.',
                        ' '
                    ]),
                    'default' => (string)($properties->getMaxPlayers() ?? 0)
                ],
                [
                    'type' => 'label',
                    'text' => ' '
                ],
                [
                    'type' => 'toggle',
                    'text' => '채팅방 전체 공개',
                    'default' => $properties->isVisible()
                ],
                [
                    'type' => 'toggle',
                    'text' => '가입신청 활성화',
                    'default' => $properties->isApplication()
                ],
                [
                    'type' => 'label',
                    'text' => ' '
                ]
            ]
        ];
    }

    public function handleResponse(Player $player, $data): void {
        if (is_array($data)) {
            if (is_numeric($data [0])) {
                $properties = $this->chattingroom->getProperties();
                $data [0] = (int)$data [0];
                $properties->setMaxPlayers($data [0] > 0 ? $data [0] : null);
                $properties->setVisible($data [2]);
                $properties->setApplication($data [3]);
                $player->sendMessage(ChattingRoomLoader::$prefix . '채팅방 설정을 수정했습니다.');
            } else {
                $player->sendMessage(ChattingRoomLoader::$prefix . '인원 제한은 숫자로 입력해주세요.');
            }
        }
    }
}