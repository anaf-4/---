<?php

namespace anaf2197\chattingroom\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\chattingroom\ChattingRoomLoader;

final class ChattingRoomCommand extends Command {

    public function __construct() {
        parent::__construct('채팅방', '§r§8채팅방 메뉴를 엽니다.', null, ['chattingroom']);
        $this->setPermission(DefaultPermissions::ROOT_USER);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($sender instanceof Player) {
            if ($this->testPermission($sender)) {
                ChattingRoomLoader::getInstance()->sendChattingRoom($sender);
            }
        }
    }
}