<?php

namespace anaf2197\chattingroom;

use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use pocketmine\Server;
use anaf2197\chattingroom\event\JoinRoomEvent;
use anaf2197\chattingroom\event\QuitRoomEvent;

final class ChattingRoom implements \JsonSerializable {

    public function __construct(private string $id, protected bool $closed, private string $owner, protected array $players, private ?int $timeLimit, private RoomProperties $roomProperties) {}

    public function getId(): string {
        return $this->id;
    }

    public function isClosed(): bool {
        return $this->closed or (!is_null($this->timeLimit) and time() >= $this->timeLimit);
    }

    public function setClosed(bool $closed): void {
        $this->closed = $closed;
    }

    public function isOwner(Player $player): bool {
        return $this->owner === $player->getName() or $player->hasPermission(DefaultPermissions::ROOT_OPERATOR);
    }

    public function getOwner(): string {
        return $this->owner;
    }

    public function getOnlinePlayers(): array {
        return array_filter(Server::getInstance()->getOnlinePlayers(), function (Player $player): bool {
            return $this->can($player);
        });
    }

    public function getPlayers(): array {
        return $this->owner !== '' ? array_merge([$this->owner], $this->players) : $this->players;
    }

    public function getProperties(): RoomProperties {
        return $this->roomProperties;
    }

    public function join(Player $player, bool $broadcast = true): void {
        $event = new JoinRoomEvent($this, $player);
        $event->call();
        if (!$event->isCancelled()) {
            $name = $player->getName();
            if ($broadcast) Server::getInstance()->broadcastMessage(ChattingRoomLoader::$prefix . $name . '님이 채팅방에 입장하셨습니다!', array_filter(array_map(function (string $playerId):?Player{
                return Server::getInstance()->getPlayerExact($playerId);
            }, $this->getPlayers()), function (?Player $player):bool{
                return $player instanceof Player;
            }));
            $this->players [] = $name;
        }
    }

    public function quit(Player $player, bool $broadcast = true): void {
        $event = new QuitRoomEvent($this, $player);
        $event->call();
        if (!$event->isCancelled()) {
            $name = $player->getName();
            unset($this->players [array_search($name, $this->players)]);
            if ($broadcast) Server::getInstance()->broadcastMessage(ChattingRoomLoader::$prefix . $name . '님이 채팅방에서 나가셨습니다.', array_filter(array_map(function (string $playerId):?Player{
                return Server::getInstance()->getPlayerExact($playerId);
            }, $this->getPlayers()), function (?Player $player):bool{
                return $player instanceof Player;
            }));
        };
    }

    public function can(Player $player): bool {
        return in_array($player->getName(), $this->getPlayers());
    }

    public function jsonSerialize(): array {
        return [$this->id, $this->closed, $this->owner, $this->players, $this->timeLimit, $this->roomProperties->jsonSerialize()];
    }

    public static function jsonDeserialize(array $data): self {
        return new self ($data [0], $data [1], $data [2], $data [3], $data [4], RoomProperties::jsonDeserialize($data [5]));
    }
}