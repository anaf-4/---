<?php

namespace anaf2197\chattingroom\event;

use pocketmine\event\Cancellable;
use pocketmine\event\CancellableTrait;
use pocketmine\event\Event;
use pocketmine\player\Player;
use anaf2197\chattingroom\ChattingRoom;

final class JoinRoomEvent extends Event implements Cancellable {

    use CancellableTrait;

    public function __construct(private ChattingRoom $chattingRoom, private Player $player) { }

    public function getChattingRoom(): ChattingRoom {
        return $this->chattingRoom;
    }

    public function getPlayer(): Player {
        return $this->player;
    }
}