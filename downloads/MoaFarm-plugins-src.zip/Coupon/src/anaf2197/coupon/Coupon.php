<?php

namespace anaf2197\coupon;


use muqsit\invmenu\InvMenu;
use muqsit\invmenu\type\InvMenuTypeIds;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\player\Player;
use anaf2197\deliveryapi\DeliveryAPI;
use anaf2197\lib\itemparser\ItemParser;

final class Coupon implements \JsonSerializable {

    /** @var Item[] */
    protected array $items;

    public function __construct(private string $id, private ?int $deadline, private ?int $recipientLimit, array $itemDatas, protected array $recipients) {
        $this->items = array_map(function (string $itemData): Item {
            return ItemParser::fromString($itemData);
        }, $itemDatas);
    }

    public function isClosed(): bool {
        $leftTime = $this->getLeftTime();
        return (is_numeric($leftTime) and $leftTime <= 0) or (is_numeric($this->recipientLimit) and $this->recipientLimit - count($this->recipients) <= 0);
    }

    public function getDeadline(): ?int {
        return $this->deadline;
    }

    public function getLeftTime(): ?int {
        return is_numeric($this->deadline) ? $this->deadline - time() : null;
    }

    public function getRecipientLimit(): ?int {
        return $this->recipientLimit;
    }

    public function isRecipient(Player $player): bool {
        return in_array(strtolower($player->getName()), $this->recipients);
    }

    public function getRecipients(): array {
        return $this->recipients;
    }

    public function sendEditInv(Player $player): void {
        $invMenu = InvMenu::create(InvMenuTypeIds::TYPE_CHEST);
        $invMenu->setName('쿠폰 보상 아이템 수정');
        $invMenu->getInventory()->setContents($this->items);
        $invMenu->setInventoryCloseListener(function (Player $player, Inventory $inventory): void {
            $this->items = $inventory->getContents();
            $player->sendMessage(CouponLoader::$prefix . '쿠폰 보상 아이템을 수정했습니다.');
        });
        $invMenu->send($player);
    }

    public function give(Player $player): void {
        if (!$this->isRecipient($player)) {
            $this->recipients [] = strtolower($player->getName());
            DeliveryAPI::getInstance()->getMailBox($player)->new('쿠폰 보상 수령 (' . $this->id . ')', $this->items, null, '청야팜');
            $player->sendMessage(CouponLoader::$prefix . '보상을 수령했습니다. 우편함을 확인해주세요!');
        } else {
            $player->sendMessage(CouponLoader::$prefix . '이미 해당 쿠폰을 수령했습니다.');
        }
    }

    public function jsonSerialize(): array {
        return [
            $this->id,
            $this->deadline,
            $this->recipientLimit,
            array_map(function (Item $item): string {
                return ItemParser::toString($item);
            }, $this->items),
            $this->recipients
        ];
    }

    public static function jsonDeserialize(array $data): self {
        return new self (... $data);
    }
}