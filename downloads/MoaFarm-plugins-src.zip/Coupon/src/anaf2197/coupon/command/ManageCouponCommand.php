<?php

namespace anaf2197\coupon\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\coupon\Coupon;
use anaf2197\coupon\CouponLoader;
use anaf2197\lib\timeparser\TimeParser;

final class ManageCouponCommand extends Command {

    public function __construct(private CouponLoader $plugin) {
        parent::__construct('쿠폰관리', '쿠폰 관리 명령어입니다.');
        $this->setPermission(DefaultPermissions::ROOT_OPERATOR);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($sender instanceof Player) {
            if ($this->testPermission($sender)) {
                switch (array_shift($args)) {
                    case '생성':
                        $couponId = array_shift($args);
                        $deadline = array_shift($args);
                        $recipientLimit = array_shift($args);
                        if (trim((string)$couponId) !== '') {
                            if (is_numeric($deadline) and is_numeric($recipientLimit)) {
                                if (!$this->plugin->getCoupon($couponId) instanceof Coupon) {
                                    $this->plugin->newCoupon($couponId, $deadline > 0 ? $deadline : null, $recipientLimit > 0 ? $recipientLimit : null);
                                    $sender->sendMessage(CouponLoader::$prefix . $couponId . ' 쿠폰을 생성했습니다.');
                                } else {
                                    $sender->sendMessage(CouponLoader::$prefix . '이미 생성된 이름입니다.');
                                }
                            } else {
                                $sender->sendMessage(CouponLoader::$prefix . '사용 기한, 사용자 제한은 숫자로 입력해주세요.');
                            }
                        } else {
                            $sender->sendMessage(CouponLoader::$prefix . '/쿠폰 생성 [이름] [사용 기한(H)] [사용자 제한]');
                        }
                        break;

                    case '수정':
                        $couponId = array_shift($args);
                        if (trim((string)$couponId) !== '') {
                            if (($coupon = $this->plugin->getCoupon($couponId)) instanceof Coupon) {
                                $coupon->sendEditInv($sender);
                            } else {
                                $sender->sendMessage(CouponLoader::$prefix . '생성되지 않은 이름입니다.');
                            }
                        } else {
                            $sender->sendMessage(CouponLoader::$prefix . '/쿠폰 수정 [이름]');
                        }
                        break;

                    case '제거':
                        $couponId = array_shift($args);
                        if (trim((string)$couponId) !== '') {
                            if ($this->plugin->getCoupon($couponId) instanceof Coupon) {
                                $this->plugin->removeCoupon($couponId);
                                $sender->sendMessage(CouponLoader::$prefix . $couponId . ' 쿠폰을 제거했습니다.');
                            } else {
                                $sender->sendMessage(CouponLoader::$prefix . '생성되지 않은 이름입니다.');
                            }
                        } else {
                            $sender->sendMessage(CouponLoader::$prefix . '/쿠폰 제거 [이름]');
                        }
                        break;

                    case '정보':
                        $couponId = array_shift($args);
                        if (trim((string)$couponId) !== '') {
                            if (($coupon = $this->plugin->getCoupon($couponId)) instanceof Coupon) {
                                $sender->sendMessage(CouponLoader::$prefix . '쿠폰 이름: ' . $couponId);
                                $sender->sendMessage(CouponLoader::$prefix . '쿠폰 상태: ' . ($coupon->isClosed() ? '비활성화' : '활성화'));
                                $deadline = $coupon->getDeadline();
                                $leftTime = $coupon->getLeftTime();
                                $sender->sendMessage(CouponLoader::$prefix . '사용 기한: ' . (is_numeric($deadline) ? (TimeParser::koreanTimeFormat($deadline) . ' (남은 시간: ' . ($leftTime > 0 ? TimeParser::koreanTimeFormat($leftTime) : '시간 초과') . ')') : '없음'));
                                $recipientLimit = $coupon->getRecipientLimit();
                                $recipients = $coupon->getRecipients();
                                $recipientCount = count($recipients);
                                $sender->sendMessage(CouponLoader::$prefix . '사용자 제한: ' . (is_numeric($recipientLimit) ? $recipientLimit . '명 (남은 사용자: ' . ($recipientCount < $recipientLimit ? ($recipientLimit - $recipientCount) . '명' : '총원 달성') . ')' : '없음'));
                                $sender->sendMessage(CouponLoader::$prefix . '사용자 (' . $recipientCount . '): ' . implode(', ', $recipients));
                            } else {
                                $sender->sendMessage(CouponLoader::$prefix . '생성되지 않은 이름입니다.');
                            }
                        } else {
                            $sender->sendMessage(CouponLoader::$prefix . '/쿠폰 정보 [이름]');
                        }
                        break;

                    case '목록':
                        $sender->sendMessage(CouponLoader::$prefix . '쿠폰 목록: ' . implode(', ', array_keys($this->plugin->getCoupons())));
                        break;

                    default:
                        $sender->sendMessage(CouponLoader::$prefix . '/쿠폰관리 생성 [이름] [사용 기한(H)] [사용자 제한]');
                        $sender->sendMessage(CouponLoader::$prefix . '/쿠폰관리 수정 [이름]');
                        $sender->sendMessage(CouponLoader::$prefix . '/쿠폰관리 제거 [이름]');
                        $sender->sendMessage(CouponLoader::$prefix . '/쿠폰관리 정보 [이름]');
                        $sender->sendMessage(CouponLoader::$prefix . '/쿠폰관리 목록');
                        $sender->sendMessage(CouponLoader::$prefix . '사용 기한, 사용자 제한은 음수 기입시 무제한 처리됩니다.');
                }
            }
        }
    }
}