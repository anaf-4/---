<?php

namespace anaf2197\coupon\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\coupon\Coupon;
use anaf2197\coupon\CouponLoader;

final class CouponCommand extends Command {

    public function __construct() {
        parent::__construct('쿠폰', '쿠폰 사용 명령어입니다.');
        $this->setPermission(DefaultPermissions::ROOT_USER);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($sender instanceof Player) {
            if ($this->testPermission($sender)) {
                $couponId = implode(' ', $args);
                if (trim($couponId) !== '') {
                    if (($coupon = CouponLoader::getInstance()->getCoupon($couponId)) instanceof Coupon) {
                        if (!$coupon->isClosed()) {
                            $coupon->give($sender);
                        } else {
                            $sender->sendMessage(CouponLoader::$prefix . '현재 마감된 쿠폰입니다.');
                        }
                    } else {
                        $sender->sendMessage(CouponLoader::$prefix . '존재하지 않는 쿠폰입니다.');
                    }
                } else {
                    $sender->sendMessage(CouponLoader::$prefix . '/쿠폰 [쿠폰 이름] - 쿠폰을 사용합니다.');
                }
            }
        }
    }
}