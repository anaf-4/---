<?php

namespace anaf2197\coupon;

use muqsit\invmenu\InvMenuHandler;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;
use anaf2197\coupon\command\CouponCommand;
use anaf2197\coupon\command\ManageCouponCommand;
use anaf2197\lib\color\ServerColor;
use anaf2197\lib\provider\DataProvider;
use anaf2197\lib\provider\ProviderHandler;

final class CouponLoader extends PluginBase {

    use SingletonTrait;

    public static string $prefix;

    private DataProvider $provider;

    protected function onEnable(): void {
        if (!InvMenuHandler::isRegistered()) {
            InvMenuHandler::register($this);
        }
        if (!ProviderHandler::isRegistered($this)) {
            ProviderHandler::register($this, Coupon::class);
            $this->provider = ProviderHandler::get($this);
        }
        $this->getServer()->getCommandMap()->registerAll(strtolower($this->getName()), [
            new CouponCommand(),
            new ManageCouponCommand($this)
        ]);
    }

    protected function onLoad(): void {
        self::setInstance($this);
        ServerColor::setPrefix($this, '쿠폰');
    }

    protected function onDisable(): void {
        $this->saveDatabase();
    }

    public function saveDatabase(): void {
        $this->provider->save();
    }

    public function getCoupons(): array {
        return $this->provider->getAll();
    }

    public function newCoupon(string $couponId, ?int $deadline, ?int $recipientLimit): void {
        $this->provider->setObject($couponId, new Coupon($couponId, is_numeric($deadline) ? time() + 60 * 60 * $deadline : $deadline, $recipientLimit, [], []));
    }

    public function removeCoupon(string $couponId): void {
        $this->provider->deleteObject($couponId);
    }

    public function getCoupon(string $couponId): ?Coupon {
        return $this->provider->getObject($couponId);
    }
}