<?php

namespace anaf2197\deliveryapi\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\deliveryapi\DeliveryAPI;

final class DeliverCommand extends Command {

    public function __construct() {
        parent::__construct('소포보내기', '소포를 보냅니다.', null, ['deliver', '우편보내기', '택배보내기', '택배발송', '우편발송', '소포발송']);
        $this->setPermission(DefaultPermissions::ROOT_USER);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($sender instanceof Player) {
            if ($this->testPermission($sender)) {
                DeliveryAPI::getInstance()->sendDeliverBox($sender);
            }
        }
    }
}