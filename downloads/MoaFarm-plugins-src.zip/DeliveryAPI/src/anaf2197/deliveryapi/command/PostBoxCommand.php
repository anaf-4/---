<?php

namespace anaf2197\deliveryapi\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\deliveryapi\DeliveryAPI;

final class PostBoxCommand extends Command {

    public function __construct() {
        parent::__construct('우편함', '내 우편함을 확인합니다.', null, ['mailbox']);
        $this->setPermission(DefaultPermissions::ROOT_USER);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($sender instanceof Player) {
            if ($this->testPermission($sender)) {
                DeliveryAPI::getInstance()->sendPostBox($sender);
            }
        }
    }
}