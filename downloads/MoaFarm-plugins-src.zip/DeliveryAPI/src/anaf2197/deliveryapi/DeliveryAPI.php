<?php

namespace anaf2197\deliveryapi;

use muqsit\invmenu\InvMenu;
use muqsit\invmenu\InvMenuHandler;
use muqsit\invmenu\transaction\InvMenuTransaction;
use muqsit\invmenu\transaction\InvMenuTransactionResult;
use muqsit\invmenu\type\InvMenuTypeIds;
use pocketmine\block\utils\DyeColor;
use pocketmine\block\VanillaBlocks;
use pocketmine\event\EventPriority;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\item\VanillaItems;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\scheduler\ClosureTask;
use pocketmine\utils\SingletonTrait;
use anaf2197\advancedprefix\AdvancedPrefix;
use anaf2197\deliveryapi\command\DeliverCommand;
use anaf2197\deliveryapi\command\PostBoxCommand;
use anaf2197\deliveryapi\form\DeliverForm;
use anaf2197\lib\color\ServerColor;
use anaf2197\servercore\CoreLoader;
use anaf2197\servercore\item\ServerItems;
use anaf2197\servercore\setting\ServerSettings;

final class DeliveryAPI extends PluginBase {

    public static string $prefix;

    private \mysqli $db;

    /** @var array<string, PlayerPostBox> */
    private array $mailboxes = [];

    use SingletonTrait;

    protected function onEnable(): void {
        $this->saveDefaultConfig();
        if (!$this->connectDb()) return;
        $this->initTables();
        $this->migrateFromJson();

        $this->getServer()->getCommandMap()->registerAll(strtolower($this->getName()), [
            new DeliverCommand(),
            new PostBoxCommand()
        ]);
        $this->getServer()->getPluginManager()->registerEvent(PlayerJoinEvent::class, function (PlayerJoinEvent $event): void {
            $player = $event->getPlayer();
            $mailBox = $this->getMailBox($player);
            if (!$mailBox instanceof PlayerPostBox) {
                $this->createMailBox($player);
            } else {
                if (!empty($mailBox->getMails())) {
                    $player->sendMessage(DeliveryAPI::$prefix . '읽지 않은 우편이 있습니다. 우편함을 확인해주세요!');
                }
            }
        }, EventPriority::MONITOR, $this);
        if (!InvMenuHandler::isRegistered()) {
            InvMenuHandler::register($this);
        }
    }

    protected function onLoad(): void {
        self::setInstance($this);
        ServerColor::setPrefix($this, '우편함');
    }

    protected function onDisable(): void {
        $this->saveDatabase();
        if (isset($this->db)) $this->db->close();
    }

    // ─── MySQL ───────────────────────────────────────────────────────────

    private function loadMysqlConfig(): array {
        $sharedPath = $this->getServer()->getDataPath() . 'plugins/mysql_shared.yml';
        if (file_exists($sharedPath)) {
            $shared = new \pocketmine\utils\Config($sharedPath);
            $cfg    = $shared->get('mysql', null);
            if (is_array($cfg)) return $cfg;
        }
        return (array) $this->getConfig()->get('mysql', []);
    }

    private function connectDb(): bool {
        $cfg    = $this->loadMysqlConfig();
        $host   = (string) ($cfg['host'] ?? '127.0.0.1');
        $port   = (int) ($cfg['port'] ?? 3306);
        $user   = (string) ($cfg['user'] ?? 'root');
        $pass   = (string) ($cfg['password'] ?? '');
        $dbName = (string) ($cfg['database'] ?? 'moafarm');

        try {
            $this->db = new \mysqli($host, $user, $pass, $dbName, $port);
        } catch (\mysqli_sql_exception $e) {
            $this->getLogger()->error('MySQL 연결 실패: ' . $e->getMessage());
            $this->getLogger()->error('▶ ' . $this->getDataFolder() . 'config.yml 의 mysql 설정을 확인하세요.');
            $this->getServer()->getPluginManager()->disablePlugin($this);
            return false;
        }
        if ($this->db->connect_error) {
            $this->getLogger()->error('MySQL 연결 실패: ' . $this->db->connect_error);
            $this->getServer()->getPluginManager()->disablePlugin($this);
            return false;
        }
        $this->db->set_charset('utf8mb4');
        return true;
    }

    private function ensureConnected(): void {
        try {
            if (!@$this->db->ping()) $this->connectDb();
        } catch (\Throwable) {
            $this->connectDb();
        }
    }

    private function initTables(): void {
        $this->db->query('CREATE TABLE IF NOT EXISTS delivery_mailboxes (
            player VARCHAR(100) NOT NULL PRIMARY KEY,
            data MEDIUMTEXT NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
    }

    /** 기존 JSON 파일 기반 우편함 데이터를 MySQL로 1회 이전합니다. */
    private function migrateFromJson(): void {
        $dir = $this->getServer()->getDataPath() . 'database/DeliveryAPI/';
        if (!is_dir($dir)) return;

        foreach (glob($dir . '*.json') ?: [] as $file) {
            $key = strtolower(basename($file, '.json'));

            $stmt = $this->db->prepare('SELECT 1 FROM delivery_mailboxes WHERE player = ?');
            $stmt->bind_param('s', $key);
            $stmt->execute();
            $exists = $stmt->get_result()->fetch_assoc() !== null;
            $stmt->close();
            if ($exists) continue;

            $content = @file_get_contents($file);
            if ($content === false) continue;
            $data = json_decode($content, true);
            if (!is_array($data)) continue;

            $stmt = $this->db->prepare('INSERT INTO delivery_mailboxes (player, data) VALUES (?, ?)');
            $stmt->bind_param('ss', $key, $content);
            $stmt->execute();
            $stmt->close();
        }
    }

    public function saveDatabase(): void {
        $this->ensureConnected();
        foreach ($this->mailboxes as $key => $box) {
            $this->saveMailBox($key, $box);
        }
    }

    private function saveMailBox(string $key, PlayerPostBox $box): void {
        $this->ensureConnected();
        $json = json_encode($box->jsonSerialize());
        $stmt = $this->db->prepare('REPLACE INTO delivery_mailboxes (player, data) VALUES (?, ?)');
        $stmt->bind_param('ss', $key, $json);
        $stmt->execute();
        $stmt->close();
    }

    public function getMailBox($player): ?PlayerPostBox {
        $key = strtolower($player instanceof Player ? $player->getName() : $player);
        if (isset($this->mailboxes[$key])) return $this->mailboxes[$key];

        $this->ensureConnected();
        $stmt = $this->db->prepare('SELECT data FROM delivery_mailboxes WHERE player = ?');
        $stmt->bind_param('s', $key);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($row === null) return null;

        $data = json_decode($row['data'], true);
        if (!is_array($data)) return null;

        $box = PlayerPostBox::jsonDeserialize($data);
        $this->mailboxes[$key] = $box;
        return $box;
    }

    private function createMailBox(Player $player): void {
        $key = strtolower($player->getName());
        $box = new PlayerPostBox($key, []);
        $this->mailboxes[$key] = $box;
        $this->saveMailBox($key, $box);
    }

    private array $currentSlot = [];
    private array $cantTouchSlot = [];
    private array $callbackItems = [];

    public function sendDeliverBox(Player $player, ?string $to = null): void {
        $invMenu = InvMenu::create(InvMenuTypeIds::TYPE_CHEST);
        $invMenu->setName('우편 발송: 1/2');
        $invMenu->setInventoryCloseListener(function (Player $player, Inventory $inventory) use ($to): void {
            $content = $inventory->getContents();
            $player->removeCurrentWindow();
            DeliveryAPI::getInstance()->getScheduler()->scheduleDelayedTask(new ClosureTask(function () use ($player, $content, $to): void {
                if ($player->isConnected()) $player->sendForm(new DeliverForm(AdvancedPrefix::getInstance()->getPlayerPrefix($player)?->getNowNickname(), array_values($content), $to));
            }), 5);
        });
        $invMenu->send($player);
    }

    public function sendPostBox(Player $player, ?array $mail = null): void {
        $invMenu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
        $invMenu->setName(is_null($mail) ? '§a' : $mail [0]);
        $this->reloadInv($invMenu->getInventory(), $mail ?? $player);
        $invMenu->setListener(function (InvMenuTransaction $transaction): InvMenuTransactionResult {
            $action = $transaction->getAction();
            $player = $transaction->getPlayer();
            $inventory = $action->getInventory();
            $sourceItem = $action->getSourceItem();
            $sourceNamedTag = $sourceItem->getNamedTag();
            if (!in_array($player->getId(), $this->cantTouchSlot)) {
                $tag = $sourceNamedTag->getTag('receive');
                if ($tag instanceof ByteTag) {
                    $player->removeCurrentWindow();
                    if ($tag->getValue()) {
                        $mailBox = DeliveryAPI::getInstance()->getMailBox($player);
                        $slot = $this->currentSlot [$player->getId()] ?? null;
                        unset($this->currentSlot [$player->getId()]);
                        if (is_array($mailBox->getMail($slot))) {
                            if ($mailBox->receive($player, $slot)) {
                                $this->sendPostBox($player);
                            } else {
                                $player->sendMessage(DeliveryAPI::$prefix . '소포를 수령할 수 없습니다. 인벤토리를 확인해주세요.');
                            }
                        }
                    } else {
                        $this->sendPostBox($player);
                        unset($this->currentSlot [$player->getId()]);
                    }
                } else {
                    $page = $sourceNamedTag->getInt('page', 1);
                    $mailBox = DeliveryAPI::getInstance()->getMailBox($player);
                    switch ($action->getSlot()) {
                        case 8:
                            $successCount = 0;
                            $failCount = 0;
                            $player->removeCurrentWindow();
                            foreach ($inventory->getContents() as $item) {
                                $slotTag = $item->getNamedTag()->getTag('mail_slot');
                                if ($slotTag instanceof IntTag) {
                                    $slot = $slotTag->getValue() - $successCount;
                                    if (is_array($mailBox->getMail($slot))) {
                                        if ($mailBox->receive($player, $slot)) {
                                            $successCount++;
                                        } else {
                                            $failCount++;
                                        }
                                    }
                                }
                            }
                            $player->sendMessage(DeliveryAPI::$prefix . '총 §l§a' . $successCount . '§r§8개의 우편을 수령했습니다.');
                            $player->sendMessage(DeliveryAPI::$prefix . '수령 실패 횟수: §l§a' . $failCount . '§r§8회');
                            break;

                        case 45:
                            if (!$sourceItem->isNull()) {
                                $this->reloadInv($inventory, $player, $page - 1);
                            }
                            break;

                        case 53:
                            if (!$sourceItem->isNull()) {
                                $this->reloadInv($inventory, $player, $page + 1);
                            }
                            break;

                        default:
                            if (!isset($this->currentSlot [$player->getId()])) {
                                $slotTag = $sourceNamedTag->getTag('mail_slot');
                                if ($slotTag instanceof IntTag) {
                                    $slot = $slotTag->getValue();
                                    if (is_array($mail = $mailBox->getMail($slot))) {
                                        $settings = CoreLoader::getInstance()->getPlayerSettings($player);
                                        if ($settings->getValue(ServerSettings::AUTO_RECEIVE_MAIL())) {
                                            if ($mailBox->receive($player, $slot)) {
                                                $this->reloadInv($inventory, $player, $page);
                                            } else {
                                                $player->removeCurrentWindow();
                                                $player->sendMessage(DeliveryAPI::$prefix . '소포를 수령할 수 없습니다. 인벤토리를 확인해 주세요.');
                                            }
                                        } else {
                                            $player->removeCurrentWindow();
                                            $this->sendPostBox($player, $mail);
                                            $this->currentSlot [$player->getId()] = $slot;
                                        }
                                    } else {
                                        $this->reloadInv($inventory, $player);
                                    }
                                }
                            }
                    }
                }
            }
            return $transaction->discard();
        });
        $invMenu->send($player);
    }

    public function getItemsByPage(Player $player, int $page): array {
        $result = [];
        if ($page > 0) {
            for ($i = ($page * 35) - 35; $i < $page * 35; $i++) {
                $mail = $this->getMailBox($player)->getMail($i);
                if (!is_null($mail)) {
                    $result [$i] = $mail;
                }
            }
        }
        return $result;
    }

    private function reloadInv(Inventory $inventory, Player|array $key, int $page = 1): void {
        if (!is_array($key)) {
            $player = $key;
            $inventory->clearAll();
            $slot = 0;
            foreach (array_map(function (array $data): Item {
                [$label, $items, $money, $sender] = $data;
                $icon = VanillaBlocks::CHEST()->asItem();
                $icon->setCustomName('§r§l§f' . $label);
                $lore = [' '];
                if (!empty($items)) $lore [] = '§r§8아이템: ' . implode(', ', array_map(function (Item $item): string { return $item->getName(); }, $items));
                if (is_numeric($money)) $lore [] = '§r§8돈: ' . $money;
                if (is_string($sender)) $lore [] = '§r§8발행인: ' . $sender;
                return $icon->setLore($lore);
            }, $this->getItemsByPage($player, $page)) as $originalSlot => $item) {
                while ($slot <= 52) {
                    if (in_array($slot, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 17, 18, 26, 27, 35, 36, 44, 45, 53]) or !$inventory->isSlotEmpty($slot)) {
                        $slot++;
                    } else {
                        break;
                    }
                }
                if ($slot < 53) {
                    $item->getNamedTag()->setInt('mail_slot', $originalSlot);
                    $item->getNamedTag()->setInt('page', $page);
                    $inventory->setItem($slot, $item);
                }
            }
            $inventory->setItem(8, ServerItems::TRANSPARENT()->setCustomName('§l§f전체 수령하기')->setLore([' ', '§r§8' . $page . '쪽에 있는 모든 우편을 수령합니다.']));
            if (!empty($this->getItemsByPage($player, $page + 1))) {
                $right_arrow = ServerItems::RIGHT_ARROW();
                $right_arrow->getNamedTag()->setInt('page', $page);
                $inventory->setItem(53, $right_arrow->setCustomName('§r§l§f다음 페이지')->setLore([' ', '§r§8현재: ' . $page . '쪽', '§r§8터치하여 다음 페이지로 이동']));
            }
            if (!empty($this->getItemsByPage($player, $page - 1))) {
                $left_arrow = ServerItems::LEFT_ARROW();
                $left_arrow->getNamedTag()->setInt('page', $page);
                $inventory->setItem(45, $left_arrow->setCustomName('§r§l§f이전 페이지')->setLore([' ', '§r§8현재: ' . $page . '쪽', '§r§8터치하여 이전 페이지로 이동']));
            }
        } else {
            [$label, $items, $money, $sender] = $key;
            $inventory->setContents($items);
            $glass = VanillaBlocks::STAINED_GLASS();
            $glass_icon = $glass->setColor(DyeColor::GREEN())->asItem();
            $glass_icon->getNamedTag()->setByte('receive', 1);
            $inventory->setItem(42, $glass_icon->setCustomName('§r§l§a수령하기')->setLore([' ', '§r§8터치하여 택배 수령']));
            $glass_icon = $glass->setColor(DyeColor::RED())->asItem();
            $glass_icon->getNamedTag()->setByte('receive', 0);
            $inventory->setItem(38, $glass_icon->setCustomName('§r§l§c돌아가기')->setLore([' ', '§r§8터치하여 우편함으로 이동']));
            $nether_star = VanillaItems::NETHER_STAR()->setCustomName('§r§l§f' . $label);
            $lore = [' '];
            if (is_numeric($money)) $lore [] = '§r§8돈: ' . $money;
            if (is_string($sender)) $lore [] = '§r§8발행인: ' . $sender;
            $inventory->setItem(40, $nether_star->setLore($lore));
        }
    }
}