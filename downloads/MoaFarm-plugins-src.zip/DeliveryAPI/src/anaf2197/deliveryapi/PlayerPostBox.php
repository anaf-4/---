<?php

namespace anaf2197\deliveryapi;

use pocketmine\item\Item;
use pocketmine\player\Player;
use pocketmine\Server;
use anaf2197\economyapi\EconomyAPI;
use anaf2197\lib\itemparser\ItemParser;

final class PlayerPostBox implements \JsonSerializable {

    public function __construct(private string $name, protected array $mails) { }

    public function getName(): string {
        return $this->name;
    }

    public function getMail(int $key): ?array {
        return $this->mails [$key] ?? null;
    }

    public function getMails(): array {
        return $this->mails;
    }

    public function new(string $label, array $items = [], ?int $money = null, ?string $sender = null): void {
        $this->mails [] = [$label, $items, $money, $sender];
        if (($player = Server::getInstance()->getPlayerExact($this->name)) instanceof Player) {
            $player->sendToastNotification('§l§a딩동~ 우편이 도착했습니다!', '§r§f* /우편함 명령어로 확인해보세요');
        }
    }

    public function receive(Player $player, int $key): bool {
        if (is_array(($data = $this->getMail($key)))) {
            [$label, $items, $money, $sender] = $data;
            if (!empty($items)) {
                $inventory = $player->getInventory();
                $contents = $inventory->getContents(true);
                $allAdded = empty($inventory->addItem(...$items));
                if (!$allAdded) {
                    $inventory->setContents($contents);
                    return false;
                }
            }
            if (is_numeric($money)) {
                EconomyAPI::getInstance()->getEconomyData($player)?->addMoney($money, $sender ? '우편 수령' : $sender . '님의 우편');
            }
            unset($this->mails [$key]);
            $this->mails = array_values($this->mails);
            $player->sendMessage(DeliveryAPI::$prefix . '[ ' . $label . '§r§8 ] 우편을 수령했습니다!');
            return true;
        }
        return false;
    }

    public function jsonSerialize(): array {
        return [
            $this->name,
            array_map(function (array $mail): array {
                $mail [1] = array_map(function (Item $item): string {
                    return ItemParser::toString($item);
                }, $mail [1]);
                return $mail;
            }, $this->mails)
        ];
    }

    public static function jsonDeserialize(array $data): self {
        return new self ($data [0], array_map(function (array $mail): array {
            $mail [1] = array_map(function (string $itemJson): Item {
                return ItemParser::fromString($itemJson);
            }, $mail [1]);
            return $mail;
        }, $data [1]));
    }
}