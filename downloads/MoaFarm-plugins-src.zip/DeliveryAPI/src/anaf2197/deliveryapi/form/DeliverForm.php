<?php

namespace anaf2197\deliveryapi\form;

use pocketmine\form\Form;
use pocketmine\player\Player;
use anaf2197\deliveryapi\DeliveryAPI;
use anaf2197\deliveryapi\PlayerPostBox;
use anaf2197\economyapi\EconomyAPI;

final class DeliverForm implements Form {

    public function __construct(private string $name, private array $items, private ?string $to) { }

    public function jsonSerialize(): array {
        return [
            'type' => 'custom_form',
            'title' => '§l우편 발송: 2 / 2',
            'content' => [
                [
                    'type' => 'input',
                    'text' => PHP_EOL . '수취인 이름을 적어주세요.' . PHP_EOL . ' ',
                    'default' => (string)$this->to
                ],
                [
                    'type' => 'input',
                    'text' => PHP_EOL . '소포 이름을 적어주세요.' . PHP_EOL . ' ',
                    'default' => $this->name . '님의 소포'
                ],
                [
                    'type' => 'input',
                    'text' => PHP_EOL . '보낼 금액을 적어주세요. (미작성 가능)' . PHP_EOL . ' ',
                    'default' => ''
                ]
            ]
        ];
    }

    public function handleResponse(Player $player, $data): void {
        if (is_array($data)) {
            $to = strtolower(array_shift($data));
            if ($to !== strtolower($player->getName())) {
                $money = (!is_numeric($data [1]) or $data [1] <= 0) ? null : $data [1];
                $label = array_shift($data);
                if (is_numeric($money) or !empty($this->items)) {
                    $mailBox = DeliveryAPI::getInstance()->getMailBox($to);
                    if ($mailBox instanceof PlayerPostBox) {
                        $economyData = EconomyAPI::getInstance()->getEconomyData($player);
                        if ($economyData->getMoney() >= ($money ?? 0)) {
                            $economyData->reduceMoney($money ?? 0, $to . '님에게 소포 전송');
                            $mailBox->new($label, $this->items, $money, $player->getName());
                            $player->sendMessage(DeliveryAPI::$prefix . $to . '님에게 소포를 보냈습니다.');
                        } else {
                            $player->sendMessage(DeliveryAPI::$prefix . '소지금이 부족합니다.');
                            $this->returnItems($player);
                        }
                    } else {
                        $player->sendMessage(DeliveryAPI::$prefix . '수취인을 찾을 수 없습니다.');
                        $this->returnItems($player);
                    }
                } else {
                    $player->sendMessage(DeliveryAPI::$prefix . '내용물이 없어 거부되었습니다.');
                }
            } else {
                $player->sendMessage(DeliveryAPI::$prefix . '자기 자신에겐 보낼 수 없습니다.');
                $this->returnItems($player);
            }
        } else {
            $this->returnItems($player);
        }
    }

    private function returnItems(Player $player): void {
        foreach ($this->items as $item) {
            $player->getInventory()->addItem($item);
        }
    }
}