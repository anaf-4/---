<?php
declare(strict_types=1);

namespace anaf2197\blockwarp\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use anaf2197\blockwarp\BlockWarpLoader;

final class WarpCommand extends Command {

    public function __construct() {
        parent::__construct('텔레포트', '워프 관리 (관리자 전용)', '/텔레포트 <설정|이동|블록연결|블록해제|삭제|목록>', ['warp']);
        $this->setPermission('blockwarp.admin');
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if (!$this->testPermission($sender)) return;

        $plugin = BlockWarpLoader::getInstance();
        $sub    = $args[0] ?? '';

        switch ($sub) {

            case '설정':
                if (!($sender instanceof Player)) { $sender->sendMessage('§c인게임에서만 사용 가능합니다.'); return; }
                $name = $args[1] ?? null;
                if ($name === null) { $sender->sendMessage('§c사용법: /텔레포트 설정 [워프이름]'); return; }
                $loc = $sender->getLocation();
                $plugin->setWarp($name, [
                    'world' => $loc->getWorld()->getFolderName(),
                    'x'     => $loc->getX(),
                    'y'     => $loc->getY(),
                    'z'     => $loc->getZ(),
                    'yaw'   => $loc->getYaw(),
                    'pitch' => $loc->getPitch(),
                ]);
                $sender->sendMessage("§a[워프] §e'$name'§a 워프가 현재 위치로 설정되었습니다.");
                break;

            case '이동':
                if (!($sender instanceof Player)) { $sender->sendMessage('§c인게임에서만 사용 가능합니다.'); return; }
                $name = $args[1] ?? null;
                if ($name === null) { $sender->sendMessage('§c사용법: /텔레포트 이동 [워프이름]'); return; }
                $warp = $plugin->getWarp($name);
                if ($warp === null) { $sender->sendMessage("§c[워프] §e'$name'§c 워프가 존재하지 않습니다."); return; }
                if (!$plugin->teleportToWarp($sender, $warp)) {
                    $sender->sendMessage("§c[워프] 월드를 불러올 수 없습니다.");
                    return;
                }
                $sender->sendMessage("§a[워프] §e'$name'§a 워프로 이동했습니다.");
                break;

            case '블록연결':
                if (!($sender instanceof Player)) { $sender->sendMessage('§c인게임에서만 사용 가능합니다.'); return; }
                $name = $args[1] ?? null;
                if ($name === null) { $sender->sendMessage('§c사용법: /텔레포트 블록연결 [워프이름]'); return; }
                if ($plugin->getWarp($name) === null) { $sender->sendMessage("§c[워프] §e'$name'§c 워프가 존재하지 않습니다. 먼저 /텔레포트 설정으로 생성하세요."); return; }
                $plugin->setPending($sender->getName(), "link:$name");
                $sender->sendMessage("§e[워프] 연결할 블록을 터치하세요.§7 (/warp 취소 로 취소)");
                break;

            case '블록해제':
                if (!($sender instanceof Player)) { $sender->sendMessage('§c인게임에서만 사용 가능합니다.'); return; }
                $plugin->setPending($sender->getName(), 'unlink');
                $sender->sendMessage('§e[워프] 해제할 블록을 터치하세요.§7 (/warp 취소 로 취소)');
                break;

            case '삭제':
                $name = $args[1] ?? null;
                if ($name === null) { $sender->sendMessage('§c사용법: /텔레포트 삭제 [워프이름]'); return; }
                if ($plugin->deleteWarp($name)) {
                    $sender->sendMessage("§a[워프] §e'$name'§a 워프가 삭제되었습니다. (연결된 블록도 함께 해제)");
                } else {
                    $sender->sendMessage("§c[워프] §e'$name'§c 워프를 찾을 수 없습니다.");
                }
                break;

            case '목록':
                $warps = $plugin->getAllWarps();
                if (empty($warps)) { $sender->sendMessage('§7[워프] 등록된 워프가 없습니다.'); return; }
                $sender->sendMessage('§e[워프 목록] §7(' . count($warps) . '개)');
                foreach ($warps as $wName => $data) {
                    $sender->sendMessage(
                        "§7 · §f$wName §8— {$data['world']} " .
                        (int)$data['x'] . ' ' . (int)$data['y'] . ' ' . (int)$data['z']
                    );
                }
                break;

            case '취소':
                if (!($sender instanceof Player)) return;
                if ($plugin->getPending($sender->getName()) !== null) {
                    $plugin->clearPending($sender->getName());
                    $sender->sendMessage('§7[워프] 블록 연결 모드가 취소되었습니다.');
                }
                break;

            default:
                $sender->sendMessage('§e[워프 관리 명령어]');
                $sender->sendMessage('§7/텔레포트 설정 [이름] §f- 현재 위치로 워프 생성');
                $sender->sendMessage('§7/텔레포트 이동 [이름] §f- 지정한 워프로 이동');
                $sender->sendMessage('§7/텔레포트 블록연결 [이름] §f- 블록에 워프 연결');
                $sender->sendMessage('§7/텔레포트 블록해제 §f- 블록 워프 연결 해제');
                $sender->sendMessage('§7/텔레포트 삭제 [이름] §f- 워프 삭제 (연결 블록 포함)');
                $sender->sendMessage('§7/텔레포트 목록 §f- 워프 목록 조회');
                $sender->sendMessage('§7/텔레포트 취소 §f- 블록 연결 모드 취소');
        }
    }
}
