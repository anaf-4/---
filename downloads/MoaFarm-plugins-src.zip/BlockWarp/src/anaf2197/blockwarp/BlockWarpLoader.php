<?php
declare(strict_types=1);

namespace anaf2197\blockwarp;

use pocketmine\entity\Location;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\Server;
use pocketmine\utils\SingletonTrait;
use anaf2197\blockwarp\command\WarpCommand;

final class BlockWarpLoader extends PluginBase {

    use SingletonTrait;

    /** @var array<string, array{world:string,x:float,y:float,z:float,yaw:float,pitch:float}> */
    private array $warps = [];

    /** @var array<string, string> blockKey => warpName */
    private array $blockWarps = [];

    /** @var array<string, string> lowerPlayerName => "link:warpname" | "unlink" */
    private array $pendingAction = [];

    /** @var array<string, int> lowerPlayerName => server tick of last teleport */
    private array $cooldowns = [];

    protected function onLoad(): void {
        self::setInstance($this);
        $this->saveDefaultConfig();
    }

    protected function onEnable(): void {
        $this->warps     = (array)($this->getConfig()->get('warps', []));
        $this->blockWarps = (array)($this->getConfig()->get('block-warps', []));

        $this->getServer()->getPluginManager()->registerEvents(new EventListener($this), $this);
        $this->getServer()->getCommandMap()->registerAll('blockwarp', [new WarpCommand()]);
    }

    protected function onDisable(): void {
        $this->persist();
    }

    private function persist(): void {
        $this->getConfig()->set('warps', $this->warps);
        $this->getConfig()->set('block-warps', $this->blockWarps);
        $this->getConfig()->save();
    }

    // ── 워프 지점 ──────────────────────────────────────────────────────────

    public function getWarp(string $name): ?array {
        return $this->warps[strtolower($name)] ?? null;
    }

    public function setWarp(string $name, array $data): void {
        $this->warps[strtolower($name)] = $data;
        $this->persist();
    }

    public function deleteWarp(string $name): bool {
        $key = strtolower($name);
        if (!isset($this->warps[$key])) return false;
        unset($this->warps[$key]);
        foreach ($this->blockWarps as $bk => $wn) {
            if ($wn === $key) unset($this->blockWarps[$bk]);
        }
        $this->persist();
        return true;
    }

    /** @return array<string, array> */
    public function getAllWarps(): array {
        return $this->warps;
    }

    // ── 블록 연결 ──────────────────────────────────────────────────────────

    public static function blockKey(string $world, int $x, int $y, int $z): string {
        return "$world:$x:$y:$z";
    }

    public function getBlockWarp(string $blockKey): ?string {
        return $this->blockWarps[$blockKey] ?? null;
    }

    public function linkBlock(string $blockKey, string $warpName): void {
        $this->blockWarps[$blockKey] = strtolower($warpName);
        $this->persist();
    }

    public function unlinkBlock(string $blockKey): bool {
        if (!isset($this->blockWarps[$blockKey])) return false;
        unset($this->blockWarps[$blockKey]);
        $this->persist();
        return true;
    }

    // ── 대기 액션 ──────────────────────────────────────────────────────────

    public function setPending(string $playerName, string $action): void {
        $this->pendingAction[strtolower($playerName)] = $action;
    }

    public function getPending(string $playerName): ?string {
        return $this->pendingAction[strtolower($playerName)] ?? null;
    }

    public function clearPending(string $playerName): void {
        unset($this->pendingAction[strtolower($playerName)]);
    }

    // ── 쿨타임 ────────────────────────────────────────────────────────────

    public function isOnCooldown(string $playerName): bool {
        $ticks = (int)$this->getConfig()->get('cooldown-ticks', 20);
        $last  = $this->cooldowns[strtolower($playerName)] ?? 0;
        return (Server::getInstance()->getTick() - $last) < $ticks;
    }

    public function setCooldown(string $playerName): void {
        $this->cooldowns[strtolower($playerName)] = Server::getInstance()->getTick();
    }

    // ── 텔레포트 공통 ─────────────────────────────────────────────────────

    public function teleportToWarp(Player $player, array $warp): bool {
        $worldManager = Server::getInstance()->getWorldManager();
        $world = $worldManager->getWorldByName($warp['world']);
        if ($world === null) {
            $worldManager->loadWorld($warp['world']);
            $world = $worldManager->getWorldByName($warp['world']);
        }
        if ($world === null) return false;

        $player->teleport(new Location(
            (float)$warp['x'],
            (float)$warp['y'],
            (float)$warp['z'],
            $world,
            (float)($warp['yaw']   ?? 0),
            (float)($warp['pitch'] ?? 0)
        ));
        return true;
    }
}
