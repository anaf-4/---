<?php
declare(strict_types=1);

namespace anaf2197\blockwarp;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerQuitEvent;

final class EventListener implements Listener {

    public function __construct(private readonly BlockWarpLoader $plugin) {}

    public function onInteract(PlayerInteractEvent $event): void {
        $player = $event->getPlayer();
        $block  = $event->getBlock();
        $name   = $player->getName();

        $bx  = (int)$block->getPosition()->getX();
        $by  = (int)$block->getPosition()->getY();
        $bz  = (int)$block->getPosition()->getZ();
        $bw  = $block->getPosition()->getWorld()->getFolderName();
        $key = BlockWarpLoader::blockKey($bw, $bx, $by, $bz);

        $pending = $this->plugin->getPending($name);

        // ── 블록 연결/해제 대기 모드 ──────────────────────────────────────
        if ($pending !== null) {
            $this->plugin->clearPending($name);
            $event->cancel();

            if (str_starts_with($pending, 'link:')) {
                $warpName = substr($pending, 5);
                $this->plugin->linkBlock($key, $warpName);
                $player->sendMessage("§a[워프] 블록이 §e'$warpName'§a 워프에 연결되었습니다.");
            } else {
                if ($this->plugin->unlinkBlock($key)) {
                    $player->sendMessage('§a[워프] 블록 워프 연결이 해제되었습니다.');
                } else {
                    $player->sendMessage('§c[워프] 해당 블록에 연결된 워프가 없습니다.');
                }
            }
            return;
        }

        // ── 블록 워프 실행 ────────────────────────────────────────────────
        $warpName = $this->plugin->getBlockWarp($key);
        if ($warpName === null) return;

        $warp = $this->plugin->getWarp($warpName);
        if ($warp === null) return;

        if ($this->plugin->isOnCooldown($name)) return;

        $this->plugin->setCooldown($name);
        $this->plugin->teleportToWarp($player, $warp);
        $event->cancel();
    }

    public function onQuit(PlayerQuitEvent $event): void {
        $this->plugin->clearPending($event->getPlayer()->getName());
    }
}
