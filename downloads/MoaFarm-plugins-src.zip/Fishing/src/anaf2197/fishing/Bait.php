<?php

namespace anaf2197\fishing;

use pocketmine\item\Item;
use anaf2197\lib\itemparser\ItemParser;

final class Bait implements \JsonSerializable {

    public const TAG_BAIT = 'bait';

    private Item $basicItem;
    private Item $baitItem;

    public function __construct(private readonly string $name, string $itemData, private readonly float $shorteningPercent) {
        $this->basicItem = ItemParser::fromString($itemData);
        $this->baitItem = clone $this->basicItem;
        $this->baitItem->setCustomName('§r§f미끼: ' . $this->name);
        $this->baitItem->setLore([
            ' ',
            '§r§8단축 시간: ' . ($this->shorteningPercent > 0 ? $this->shorteningPercent . '%' : '없음')
        ]);
        $this->baitItem->getNamedTag()->setString(self::TAG_BAIT, $this->name);
    }

    public function getName(): string {
        return $this->name;
    }

    public function asItem(): Item {
        return $this->baitItem;
    }

    public function getShorteningPercent(): float {
        return $this->shorteningPercent;
    }

    public function jsonSerialize(): array {
        return [
            $this->name,
            ItemParser::toString($this->basicItem),
            $this->shorteningPercent
        ];
    }

    public static function jsonDeserialize(array $data): self {
        return new self (... $data);
    }
}