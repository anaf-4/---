<?php

namespace anaf2197\fishing;

use pocketmine\entity\Location;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\item\Item;
use pocketmine\nbt\tag\StringTag;
use pocketmine\player\Player;
use pocketmine\Server;
use anaf2197\advancedlevel\AdvancedLevel;
use anaf2197\advancedlevel\PlayerLevel;
use anaf2197\fishing\entity\FishingHook;
use anaf2197\fishing\event\FishingEvent;
use anaf2197\fishing\item\FishingRod;
use anaf2197\fishing\minigame\FishingMinigame;
use anaf2197\lib\itemparser\ItemParser;

final class Fisherman implements \JsonSerializable {

    private ?FishingHook $hook = null;
    private ?Item $baitItem;
    private ?FishingMinigame $minigame = null;

    private FishingManager $fishingManager;

    public function __construct(private readonly string $id, ?string $baitItemData) {
        $this->baitItem = is_string($baitItemData) ? ItemParser::fromString($baitItemData) : null;
        $this->fishingManager = FishingLoader::getInstance()->getFishingManager();
    }

    public function getMinigame(): ?FishingMinigame {
        return $this->minigame;
    }

    public function setMinigame(?FishingMinigame $minigame): void {
        $this->minigame = $minigame;
    }

    public function isInMinigame(): bool {
        return $this->minigame !== null && !$this->minigame->isFinished();
    }

    public function getEnchantmentLevel(): int {
        $player = $this->getPlayer();
        if ($player === null) return 0;
        $item = $player->getInventory()->getItemInHand();
        if (!$item instanceof FishingRod) return 0;
        return $item->getEnchantmentLevel(VanillaEnchantments::FORTUNE());
    }

    public function getPlayer(): ?Player {
        return Server::getInstance()->getPlayerExact($this->id);
    }

    public function isFishing(): bool {
        return !is_null($this->hook);
    }

    public function getHook(): ?FishingHook {
        return $this->hook;
    }

    public function getBaitItem(): ?Item {
        return $this->baitItem;
    }

    public function getBait(): ?Bait {
        if (($tag = $this->baitItem?->getNamedTag()->getTag(Bait::TAG_BAIT)) instanceof StringTag) {
            return $this->fishingManager->getBait($tag->getValue());
        }
        return null;
    }

    public function setBaitItem(?Item $item): void {
        $this->baitItem = $item;
    }

    public function pickoutBait(bool $sendMessage = false): void {
        $player = $this->getPlayer();
        if ($player instanceof Player) {
            if (!$this->isFishing()) {
                $inventory = $player->getInventory();
                $baitItem = $this->baitItem;
                if ($baitItem instanceof Item) {
                    if ($inventory->canAddItem($baitItem)) {
                        $inventory->addItem(clone $baitItem);
                        $this->baitItem = null;
                        if ($sendMessage) $player->sendMessage(FishingLoader::$prefix . '미끼를 제거했습니다.');
                    } else {
                        if ($sendMessage) $player->sendMessage(FishingLoader::$prefix . '인벤토리 공간을 확인해주세요.');
                    }
                } else {
                    if ($sendMessage) $player->sendMessage(FishingLoader::$prefix . '사용중인 미끼가 없습니다.');
                }
            } else {
                if ($sendMessage) $player->sendMessage(FishingLoader::$prefix . '낚시 종료후 다시 시도해주세요.');
            }
        }
    }

    public function start(): void {
        if (is_null($this->hook)) {
            $player = $this->getPlayer();
            if ($player instanceof Player) {
                if ($this->baitItem instanceof Item) {
                    $position = $player->getPosition();
                    $this->hook = $hook = new FishingHook(
                        new Location($position->x, $position->y + 1, $position->z, $position->getWorld(), 0, 0),
                        $player,
                        $this
                    );
                    $hook->spawnToAll();
                } else {
                    $player->sendMessage(FishingLoader::$prefix . '미끼를 장착해주세요.');
                }
            }
        }
    }

    public function stop(): bool {
        if ($this->hook instanceof FishingHook) {
            $player = $this->getPlayer();
            if ($player instanceof Player) {
                $canPullup = $this->hook->canPullup();
                $this->closeHook();

                if ($canPullup) {
                    // ── 티어 결정 ──
                    $rand = mt_rand(1, 100);
                    $tier = Fish::TIER_D;
                    foreach (FishingLoader::TIER_LIST as $key => $chance) {
                        if ($rand <= $chance) {
                            $tier = $key;
                            break;
                        }
                    }

                    // 낚싯대 강화 보너스 (L 제외)
                    if ($tier !== Fish::TIER_L) {
                        $upgradeChance = $this->getEnchantmentLevel() * 2;
                        if (mt_rand(1, 100) <= $upgradeChance) {
                            $tier = match ($tier) {
                                Fish::TIER_D => Fish::TIER_C,
                                Fish::TIER_C => Fish::TIER_B,
                                Fish::TIER_B => Fish::TIER_A,
                                Fish::TIER_A => Fish::TIER_L,
                                default      => $tier,
                            };
                        }
                    }

                    // ── 관리자가 활성화한 풀에서만 물고기 선택 ──
                    $isSpecial = ($tier === Fish::TIER_L);
                    $pool = array_values($this->fishingManager->getActiveFishes($isSpecial));

                    if (empty($pool)) {
                        $player->sendMessage(FishingLoader::$prefix . '현재 준비된 물고기가 없습니다.');
                        return false;
                    }

                    /** @var Fish $fish */
                    $fish = $pool[mt_rand(0, count($pool) - 1)];

                    // ── 미니게임 시작 ──
                    $baitItem = $this->baitItem;
                    $player->sendMessage(FishingLoader::$prefix . '§e물고기가 물었습니다! 초록 구간에서 낚싯대를 클릭하세요!');

                    $minigame = new FishingMinigame(
                        $player->getName(),
                        function (bool $success) use ($player, $fish, $tier, $baitItem): void {
                            // 미끼 차감 (미끼 없이 낚시한 경우 null일 수 있으므로 체크)
                            if ($baitItem !== null) {
                                $baitItem->setCount($baitItem->getCount() - 1);
                                if ($baitItem->getCount() <= 0) {
                                    $this->baitItem = null;
                                }
                            }

                            if ($success) {
                                $event = new FishingEvent($player, $fish->asItem($tier));
                                $event->call();
                                $player->getInventory()->addItem($event->getItem());
                                $amount = 15;
                                $playerLevel = AdvancedLevel::getInstance()->getPlayerLevel($player->getName());
                                if ($playerLevel instanceof PlayerLevel) {
                                    $playerLevel->pointUp($amount);
                                }
                                $player->sendMessage(FishingLoader::$prefix . strtoupper($tier) . '급 ' . $fish->getName() . '(을)를 낚았습니다!');
                                // 낚시 레어 업적: L등급 물고기 (#7)
                                if ($tier === Fish::TIER_L && class_exists(\anaf2197\achievement\AchievementLoader::class)) {
                                    \anaf2197\achievement\AchievementLoader::getInstance()->addProgress($player, \anaf2197\achievement\Achievement::TYPE_FISHING_RARE);
                                }
                            }
                            $this->minigame = null;
                        }
                    );

                    $this->minigame = $minigame;
                    FishingLoader::getInstance()->getScheduler()->scheduleRepeatingTask($minigame, 2);
                }
                return $canPullup;
            }
        }
        return false;
    }

    public function closeHook(): void {
        if ($this->hook instanceof FishingHook) {
            $this->hook->close();
            $this->hook = null;
        }
    }

    public function jsonSerialize(): array {
        return [
            $this->id,
            is_null($this->baitItem) ? null : ItemParser::toString($this->baitItem)
        ];
    }

    public static function jsonDeserialize(array $data): self {
        return new self($data[0], $data[1]);
    }
}