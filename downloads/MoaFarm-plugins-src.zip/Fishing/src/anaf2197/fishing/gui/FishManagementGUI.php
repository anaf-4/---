<?php
namespace anaf2197\fishing\gui;

use muqsit\invmenu\InvMenu;
use muqsit\invmenu\transaction\InvMenuTransaction;
use muqsit\invmenu\transaction\InvMenuTransactionResult;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use anaf2197\fishing\Fish;
use anaf2197\fishing\FishingLoader;
use anaf2197\fishing\FishingManager;
use anaf2197\servercore\item\ServerItems;

/**
 * 물고기 관리 GUI
 *
 * [물고기제거] 서브커맨드: 전체 창고에서 물고기 삭제
 * [물고기활성] 서브커맨드: 낚시로 잡힐 물고기를 GUI로 활성/비활성 토글
 *
 * GUI 색상 규칙
 *  §a (초록) = 활성화됨 → 클릭 시 비활성화
 *  §c (빨강) = 비활성화됨 → 클릭 시 활성화
 */
final class FishManagementGUI {

    private const ITEMS_PER_PAGE = 45;

    public function __construct(private readonly FishingManager $fishingManager) {}

    // ══════════════════════════════════════════════════════════════
    //  ① 전역 물고기 제거 GUI  (기존 동작 유지)
    // ══════════════════════════════════════════════════════════════

    public function send(Player $player, int $page = 1): void {
        $menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST);
        $menu->setName("§l§c전역 물고기 제거 §r§8(페이지 {$page})");

        $fishes   = $this->fishingManager->getFishes();
        $allItems = $this->buildRemoveItems($fishes);

        [$totalPages, $page] = $this->calcPage(count($allItems), $page);

        $inventory  = $menu->getInventory();
        $startIndex = ($page - 1) * self::ITEMS_PER_PAGE;
        $endIndex   = min($startIndex + self::ITEMS_PER_PAGE, count($allItems));
        for ($i = $startIndex; $i < $endIndex; $i++) {
            $inventory->setItem($i - $startIndex, $allItems[$i]['item']);
        }
        $this->setNavItems($inventory, $page, $totalPages, count($fishes), count($allItems));

        $currentPage = $page;
        $menu->setListener(function (InvMenuTransaction $tx) use ($allItems, $currentPage, $totalPages): InvMenuTransactionResult {
            $p    = $tx->getPlayer();
            $slot = $tx->getAction()->getSlot();

            if ($slot === 48 && $currentPage > 1) { $p->removeCurrentWindow(); $this->send($p, $currentPage - 1); return $tx->discard(); }
            if ($slot === 50 && $currentPage < $totalPages) { $p->removeCurrentWindow(); $this->send($p, $currentPage + 1); return $tx->discard(); }
            if ($slot >= 45) return $tx->discard();

            $idx = ($currentPage - 1) * self::ITEMS_PER_PAGE + $slot;
            if (!isset($allItems[$idx])) return $tx->discard();

            $fishName = $allItems[$idx]['fishName'];
            $tier     = $allItems[$idx]['tier'];
            $fish     = $this->fishingManager->getFish($fishName);
            if ($fish === null) return $tx->discard();

            $fish->disableTier($tier);
            if (count($fish->getEnabledTiers()) === 0) {
                $this->fishingManager->removeFish($fishName);
                $p->sendMessage(FishingLoader::$prefix . "§e{$fishName}§f의 모든 등급이 비활성화되어 물고기를 제거했습니다.");
            } else {
                $p->sendMessage(FishingLoader::$prefix . "§e{$fishName} §8(" . strtoupper($tier) . "등급)§f을 비활성화했습니다.");
            }

            $p->removeCurrentWindow();
            $this->send($p, $currentPage);
            return $tx->discard();
        });

        $menu->send($player);
    }

    // ══════════════════════════════════════════════════════════════
    //  ② 낚시 활성 풀 편집 GUI  ← 핵심
    //
    //  전체 창고의 물고기를 나열하되,
    //  활성화된 물고기: §a 이름 + "클릭하여 비활성화"
    //  비활성화된 물고기: §c 이름 + "클릭하여 활성화"
    // ══════════════════════════════════════════════════════════════

    public function sendActivePool(Player $player, int $page = 1): void {
        $menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST);
        $menu->setName("§l§e낚시 물고기 활성 관리 §r§8(페이지 {$page})");

        $fishes   = $this->fishingManager->getFishes();
        $allItems = $this->buildActivePoolItems($fishes);

        [$totalPages, $page] = $this->calcPage(count($allItems), $page);

        $inventory  = $menu->getInventory();
        $startIndex = ($page - 1) * self::ITEMS_PER_PAGE;
        $endIndex   = min($startIndex + self::ITEMS_PER_PAGE, count($allItems));
        for ($i = $startIndex; $i < $endIndex; $i++) {
            $inventory->setItem($i - $startIndex, $allItems[$i]['item']);
        }
        $this->setNavItems($inventory, $page, $totalPages, count($fishes), count($allItems));

        $currentPage = $page;
        $menu->setListener(function (InvMenuTransaction $tx) use ($allItems, $currentPage, $totalPages): InvMenuTransactionResult {
            $p    = $tx->getPlayer();
            $slot = $tx->getAction()->getSlot();

            if ($slot === 48 && $currentPage > 1) { $p->removeCurrentWindow(); $this->sendActivePool($p, $currentPage - 1); return $tx->discard(); }
            if ($slot === 50 && $currentPage < $totalPages) { $p->removeCurrentWindow(); $this->sendActivePool($p, $currentPage + 1); return $tx->discard(); }
            if ($slot >= 45) return $tx->discard();

            $idx = ($currentPage - 1) * self::ITEMS_PER_PAGE + $slot;
            if (!isset($allItems[$idx])) return $tx->discard();

            $fishName = $allItems[$idx]['fishName'];
            $active   = $allItems[$idx]['active'];

            if ($active) {
                $this->fishingManager->deactivateFish($fishName);
                $p->sendMessage(FishingLoader::$prefix . "§c{$fishName}§f을 낚시 풀에서 제거했습니다.");
            } else {
                $this->fishingManager->activateFish($fishName);
                $p->sendMessage(FishingLoader::$prefix . "§a{$fishName}§f을 낚시 풀에 추가했습니다.");
            }

            $p->removeCurrentWindow();
            $this->sendActivePool($p, $currentPage);
            return $tx->discard();
        });

        $menu->send($player);
    }

    // ─── 내부 헬퍼 ───────────────────────────────────────────────

    private function buildRemoveItems(array $fishes): array {
        $allItems = [];
        foreach ($fishes as $fishName => $fish) {
            foreach (Fish::getTiers() as $tier) {
                if (!$fish->isTierEnabled($tier)) continue;
                $item = $fish->asItem($tier);
                $lore = $item->getLore();
                $lore[] = '';
                $lore[] = '§r§c클릭하여 이 등급 전역 제거';
                $item->setLore($lore);
                $allItems[] = ['item' => $item, 'fishName' => $fishName, 'tier' => $tier];
            }
        }
        return $allItems;
    }

    private function buildActivePoolItems(array $fishes): array {
        $allItems = [];
        foreach ($fishes as $fishName => $fish) {
            $active = $this->fishingManager->isActiveFish($fishName);

            $item = $fish->asItem(Fish::TIER_D);
            if ($active) {
                $item->setCustomName('§r§a§l▶ ' . $fish->getName() . ' §r§a[활성]');
                $item->setLore([
                    '§r§8이 물고기는 낚시 풀에 등록되어 있습니다.',
                    '§r§8유저가 낚시를 통해 이 물고기를 잡을 수 있습니다.',
                    '',
                    '§r§c클릭하여 낚시 풀에서 제거',
                ]);
            } else {
                $item->setCustomName('§r§8§l▷ ' . $fish->getName() . ' §r§c[비활성]');
                $item->setLore([
                    '§r§8이 물고기는 낚시 풀에 없습니다.',
                    '§r§8유저가 이 물고기를 잡을 수 없습니다.',
                    '',
                    '§r§a클릭하여 낚시 풀에 추가',
                ]);
            }

            $allItems[] = ['item' => $item, 'fishName' => $fishName, 'active' => $active];
        }
        return $allItems;
    }

    private function calcPage(int $totalItems, int $page): array {
        $totalPages = max(1, (int) ceil($totalItems / self::ITEMS_PER_PAGE));
        return [$totalPages, max(1, min($page, $totalPages))];
    }

    private function setNavItems(\pocketmine\inventory\Inventory $inv, int $page, int $totalPages, int $fishCount, int $itemCount): void {
        if ($page > 1) {
            $btn = ServerItems::LEFT_ARROW()->setCustomName('§l§c◀ 이전 페이지');
            $btn->setLore(["§r§8{$page}§8/§8{$totalPages} 페이지"]);
            $inv->setItem(48, $btn);
        }

        $info = VanillaItems::BOOK()->setCustomName('§l§e페이지 정보');
        $info->setLore([
            "§r§8{$page}§8/§8{$totalPages} 페이지",
            "§r§8물고기 종류: §f{$fishCount}",
        ]);
        $inv->setItem(49, $info);

        if ($page < $totalPages) {
            $btn = ServerItems::RIGHT_ARROW()->setCustomName('§l§a다음 페이지 ▶');
            $btn->setLore(["§r§8{$page}§8/§8{$totalPages} 페이지"]);
            $inv->setItem(50, $btn);
        }
    }
}