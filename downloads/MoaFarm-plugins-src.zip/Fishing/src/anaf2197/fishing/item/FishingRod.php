<?php

namespace anaf2197\fishing\item;

use pocketmine\item\FishingRod as PM_FishingRod;
use pocketmine\item\ItemUseResult;
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use anaf2197\fishing\Fisherman;
use anaf2197\fishing\FishingLoader;

final class FishingRod extends PM_FishingRod {

    public function onClickAir(Player $player, Vector3 $directionVector, array &$returnedItems): ItemUseResult {
        $fisherman = FishingLoader::getInstance()->getFisherman($player);
        if ($fisherman instanceof Fisherman) {
            // 미니게임 진행 중이면 클릭 처리
            if ($fisherman->isInMinigame()) {
                $fisherman->getMinigame()->onClick();
                return ItemUseResult::SUCCESS();
            }
            if (!$fisherman->isFishing()) $fisherman->start(); else $fisherman->stop();
        }
        return ItemUseResult::SUCCESS();
    }
}