<?php

namespace anaf2197\fishing;

final class FishingManager implements \JsonSerializable {

    /** @var Fish[] 전체 물고기 창고 (등록만 된 상태) */
    protected array $fishes;

    /** @var Bait[] */
    protected array $baits;

    /**
     * 관리자가 GUI로 직접 활성화한 물고기 풀
     * 이 목록에 있는 물고기만 유저가 낚시로 잡을 수 있음
     * 구조: [ fishName => true ]
     * @var array<string, bool>
     */
    protected array $activeFishes;

    public function __construct(array $fishDatas, array $baitDatas, array $activeFishes = []) {
        $this->fishes = array_map(function (array $fishData): Fish {
            return Fish::jsonDeserialize($fishData);
        }, $fishDatas);
        $this->baits = array_map(function (array $baitData): Bait {
            return Bait::jsonDeserialize($baitData);
        }, $baitDatas);
        $this->activeFishes = $activeFishes;
    }

    // ─── 전체 창고 (관리자 등록/제거용) ───────────────────────────

    public function getFishes(bool $includeSpecial = true): array {
        return $includeSpecial ? $this->fishes : array_filter($this->fishes, fn(Fish $f) => !$f->isSpecial());
    }

    public function getSpecialFishes(): array {
        return array_filter($this->fishes, fn(Fish $f) => $f->isSpecial());
    }

    public function getFish(string $fishName): ?Fish {
        return $this->fishes[$fishName] ?? null;
    }

    public function addFish(Fish $fish): void {
        $this->fishes[$fish->getName()] = $fish;
    }

    public function removeFish(string $fishName): void {
        unset($this->fishes[$fishName]);
        // 활성 풀에서도 함께 제거
        unset($this->activeFishes[$fishName]);
    }

    // ─── 활성 풀 (낚시로 실제 잡히는 물고기) ─────────────────────

    /** 활성 풀에 물고기 추가 */
    public function activateFish(string $fishName): bool {
        if ($this->getFish($fishName) === null) return false;
        $this->activeFishes[$fishName] = true;
        return true;
    }

    /** 활성 풀에서 물고기 제거 */
    public function deactivateFish(string $fishName): void {
        unset($this->activeFishes[$fishName]);
    }

    /** 활성 풀에 있는지 확인 */
    public function isActiveFish(string $fishName): bool {
        return isset($this->activeFishes[$fishName]);
    }

    /**
     * 낚시로 잡힐 수 있는 물고기 목록 반환
     * $specialOnly = true  → L등급(특수) 물고기만
     * $specialOnly = false → 일반 물고기만
     */
    public function getActiveFishes(bool $specialOnly = false): array {
        $result = [];
        foreach ($this->activeFishes as $fishName => $_) {
            $fish = $this->getFish($fishName);
            if ($fish === null) continue;
            if ($specialOnly && !$fish->isSpecial()) continue;
            if (!$specialOnly && $fish->isSpecial()) continue;
            $result[$fishName] = $fish;
        }
        return $result;
    }

    // ─── Bait ────────────────────────────────────────────────────

    public function getBaits(): array { return $this->baits; }
    public function getBait(string $baitName): ?Bait { return $this->baits[$baitName] ?? null; }
    public function addBait(Bait $bait): void { $this->baits[$bait->getName()] = $bait; }
    public function removeBait(string $baitName): void { unset($this->baits[$baitName]); }

    // ─── Serialization ────────────────────────────────────────────

    public function jsonSerialize(): array {
        return [
            array_map(fn(Fish $f) => $f->jsonSerialize(), $this->fishes),
            array_map(fn(Bait $b) => $b->jsonSerialize(), $this->baits),
            $this->activeFishes,
        ];
    }

    public static function jsonDeserialize(array $data): self {
        // 하위 호환: 기존 저장 데이터에 activeFishes 없으면 빈 배열
        $data[2] = $data[2] ?? [];
        return new self(...$data);
    }
}