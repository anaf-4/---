<?php

declare(strict_types=1);

namespace anaf2197\fishing\event;

use pocketmine\event\player\PlayerEvent;
use pocketmine\item\Item;
use pocketmine\player\Player;

final class FishingEvent extends PlayerEvent {
    public function __construct(
        protected Player $player,
        private Item $item
    )
    {
    }

    public function getItem(): Item
    {
        return $this->item;
    }

    public function setItem(Item $item): void
    {
        $this->item = $item;
    }
}