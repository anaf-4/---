<?php

namespace anaf2197\fishing;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerItemHeldEvent;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\item\Item;
use pocketmine\item\VanillaItems;
use pocketmine\nbt\tag\StringTag;

final class EventListener implements Listener {

    private FishingManager $fishingManager;
    /** @var array<string, float> */
    private array $useCooldown = [];

    public function __construct(private readonly FishingLoader $plugin) {
        $this->fishingManager = $this->plugin->getFishingManager();
    }

    public function onPlayerJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        if (is_null($this->plugin->getFisherman($player))) {
            $this->plugin->newFisherman($player);
        }
    }

    public function onPlayerItemUse(PlayerItemUseEvent $event): void {
        $item = $event->getItem();
        if (!($item->getNamedTag()->getTag(Bait::TAG_BAIT) instanceof StringTag)) return;
        $player = $event->getPlayer();
        $name = strtolower($player->getName());
        $now = microtime(true);
        if (isset($this->useCooldown[$name]) && $now - $this->useCooldown[$name] < 0.5) return;
        $this->useCooldown[$name] = $now;
        $this->processBait($player, $item);
    }

    /**
     * @priority HIGHEST
     * @handleCancelled true
     */
    public function onPlayerInteract(PlayerInteractEvent $event): void {
        if ($event->getAction() === PlayerInteractEvent::LEFT_CLICK_BLOCK) return;
        $item = $event->getItem();
        if (!($item->getNamedTag()->getTag(Bait::TAG_BAIT) instanceof StringTag)) return;
        $player = $event->getPlayer();
        $name = strtolower($player->getName());
        $now = microtime(true);
        if (isset($this->useCooldown[$name]) && $now - $this->useCooldown[$name] < 0.5) return;
        $this->useCooldown[$name] = $now;
        $event->cancel();
        $this->processBait($player, $item);
    }

    private function processBait(\pocketmine\player\Player $player, Item $item): void {
        $tag = $item->getNamedTag()->getTag(Bait::TAG_BAIT);
        if (!($tag instanceof StringTag)) return;
        if (!($this->fishingManager->getBait($tag->getValue()) instanceof Bait)) {
            $player->sendMessage(FishingLoader::$prefix . '현재 사용이 불가한 미끼입니다.');
            return;
        }
        $playerName = $player->getName();
        $fisherman = $this->plugin->getFisherman($player);
        $isSneaking = $player->isSneaking();
        $addCount = $isSneaking ? min(64, $item->getCount()) : 1;
        $existingBait = $fisherman->getBaitItem();
        if ($existingBait instanceof Item) {
            $existingTag = $existingBait->getNamedTag()->getTag(Bait::TAG_BAIT);
            if ($existingTag instanceof StringTag && $existingTag->getValue() === $tag->getValue()) {
                $existingBait->setCount($existingBait->getCount() + $addCount);
            } else {
                $fisherman->pickoutBait();
                $baitItem = clone $item;
                $baitItem->setCount($addCount);
                $fisherman->setBaitItem($baitItem);
            }
        } else {
            $baitItem = clone $item;
            $baitItem->setCount($addCount);
            $fisherman->setBaitItem($baitItem);
        }
        $this->plugin->saveFisherman($playerName, $fisherman);
        $item->setCount($item->getCount() - $addCount);
        if ($item->getCount() <= 0) {
            $player->getInventory()->setItemInHand(VanillaItems::AIR());
        } else {
            $player->getInventory()->setItemInHand($item);
        }
        $currentCount = $fisherman->getBaitItem()->getCount();
        $player->sendMessage(FishingLoader::$prefix . '해당 미끼를 장착했습니다. (남은 미끼: ' . $currentCount . '개)');
    }

    public function onPlayerItemHeld(PlayerItemHeldEvent $event): void {
        $fisherman = FishingLoader::getInstance()->getFisherman($event->getPlayer());
        if ($fisherman instanceof Fisherman)
            if ($fisherman->isFishing()) $fisherman->stop();
    }
}