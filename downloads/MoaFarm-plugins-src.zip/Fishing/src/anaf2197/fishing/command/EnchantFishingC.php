<?php
declare(strict_types=1);

namespace anaf2197\fishing\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\StringToEnchantmentParser;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\permission\DefaultPermissionNames;
use pocketmine\player\Player;
use anaf2197\fishing\FishingLoader;
use anaf2197\fishing\item\FishingRod;

class EnchantFishingC extends Command
{
    public function __construct()
    {
        parent::__construct('낚시강화', '낚싯대를 강화합니다.', '/낚시강화', ['낚싯대강화']);
        $this->setPermission(DefaultPermissionNames::GROUP_USER);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void
    {
        if (!$sender instanceof Player || !$this->testPermission($sender)) return;
        $item = $sender->getInventory()->getItemInHand();

        // 낚싯대 없을 때 스펙만 표시
        if (!$item instanceof FishingRod) {
            $sender->sendMessage(FishingLoader::$prefix . '낚싯대를 들고 다시 시도해주세요.');
            $this->sendSpec($sender, 0);
            return;
        }

        $level = $item->getEnchantmentLevel(VanillaEnchantments::FORTUNE());

        // 서브 커맨드: 스펙 확인
        if (($args[0] ?? '') === '스펙') {
            $this->sendSpec($sender, $level);
            return;
        }

        if ($level >= count(FishingLoader::ENFORCE_STONE_COUNT)) {
            $sender->sendMessage(FishingLoader::$prefix . '해당 낚시대는 최고 레벨에 도달했습니다.');
            $this->sendSpec($sender, $level);
            return;
        }

        $requireItem = FishingLoader::getInstance()->getQuitItem();
        $requireItem->setCount(FishingLoader::ENFORCE_STONE_COUNT[$level]);
        if (!$sender->getInventory()->contains($requireItem)) {
            $sender->sendMessage(FishingLoader::$prefix . '강화석이 부족합니다. (필요: ' . FishingLoader::ENFORCE_STONE_COUNT[$level] . '개)');
            $this->sendSpec($sender, $level);
            return;
        }

        $sender->getInventory()->removeItem($requireItem);
        $rand = mt_rand(1, 100);
        if ($rand <= FishingLoader::ENFORCE_CHANCE[$level]) {
            $newLevel = $level + 1;
            $enhanced = $item->addEnchantment(new EnchantmentInstance(
                StringToEnchantmentParser::getInstance()->parse('fortune'),
                $newLevel
            ));
            $this->applyLore($enhanced, $newLevel);
            $sender->getInventory()->setItemInHand($enhanced);
            $sender->sendMessage(FishingLoader::$prefix . '낚싯대 ' . $newLevel . '강 강화에 성공했습니다!');
            $this->sendSpec($sender, $newLevel);
        } else {
            $sender->sendMessage(FishingLoader::$prefix . '강화에 실패했습니다. (' . FishingLoader::ENFORCE_CHANCE[$level] . '% 확률)');
            $this->sendSpec($sender, $level);
        }
    }

    private function applyLore(FishingRod $item, int $level): void
    {
        $maxLevel = count(FishingLoader::ENFORCE_STONE_COUNT);

        // 기존 스펙 로어 제거 (§8로 시작하는 줄들)
        $lore = array_filter($item->getLore(), fn(string $line) => !str_starts_with($line, '§8[낚싯대'));

        $lore[] = ' ';
        $lore[] = '§8[낚싯대 스펙]';
        $lore[] = '§8강화: §e' . $level . '강 §8/ §8' . $maxLevel . '강';
        $lore[] = '§8티어UP: §a+' . ($level * 2) . '%';
        if ($level < $maxLevel) {
            $lore[] = '§8다음 강화 확률: §8' . FishingLoader::ENFORCE_CHANCE[$level] . '%';
        } else {
            $lore[] = '§a§8최대 강화 달성!';
        }

        $item->setLore(array_values($lore));
    }

    private function sendSpec(CommandSender $sender, int $level): void
    {
        $maxLevel = count(FishingLoader::ENFORCE_STONE_COUNT);
        $sender->sendMessage('');
        $sender->sendMessage(FishingLoader::$prefix . '§l낚싯대 현재 스펙');
        $sender->sendMessage(FishingLoader::$prefix . '현재 강화 레벨: §e' . $level . '강 §8/ §f' . $maxLevel . '강');
        $sender->sendMessage(FishingLoader::$prefix . '티어 업그레이드: §a+' . ($level * 2) . '% §8(같은 물고기가 한 티어 높게 잡힐 확률)');

        if ($level < $maxLevel) {
            $sender->sendMessage(FishingLoader::$prefix . '다음 강화: §f강화석 ' . FishingLoader::ENFORCE_STONE_COUNT[$level] . '개 §8필요 / 성공 확률 §e' . FishingLoader::ENFORCE_CHANCE[$level] . '%');
        } else {
            $sender->sendMessage(FishingLoader::$prefix . '§a최대 강화 완료!');
        }

        $sender->sendMessage(FishingLoader::$prefix . '§8[강화 확률표] 1강:100% / 2강:80% / 3강:50% / 4강:25% / 5강:10%');
        $sender->sendMessage('');
    }
}