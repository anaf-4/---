<?php

namespace anaf2197\fishing\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\fishing\FishingLoader;

final class PickoutBaitCommand extends Command {

    public function __construct(private readonly FishingLoader $plugin) {
        parent::__construct('미끼빼기', '현재 낚시대에 장착된 미끼를 뺍니다.');
        $this->setPermission(DefaultPermissions::ROOT_USER);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($sender instanceof Player and $this->testPermission($sender)) {
            $this->plugin->getFisherman($sender)->pickoutBait(true);
        }
    }
}