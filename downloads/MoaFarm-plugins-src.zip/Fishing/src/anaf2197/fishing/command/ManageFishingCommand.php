<?php

namespace anaf2197\fishing\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\fishing\Bait;
use anaf2197\fishing\Fish;
use anaf2197\fishing\FishingLoader;
use anaf2197\fishing\FishingManager;
use anaf2197\fishing\gui\FishManagementGUI;
use anaf2197\lib\itemparser\ItemParser;

final class ManageFishingCommand extends Command {

    public function __construct(private readonly FishingManager $fishingManager) {
        parent::__construct('낚시관리', '낚시 관리 명령어입니다.');
        $this->setPermission(DefaultPermissions::ROOT_OPERATOR);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if (!($sender instanceof Player) || !$this->testPermission($sender)) return;

        $tiers = Fish::getTiers();
        $subCommand = array_shift($args);

        switch ($subCommand) {

            // ── 물고기 추가 ──────────────────────────────────────────
            case '물고기추가':
                $name = implode(' ', array_slice($args, 0, -1));
                $type = end($args);
                if (trim((string)$type) !== '' && trim($name) !== '') {
                    if (in_array($type, ['일반', '특수'])) {
                        if (is_null($this->fishingManager->getFish($name))) {
                            $item = $sender->getInventory()->getItemInHand();
                            if (!$item->isNull()) {
                                $this->fishingManager->addFish(new Fish($name, ItemParser::toString($item->setCount(1)), $type === '특수'));
                                $sender->sendMessage(FishingLoader::$prefix . '새로운 물고기를 추가했습니다.');
                                $sender->sendMessage(FishingLoader::$prefix . '§8낚시로 잡히게 하려면 /낚시관리 물고기활성 으로 활성화하세요.');
                            } else {
                                $sender->sendMessage(FishingLoader::$prefix . '공기는 물고기로 추가할 수 없습니다.');
                            }
                        } else {
                            $sender->sendMessage(FishingLoader::$prefix . '이미 생성된 물고기 이름입니다.');
                        }
                    } else {
                        $sender->sendMessage(FishingLoader::$prefix . '물고기 타입을 확인해주세요. [일반/특수]');
                    }
                } else {
                    $sender->sendMessage(FishingLoader::$prefix . '/낚시관리 물고기추가 [이름] [일반/특수]');
                }
                break;

            // ── 물고기 제거 (전역 창고에서 삭제) ────────────────────
            case '물고기제거':
                if (empty($args)) {
                    (new FishManagementGUI($this->fishingManager))->send($sender);
                } else {
                    $name = implode(' ', $args);
                    if (trim($name) !== '') {
                        if (!is_null($this->fishingManager->getFish($name))) {
                            $this->fishingManager->removeFish($name);
                            $sender->sendMessage(FishingLoader::$prefix . '해당 물고기를 제거했습니다.');
                        } else {
                            $sender->sendMessage(FishingLoader::$prefix . '생성되지 않은 물고기 이름입니다.');
                        }
                    }
                }
                break;

            // ── 물고기활성: 낚시로 잡힐 풀 GUI 관리 ────────────────
            case '물고기활성':
                /*
                 * /낚시관리 물고기활성
                 *   → GUI 열기 (클릭으로 활성/비활성 토글)
                 *
                 * /낚시관리 물고기활성 추가 [물고기명]
                 * /낚시관리 물고기활성 제거 [물고기명]
                 * /낚시관리 물고기활성 목록
                 */
                $action = array_shift($args);

                if ($action === null) {
                    (new FishManagementGUI($this->fishingManager))->sendActivePool($sender);
                    break;
                }

                switch ($action) {
                    case '추가':
                        $fishName = implode(' ', $args);
                        if (trim($fishName) === '') {
                            $sender->sendMessage(FishingLoader::$prefix . '/낚시관리 물고기활성 추가 [물고기명]');
                            break;
                        }
                        if ($this->fishingManager->activateFish($fishName)) {
                            $sender->sendMessage(FishingLoader::$prefix . "§a{$fishName}§f을 낚시 풀에 추가했습니다.");
                        } else {
                            $sender->sendMessage(FishingLoader::$prefix . '존재하지 않는 물고기입니다.');
                        }
                        break;

                    case '제거':
                        $fishName = implode(' ', $args);
                        if (trim($fishName) === '') {
                            $sender->sendMessage(FishingLoader::$prefix . '/낚시관리 물고기활성 제거 [물고기명]');
                            break;
                        }
                        $this->fishingManager->deactivateFish($fishName);
                        $sender->sendMessage(FishingLoader::$prefix . "§c{$fishName}§f을 낚시 풀에서 제거했습니다.");
                        break;

                    case '목록':
                        $normal  = $this->fishingManager->getActiveFishes(false);
                        $special = $this->fishingManager->getActiveFishes(true);
                        $sender->sendMessage(FishingLoader::$prefix . '=== 낚시 활성 풀 ===');
                        $sender->sendMessage(FishingLoader::$prefix . '일반(' . count($normal) . '): ' . (empty($normal) ? '없음' : implode(', ', array_keys($normal))));
                        $sender->sendMessage(FishingLoader::$prefix . '특수(' . count($special) . '): ' . (empty($special) ? '없음' : implode(', ', array_keys($special))));
                        break;

                    default:
                        $sender->sendMessage(FishingLoader::$prefix . '/낚시관리 물고기활성 [추가/제거/목록]');
                        break;
                }
                break;

            // ── 물고기 지급/목록 ─────────────────────────────────────
            case '물고기지급':
                $name = implode(' ', $args);
                if (trim($name) !== '') {
                    $fish = $this->fishingManager->getFish($name);
                    if (!is_null($fish)) {
                        foreach (Fish::getTiers() as $tier) {
                            $sender->getInventory()->addItem($fish->asItem($tier));
                        }
                        $sender->sendMessage(FishingLoader::$prefix . '해당 물고기를 등급별로 지급했습니다.');
                    } else {
                        $sender->sendMessage(FishingLoader::$prefix . '생성되지 않은 물고기 이름입니다.');
                    }
                } else {
                    $sender->sendMessage(FishingLoader::$prefix . '/낚시관리 물고기지급 [이름]');
                }
                break;

            case '물고기목록':
                $fishes = $this->fishingManager->getFishes();
                $sender->sendMessage(FishingLoader::$prefix . '전체 물고기 ' . count($fishes) . '종류');
                $sender->sendMessage(FishingLoader::$prefix . '목록: ' . implode(', ', array_keys($fishes)));
                break;

            // ── 미끼 ─────────────────────────────────────────────────
            case '미끼추가':
                $name = implode(' ', array_slice($args, 0, -1));
                $shorteningPercent = end($args);
                if (trim((string)$shorteningPercent) !== '' && trim($name) !== '') {
                    if (is_numeric($shorteningPercent)) {
                        if ($shorteningPercent < 100) {
                            if (is_null($this->fishingManager->getBait($name))) {
                                $item = $sender->getInventory()->getItemInHand();
                                if (!$item->isNull()) {
                                    $this->fishingManager->addBait(new Bait($name, ItemParser::toString($item->setCount(1)), $shorteningPercent));
                                    $sender->sendMessage(FishingLoader::$prefix . '새로운 미끼를 추가했습니다.');
                                } else {
                                    $sender->sendMessage(FishingLoader::$prefix . '공기는 미끼로 추가할 수 없습니다.');
                                }
                            } else {
                                $sender->sendMessage(FishingLoader::$prefix . '이미 생성된 미끼 이름입니다.');
                            }
                        } else {
                            $sender->sendMessage(FishingLoader::$prefix . '100% 미만으로 입력해주세요.');
                        }
                    } else {
                        $sender->sendMessage(FishingLoader::$prefix . '퍼센트를 숫자로 입력해주세요.');
                    }
                } else {
                    $sender->sendMessage(FishingLoader::$prefix . '/낚시관리 미끼추가 [이름] [단축 퍼센트]');
                }
                break;

            case '미끼제거':
                $name = implode(' ', $args);
                if (trim($name) !== '') {
                    if (!is_null($this->fishingManager->getBait($name))) {
                        $this->fishingManager->removeBait($name);
                        $sender->sendMessage(FishingLoader::$prefix . '해당 미끼를 제거했습니다.');
                    } else {
                        $sender->sendMessage(FishingLoader::$prefix . '생성되지 않은 미끼 이름입니다.');
                    }
                } else {
                    $sender->sendMessage(FishingLoader::$prefix . '/낚시관리 미끼제거 [이름]');
                }
                break;

            case '미끼지급':
                $name = implode(' ', $args);
                if (trim($name) !== '') {
                    $bait = $this->fishingManager->getBait($name);
                    if (!is_null($bait)) {
                        $sender->getInventory()->addItem($bait->asItem());
                        $sender->sendMessage(FishingLoader::$prefix . '해당 미끼를 지급받았습니다.');
                    } else {
                        $sender->sendMessage(FishingLoader::$prefix . '생성되지 않은 미끼 이름입니다.');
                    }
                } else {
                    $sender->sendMessage(FishingLoader::$prefix . '/낚시관리 미끼지급 [이름]');
                }
                break;

            case '미끼목록':
                $baits = $this->fishingManager->getBaits();
                $sender->sendMessage(FishingLoader::$prefix . '생성된 미끼 ' . count($baits) . '종류');
                $sender->sendMessage(FishingLoader::$prefix . '목록: ' . implode(', ', array_keys($baits)));
                break;

            // ── 강화석 ───────────────────────────────────────────────
            case '강화석지급':
                $amount = array_shift($args);
                if (is_numeric($amount) && (int)$amount > 0) {
                    for ($i = 0; $i < (int)$amount; $i++) {
                        $sender->getInventory()->addItem(FishingLoader::getInstance()->getQuitItem());
                    }
                    $sender->sendMessage(FishingLoader::$prefix . "강화석 {$amount}개를 지급했습니다.");
                } else {
                    $sender->sendMessage(FishingLoader::$prefix . '/낚시관리 강화석지급 [갯수]');
                }
                break;

            // ── 도움말 ───────────────────────────────────────────────
            default:
                $sender->sendMessage(FishingLoader::$prefix . '§e=== 물고기 창고 ===');
                $sender->sendMessage(FishingLoader::$prefix . '/낚시관리 물고기추가 [이름] [일반/특수]');
                $sender->sendMessage(FishingLoader::$prefix . '/낚시관리 물고기제거       §8- GUI로 등급별 제거');
                $sender->sendMessage(FishingLoader::$prefix . '/낚시관리 물고기제거 [이름] §8- 직접 제거');
                $sender->sendMessage(FishingLoader::$prefix . '/낚시관리 물고기지급 [이름]');
                $sender->sendMessage(FishingLoader::$prefix . '/낚시관리 물고기목록');
                $sender->sendMessage(FishingLoader::$prefix . '§e=== 낚시 풀 (실제로 잡히는 물고기) ===');
                $sender->sendMessage(FishingLoader::$prefix . '/낚시관리 물고기활성           §8- GUI로 활성/비활성 토글');
                $sender->sendMessage(FishingLoader::$prefix . '/낚시관리 물고기활성 추가 [이름]');
                $sender->sendMessage(FishingLoader::$prefix . '/낚시관리 물고기활성 제거 [이름]');
                $sender->sendMessage(FishingLoader::$prefix . '/낚시관리 물고기활성 목록');
                $sender->sendMessage(FishingLoader::$prefix . '§e=== 미끼 ===');
                $sender->sendMessage(FishingLoader::$prefix . '/낚시관리 미끼추가 [이름] [단축 퍼센트]');
                $sender->sendMessage(FishingLoader::$prefix . '/낚시관리 미끼제거 [이름]');
                $sender->sendMessage(FishingLoader::$prefix . '/낚시관리 미끼지급 [이름]');
                $sender->sendMessage(FishingLoader::$prefix . '/낚시관리 미끼목록');
                $sender->sendMessage(FishingLoader::$prefix . '§e=== 강화석 ===');
                $sender->sendMessage(FishingLoader::$prefix . '/낚시관리 강화석지급 [갯수]');
                $sender->sendMessage(FishingLoader::$prefix . '§8등급: ' . implode(', ', $tiers));
                break;
        }
    }
}