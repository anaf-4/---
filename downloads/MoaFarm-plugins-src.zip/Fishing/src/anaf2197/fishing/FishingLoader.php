<?php

namespace anaf2197\fishing;

use muqsit\invmenu\InvMenuHandler;
use Override\Override;
use pocketmine\data\bedrock\item\ItemTypeNames;
use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\EntityFactory;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemTypeIds;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;
use pocketmine\world\World;
use anaf2197\fishing\command\EnchantFishingC;
use anaf2197\fishing\command\ManageFishingCommand;
use anaf2197\fishing\command\PickoutBaitCommand;
use anaf2197\fishing\entity\FishingHook;
use anaf2197\fishing\item\FishingRod;
use anaf2197\fishing\utils\FishingUtils;
use anaf2197\lib\color\ServerColor;
use anaf2197\lib\provider\DataProvider;
use anaf2197\lib\provider\ProviderHandler;

final class FishingLoader extends PluginBase {

    public const HASH_FISHING = 'database';

    public const TIER_LIST = [
        Fish::TIER_D => 30,
        Fish::TIER_C => 55,
        Fish::TIER_B => 78,
        Fish::TIER_A => 92,
        Fish::TIER_L => 100
    ];
    public const ENFORCE_STONE_COUNT = [
        1,
        3,
        5,
        10,
        15
    ];

    public const ENFORCE_CHANCE = [
        100,
        80,
        50,
        25,
        10
    ];

    use SingletonTrait, FishingUtils;

    public static string $prefix;

    private FishingManager $fishingManager;
    private DataProvider $fishermanProvider;

    /** @var Fisherman[] */
    private array $fishermanCache = [];

    protected function onEnable(): void {
        // InvMenu 핸들러 등록
        if (!InvMenuHandler::isRegistered()) {
            InvMenuHandler::register($this);
        }
        
        $this->overrideFishingRod();
        $this->registerProvider();

        EntityFactory::getInstance()->register(
            FishingHook::class,
            function(World $world, CompoundTag $nbt): FishingHook {
                $dummyFisherman = new Fisherman('dummy', null);
                return new FishingHook(EntityDataHelper::parseLocation($nbt, $world), null, $dummyFisherman);
            },
            ['FishingHook']
        );

        $this->getServer()->getCommandMap()->registerAll(strtolower($this->getName()), [
            new ManageFishingCommand($this->fishingManager),
            new PickoutBaitCommand($this),
            new EnchantFishingC()
        ]);
        $this->getServer()->getPluginManager()->registerEvents(new EventListener($this), $this);
    }

    protected function onLoad(): void {
        self::setInstance($this);
        ServerColor::setPrefix($this, '낚시');
    }

    public function getFishermanProvider(): DataProvider {
        return $this->fishermanProvider;
    }

    protected function onDisable(): void {
        $this->saveDatabase();
    }

    public function saveDatabase(): void {
        $this->fishermanProvider->save();

        $provider = ProviderHandler::get($this);
        $provider->setObject(self::HASH_FISHING, $this->fishingManager);
        $provider->save();
    }

    private function registerProvider(): void {
        if (!ProviderHandler::isRegistered($this)) {
            ProviderHandler::register($this, FishingManager::class);
            $provider = ProviderHandler::get($this);
            if ($provider->getObject(self::HASH_FISHING) === null) {
                $provider->setObject(self::HASH_FISHING, new FishingManager([], []));
            }
            $this->fishingManager = $provider->getObject(self::HASH_FISHING);
        }
        $fishermanHash = 'fishermans';
        if (!ProviderHandler::isRegistered($this, $fishermanHash)) {
            ProviderHandler::register($this, Fisherman::class, $fishermanHash);
            $this->fishermanProvider = ProviderHandler::get($this, $fishermanHash);
        }
    }

    private function overrideFishingRod(): void {
        $fishingRod = new FishingRod(new ItemIdentifier(ItemTypeIds::FISHING_ROD), 'Fishing Rod');
        Override::override('fishing_rod', $fishingRod);
        Override::deserializer(ItemTypeNames::FISHING_ROD, $fishingRod, function () use ($fishingRod) {
            return clone $fishingRod;
        });
        Override::serializer(ItemTypeNames::FISHING_ROD, $fishingRod);
        Override::resetCreativeInventory();
    }

    public function getFishingManager(): FishingManager {
        return $this->fishingManager;
    }

    public function getFisherman($player): ?Fisherman {
        $name = strtolower($player instanceof Player ? $player->getName() : $player);

        // 캐시에서 먼저 확인
        if (isset($this->fishermanCache[$name])) {
            return $this->fishermanCache[$name];
        }

        // Provider에서 불러오기
        $fisherman = $this->fishermanProvider->getObject($name);
        if ($fisherman instanceof Fisherman) {
            $this->fishermanCache[$name] = $fisherman;
        }
        return $fisherman;
    }

    public function saveFisherman(string $playerName, Fisherman $fisherman): void {
        $name = strtolower($playerName);
        $this->fishermanCache[$name] = $fisherman;
        $this->fishermanProvider->setObject($name, $fisherman);
    }

    public function newFisherman($player): void {
        $name = strtolower($player instanceof Player ? $player->getName() : $player);
        $fisherman = new Fisherman($name, null);
        $this->fishermanCache[$name] = $fisherman;
        $this->fishermanProvider->setObject($name, $fisherman);
    }
}