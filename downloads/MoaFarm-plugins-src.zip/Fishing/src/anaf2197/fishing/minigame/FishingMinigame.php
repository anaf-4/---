<?php

declare(strict_types=1);

namespace anaf2197\fishing\minigame;

use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\player\Player;
use pocketmine\scheduler\Task;
use pocketmine\Server;
use anaf2197\fishing\FishingLoader;

/**
 * 낚시 미니게임
 *
 * 타이틀로 바를 표시하고, 커서가 좌우로 이동함
 * 초록 구간(고정)에 커서가 있을 때 클릭 → 성공
 * 빨강 구간에 커서가 있을 때 클릭 → 즉시 실패
 * 3~5번 성공 시 물고기 획득
 */
final class FishingMinigame extends Task {

    // 바 전체 길이 (칸 수)
    private const BAR_SIZE = 20;

    // 초록 구간 크기 (칸 수) - 바의 중앙 고정
    private const GREEN_SIZE = 5;

    // 커서 이동 방향: 1 = 오른쪽, -1 = 왼쪽
    private int $direction = 1;

    // 커서 현재 위치 (0 ~ BAR_SIZE-1)
    private int $cursorPos = 0;

    // 초록 구간 시작 위치 (고정, 바 중앙)
    private int $greenStart;

    // 성공 횟수
    private int $successCount = 0;

    // 필요한 성공 횟수 (3~5 랜덤)
    private int $requiredCount;

    // 미니게임 종료 여부
    private bool $finished = false;

    // 미니게임 결과 콜백: true=성공, false=실패
    /** @var callable(bool): void */
    private $onFinish;

    public function __construct(
        private readonly string $playerName,
        callable $onFinish
    ) {
        $this->onFinish = $onFinish;
        $this->requiredCount = mt_rand(3, 5);
        // 초록 구간: 바 중앙 고정
        $this->greenStart = (int) floor((self::BAR_SIZE - self::GREEN_SIZE) / 2);
    }

    public function onRun(): void {
        if ($this->finished) return;

        $player = Server::getInstance()->getPlayerExact($this->playerName);
        if (!$player instanceof Player || !$player->isConnected()) {
            $this->finish(false);
            return;
        }

        // 커서 이동
        $this->cursorPos += $this->direction;
        if ($this->cursorPos >= self::BAR_SIZE - 1) {
            $this->cursorPos = self::BAR_SIZE - 1;
            $this->direction = -1;
        } elseif ($this->cursorPos <= 0) {
            $this->cursorPos = 0;
            $this->direction = 1;
        }

        $this->sendBar($player);
    }

    /**
     * 플레이어가 클릭했을 때 호출
     */
    public function onClick(): void {
        if ($this->finished) return;

        $player = Server::getInstance()->getPlayerExact($this->playerName);
        if (!$player instanceof Player) return;

        if ($this->isCursorInGreen()) {
            // 성공 클릭 소리 (click 소리)
            $pos = $player->getPosition();
            $pk = new PlaySoundPacket();
            $pk->soundName = 'random.click';
            $pk->x = $pos->x;
            $pk->y = $pos->y;
            $pk->z = $pos->z;
            $pk->volume = 1.0;
            $pk->pitch = 1.5;
            $player->getNetworkSession()->sendDataPacket($pk);

            $this->successCount++;
            $player->sendMessage(FishingLoader::$prefix . '§a성공! (' . $this->successCount . '/' . $this->requiredCount . ')');

            if ($this->successCount >= $this->requiredCount) {
                $this->finish(true);
            }
        } else {
            // 실패 - 빨강 구간 클릭
            $player->sendMessage(FishingLoader::$prefix . '§c타이밍을 놓쳐 물고기가 도망갔습니다!');
            $this->finish(false);
        }
    }

    /**
     * 커서가 초록 구간 안에 있는지 확인
     */
    public function isCursorInGreen(): bool {
        return $this->cursorPos >= $this->greenStart
            && $this->cursorPos < $this->greenStart + self::GREEN_SIZE;
    }

    /**
     * 타이틀로 바 표시
     *
     * 예시:
     * §c|||||§a|||||§c||●||§c|||||
     * 위쪽: 바
     * 아래쪽: [성공횟수/필요횟수] 낚싯대를 클릭하세요!
     */
    private function sendBar(Player $player): void {
        $bar = '';
        for ($i = 0; $i < self::BAR_SIZE; $i++) {
            $inGreen = ($i >= $this->greenStart && $i < $this->greenStart + self::GREEN_SIZE);

            if ($i === $this->cursorPos) {
                // 커서: 초록이면 §a●, 빨강이면 §c●
                $bar .= ($inGreen ? '§a' : '§c') . '●';
            } else {
                // 일반 바: 초록이면 §a|, 빨강이면 §c|
                $bar .= ($inGreen ? '§a' : '§c') . '|';
            }
        }

        $subtitle = '§f(' . $this->successCount . '/' . $this->requiredCount . ') §e낚싯대를 클릭하세요!';
        $player->sendTitle($bar, $subtitle, 0, 4, 0);
    }

    private function finish(bool $success): void {
        $this->finished = true;
        if ($this->getHandler() !== null) {
            $this->getHandler()->cancel();
        }

        $player = Server::getInstance()->getPlayerExact($this->playerName);
        if ($player instanceof Player) {
            // 타이틀 제거
            $player->sendTitle('', '', 0, 0, 0);

            // 사운드 재생
            $pos = $player->getPosition();
            $pk = new PlaySoundPacket();
            $pk->soundName = $success ? 'note.bell' : 'random.explode';
            $pk->x = $pos->x;
            $pk->y = $pos->y;
            $pk->z = $pos->z;
            $pk->volume = 1.0;
            $pk->pitch = 1.0;
            $player->getNetworkSession()->sendDataPacket($pk);
        }

        ($this->onFinish)($success);
    }

    public function isFinished(): bool {
        return $this->finished;
    }
}