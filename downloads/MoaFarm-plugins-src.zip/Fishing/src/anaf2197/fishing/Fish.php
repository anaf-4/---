<?php
namespace anaf2197\fishing;

use pocketmine\item\Item;
use anaf2197\lib\itemparser\ItemParser;

final class Fish implements \JsonSerializable {
    
    public const TIER_L = 'l';
    public const TIER_A = 'a';
    public const TIER_B = 'b';
    public const TIER_C = 'c';
    public const TIER_D = 'd';
    
    private Item $basicItem;
    private Item $fishItem;
    private array $disabledTiers = [];
    
    public function __construct(
        private readonly string $name,
        string $itemData,
        private readonly bool $special,
        array $disabledTiers = []
    ) {
        $this->basicItem = ItemParser::fromString($itemData);
        $this->fishItem = clone $this->basicItem;
        $this->disabledTiers = $disabledTiers;
    }
    
    public function getName(): string {
        return $this->name;
    }
    
    public function isSpecial(): bool {
        return $this->special;
    }
    
    /**
     * 특정 등급을 비활성화
     */
    public function disableTier(string $tier): void {
        if (!in_array($tier, $this->disabledTiers)) {
            $this->disabledTiers[] = $tier;
        }
    }
    
    /**
     * 특정 등급을 활성화
     */
    public function enableTier(string $tier): void {
        $this->disabledTiers = array_filter($this->disabledTiers, fn($t) => $t !== $tier);
    }
    
    /**
     * 등급이 활성화되어 있는지 확인
     */
    public function isTierEnabled(string $tier): bool {
        return !in_array($tier, $this->disabledTiers);
    }
    
    /**
     * 비활성화된 등급 목록 반환
     */
    public function getDisabledTiers(): array {
        return $this->disabledTiers;
    }
    
    /**
     * 활성화된 등급 목록 반환
     */
    public function getEnabledTiers(): array {
        return array_filter(self::getTiers(), fn($tier) => $this->isTierEnabled($tier));
    }
    
    public function asItem(string $tier = self::TIER_D): Item {
        $color = match ($tier) {
            self::TIER_L => '6',
            self::TIER_A => 'a',
            self::TIER_B => 'b',
            self::TIER_C => 'c',
            default => '3'
        };
        $this->fishItem->setCustomName('§r§l§' . $color . '[' . strtoupper($tier) . ']§r§f ' . $this->name);
        return clone $this->fishItem;
    }
    
    public static function getTiers(): array {
        return [
            self::TIER_L,
            self::TIER_A,
            self::TIER_B,
            self::TIER_C,
            self::TIER_D
        ];
    }
    
    public function jsonSerialize(): array {
        return [
            $this->name,
            ItemParser::toString($this->basicItem),
            $this->special,
            $this->disabledTiers
        ];
    }
    
    public static function jsonDeserialize(array $data): self {
        // 하위 호환성: disabledTiers가 없으면 빈 배열 사용
        if (!isset($data[3])) {
            $data[3] = [];
        }
        return new self(...$data);
    }
}