<?php

namespace anaf2197\fishing\utils;

use pocketmine\item\Item;
use pocketmine\item\VanillaItems;
use anaf2197\servercore\item\ItemDesign;
use anaf2197\servercore\item\ItemTypes;

trait FishingUtils {
    public function getQuitItem(): Item
    {
        $item = VanillaItems::PAPER();
        ItemDesign::setItemDesign($item, ItemTypes::UNIQUE, '낚싯대 강화석', [
            '낚싯대 강화에 사용됩니다..',
        ], '/낚시강화');
        return $item;
    }
}