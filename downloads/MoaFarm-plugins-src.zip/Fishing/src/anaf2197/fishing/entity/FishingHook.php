<?php

namespace anaf2197\fishing\entity;

use pocketmine\block\Block;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\entity\Location;
use pocketmine\entity\projectile\Throwable;
use pocketmine\math\RayTraceResult;
use pocketmine\math\Vector3;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;
use pocketmine\player\Player;
use anaf2197\advancedprefix\AdvancedPrefix;
use anaf2197\fishing\Bait;
use anaf2197\fishing\Fisherman;
use anaf2197\fishing\FishingLoader;

final class FishingHook extends Throwable {

    private int $tick;
    private string $nickname;

    public function __construct(Location $location, ?Player $player, private readonly Fisherman $fisherman) {
        parent::__construct($location, $player);
        $this->setCanSaveWithChunk(false);
        $this->setNameTagAlwaysVisible();
        $this->setMotion($player->getDirectionVector()->multiply(0.35));
        $this->tick = 20 * 10;
        $bait = $this->fisherman->getBait();
        if ($bait instanceof Bait) {
            $shorteningPercent = $bait->getShorteningPercent();
            if ($shorteningPercent > 0) {
                $this->tick *= (1.0 - ($shorteningPercent / 100));
                $this->tick = round($this->tick, 1);
            }
        } else $this->fisherman->closeHook();
        $this->nickname = AdvancedPrefix::getInstance()->getPlayerPrefix($player)?->getNowNickname();
    }

    public static function getNetworkTypeId(): string {
        return EntityIds::FISHING_HOOK;
    }

    protected function getInitialSizeInfo(): EntitySizeInfo {
        return new EntitySizeInfo(0.25, 0.25);
    }

    private bool $isTouchingWater = false;

    protected function updateMovement(bool $teleport = false): void {
        if (!$this->isTouchingWater) parent::updateMovement($teleport);
    }

    protected function onHitBlock(Block $blockHit, RayTraceResult $hitResult): void {
        $this->blockHit = $blockHit->getPosition()->asVector3();
    }

    protected function entityBaseTick(int $tickDiff = 1): bool {
        /** @var Player $player */
        $player = $this->getOwningEntity();
        if ($player instanceof Player and $player->isConnected()) {
            $bait = $this->fisherman->getBait();
            if ($bait instanceof Bait) {
                if ($this->blockHit instanceof Vector3 and !$this->isUnderwater()) {
                    $this->fisherman->closeHook();
                    $player->sendMessage(FishingLoader::$prefix . '낚시는 물 속에서만 할 수 있습니다.');
                } else if ($this->isTouchingWater) {
                    $this->tick--;
                    if ($this->tick % 2 === 0) {
                        $this->updateNameTag();
                        $player->sendActionBarMessage('[장착한 미끼: ' . $bait->getName() . ' ' . $this->fisherman->getBaitItem()->getCount() . '개]');
                    }
                    if ($this->tick + (20 * 5) < 0) {
                        $this->fisherman->closeHook();
                        $player->sendMessage(FishingLoader::$prefix . '물고기가 미끼만 먹고 도망갔습니다.');
                        $this->fisherman->getBaitItem()->setCount($this->fisherman->getBaitItem()->getCount() - 1);
                    }
                } else if ($this->isUnderwater()) {
                    $this->isTouchingWater = true;
                    $this->gravity = 0;
                }
            } else $this->fisherman->closeHook();
        } else $this->fisherman->closeHook();
        return parent::entityBaseTick($tickDiff);
    }

    public function canPullup(): bool {
        return 0 > $this->tick and $this->tick + (20 * 5) > 0;
    }

    private function updateNameTag(): void {
        if ($this->canPullup()) {
            $this->setNameTag('§l§c!!!');
        } else {
            $this->setNameTag('§r§f' . $this->nickname . '§r§f님의 낚시 찌' . "\n§r§e[" . round($this->tick / 20, 1) . '초]');
        }
    }
}