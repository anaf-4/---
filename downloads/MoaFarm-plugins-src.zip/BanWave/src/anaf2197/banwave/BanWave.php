<?php
declare(strict_types=1);

namespace anaf2197\banwave;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;

final class BanWave extends PluginBase {

    use SingletonTrait;

    /** @var array<string, array{reason: string, addedBy: string, addedAt: int}> */
    private array $queue = [];

    protected function onLoad(): void {
        self::setInstance($this);
    }

    protected function onEnable(): void {
        $this->loadQueue();
        $this->getLogger()->info('BanWave 활성화 (대기: ' . count($this->queue) . '명)');
    }

    protected function onDisable(): void {
        $this->saveQueue();
    }

    private function loadQueue(): void {
        $file = $this->getDataFolder() . 'queue.json';
        if (is_file($file)) {
            $data = json_decode(file_get_contents($file), true);
            $this->queue = is_array($data) ? $data : [];
        }
    }

    private function saveQueue(): void {
        @mkdir($this->getDataFolder(), 0777, true);
        file_put_contents($this->getDataFolder() . 'queue.json', json_encode($this->queue, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        switch ($command->getName()) {
            case '밴웨이브추가':
                return $this->cmdAdd($sender, $args);
            case '밴웨이브제거':
                return $this->cmdRemove($sender, $args);
            case '밴웨이브목록':
                return $this->cmdList($sender);
            case '밴웨이브실행':
                return $this->cmdExecute($sender);
        }
        return false;
    }

    private function cmdAdd(CommandSender $sender, array $args): bool {
        if (count($args) < 2) {
            $sender->sendMessage('§c사용법: /밴웨이브추가 [플레이어] [사유]');
            return true;
        }
        $target = strtolower(array_shift($args));
        $reason = implode(' ', $args);

        if (isset($this->queue[$target])) {
            $sender->sendMessage("§e[BanWave] §f{$target}§8은 이미 대기 목록에 있습니다.");
            return true;
        }

        $this->queue[$target] = [
            'reason'   => $reason,
            'addedBy'  => $sender->getName(),
            'addedAt'  => time(),
        ];
        $this->saveQueue();
        $sender->sendMessage("§a[BanWave] §f{$target}§a를 밴웨이브 목록에 추가했습니다. (사유: {$reason})");
        $this->getLogger()->info("[BanWave] 추가: {$target} by {$sender->getName()} - {$reason}");
        return true;
    }

    private function cmdRemove(CommandSender $sender, array $args): bool {
        if (empty($args[0])) {
            $sender->sendMessage('§c사용법: /밴웨이브제거 [플레이어]');
            return true;
        }
        $target = strtolower($args[0]);
        if (!isset($this->queue[$target])) {
            $sender->sendMessage("§c[BanWave] §f{$target}§c은 목록에 없습니다.");
            return true;
        }
        unset($this->queue[$target]);
        $this->saveQueue();
        $sender->sendMessage("§a[BanWave] §f{$target}§a를 목록에서 제거했습니다.");
        return true;
    }

    private function cmdList(CommandSender $sender): bool {
        if (empty($this->queue)) {
            $sender->sendMessage('§8[BanWave] 대기 목록이 비어 있습니다.');
            return true;
        }
        $sender->sendMessage('§c━━━━━━━━ BanWave 대기 목록 (' . count($this->queue) . '명) ━━━━━━━━');
        foreach ($this->queue as $name => $data) {
            $time = date('m/d H:i', $data['addedAt']);
            $sender->sendMessage("§f{$name} §8| 사유: §e{$data['reason']} §8| 추가: §b{$data['addedBy']} ({$time})");
        }
        $sender->sendMessage('§c━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        return true;
    }

    private function cmdExecute(CommandSender $sender): bool {
        if (empty($this->queue)) {
            $sender->sendMessage('§8[BanWave] 대기 목록이 비어 있습니다.');
            return true;
        }

        $count    = count($this->queue);
        $banList  = $this->getServer()->getNameBans();
        $executed = 0;

        foreach ($this->queue as $name => $data) {
            $banList->addBan($name, 'BanWave: ' . $data['reason'], null, $sender->getName());
            $player = $this->getServer()->getPlayerExact($name);
            if ($player !== null) {
                $player->kick('§c[BanWave] 계정이 정지됐습니다. 사유: ' . $data['reason']);
            }
            $this->getLogger()->warning("[BanWave] 밴 실행: {$name} (사유: {$data['reason']}) by {$sender->getName()}");
            $executed++;
        }

        $this->queue = [];
        $this->saveQueue();

        $this->getServer()->broadcastMessage("§c[BanWave] 서버 정화 작업이 완료됐습니다. 총 §f{$executed}§c명이 처리됐습니다.");
        $sender->sendMessage("§a[BanWave] {$executed}명을 밴 처리했습니다.");
        return true;
    }
}
