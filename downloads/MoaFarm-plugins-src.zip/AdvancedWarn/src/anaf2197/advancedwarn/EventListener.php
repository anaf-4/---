<?php

namespace anaf2197\advancedwarn;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;

final class EventListener implements Listener {

    public function onPlayerJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        $playerWarn = AdvancedWarn::getInstance()->getPlayerWarn($player);
        if ($playerWarn instanceof PlayerWarn) {
            foreach ($playerWarn->getRecord() as $key => $value) {
                if (isset($value ['time-deadline'])) {
                    if (time() >= $value ['time-deadline']) {
                        AdvancedWarn::getInstance()->deleteWarn($player, $key);
                    }
                }
            }
            $isBanned = AdvancedWarn::getInstance()->isBannedPlayer($player);
            if ($isBanned) {
                $player->kick('§4차단된 닉네임입니다.§r', false, false);
            }
        } else {
            AdvancedWarn::getInstance()->setPlayerWarn(new PlayerWarn(strtolower($player->getName()), 0, []));
        }
    }
}