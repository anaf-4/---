<?php

namespace anaf2197\advancedwarn;


final class PlayerWarn implements \JsonSerializable {

    private AdvancedWarn $plugin;

    public function __construct(private string $name, protected int $count, protected array $record) {
        $this->plugin = AdvancedWarn::getInstance();
    }

    public function getName(): string {
        return $this->name;
    }

    public function getCount(): int {
        return $this->count;
    }

    public function getRecord(): array {
        return $this->record;
    }

    public function addWarn(int $amount, int $deadline, string $reason, string $supplier): void {
        $deadlineTimestamp = time() + (60 * 60 * 24 * $deadline);
        $this->count += $amount;
        $this->record[] = [
            'record-type'   => '지급',
            'date'          => date('Y.m.d. H:i'),
            'deadline'      => $deadline,
            'date-deadline' => date('Y년 n월 j일 H시 i분', $deadlineTimestamp),
            'amount'        => $amount,
            'time-deadline' => $deadlineTimestamp,
            'reason'        => $reason,
            'supplier'      => $supplier
        ];
    }

    public function deleteWarn(int $key): void {
        if (isset ($this->record [$key])) {
            $this->count -= $this->record [$key] ['amount'];
            $this->count = max(0, $this->count);
            unset ($this->record [$key]);
            $this->record = array_values($this->record);
        }
    }

    public function reduceWarn(int $amount, string $reason, string $supplier): void {
        $this->count -= $amount;
        $this->count = max(0, $this->count);
        $this->record [] = [
            'record-type' => '차감',
            'date' => date('Y.m.d. H:i'),
            'amount' => $amount,
            'reason' => $reason,
            'supplier' => $supplier
        ];
    }

    public function jsonSerialize(): array {
        return [
            $this->name,
            $this->count,
            $this->record
        ];
    }

    public static function jsonDeserialize(array $data): self {
        return new self (... $data);
    }
}