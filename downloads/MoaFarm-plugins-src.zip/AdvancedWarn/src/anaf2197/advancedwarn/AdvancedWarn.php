<?php

namespace anaf2197\advancedwarn;

use pocketmine\plugin\PluginBase;
use pocketmine\player\Player;
use pocketmine\utils\SingletonTrait;
use anaf2197\advancedwarn\command\AddWarnCommand;
use anaf2197\advancedwarn\command\CheckWarnCommand;
use anaf2197\advancedwarn\command\ReduceWarnCommand;
use anaf2197\advancedwarn\event\AddWarnEvent;
use anaf2197\advancedwarn\event\ReduceWarnEvent;
use anaf2197\lib\color\ServerColor;
use anaf2197\lib\provider\DataProvider;
use anaf2197\lib\provider\ProviderHandler;

final class AdvancedWarn extends PluginBase {

    use SingletonTrait {
        getInstance as protected _getInstance;
    }

    const BAN_WARN_COUNT = 10;

    public static string $prefix;

    private DataProvider $provider;

    private string $dbHost;
    private int    $dbPort;
    private string $dbUser;
    private string $dbPass;
    private string $dbName;
    private string $botUrl;

    private \mysqli $db;

    public function onLoad(): void {
        date_default_timezone_set('Asia/Seoul');
        self::setInstance($this);
        ServerColor::setPrefix($this, '경고');
        if (!ProviderHandler::isRegistered($this)) {
            ProviderHandler::register($this, PlayerWarn::class);
            $this->provider = ProviderHandler::get($this);
        }
    }

    public function onEnable(): void {
        $this->saveDefaultConfig();
        $cfg = $this->getConfig()->get('database');
        $this->dbHost = (string) $cfg['host'];
        $this->dbPort = (int)   $cfg['port'];
        $this->dbUser = (string) $cfg['username'];
        $this->dbPass = (string) $cfg['password'];
        $this->dbName = (string) $cfg['database'];
        $this->botUrl = (string) $this->getConfig()->get('bot_url', 'http://127.0.0.1:8765/warn');

        // MySQL 연결
        $this->db = new \mysqli(
            $this->dbHost,
            $this->dbUser,
            $this->dbPass,
            $this->dbName,
            $this->dbPort
        );

        if ($this->db->connect_error) {
            $this->getLogger()->error("MySQL 연결 실패: " . $this->db->connect_error);
            $this->getServer()->getPluginManager()->disablePlugin($this);
            return;
        }

        $this->getLogger()->info("MySQL 연결 성공!");
        $this->getServer()->getPluginManager()->registerEvents(new EventListener(), $this);
        $this->getServer()->getCommandMap()->registerAll(strtolower($this->getName()), [
            new AddWarnCommand(),
            new CheckWarnCommand(),
            new ReduceWarnCommand()
        ]);
    }

    protected function onDisable(): void {
        $this->saveDatabase();
        if (isset($this->db)) {
            $this->db->close();
        }
    }

    public function saveDatabase(): void {
        $this->provider->save();
    }

    public function getPlayerWarn($player): ?PlayerWarn {
        return $this->provider->getObject($player);
    }

    public function setPlayerWarn(PlayerWarn $playerWarn): void {
        $this->provider->setObject($playerWarn->getName(), $playerWarn);
    }

    public function isBannedPlayer($player): bool {
        $playerWarn = $this->getPlayerWarn($player);
        return $playerWarn->getCount() >= self::BAN_WARN_COUNT;
    }

    // ── 경고 추가 ─────────────────────────────────────────────
    public function addWarn($player, int $amount, int $deadline, string $reason = '시스템에 의한 경고', string $supplier = '시스템'): void {
        if ($amount >= 0) {
            $playerWarn = $this->getPlayerWarn($player);
            $isBanned   = $this->isBannedPlayer($player);
            $name       = strtolower($player instanceof Player ? $player->getName() : $player);

            $event = new AddWarnEvent($name, $playerWarn->getCount(), $amount, $deadline, $reason, $supplier);
            $event->call();

            if (!$event->isCancelled()) {
                $playerWarn->addWarn($amount, $deadline > 0 ? $deadline : PHP_INT_MAX, $reason, $supplier);
                $afterCount = $playerWarn->getCount();

                // 서버 브로드캐스트
                $content  = self::$prefix . $name . '§8님에게 경고가 지급되었습니다.';
                $content .= PHP_EOL . self::$prefix . '지급된 경고: ' . $amount;
                $content .= PHP_EOL . self::$prefix . '총 경고수: ' . $afterCount;
                $content .= PHP_EOL . self::$prefix . '지급된 사유: ' . $reason;
                if ($deadline > 0) $content .= PHP_EOL . self::$prefix . '경고 유효 기간: ' . $deadline . '일';
                $content .= PHP_EOL . self::$prefix . '지급 책임자: ' . $supplier;
                $this->getServer()->broadcastMessage($content);

                // MySQL 기록 저장
                $this->saveWarnLog($name, 'add', $amount, $afterCount, $deadline, $reason, $supplier);

                // 디코 봇에 알림 전송
                $this->notifyDiscord([
                    'type'       => 'add',
                    'player'     => $name,
                    'amount'     => $amount,
                    'total'      => $afterCount,
                    'deadline'   => $deadline,
                    'reason'     => $reason,
                    'supplier'   => $supplier,
                ]);

                // 경고 수 초과 시 밴 처리
                if ($afterCount >= self::BAN_WARN_COUNT and !$isBanned) {
                    $bannedPlayer = $this->getServer()->getPlayerExact($name);
                    if ($bannedPlayer instanceof Player) {
                        $bannedPlayer->kick('§f경고 수 초과로, 서비스 이용이 제한되었습니다.§r');
                    }
                    $this->getServer()->broadcastMessage(self::$prefix . '§f' . $name . '§8님께서 경고 수 초과로, 서비스 이용이 제한되었습니다.');
                }
            }
        } else {
            $this->reduceWarn($player, abs($amount), $reason, $supplier);
        }
    }

    // ── 경고 삭제 (만료) ──────────────────────────────────────
    public function deleteWarn($player, int $key): void {
        $playerWarn = $this->getPlayerWarn($player);
        $isBanned   = $this->isBannedPlayer($player);
        $playerWarn->deleteWarn($key);
        if ($playerWarn->getCount() < self::BAN_WARN_COUNT and $isBanned) {
            $this->getServer()->broadcastMessage(
                self::$prefix . '§f' . strtolower($player instanceof Player ? $player->getName() : $player)
                . '§8님이 §f경고 기준 수치 미달§8로, 서비스 이용이 재 허용되었습니다.'
            );
        }
    }

    // ── 경고 차감 ─────────────────────────────────────────────
    public function reduceWarn($player, int $amount, string $reason = '시스템에 의한 차감', string $supplier = '시스템'): void {
        if ($amount >= 0) {
            $playerWarn = $this->getPlayerWarn($player);
            $isBanned   = $this->isBannedPlayer($player);
            $name       = strtolower($player instanceof Player ? $player->getName() : $player);

            $event = new ReduceWarnEvent($name, $playerWarn->getCount(), $amount, $reason, $supplier);
            $event->call();

            if (!$event->isCancelled()) {
                $playerWarn->reduceWarn($amount, $reason, $supplier);
                $afterCount = $playerWarn->getCount();

                // 서버 브로드캐스트
                $content  = self::$prefix . $name . '§8님의 경고가 차감되었습니다.';
                $content .= PHP_EOL . self::$prefix . '차감된 경고: ' . $amount;
                $content .= PHP_EOL . self::$prefix . '총 경고수: ' . $afterCount;
                $content .= PHP_EOL . self::$prefix . '차감된 사유: ' . $reason;
                $content .= PHP_EOL . self::$prefix . '차감 책임자: ' . $supplier;
                $this->getServer()->broadcastMessage($content);

                // MySQL 기록 저장
                $this->saveWarnLog($name, 'reduce', $amount, $afterCount, 0, $reason, $supplier);

                // 디코 봇에 알림 전송
                $this->notifyDiscord([
                    'type'     => 'reduce',
                    'player'   => $name,
                    'amount'   => $amount,
                    'total'    => $afterCount,
                    'reason'   => $reason,
                    'supplier' => $supplier,
                ]);

                if ($afterCount < self::BAN_WARN_COUNT and $isBanned) {
                    $this->getServer()->broadcastMessage(
                        self::$prefix . $name . '§8님이 경고 기준 수치 미달로 서비스 이용이 재 허용되었습니다.'
                    );
                }
            }
        } else {
            $this->addWarn($player, $amount, 7, $reason, $supplier);
        }
    }

    private function reconnectIfNeeded(): void {
        try {
            $this->db->query('SELECT 1');
        } catch (\mysqli_sql_exception $e) {
            if ($e->getCode() === 2006 || $e->getCode() === 2013) {
                $this->db = new \mysqli($this->dbHost, $this->dbUser, $this->dbPass, $this->dbName, $this->dbPort);
            } else {
                throw $e;
            }
        }
    }

    // ── MySQL 경고 로그 저장 ───────────────────────────────────
    private function saveWarnLog(
        string $player,
        string $type,
        int    $amount,
        int    $totalAfter,
        int    $deadline,
        string $reason,
        string $supplier
    ): void {
        $this->reconnectIfNeeded();
        $stmt = $this->db->prepare("
            INSERT INTO warn_log (player, type, amount, total_after, deadline, reason, supplier)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        if ($stmt) {
            $stmt->bind_param("ssiisss", $player, $type, $amount, $totalAfter, $deadline, $reason, $supplier);
            $stmt->execute();
            $stmt->close();
        } else {
            $this->getLogger()->error("warn_log INSERT 준비 실패: " . $this->db->error);
        }
    }

    // ── 디코 봇 HTTP 알림 ─────────────────────────────────────
    private function notifyDiscord(array $data): void {
        $body = json_encode($data);
        $ch   = curl_init($this->botUrl);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $body,
            CURLOPT_HTTPHEADER     => ["Content-Type: application/json"],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 5,
            CURLOPT_CONNECTTIMEOUT => 3,
        ]);
        $response  = curl_exec($ch);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($curlError) {
            $this->getLogger()->warning("디코 알림 전송 실패: " . $curlError);
        }
    }
}