<?php

namespace anaf2197\advancedwarn\event;

use pocketmine\event\Cancellable;
use pocketmine\event\CancellableTrait;
use pocketmine\event\Event;

final class AddWarnEvent extends Event implements Cancellable {

    use CancellableTrait;

    public function __construct(private string $player, private int $count, protected int $amount, private int $deadline, private string $reason, private string $supplier) { }

    public function getPlayer(): string {
        return $this->player;
    }

    public function getAmount(): int {
        return $this->amount;
    }

    public function getDeadline(): int {
        return $this->deadline;
    }

    public function getReason(): string {
        return $this->reason;
    }

    public function getSupplier(): string {
        return $this->supplier;
    }

    public function getBeforeCount(): int {
        return $this->count;
    }

    public function getAfterCount(): int {
        return $this->getBeforeCount() + $this->getAmount();
    }
}