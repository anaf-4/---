<?php

namespace anaf2197\advancedwarn\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use anaf2197\advancedwarn\AdvancedWarn;
use anaf2197\advancedwarn\PlayerWarn;
use anaf2197\guideapi\GuideAPI;

final class ReduceWarnCommand extends Command {

    public function __construct() {
        parent::__construct('경고차감', '§r§8대상 게이머의 경고를 차감합니다.', null, ['경고차감', 'subtractwarn', 'reducewarn']);
        $this->setPermission(DefaultPermissions::ROOT_USER);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($this->testPermission($sender)) {
            if ($sender->hasPermission(DefaultPermissions::ROOT_OPERATOR) or GuideAPI::getInstance()->getGuideManager()->isGuide($sender->getName())) {
                if (count($args) >= 3) {
                    $to = array_shift($args);
                    $amount = array_shift($args);
                    $reason = array_shift($args);
                    if (is_numeric($amount)) {
                        $playerWarn = AdvancedWarn::getInstance()->getPlayerWarn($to);
                        if ($playerWarn instanceof PlayerWarn) {
                            AdvancedWarn::getInstance()->reduceWarn($to, $amount, $reason, $sender->getName());
                            $sender->sendMessage(AdvancedWarn::$prefix . '§f' . $to . '§8님의 경고를 차감하였습니다');
                        }
                    } else {
                        $sender->sendMessage(AdvancedWarn::$prefix . '차감 값은 숫자로 입력해 주세요.');
                    }
                } else {
                    $sender->sendMessage(AdvancedWarn::$prefix . '/경고차감 [게이머태그] [값] [사유] : 경고를 차감합니다.');
                }
            }
        }
    }
}