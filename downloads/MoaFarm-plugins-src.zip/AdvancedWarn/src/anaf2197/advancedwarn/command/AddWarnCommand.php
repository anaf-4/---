<?php

namespace anaf2197\advancedwarn\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use anaf2197\advancedwarn\AdvancedWarn;
use anaf2197\advancedwarn\PlayerWarn;
use anaf2197\guideapi\GuideAPI;

final class AddWarnCommand extends Command {

    public function __construct() {
        parent::__construct('경고추가', '§r§8대상 게이머에게 경고를 지급합니다.', null, ['경고지급', 'givewarn', 'addwarn']);
        $this->setPermission(DefaultPermissions::ROOT_OPERATOR);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($this->testPermission($sender)) {
            if ($sender->hasPermission(DefaultPermissions::ROOT_OPERATOR) or GuideAPI::getInstance()->getGuideManager()->isGuide($sender->getName())) {
                if (count($args) >= 4) {
                    $to = array_shift($args);
                    $amount = array_shift($args);
                    $deadline = array_shift($args);
                    $reason = array_shift($args);
                    if (is_numeric($amount)) {
                        if (is_numeric($deadline)) {
                            $playerWarn = AdvancedWarn::getInstance()->getPlayerWarn($to);
                            if ($playerWarn instanceof PlayerWarn) {
                                AdvancedWarn::getInstance()->addWarn($to, $amount, $deadline, $reason, $sender->getName());
                                $sender->sendMessage(AdvancedWarn::$prefix . '§f' . $to . '§8님에게 경고를 지급하였습니다');
                            }
                        } else {
                            $sender->sendMessage(AdvancedWarn::$prefix . '경고 유효기간은 숫자로 입력해 주세요.');
                        }
                    } else {
                        $sender->sendMessage(AdvancedWarn::$prefix . '경고 값은 숫자로 입력해 주세요.');
                    }
                } else {
                    $sender->sendMessage(AdvancedWarn::$prefix . '/경고추가 [게이머태그] [값] [기한] [사유] : 경고를 지급합니다.');
                }
            }
        }
    }
}