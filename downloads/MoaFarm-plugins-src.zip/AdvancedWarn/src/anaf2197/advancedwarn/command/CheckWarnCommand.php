<?php

namespace anaf2197\advancedwarn\command;

use pocketmine\permission\DefaultPermissions;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use anaf2197\advancedwarn\AdvancedWarn;
use anaf2197\advancedwarn\form\CheckWarnForm;
use anaf2197\advancedwarn\PlayerWarn;

final class CheckWarnCommand extends Command {

    public function __construct() {
        parent::__construct('경고확인', '§r§8대상 게이머의 경고 정보를 확인합니다.', null, ['경고보기', 'seewarn', 'checkwarn']);
        $this->setPermission(DefaultPermissions::ROOT_USER);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($sender instanceof Player) {
            if ($this->testPermission($sender)) {
                $to = (array_shift($args) ?? $sender->getName());
                $playerWarn = AdvancedWarn::getInstance()->getPlayerWarn($to);
                if ($playerWarn instanceof PlayerWarn) {
                    $sender->sendForm(new CheckWarnForm($playerWarn));
                } else {
                    $sender->sendMessage(AdvancedWarn::$prefix . '기록이 존재하지 않는 게이머입니다.');
                }
            }
        }
    }
}