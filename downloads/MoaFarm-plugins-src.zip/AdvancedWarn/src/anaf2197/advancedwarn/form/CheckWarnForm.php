<?php

namespace anaf2197\advancedwarn\form;

use pocketmine\form\Form;
use pocketmine\player\Player;
use anaf2197\advancedwarn\AdvancedWarn;
use anaf2197\advancedwarn\PlayerWarn;

final class CheckWarnForm implements Form {

    public function __construct(private PlayerWarn $playerWarn) { }

    public function jsonSerialize(): array {
        return [
            'type' => 'form',
            'title' => '§l경고 처리 기록: §r§8' . $this->playerWarn->getName(),
            'content' => implode(PHP_EOL, array_merge([
                ' ',
                '§l§f| §r§f경고 누적 수: §g' . $this->playerWarn->getCount() . '§f/' . AdvancedWarn::BAN_WARN_COUNT,
                ' '
            ], array_map(function ($value): string {
                $content = PHP_EOL . $value ['date'] . ' §l§f> §r§f경고 ' . $value ['amount'] . ' ' . $value ['record-type'];
                if (($value ['deadline'] ?? PHP_INT_MAX) < PHP_INT_MAX) {
                    $content .= PHP_EOL . '만료일: ' . $value ['date-deadline'];
                }
                $content .= PHP_EOL . '사유: ' . $value ['reason'] . ' §l§f/ §r§f책임자: ' . $value ['supplier'] . "\n";
                return $content;
            }, $this->playerWarn->getRecord()))),
            'buttons' => []
        ];
    }

    public function handleResponse(Player $player, $data): void { }
}