<?php

namespace anaf2197\awayfromkeyboard\task;

use pocketmine\event\EventPriority;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\scheduler\Task;
use pocketmine\Server;
use anaf2197\advancedwarp\AdvancedWarp;
use anaf2197\awayfromkeyboard\AwayFromKeyboard;
use anaf2197\servercore\CoreLoader;
use anaf2197\servercore\setting\ServerSettings;

final class MoveChannelTask extends Task {

    private array $stack = [];

    public function __construct() {
        Server::getInstance()->getPluginManager()->registerEvent(PlayerMoveEvent::class, function (PlayerMoveEvent $event): void {
            $this->stack [$event->getPlayer()->getId()] = 0;
        }, EventPriority::MONITOR, AwayFromKeyboard::getInstance());
    }

    public function onRun(): void {
        foreach (Server::getInstance()->getOnlinePlayers() as $player) {
            $id = $player->getId();
            if (!isset($this->stack [$id])) {
                $this->stack [$id] = 0;
            }
            $this->stack [$id]++;
            if ($this->stack [$id] >= 60 * 10) {
                $worldName = $player->getWorld()->getFolderName();
                if ($worldName !== '잠수존') {
                    $settings = CoreLoader::getInstance()->getPlayerSettings($player);
                    if ($settings->getValue(ServerSettings::AUTO_AFK())) {
                        AdvancedWarp::getInstance()->getWarp('잠수')?->warp($player);
                    } else {
                        $this->stack [$id] = 0;
                    }
                }
            }
        }
    }
}