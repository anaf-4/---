<?php

namespace anaf2197\awayfromkeyboard\task;

use pocketmine\scheduler\Task;
use pocketmine\Server;
use pocketmine\world\sound\BellRingSound;
use pocketmine\world\World;
use anaf2197\awayfromkeyboard\AwayFromKeyboard;

final class GivePointTask extends Task {

    public function onRun(): void {
        $world = Server::getInstance()->getWorldManager()->getWorldByName('잠수존');
        if ($world instanceof World) {
            foreach ($world->getPlayers() as $player) {
                $playerAFK = AwayFromKeyboard::getInstance()->getPlayerAFK($player);
                $playerAFK->addPoint(10);
                $player->sendTitle('§l§b§oAFK', '§r§f잠수 포인트가 지급되었습니다.' . PHP_EOL . '소지 포인트: ' . $playerAFK->getPoint());
                $player->sendMessage(AwayFromKeyboard::$prefix . '잠수 포인트가 지급되었습니다. (' . $playerAFK->getPoint() . 'AP)');
                $player->getWorld()->addSound($player->getPosition(), new BellRingSound());
            }
        }
    }
}