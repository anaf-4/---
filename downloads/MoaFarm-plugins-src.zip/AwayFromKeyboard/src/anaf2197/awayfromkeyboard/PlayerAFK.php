<?php

namespace anaf2197\awayfromkeyboard;

use pocketmine\player\Player;
use pocketmine\Server;
use anaf2197\lib\scoreboard\Scoreboard;
use anaf2197\servercore\CoreLoader;

final class PlayerAFK implements \JsonSerializable {

    public function __construct(private string $name, protected int $point) { }

    public function getPoint(): int {
        return $this->point;
    }

    public function addPoint(int $amount): void {
        if ($amount >= 0) {
            $this->point += $amount;
        } else {
            $this->reducePoint(abs($amount));
        }
    }

    public function reducePoint(int $amount): void {
        if ($amount >= 0) {
            $this->point -= $amount;
        } else {
            $this->addPoint(abs($amount));
        }
    }

    public function setPoint(int $amount): void {
        $this->point = $amount;
    }

    public function jsonSerialize(): array {
        return [$this->name, $this->point];
    }

    public static function jsonDeserialize(array $data): self {
        return new self (... $data);
    }
}