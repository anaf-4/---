<?php

namespace anaf2197\awayfromkeyboard\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\awayfromkeyboard\AwayFromKeyboard;

final class MyPointCommand extends Command {

    public function __construct() {
        parent::__construct('잠수포인트', '§r§8나의 잠수 포인트를 확인합니다.', null, ['ap', '잠포', 'apkpoint']);
        $this->setPermission(DefaultPermissions::ROOT_USER);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($sender instanceof Player) {
            if ($this->testPermission($sender)) {
                $playerAFK = AwayFromKeyboard::getInstance()->getPlayerAFK($sender);
                $sender->sendMessage(AwayFromKeyboard::$prefix . '현재 소지한 포인트: ' . $playerAFK->getPoint());
            }
        }
    }
}