<?php


namespace anaf2197\awayfromkeyboard\command;

use pocketmine\permission\DefaultPermissions;
use pocketmine\Server;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use anaf2197\awayfromkeyboard\AwayFromKeyboard;
use anaf2197\awayfromkeyboard\PlayerAFK;

final class SetPointCommand extends Command {

    public function __construct() {
        parent::__construct('잠수포인트설정', '§r§8잠수 포인트를 설정합니다.', null, ['setapkpoint']);
        $this->setPermission(DefaultPermissions::ROOT_OPERATOR);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($sender instanceof Player) {
            if ($this->testPermission($sender)) {
                $player = array_shift($args);
                $amount = array_shift($args);
                if (trim((string)$amount) !== '') {
                    if (is_numeric($amount)) {
                        $amount = abs($amount);
                        $object = Server::getInstance()->getPlayerByPrefix($player);
                        if ($object instanceof Player) {
                            $player = $object->getName();
                        }
                        $playerAFK = AwayFromKeyboard::getInstance()->getPlayerAFK($player);
                        if ($playerAFK instanceof PlayerAFK) {
                            $playerAFK->setPoint((int)$amount);
                            $sender->sendMessage(AwayFromKeyboard::$prefix . $player . '님의 잠수 포인트를 ' . $amount . ' (으)로 설정하였습니다.');
                        } else {
                            $sender->sendMessage(AwayFromKeyboard::$prefix . '데이터가 존재하지 않는 게이머입니다.');
                        }
                    } else {
                        $sender->sendMessage(AwayFromKeyboard::$prefix . '포인트는 숫자로 입력해 주세요.');
                    }
                } else {
                    $sender->sendMessage(AwayFromKeyboard::$prefix . '/잠수포인트설정 [게이머태그] [포인트] - 대상 게이머의 잠수 포인트를 설정합니다.');
                }
            }
        }
    }
}