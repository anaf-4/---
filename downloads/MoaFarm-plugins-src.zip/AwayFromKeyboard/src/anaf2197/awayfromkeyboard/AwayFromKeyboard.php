<?php

namespace anaf2197\awayfromkeyboard;

use pocketmine\event\EventPriority;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;
use anaf2197\awayfromkeyboard\command\MyPointCommand;
use anaf2197\awayfromkeyboard\command\SetPointCommand;
use anaf2197\awayfromkeyboard\task\GivePointTask;
use anaf2197\awayfromkeyboard\task\MoveChannelTask;
use anaf2197\lib\color\ServerColor;
use anaf2197\lib\provider\DataProvider;
use anaf2197\lib\provider\ProviderHandler;

final class AwayFromKeyboard extends PluginBase {

    use SingletonTrait;

    public static string $prefix;

    private DataProvider $provider;

    protected function onEnable(): void {
        $this->getServer()->getCommandMap()->registerAll(strtolower($this->getName()), [
            new MyPointCommand(),
            new SetPointCommand()
        ]);
        $this->getServer()->getPluginManager()->registerEvent(PlayerJoinEvent::class, function (PlayerJoinEvent $event): void {
            $player = $event->getPlayer();
            if (!$this->getPlayerAFK($player) instanceof PlayerAFK) {
                $this->setPlayerAFK($player, new PlayerAFK(strtolower($player->getName()), 0));
            }
        }, EventPriority::MONITOR, $this);
        $this->getScheduler()->scheduleRepeatingTask(new GivePointTask(), 20 * 60 * 10);
        $this->getScheduler()->scheduleRepeatingTask(new MoveChannelTask(), 20);
    }

    protected function onDisable(): void {
        $this->saveDatabase();
    }

    public function saveDatabase(): void {
        $this->provider->save();
    }

    protected function onLoad(): void {
        self::setInstance($this);
        ServerColor::setPrefix($this, '잠수');
        if (!ProviderHandler::isRegistered($this)) {
            ProviderHandler::register($this, PlayerAFK::class);
            $this->provider = ProviderHandler::get($this);
        }
    }

    public function getPlayerAFK($player): ?PlayerAFK {
        return $this->provider->getObject($player);
    }

    public function setPlayerAFK($player, PlayerAFK $object): void {
        $this->provider->setObject($player, $object);
    }
}