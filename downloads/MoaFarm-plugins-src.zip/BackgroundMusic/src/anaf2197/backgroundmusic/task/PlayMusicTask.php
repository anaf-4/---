<?php

namespace anaf2197\backgroundmusic\task;

use pocketmine\scheduler\Task;
use pocketmine\Server;
use anaf2197\backgroundmusic\BackgroundMusic;
use anaf2197\backgroundmusic\queue\Queue;
use anaf2197\servercore\CoreLoader;
use anaf2197\servercore\setting\ServerSettings;

final class PlayMusicTask extends Task {

    public function onRun(): void {
        $runningTime = BackgroundMusic::getRunningTime();
        $musicName = BackgroundMusic::getMusicName();
        foreach (Server::getInstance()->getOnlinePlayers() as $player) {
            if ($player->isConnected()) {
                if (!is_array(Queue::getQueue($player))) {
                    $playerSettings = CoreLoader::getInstance()->getPlayerSettings($player);
                    if (!is_null($playerSettings) and $playerSettings->getValue(ServerSettings::BACKGROUND_MUSIC())) {
                        BackgroundMusic::getInstance()->start($player, $musicName);
                        Queue::setQueue($player, [$runningTime + time()]);
                    }
                } else if (Queue::getQueue($player) [0] <= time()) {
                    Queue::deleteQueue($player);
                    # BackgroundMusic::getInstance()->stop($player, $musicName);
                }
            }
        }
    }
}
