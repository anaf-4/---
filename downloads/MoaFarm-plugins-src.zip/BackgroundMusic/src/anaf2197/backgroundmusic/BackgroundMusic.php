<?php

namespace anaf2197\backgroundmusic;

use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\StopSoundPacket;
use pocketmine\plugin\PluginBase;
use pocketmine\scheduler\ClosureTask;
use pocketmine\utils\SingletonTrait;
use pocketmine\player\Player;
use anaf2197\backgroundmusic\task\PlayMusicTask;

final class BackgroundMusic extends PluginBase {

    use SingletonTrait;

    protected function onEnable(): void {
        $this->getScheduler()->scheduleRepeatingTask(new PlayMusicTask(), 20);
    }

    protected function onLoad(): void {
        self::setInstance($this);
    }

    public static function getRunningTime(): int {
        return 124;
    }

    public static function getMusicName(): string {
        return 'bgm';
    }

    public function start(Player $player, string $musicName): void {
        $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function () use ($player, $musicName): void {
            if ($player->isOnline()) {
                $position = $player->getPosition();
                $player->getNetworkSession()->sendDataPacket(PlaySoundPacket::create($musicName, $position->getX(), $position->getY(), $position->getZ(), 100, 1, false));
            }
        }), 100);
    }

    public function stop(Player $player, string $musicName = ''): bool {
        return $player->getNetworkSession()->sendDataPacket(StopSoundPacket::create($musicName, $musicName === ''));
    }
}