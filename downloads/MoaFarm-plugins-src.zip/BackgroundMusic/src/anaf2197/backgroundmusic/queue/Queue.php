<?php

namespace anaf2197\backgroundmusic\queue;

use pocketmine\player\Player;

final class Queue {

    protected static array $queue = [];

    public static function getQueue(Player $player): ?array {
        return self::$queue [$player->getId()] ?? null;
    }

    public static function setQueue(Player $player, array $value): void {
        self::$queue [$player->getId()] = $value;
    }

    public static function deleteQueue(Player $player): void {
        unset (self::$queue [$player->getId()]);
    }
}
