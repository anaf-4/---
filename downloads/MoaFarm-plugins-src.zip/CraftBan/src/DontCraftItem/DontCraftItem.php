<?php
declare(strict_types=1);

namespace DontCraftItem;

use JsonException;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\inventory\CraftItemEvent;
use pocketmine\event\Listener;
use pocketmine\item\Item;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;

class DontCraftItem extends PluginBase implements Listener{

	/** @var Config */
	protected Config $config;

	public array $db = [];
    public const PREFIX = '§l§d[조합밴] §r§8';

	protected function onEnable() : void{
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		@mkdir($this->getDataFolder());
		$this->config = new Config($this->getDataFolder() . 'Config.yml', Config::YAML, [
			'ban-item' => []
		]);
		$this->db = $this->config->getAll();
		$this->getServer()->getCommandMap()->register('craftban', new AddCraftBanCommand($this));
	}

	public function onCraft(CraftItemEvent $event): void
    {
		$result = $event->getOutputs();
		$item = array_pop($result);
		if($item instanceof Item){
			$id = $item->getTypeId();
			if(isset($this->db['ban-item'] [$id])){
				if($event->getPlayer()->hasPermission(DefaultPermissions::ROOT_OPERATOR)){
					return;
				}
				$event->cancel();
			}
		}
	}

    /**
     * @throws JsonException
     */
    protected function onDisable() : void{
		$this->config->setAll($this->db);
		$this->config->save();
	}
}

class AddCraftBanCommand extends Command{

	protected DontCraftItem $plugin;

	public function __construct(DontCraftItem $plugin){
		$this->plugin = $plugin;
		parent::__construct('조합밴', '아이템 조합밴 관리 명령어');
        $this->setPermission(DefaultPermissions::ROOT_OPERATOR);
	}

	public function execute(CommandSender $sender, string $commandLabel, array $args) : bool{
		if(!$sender instanceof Player)
			return true;
		if(!isset($args[0])){
			$args[0] = 'x';
		}
		$inv = $sender->getInventory();
		switch($args[0]){
			case '추가':
				if($inv->getItemInHand()->getTypeId() === 0){
					$sender->sendMessage(DontCraftItem::PREFIX . '공기는 조합밴에 추가할 수 없습니다.');
					return true;
				}
				$this->plugin->db['ban-item'] [$inv->getItemInHand()->getTypeId()] = true;
				$sender->sendMessage(DontCraftItem::PREFIX . '해당 아이템을 조합밴에 추가하였습니다.');
				break;
			case '제거':
				if($inv->getItemInHand()->getTypeId() === 0){
					$sender->sendMessage(DontCraftItem::PREFIX . '공기를 조합밴에 제거할 수 없습니다.');
					return true;
				}
				if(!isset($this->plugin->db['ban-item'] [$inv->getItemInHand()->getTypeId()])){
					$sender->sendMessage(DontCraftItem::PREFIX . '해당 아이템 데이터는 존재하지 않습니다.');
					return true;
				}
				unset($this->plugin->db['ban-item'] [$inv->getItemInHand()->getTypeId()]);
                $sender->sendMessage(DontCraftItem::PREFIX . '해당 아이템을 조합밴에서 제거하였습니다.');
				break;
			case 'list':
				if(empty($this->plugin->db['ban-item'])){
					$sender->sendMessage(DontCraftItem::PREFIX . '조합밴 데이터가 존재하지 않습니다.');
					break;
				}
				$sender->sendMessage(DontCraftItem::PREFIX . '조합밴 목록: ' . implode(", ", array_map(function(string $id) : string{
						return (string) $id;
					}, array_keys($this->plugin->db['ban-item']))));
				break;
			default:
                $sender->sendMessage(DontCraftItem::PREFIX . '/조합밴 추가 - 손에 든 아이템 조합을 금지시킵니다.');
                $sender->sendMessage(DontCraftItem::PREFIX . '/조합밴 제거 - 조합밴에 등록된 아이템을 제거합니다.');
                $sender->sendMessage(DontCraftItem::PREFIX . '/조합밴 목록 - 조합밴에 등록된 아이템 목록을 확인합니다.');
		}
		return true;
	}
}
