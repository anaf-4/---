<?php
declare(strict_types=1);

namespace Valres\CustomItemCreator\listeners;

use pocketmine\event\Listener;
use pocketmine\event\server\DataPacketSendEvent;
use pocketmine\network\mcpe\protocol\BiomeDefinitionListPacket;
use pocketmine\network\mcpe\protocol\ItemComponentPacket;
use pocketmine\network\mcpe\protocol\ItemRegistryPacket;
use pocketmine\network\mcpe\protocol\ResourcePackStackPacket;
use pocketmine\network\mcpe\protocol\StartGamePacket;
use pocketmine\network\mcpe\protocol\types\BlockPaletteEntry;
use pocketmine\network\mcpe\protocol\types\Experiments;
use pocketmine\network\mcpe\protocol\types\ItemTypeEntry;
use Valres\CustomItemCreator\libs\block\CustomiesBlockFactory;
use Valres\CustomItemCreator\libs\item\CustomiesItemFactory;
use function array_merge;
use function count;

final class CustomiesListener implements Listener {

	private ?ItemComponentPacket $cachedItemComponentPacket = null;
	/** @var ItemTypeEntry[] */
	private array $cachedItemTable = [];
	/** @var BlockPaletteEntry[] */
	private array $cachedBlockPalette = [];
	private Experiments $experiments;

	public function __construct() {
		$this->experiments = new Experiments([
			// "data_driven_items" is required for custom blocks to render in-game. With this disabled, they will be
			// shown as the UPDATE texture block.
			"data_driven_items" => true,
		], true);
	}

	public function onDataPacketSend(DataPacketSendEvent $event): void {
		foreach($event->getPackets() as $packet){
            if($packet instanceof ItemRegistryPacket) {
                (function() : void{
                    /** @noinspection PhpDynamicFieldDeclarationInspection */
                    /** @noinspection PhpUndefinedFieldInspection */
                    $this->entries = array_merge($this->entries, CustomiesItemFactory::getInstance()->getItemTableEntries());
                })->call($packet);
            } elseif($packet instanceof StartGamePacket) {
				$packet->levelSettings->experiments = $this->experiments;
				$packet->blockPalette = $this->cachedBlockPalette;
			} elseif($packet instanceof ResourcePackStackPacket) {
				$packet->experiments = $this->experiments;
			}
		}
	}
}
