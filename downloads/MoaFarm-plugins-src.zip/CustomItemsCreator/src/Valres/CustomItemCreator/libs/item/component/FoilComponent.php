<?php
declare(strict_types=1);

namespace Valres\CustomItemCreator\libs\item\component;

final class FoilComponent implements ItemComponent {

	private bool $foil;

	public function __construct(bool $foil = true) {
		$this->foil = $foil;
	}

	public function getName(): string {
		return "foil";
	}

	public function getValue(): bool {
		return $this->foil;
	}

	public function isProperty(): bool {
		return true;
	}
}