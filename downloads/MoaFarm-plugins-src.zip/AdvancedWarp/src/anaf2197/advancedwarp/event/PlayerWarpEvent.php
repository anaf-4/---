<?php

namespace anaf2197\advancedwarp\event;

use pocketmine\event\Cancellable;
use pocketmine\event\CancellableTrait;
use pocketmine\event\Event;
use pocketmine\player\Player;
use anaf2197\advancedwarp\Warp;

final class PlayerWarpEvent extends Event implements Cancellable {

    use CancellableTrait;

    public function __construct(private Warp $warpObject, private Player $player) { }

    public function getWarp(): Warp {
        return $this->warpObject;
    }

    public function getPlayer(): Player {
        return $this->player;
    }
}