<?php

namespace anaf2197\advancedwarp\form;

use pocketmine\form\Form;
use pocketmine\player\Player;
use anaf2197\advancedwarp\Warp;
use anaf2197\advancedwarp\AdvancedWarp;

final class WarpCategoriesForm implements Form {

    protected array $warps = [];

    public function __construct() {
        /** @var Warp $warp */
        foreach (AdvancedWarp::getInstance()->getWarps() as $warp) {
            $this->warps [$warp->getCategory()] [] = $warp;
        }
    }

    public function jsonSerialize(): array {
        return [
            'type' => 'form',
            'title' => '§l 카테고리 목록',
            'content' => ' ',
            'buttons' => array_map(function (string $category): array {
                return [
                    'text' => '§l§0' . $category . PHP_EOL . '§r§8개수: ' . count($this->warps [$category]) . '개'
                ];
            }, array_keys($this->warps))
        ];
    }

    public function handleResponse(Player $player, $data): void {
        if (is_numeric($data)) {
            $category = array_keys($this->warps) [$data];
            $player->sendForm(new WarpsByCategoryForm($category, $this->warps [$category]));
        }
    }
}