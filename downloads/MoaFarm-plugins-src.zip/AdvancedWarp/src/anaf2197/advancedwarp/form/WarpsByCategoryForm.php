<?php

namespace anaf2197\advancedwarp\form;

use pocketmine\form\Form;
use pocketmine\player\Player;
use anaf2197\advancedlevel\AdvancedLevel;
use anaf2197\advancedwarp\AdvancedWarp;
use anaf2197\advancedwarp\Warp;

final class WarpsByCategoryForm implements Form {

    public function __construct(private string $category, private array $warps) { }

    public function jsonSerialize(): array {
        return [
            'type' => 'form',
            'title' => '§l' . $this->category,
            'content' => ' ',
            'buttons' => array_map(function (Warp $warpObject): array {
                $text = '§l' . $warpObject->getId();
                if (($levelLimit = $warpObject->getLevelLimit()) > 0) {
                    $text .= PHP_EOL . '§r§8레벨 제한: ' . $levelLimit;
                }

                $button = [
                    'text' => $text
                ];

                // Warp 이름에 따라 이미지 설정
                $button['image'] = match ($warpObject->getId()) {
                    '스폰' => ['type' => 'path', 'data' => 'textures/ui/warp/스폰'],
                    '발굴장' => ['type' => 'path', 'data' => 'textures/ui/warp/발굴장'],
                    '교환소' => ['type' => 'path', 'data' => 'textures/ui/warp/교환소'],
                    '낚시터' => ['type' => 'path', 'data' => 'textures/ui/warp/낚시터'],
                    '튜토리얼' => ['type' => 'path', 'data' => 'textures/ui/warp/튜토리얼'],
                    '대장간' => ['type' => 'path', 'data' => 'textures/ui/warp/대장간'],
                    '광산' => ['type' => 'path', 'data' => 'textures/ui/warp/광산'],
                    '잠수' => ['type' => 'path', 'data' => 'textures/ui/warp/잠수'],
                    '코스튬' => ['type' => 'path', 'data' => 'textures/ui/warp/코스튬'],
                    '벌목장' => ['type' => 'path', 'data' => 'textures/ui/warp/벌목장'],
                    '상점' => ['type' => 'path', 'data' => 'textures/ui/warp/상점'],
                    '낚시터' => ['type' => 'path', 'data' => 'textures/ui/warp/낚시터'],
                    '목장' => ['type' => 'path', 'data' => 'textures/ui/warp/목장'],
                    '벚꽃 장소' => ['type' => 'path', 'data' => 'textures/ui/warp/벚꽃 장소'],
                    default => null // 이미지가 없는 경우 null
                };

                // 이미지가 null인 경우 배열에서 제거
                if ($button['image'] === null) {
                    unset($button['image']);
                }

                return $button;
            }, $this->warps)
        ];
    }



    public function handleResponse(Player $player, $data): void {
        if (is_numeric($data)) {
            $warpObject = $this->warps [$data];
            $level = AdvancedLevel::getInstance()->getPlayerLevel($player)->getLevel();
            $levelLimit = $warpObject->getLevelLimit();
            if ($level >= $levelLimit) {
                $warpObject->warp($player);
            } else {
                $player->sendMessage(AdvancedWarp::$prefix . '레벨이 부족하여 이동할 수 없습니다. (' . ($levelLimit - $level) . 'lv 부족)');
            }
        }
    }
}