<?php

namespace anaf2197\advancedwarp\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\advancedwarp\form\WarpCategoriesForm;
use anaf2197\advancedwarp\form\WarpsByCategoryForm;
use anaf2197\advancedwarp\Warp;
use anaf2197\advancedwarp\AdvancedWarp;

final class WarpListCommand extends Command {

    public function __construct() {
        parent::__construct('워프목록', '§r§8생성되어 있는 워프 목록을 확인합니다.', null, ['warplist']);
        $this->setPermission(DefaultPermissions::ROOT_USER);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($sender instanceof Player) {
            if ($this->testPermission($sender)) {
                $category = array_shift($args);
                if (is_null($category)) {
                    $sender->sendForm(new WarpCategoriesForm());
                } else {
                    $warps = array_values(array_filter(array_values(AdvancedWarp::getInstance()->getWarps()), function (Warp $warp) use ($category): bool {
                        return $warp->getCategory() === $category;
                    }));
                    if (!empty($warps)) {
                        $sender->sendForm(new WarpsByCategoryForm($category, $warps));
                    } else {
                        $sender->sendMessage(AdvancedWarp::$prefix . '존재하지 않는 카테고리입니다.');
                    }
                }
            }
        }
    }
}