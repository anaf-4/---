<?php

namespace anaf2197\advancedwarp\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use anaf2197\advancedwarp\Warp;
use anaf2197\advancedwarp\AdvancedWarp;

final class DeleteWarpCommand extends Command {

    public function __construct() {
        parent::__construct('워프제거', '§r§8워프를 제거합니다.', null, ['deletewarp']);
        $this->setPermission(DefaultPermissions::ROOT_OPERATOR);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($this->testPermission($sender)) {
            $id = (string)array_shift($args);
            if (trim($id) !== '') {
                $warp = AdvancedWarp::getInstance()->getWarp($id);
                if ($warp instanceof Warp) {
                    $warp->unregister();
                    $sender->sendMessage(AdvancedWarp::$prefix . '해당 워프를 제거했습니다.');
                } else {
                    $sender->sendMessage(AdvancedWarp::$prefix . '존재하지 않는 이름입니다.');
                }
            } else {
                $sender->sendMessage(AdvancedWarp::$prefix . '/워프제거 [이름] - 워프를 제거합니다.');
            }
        }
    }
}