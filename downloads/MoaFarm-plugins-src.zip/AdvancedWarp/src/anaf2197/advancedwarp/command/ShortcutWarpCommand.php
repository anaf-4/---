<?php

namespace anaf2197\advancedwarp\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\advancedlevel\AdvancedLevel;
use anaf2197\advancedwarp\AdvancedWarp;
use anaf2197\advancedwarp\Warp;

final class ShortcutWarpCommand extends Command {

    private readonly Warp $warp;

    public function __construct(string $id) {
        parent::__construct($id, $id . '(으)로 이동합니다.');
        $this->setPermission(DefaultPermissions::ROOT_USER);
        $this->warp = AdvancedWarp::getInstance()->getWarp($id);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($sender instanceof Player) {
            if ($this->testPermission($sender)) {
                $playerLevel = AdvancedLevel::getInstance()->getPlayerLevel($sender);
                $level = $playerLevel->getLevel();
                $levelLimit = $this->warp->getLevelLimit();
                if ($level >= $levelLimit) {
                    $this->warp->warp($sender);
                } else {
                    $sender->sendMessage(AdvancedWarp::$prefix . '레벨이 부족하여 이동할 수 없습니다. (' . ($levelLimit - $level) . 'lv 부족)');
                }
            }
        }
    }
}