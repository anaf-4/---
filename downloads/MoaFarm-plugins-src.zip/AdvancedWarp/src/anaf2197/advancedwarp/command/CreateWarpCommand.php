<?php

namespace anaf2197\advancedwarp\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\advancedwarp\Warp;
use anaf2197\advancedwarp\AdvancedWarp;
use anaf2197\lib\positionparser\PositionParser;

final class CreateWarpCommand extends Command {

    public function __construct() {
        parent::__construct('워프생성', '§r§8워프를 생성합니다.', null, ['createwarp']);
        $this->setPermission(DefaultPermissions::ROOT_OPERATOR);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($sender instanceof Player) {
            if ($this->testPermission($sender)) {
                $id = (string)array_shift($args);
                $category = (string)array_shift($args);
                if (trim($category) !== '') {
                    if (preg_match('/[\\\\\/:\*\?"<>|]/', $id)) {
                        $sender->sendMessage(AdvancedWarp::$prefix . '워프 이름에 사용할 수 없는 문자가 포함되어 있습니다. (\\/:*?"<>| 불가)');
                        return;
                    }
                    $levelLimit = array_shift($args) ?? 0;
                    $warp = AdvancedWarp::getInstance()->getWarp($id);
                    if ($warp instanceof Warp) {
                        $sender->sendMessage(AdvancedWarp::$prefix . '이미 존재하는 워프 이름입니다.');
                    } else {
                        if (is_numeric($levelLimit)) {
                            AdvancedWarp::getInstance()->createWarp($id, new Warp($id, $category, (int)$levelLimit, $sender->getWorld()->getFolderName(), PositionParser::toString($sender->getPosition())));
                            $sender->sendMessage(AdvancedWarp::$prefix . $id . ' 워프를 생성하였습니다.');
                        } else {
                            $sender->sendMessage(AdvancedWarp::$prefix . '레벨 제한은 숫자로 입력해 주세요.');
                        }
                    }
                } else {
                    $sender->sendMessage(AdvancedWarp::$prefix . '/워프생성 [이름] [카테고리] [레벨제한(기본0)] - 현재 위치에 워프를 생성합니다.');
                }
            }
        }
    }
}