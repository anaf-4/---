<?php

namespace anaf2197\advancedwarp;

use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;
use anaf2197\lib\provider\DataProvider;
use anaf2197\lib\provider\ProviderHandler;
use anaf2197\lib\color\ServerColor;
use anaf2197\advancedwarp\command\CreateWarpCommand;
use anaf2197\advancedwarp\command\DeleteWarpCommand;
use anaf2197\advancedwarp\command\ShortcutWarpCommand;
use anaf2197\advancedwarp\command\WarpListCommand;

final class AdvancedWarp extends PluginBase {

    use SingletonTrait;

    public static string $prefix;

    private DataProvider $provider;

    protected function onEnable(): void {
        if (!ProviderHandler::isRegistered($this)) {
            ProviderHandler::register($this, Warp::class);
            $this->provider = ProviderHandler::get($this);
        }
        $this->getServer()->getCommandMap()->registerAll(strtolower($this->getName()), [
            new CreateWarpCommand(),
            new DeleteWarpCommand(),
            new WarpListCommand()
        ]);
        $this->loadShortcutWarp(array_map(function (Warp $warpObject): string {
            return $warpObject->getId();
        }, $this->getWarps()));
    }

    protected function onLoad(): void {
        self::setInstance($this);
        ServerColor::setPrefix($this, '워프');
    }

    protected function onDisable(): void {
        $this->saveDatabase();
    }

    public function saveDatabase(): void {
        $this->provider->save();
    }

    private function loadShortcutWarp(string|array $ids): void {
        if (is_string($ids)) {
            $ids = [$ids];
        }
        $this->getLogger()->info(count($ids) . '개의 워프 명령어가 생성되었습니다.');
        foreach ($ids as $id) {
            $this->getServer()->getCommandMap()->register(strtolower($this->getName()), new ShortcutWarpCommand($id));
        }
    }

    public function getWarps(): array {
        return $this->provider->getAll();
    }

    public function getWarp(string $id): ?Warp {
        return $this->provider->getObject($id);
    }

    public function createWarp(string $id, Warp $warpObject): void {
        $this->provider->setObject($id, $warpObject);
        $this->loadShortcutWarp($id);
    }

    public function deleteWarp(string $id): void {
        $this->provider->deleteObject($id);
    }
}