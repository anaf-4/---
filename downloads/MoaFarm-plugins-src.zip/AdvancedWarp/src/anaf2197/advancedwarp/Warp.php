<?php
namespace anaf2197\advancedwarp;

use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\world\Position;
use pocketmine\world\sound\XpLevelUpSound;
use anaf2197\lib\positionparser\PositionParser;
use anaf2197\advancedwarp\event\PlayerWarpEvent;

final class Warp implements \JsonSerializable {
    
    private Position $position;

    public function __construct(private string $id, private string $category, private int $levelLimit, private string $worldName, string $positionData) {
        Server::getInstance()->getWorldManager()->loadWorld($worldName);
        $this->position = PositionParser::fromString($positionData, Server::getInstance(), $worldName);
    }

    public function unregister(): void {
        $commandMap = Server::getInstance()->getCommandMap();
        $commandMap->unregister($commandMap->getCommand($this->id));
        AdvancedWarp::getInstance()->deleteWarp($this->id);
    }

    public function getId(): string {
        return $this->id;
    }

    public function getCategory(): string {
        return $this->category;
    }

    public function getLevelLimit(): int {
        return $this->levelLimit;
    }

    public function warp(Player $player): bool {
        $event = new PlayerWarpEvent($this, $player);
        $event->call();
        
        if (!$event->isCancelled()) {
            $player->teleport($this->position->up(0.4));
            $player->getWorld()->addSound($player->getPosition(), new XpLevelUpSound(10));
            $player->sendMessage(AdvancedWarp::$prefix . '§a' . $this->id . '§r§8(으)로 이동하였습니다.');
            $player->sendTitle('§l§e워프§r', '§f- §e' . $this->id . '§f(으)로 이동하였습니다 -');
            
            // ===== 길라잡이 퀘스트 연동 코드 추가 =====
            $this->checkGuideQuest($player);
            // =========================================
            
            return true;
        }
        return false;
    }

    // ===== 길라잡이 퀘스트 체크 메서드 추가 =====
    private function checkGuideQuest(Player $player): void {
        $guidePlugin = Server::getInstance()->getPluginManager()->getPlugin("GuidePro");
        if ($guidePlugin !== null && $guidePlugin->isEnabled()) {
            // 워프 ID를 명령어로 전달 (예: "광산", "벌목장", "발굴장", "낚시터" 등)
            $guidePlugin->checkCommandQuest($player->getName(), $this->id);
        }
    }
    // ===========================================

    public function jsonSerialize(): array {
        return [
            $this->id,
            $this->category,
            $this->levelLimit,
            $this->worldName,
            PositionParser::toString($this->position, $this->worldName)
        ];
    }

    public static function jsonDeserialize(array $data): self {
        return new self (... $data);
    }
}