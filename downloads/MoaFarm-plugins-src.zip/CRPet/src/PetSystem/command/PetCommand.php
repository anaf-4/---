<?php

declare(strict_types=1);

namespace PetSystem\command;

use PetSystem\Main;
use PetSystem\ui\PetFormUI;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class PetCommand {

    public function __construct(private Main $plugin) {}

    public function run(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!($sender instanceof Player)) {
            $sender->sendMessage("§c이 커맨드는 인게임에서만 사용할 수 있습니다.");
            return false;
        }

        if (!$sender->hasPermission("petsystem.command.pet")) {
            $sender->sendMessage("§c권한이 없습니다.");
            return false;
        }

        if (empty($args)) {
            PetFormUI::openMainMenu($sender, $this->plugin);
            return true;
        }

        $sub = strtolower($args[0]);

        match ($sub) {
            "summon", "s"  => $this->handleSummon($sender, $args),
            "despawn", "d" => $this->handleDespawn($sender),
            "rename", "r"  => $this->handleRename($sender, $args),
            "release"      => $this->handleRelease($sender, $args),
            "sit"          => $this->handleSit($sender),
            "guard", "g"   => $this->handleGuard($sender),
            "status"       => $this->handleStatus($sender),
            "evolve"       => $this->handleEvolve($sender),
            "list"         => $this->handleList($sender),
            "gui"          => PetFormUI::openMainMenu($sender, $this->plugin),
            "mount", "m"   => $this->handleMount($sender),
            default        => $sender->sendMessage("§f사용법: /pet <summon|despawn|rename|release|sit|guard|status|evolve|list|gui>"),
        };

        return true;
    }

    private function handleSummon(Player $player, array $args): void {
        $index = isset($args[1]) ? (int)$args[1] - 1 : 0;
        if ($index < 0) $index = 0;

        if (!$this->plugin->getPetManager()->summonPet($player, $index)) {
            $player->sendMessage("§c펫 소환에 실패했습니다. §8/pet list §c로 보유 펫을 확인하세요.");
        }
    }

    private function handleDespawn(Player $player): void {
        if (!$this->plugin->getPetManager()->despawnPet($player)) {
            $player->sendMessage("§c현재 소환된 펫이 없습니다.");
        }
    }

    private function handleRename(Player $player, array $args): void {
        if (!isset($args[1], $args[2])) {
            $player->sendMessage("§c사용법: /pet rename <번호> <이름>");
            return;
        }
        $index   = (int)$args[1] - 1;
        $newName = implode(" ", array_slice($args, 2));

        if (mb_strlen($newName) > 16) {
            $player->sendMessage("§c이름은 최대 16자까지 가능합니다.");
            return;
        }

        $this->plugin->getPetManager()->renamePet($player, $index, $newName);
    }

    private function handleRelease(Player $player, array $args): void {
        $index = isset($args[1]) ? (int)$args[1] - 1 : 0;
        PetFormUI::openConfirmRelease($player, $this->plugin, $index);
    }

    private function handleSit(Player $player): void {
        $this->plugin->getPetManager()->toggleSit($player);
    }

    private function handleGuard(Player $player): void {
        $this->plugin->getPetManager()->toggleGuard($player);
    }

    private function handleStatus(Player $player): void {
        $active = $this->plugin->getPetManager()->getActivePet($player);
        if ($active === null) {
            $player->sendMessage("§c소환된 펫이 없습니다.");
            return;
        }

        $data = $active->getPetData();
        $def  = $active->getPetDefinition();

        $player->sendMessage("§6═══════ §e" . $data->getCustomName() . " §6═══════");
        $player->sendMessage("§8종류: §f" . $def->getDisplayName());
        $player->sendMessage("§8단계: §f" . $data->getStageName() . " (" . $data->getEvolutionStage() . "/3)");
        $player->sendMessage("§8레벨: §a" . $data->getLevel());
        $player->sendMessage("§8경험치: §e" . $data->getExp() . " §8/ §e" . $data->getExpToNext() . " §8(" . round($data->getExpPercent(), 1) . "%)");
        $player->sendMessage("§8체력: §c" . round($data->getHealth(), 1) . "§8/§c" . round($data->getMaxHealth(), 1));
        $player->sendMessage("§8배고픔: §6" . $data->getHunger() . "§8/§6100");
        $player->sendMessage("§8행복도: §d" . $data->getHappiness() . "§8/§d100");
        $player->sendMessage("§8상태: §f" . $this->getStateName($data->getState()));
        $player->sendMessage("§8스킬: §f" . (count($data->getUnlockedSkills()) > 0 ? implode(", ", $data->getUnlockedSkills()) : "없음"));
        $player->sendMessage("§8함께한 시간: §f" . round($data->getTotalPlaytime() / 1200, 1) . "분");

        if ($data->canEvolve()) {
            $player->sendMessage("§5§d진화 가능! §8/pet evolve");
        } else {
            $player->sendMessage("§8다음 진화까지: §fLv." . $data->getRequiredLevelForNextEvolution() . " 필요");
        }
        $player->sendMessage("§6═══════════════════════");
    }

    private function getStateName(string $state): string {
        return match($state) {
            "following" => "§a추적 중",
            "sitting"   => "§8앉음",
            "guarding"  => "§c경호 중",
            default     => $state,
        };
    }

    private function handleEvolve(Player $player): void {
        $this->plugin->getPetManager()->tryEvolveActivePet($player);
    }

    private function handleList(Player $player): void {
        $pets = $this->plugin->getPetManager()->getPlayerPets($player);

        if (empty($pets)) {
            $player->sendMessage("§c보유한 펫이 없습니다.");
            return;
        }

        $player->sendMessage("§6═══ §e보유 펫 목록 §6═══");
        foreach ($pets as $i => $pet) {
            $num   = $i + 1;
            $player->sendMessage("§e{$num}. §f" . $pet->getCustomName() . " §8[" . $pet->getStageName() . "] §aLv." . $pet->getLevel());
        }
        $player->sendMessage("§8소환: §f/pet summon <번호>");
    }

    private function handleMount(Player $player): void {
        $active = $this->plugin->getPetManager()->getActivePet($player);
        if ($active === null) {
            $player->sendMessage("§c소환된 펫이 없습니다.");
            return;
        }
        if (!$active->mountPlayer($player)) {
            $player->sendMessage("§c이 펫은 탈 수 없습니다.");
        }
    }
}