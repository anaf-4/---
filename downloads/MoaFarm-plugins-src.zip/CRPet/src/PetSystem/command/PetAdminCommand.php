<?php

declare(strict_types=1);

namespace PetSystem\command;

use PetSystem\Main;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class PetAdminCommand {

    public function __construct(private Main $plugin) {}

    public function run(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$sender->hasPermission("petsystem.admin")) {
            $sender->sendMessage("§c권한이 없습니다.");
            return false;
        }

        if (empty($args)) {
            $sender->sendMessage("§6[PetAdmin] §f사용법: /petadmin <give|remove|reload|info|list>");
            return false;
        }

        match (strtolower($args[0])) {
            "give"   => $this->handleGive($sender, $args),
            "remove" => $this->handleRemove($sender, $args),
            "reload" => $this->handleReload($sender),
            "info"   => $this->handleInfo($sender, $args),
            "list"   => $this->handleListDefs($sender),
            default  => $sender->sendMessage("§c알 수 없는 서브커맨드: {$args[0]}"),
        };

        return true;
    }

    private function handleGive(CommandSender $sender, array $args): void {
        if (!isset($args[1], $args[2])) {
            $sender->sendMessage("§c사용법: /petadmin give <플레이어> <펫ID> [이름]");
            return;
        }

        $targetName = $args[1];
        $petId      = $args[2];
        $petName    = isset($args[3]) ? implode(" ", array_slice($args, 3)) : "";

        $target = $this->plugin->getServer()->getPlayerByPrefix($targetName);
        if ($target === null) {
            $sender->sendMessage("§c플레이어를 찾을 수 없습니다: {$targetName}");
            return;
        }

        $def = $this->plugin->getPetManager()->getDefinition($petId);
        if ($def === null) {
            $sender->sendMessage("§c존재하지 않는 펫 ID: {$petId}");
            $sender->sendMessage("§8사용 가능한 ID: /petadmin list");
            return;
        }

        if ($this->plugin->getPetManager()->givePet($target, $petId, $petName)) {
            $sender->sendMessage("§a{$target->getName()} §f에게 펫 §e{$petId} §f을(를) 지급했습니다.");
        }
    }

    private function handleRemove(CommandSender $sender, array $args): void {
        if (!isset($args[1], $args[2])) {
            $sender->sendMessage("§c사용법: /petadmin remove <플레이어> <번호>");
            return;
        }

        $targetName = $args[1];
        $index      = (int)$args[2] - 1;
        $target     = $this->plugin->getServer()->getPlayerByPrefix($targetName);

        if ($target === null) {
            $sender->sendMessage("§c플레이어를 찾을 수 없습니다.");
            return;
        }

        if ($this->plugin->getPetManager()->releasePet($target, $index)) {
            $sender->sendMessage("§a{$target->getName()} §f의 §e" . ($index + 1) . "번 §f펫을 제거했습니다.");
        }
    }

    private function handleReload(CommandSender $sender): void {
        $sender->sendMessage("§8펫 시스템 재로드 중...");
        $sender->sendMessage("§a펫 시스템이 재로드되었습니다.");
    }

    private function handleInfo(CommandSender $sender, array $args): void {
        if (!isset($args[1])) {
            $sender->sendMessage("§c사용법: /petadmin info <플레이어>");
            return;
        }

        $target = $this->plugin->getServer()->getPlayerByPrefix($args[1]);
        if ($target === null) {
            $sender->sendMessage("§c오프라인 플레이어는 조회할 수 없습니다.");
            return;
        }

        $pets = $this->plugin->getPetManager()->getPlayerPets($target);
        $sender->sendMessage("§6[{$target->getName()}] §f보유 펫: " . count($pets) . "마리");

        foreach ($pets as $i => $pet) {
            $sender->sendMessage("§e" . ($i + 1) . ". §f" . $pet->getCustomName() . " §8(" . $pet->getPetId() . ") Lv." . $pet->getLevel());
        }

        $active = $this->plugin->getPetManager()->getActivePet($target);
        if ($active !== null) {
            $sender->sendMessage("§a현재 소환 중: §f" . $active->getPetData()->getCustomName());
        }
    }

    private function handleListDefs(CommandSender $sender): void {
        $defs = $this->plugin->getPetManager()->getAllDefinitions();
        $sender->sendMessage("§6══ 등록된 펫 종류 ══");
        foreach ($defs as $id => $def) {
            $mountable = $def->isMountable() ? "§a[탑승가능]" : "";
            $sender->sendMessage("§e{$id} §8- §f" . $def->getDisplayName() . " {$mountable} §8카테고리: " . $def->getCategory());
        }
    }
}