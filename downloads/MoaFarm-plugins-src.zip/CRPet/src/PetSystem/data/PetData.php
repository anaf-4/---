<?php

declare(strict_types=1);

namespace PetSystem\data;

/**
 * 펫의 저장 데이터를 담는 모델 클래스
 * MCPets의 statistics, taming, evolution 데이터를 참고
 */
class PetData {

    // 진화 단계 상수
    public const STAGE_BABY   = 0;
    public const STAGE_YOUNG  = 1;
    public const STAGE_ADULT  = 2;
    public const STAGE_ELDER  = 3;

    // 상태 상수
    public const STATE_FOLLOWING = "following";
    public const STATE_SITTING   = "sitting";
    public const STATE_GUARDING  = "guarding";

    public function __construct(
        private string $petId,          // pets.yml에서 정의한 ID (예: "cat", "wolf")
        private string $ownerUUID,
        private string $customName,
        private int    $level        = 1,
        private int    $exp          = 0,
        private int    $expToNext    = 100,
        private float  $health       = 20.0,
        private float  $maxHealth    = 20.0,
        private int    $evolutionStage = self::STAGE_BABY,
        private string $state        = self::STATE_FOLLOWING,
        private array  $inventory    = [],          // 아이템 저장 (슬롯 => item 배열)
        private string $skin         = "default",   // 스킨 선택
        private int    $happiness    = 100,         // 행복도 (0~100)
        private int    $hunger       = 100,         // 배고픔 (0~100)
        private array  $unlockedSkills = [],
        private int    $totalPlaytime = 0,          // 함께한 틱 수
    ) {}

    // ── getters ──────────────────────────────────────────────────────────────

    public function getPetId(): string { return $this->petId; }
    public function getOwnerUUID(): string { return $this->ownerUUID; }
    public function getCustomName(): string { return $this->customName; }
    public function getLevel(): int { return $this->level; }
    public function getExp(): int { return $this->exp; }
    public function getExpToNext(): int { return $this->expToNext; }
    public function getHealth(): float { return $this->health; }
    public function getMaxHealth(): float { return $this->maxHealth; }
    public function getEvolutionStage(): int { return $this->evolutionStage; }
    public function getState(): string { return $this->state; }
    public function getInventory(): array { return $this->inventory; }
    public function getSkin(): string { return $this->skin; }
    public function getHappiness(): int { return $this->happiness; }
    public function getHunger(): int { return $this->hunger; }
    public function getUnlockedSkills(): array { return $this->unlockedSkills; }
    public function getTotalPlaytime(): int { return $this->totalPlaytime; }

    // ── setters ──────────────────────────────────────────────────────────────

    public function setCustomName(string $name): void { $this->customName = $name; }
    public function setHealth(float $hp): void { $this->health = max(0.0, min($hp, $this->maxHealth)); }
    public function setMaxHealth(float $hp): void { $this->maxHealth = $hp; }
    public function setState(string $state): void { $this->state = $state; }
    public function setSkin(string $skin): void { $this->skin = $skin; }
    public function setInventory(array $inv): void { $this->inventory = $inv; }

    public function setHappiness(int $val): void {
        $this->happiness = max(0, min(100, $val));
    }

    public function setHunger(int $val): void {
        $this->hunger = max(0, min(100, $val));
    }

    public function addPlaytime(int $ticks): void {
        $this->totalPlaytime += $ticks;
    }

    // ── 경험치 / 레벨업 ───────────────────────────────────────────────────────

    public function addExp(int $amount): bool {
        $this->exp += $amount;
        if ($this->exp >= $this->expToNext) {
            $this->levelUp();
            return true;
        }
        return false;
    }

    private function levelUp(): void {
        $this->exp -= $this->expToNext;
        $this->level++;
        $this->expToNext = (int)($this->expToNext * 1.3);
        $this->maxHealth += 2.0;
        $this->health = $this->maxHealth;
    }

    public function getExpPercent(): float {
        return $this->expToNext > 0 ? ($this->exp / $this->expToNext) * 100 : 100;
    }

    // ── 진화 ─────────────────────────────────────────────────────────────────

    public function canEvolve(): bool {
        return $this->evolutionStage < self::STAGE_ELDER && $this->level >= $this->getRequiredLevelForNextEvolution();
    }

    public function getRequiredLevelForNextEvolution(): int {
        return match($this->evolutionStage) {
            self::STAGE_BABY  => 10,
            self::STAGE_YOUNG => 25,
            self::STAGE_ADULT => 50,
            default           => PHP_INT_MAX,
        };
    }

    public function evolve(): bool {
        if (!$this->canEvolve()) return false;
        $this->evolutionStage++;
        $this->maxHealth += 10.0;
        $this->health = $this->maxHealth;
        return true;
    }

    public function getStageName(): string {
        return match($this->evolutionStage) {
            self::STAGE_BABY  => "아기",
            self::STAGE_YOUNG => "청년",
            self::STAGE_ADULT => "성체",
            self::STAGE_ELDER => "장로",
            default           => "알 수 없음",
        };
    }

    // ── 스킬 ─────────────────────────────────────────────────────────────────

    public function unlockSkill(string $skillId): void {
        if (!in_array($skillId, $this->unlockedSkills, true)) {
            $this->unlockedSkills[] = $skillId;
        }
    }

    public function hasSkill(string $skillId): bool {
        return in_array($skillId, $this->unlockedSkills, true);
    }

    // ── 직렬화 ────────────────────────────────────────────────────────────────

    public function toArray(): array {
        return [
            "petId"           => $this->petId,
            "ownerUUID"       => $this->ownerUUID,
            "customName"      => $this->customName,
            "level"           => $this->level,
            "exp"             => $this->exp,
            "expToNext"       => $this->expToNext,
            "health"          => $this->health,
            "maxHealth"       => $this->maxHealth,
            "evolutionStage"  => $this->evolutionStage,
            "state"           => $this->state,
            "inventory"       => $this->inventory,
            "skin"            => $this->skin,
            "happiness"       => $this->happiness,
            "hunger"          => $this->hunger,
            "unlockedSkills"  => $this->unlockedSkills,
            "totalPlaytime"   => $this->totalPlaytime,
        ];
    }

    public static function fromArray(array $data): self {
        return new self(
            petId:          $data["petId"]          ?? "unknown",
            ownerUUID:      $data["ownerUUID"]      ?? "",
            customName:     $data["customName"]     ?? "펫",
            level:          $data["level"]          ?? 1,
            exp:            $data["exp"]            ?? 0,
            expToNext:      $data["expToNext"]      ?? 100,
            health:         (float)($data["health"] ?? 20.0),
            maxHealth:      (float)($data["maxHealth"] ?? 20.0),
            evolutionStage: $data["evolutionStage"] ?? self::STAGE_BABY,
            state:          $data["state"]          ?? self::STATE_FOLLOWING,
            inventory:      $data["inventory"]      ?? [],
            skin:           $data["skin"]           ?? "default",
            happiness:      $data["happiness"]      ?? 100,
            hunger:         $data["hunger"]         ?? 100,
            unlockedSkills: $data["unlockedSkills"] ?? [],
            totalPlaytime:  $data["totalPlaytime"]  ?? 0,
        );
    }
}