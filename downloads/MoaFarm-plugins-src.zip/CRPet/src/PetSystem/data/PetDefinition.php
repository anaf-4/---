<?php

declare(strict_types=1);

namespace PetSystem\data;

/**
 * pets.yml 에서 로드하는 펫 종류 정의
 * MCPets의 Pet 오브젝트 (비활성 인스턴스) 개념
 */
class PetDefinition {

    public function __construct(
        private string $id,
        private string $displayName,
        private string $entityType,         // PocketMine 엔티티 타입 (예: "Cat", "Wolf")
        private string $permission,
        private float  $baseHealth,
        private float  $baseScale,
        private array  $evolutionScales,    // 단계별 크기 [baby, young, adult, elder]
        private array  $foods,              // 먹일 수 있는 아이템 ID 목록
        private int    $expPerKill,
        private array  $skills,             // 해제 가능한 스킬 목록
        private bool   $mountable,
        private string $tamingItem,         // 길들이기에 사용하는 아이템
        private int    $tamingChance,       // 길들이기 성공 확률 (%)
        private array  $evolutions,         // 진화 시 스킨 / 타입 변경
        private array  $sounds,             // 사운드 맵
        private string $category,           // GUI 카테고리
    ) {}

    public function getId(): string { return $this->id; }
    public function getDisplayName(): string { return $this->displayName; }
    public function getEntityType(): string { return $this->entityType; }
    public function getPermission(): string { return $this->permission; }
    public function getBaseHealth(): float { return $this->baseHealth; }
    public function getBaseScale(): float { return $this->baseScale; }
    public function getEvolutionScales(): array { return $this->evolutionScales; }
    public function getFoods(): array { return $this->foods; }
    public function getExpPerKill(): int { return $this->expPerKill; }
    public function getSkills(): array { return $this->skills; }
    public function isMountable(): bool { return $this->mountable; }
    public function getTamingItem(): string { return $this->tamingItem; }
    public function getTamingChance(): int { return $this->tamingChance; }
    public function getEvolutions(): array { return $this->evolutions; }
    public function getSounds(): array { return $this->sounds; }
    public function getCategory(): string { return $this->category; }

    public function getScaleForStage(int $stage): float {
        return $this->evolutionScales[$stage] ?? $this->baseScale;
    }

    public static function fromArray(string $id, array $data): self {
        return new self(
            id:              $id,
            displayName:     $data["display_name"]   ?? $id,
            entityType:      $data["entity_type"]    ?? "Cat",
            permission:      $data["permission"]     ?? "petsystem.pet." . $id,
            baseHealth:      (float)($data["base_health"]  ?? 20.0),
            baseScale:       (float)($data["base_scale"]   ?? 0.5),
            evolutionScales: $data["evolution_scales"] ?? [0.5, 0.7, 1.0, 1.3],
            foods:           $data["foods"]           ?? [],
            expPerKill:      (int)($data["exp_per_kill"]   ?? 5),
            skills:          $data["skills"]          ?? [],
            mountable:       (bool)($data["mountable"] ?? false),
            tamingItem:      $data["taming_item"]     ?? "fish",
            tamingChance:    (int)($data["taming_chance"]  ?? 50),
            evolutions:      $data["evolutions"]      ?? [],
            sounds:          $data["sounds"]          ?? [],
            category:        $data["category"]        ?? "일반",
        );
    }
}