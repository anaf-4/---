<?php

declare(strict_types=1);

namespace PetSystem\listener;

use PetSystem\entity\BasePetEntity;
use PetSystem\Main;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDeathEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\Listener;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;

class PetListener implements Listener {

    public function __construct(private Main $plugin) {}

    // ── 접속 / 나가기 ────────────────────────────────────────────────────────

    public function onJoin(PlayerJoinEvent $event): void {
        $this->plugin->getPetManager()->loadPlayerData($event->getPlayer());
    }

    public function onQuit(PlayerQuitEvent $event): void {
        $this->plugin->getPetManager()->onPlayerQuit($event->getPlayer());
    }

    // ── 펫 피해 차단 ─────────────────────────────────────────────────────────

    public function onEntityDamage(EntityDamageEvent $event): void {
        $entity = $event->getEntity();
        if (!($entity instanceof BasePetEntity)) return;

        if ($event instanceof EntityDamageByEntityEvent) {
            $damager = $event->getDamager();
            if ($damager instanceof Player && !$entity->isOwner($damager)) {
                $event->cancel();
                $damager->sendTip("§c타인의 펫을 공격할 수 없습니다.");
                return;
            }
        }

        // 낙하 피해 차단
        if ($event->getCause() === EntityDamageEvent::CAUSE_FALL) {
            $event->cancel();
        }
    }

    // ── 펫 사망 처리 ─────────────────────────────────────────────────────────

    public function onEntityDeath(EntityDeathEvent $event): void {
        $entity = $event->getEntity();
        if (!($entity instanceof BasePetEntity)) return;

        $event->setDrops([]);
        $event->setXpDropAmount(0);
    }

    // ── 펫 상호작용 (우클릭) ─────────────────────────────────────────────────

    /**
     * PM5에서 PlayerInteractEvent::RIGHT_CLICK_AIR 상수 제거됨.
     * LEFT_CLICK_BLOCK(0)만 걸러내고 나머지 액션은 모두 처리.
     */
    public function onInteract(PlayerInteractEvent $event): void {
        $player = $event->getPlayer();
        $action = $event->getAction();

        // 좌클릭 블록은 무시
        if ($action === PlayerInteractEvent::LEFT_CLICK_BLOCK) return;

        // 시야 방향으로 가까운 펫 탐색 (5블록 이내)
        $entity = $this->getTargetPet($player, 5.0);
        if ($entity === null) return;
        if (!$entity->isOwner($player)) return;

        $event->cancel();

        $item   = $player->getInventory()->getItemInHand();
        $itemId = (string)$item->getTypeId();

        $manager = $this->plugin->getPetManager();

        if ($manager->feedActivePet($player, $itemId)) {
            if (!$player->isCreative()) {
                $held = $player->getInventory()->getItemInHand();
                $held->setCount($held->getCount() - 1);
                $player->getInventory()->setItemInHand(
                    $held->getCount() > 0 ? $held : VanillaItems::AIR()
                );
            }
            $player->sendTip("§a" . $entity->getPetData()->getCustomName() . " §f이(가) 맛있게 먹었습니다!");
        } else {
            $manager->openPetGui($player, $entity);
        }
    }

    /**
     * 플레이어 시선 기준으로 가장 가까운 BasePetEntity 반환
     */
    private function getTargetPet(Player $player, float $maxDistance): ?BasePetEntity {
        $eyePos  = $player->getEyePos();
        $dirVec  = $player->getDirectionVector();
        $world   = $player->getWorld();

        $closest     = null;
        $closestDist = $maxDistance;

        foreach ($world->getEntities() as $entity) {
            if (!($entity instanceof BasePetEntity)) continue;

            $diff = $entity->getPosition()->subtractVector($eyePos);
            $dot  = $diff->dot($dirVec);
            if ($dot < 0 || $dot > $maxDistance) continue;

            $projected = $eyePos->addVector($dirVec->multiply($dot));
            $perpDist  = $entity->getPosition()->subtractVector($projected)->length();

            if ($perpDist <= 1.0 && $dot < $closestDist) {
                $closest     = $entity;
                $closestDist = $dot;
            }
        }

        return $closest;
    }

    // ── 킬 경험치 ────────────────────────────────────────────────────────────

    public function onEntityKilled(EntityDeathEvent $event): void {
        $entity = $event->getEntity();
        if ($entity instanceof BasePetEntity) return;

        $lastDamage = $entity->getLastDamageCause();
        if (!($lastDamage instanceof EntityDamageByEntityEvent)) return;

        $damager = $lastDamage->getDamager();

        if ($damager instanceof Player) {
            $this->plugin->getPetManager()->grantKillExp($damager);
        } elseif ($damager instanceof BasePetEntity) {
            $owner = $damager->getOwner();
            if ($owner !== null) {
                $this->plugin->getPetManager()->grantKillExp($owner);
            }
        }
    }
}