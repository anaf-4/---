<?php

declare(strict_types=1);

namespace PetSystem\task;

use PetSystem\Main;
use pocketmine\scheduler\Task;

class PetTickTask extends Task {

    private int $autoSaveTick = 0;

    public function __construct(private Main $plugin) {}

    public function onRun(): void {
        $this->autoSaveTick++;

        // 1500 * 4틱 = 6000틱 = 5분마다 자동 저장
        if ($this->autoSaveTick >= 1500) {
            $this->plugin->getPetManager()->saveAllPets();
            $this->autoSaveTick = 0;
        }
    }
}