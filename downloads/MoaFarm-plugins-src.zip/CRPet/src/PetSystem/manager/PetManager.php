<?php

declare(strict_types=1);

namespace PetSystem\manager;

use PetSystem\data\PetData;
use PetSystem\data\PetDefinition;
use PetSystem\entity\BasePetEntity;
use PetSystem\entity\PetEntityRegistry;
use PetSystem\Main;
use PetSystem\ui\PetFormUI;
use pocketmine\entity\Location;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\player\Player;
use pocketmine\utils\Config;

class PetManager {

    /** @var array<string, BasePetEntity> UUID => 활성 펫 */
    private array $activePets = [];

    /** @var array<string, PetData[]> UUID => 소유 펫 목록 */
    private array $playerPets = [];

    /** @var array<string, PetDefinition> petId => 펫 정의 */
    private array $definitions = [];

    /** @var array<string, Config> UUID => YAML Config (MySQL 없을 때 폴백) */
    private array $configs = [];

    public function __construct(private Main $plugin) {
        $this->loadDefinitions();
    }

    // ── 펫 정의 로드 ──────────────────────────────────────────────────────────

    private function loadDefinitions(): void {
        $config = new Config($this->plugin->getDataFolder() . "pets.yml", Config::YAML);
        foreach ($config->getAll() as $id => $data) {
            if (is_array($data)) {
                $this->definitions[(string)$id] = PetDefinition::fromArray((string)$id, $data);
            }
        }
        $this->plugin->getLogger()->info("§8펫 정의 로드 완료: §e" . count($this->definitions) . "종");
    }

    public function getDefinition(string $petId): ?PetDefinition {
        return $this->definitions[$petId] ?? null;
    }

    /** @return PetDefinition[] */
    public function getAllDefinitions(): array {
        return $this->definitions;
    }

    // ── MySQL 연결 헬퍼 ────────────────────────────────────────────────────────

    private function db(): ?\mysqli {
        $db = $this->plugin->getDb();
        if ($db === null) return null;
        try { if (!@$db->ping()) $this->plugin->reconnectDb(); } catch (\Throwable) { $this->plugin->reconnectDb(); }
        return $this->plugin->getDb();
    }

    private function useMySQL(): bool {
        return $this->plugin->getDb() !== null;
    }

    // ── 플레이어 데이터 로드 ──────────────────────────────────────────────────

    public function loadPlayerData(Player $player): void {
        $uuid = $player->getUniqueId()->toString();
        if (isset($this->playerPets[$uuid])) return;

        if ($this->useMySQL()) {
            $this->loadFromMySQL($uuid);
        } else {
            $this->loadFromYAML($uuid);
        }
    }

    private function loadFromMySQL(string $uuid): void {
        $db = $this->db();
        if ($db === null) { $this->loadFromYAML($uuid); return; }

        $stmt = $db->prepare('SELECT * FROM pet_data WHERE owner_uuid = ? ORDER BY pet_index ASC');
        $stmt->bind_param('s', $uuid);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        $pets = [];
        foreach ($rows as $row) {
            $pets[] = PetData::fromArray([
                'petId'          => $row['pet_id'],
                'ownerUUID'      => $row['owner_uuid'],
                'customName'     => $row['custom_name'],
                'level'          => (int) $row['level'],
                'exp'            => (int) $row['exp'],
                'expToNext'      => (int) $row['exp_to_next'],
                'health'         => (float) $row['health'],
                'maxHealth'      => (float) $row['max_health'],
                'evolutionStage' => (int) $row['evolution_stage'],
                'state'          => $row['state'],
                'inventory'      => json_decode($row['inventory'], true) ?? [],
                'skin'           => $row['skin'],
                'happiness'      => (int) $row['happiness'],
                'hunger'         => (int) $row['hunger'],
                'unlockedSkills' => json_decode($row['unlocked_skills'], true) ?? [],
                'totalPlaytime'  => (int) $row['total_playtime'],
            ]);
        }
        $this->playerPets[$uuid] = $pets;
    }

    private function loadFromYAML(string $uuid): void {
        $config = new Config(
            $this->plugin->getDataFolder() . "player_data/{$uuid}.yml",
            Config::YAML
        );
        $this->configs[$uuid] = $config;

        $pets = [];
        foreach ($config->getAll() as $petArray) {
            if (is_array($petArray) && isset($petArray["petId"])) {
                $pets[] = PetData::fromArray($petArray);
            }
        }
        $this->playerPets[$uuid] = $pets;
    }

    // ── 플레이어 데이터 저장 ──────────────────────────────────────────────────

    private function savePlayerDataByUUID(string $uuid): void {
        if (!isset($this->playerPets[$uuid])) return;

        if ($this->useMySQL()) {
            $this->saveToMySQL($uuid);
        } else {
            $this->saveToYAML($uuid);
        }
    }

    private function saveToMySQL(string $uuid): void {
        $db = $this->db();
        if ($db === null) { $this->saveToYAML($uuid); return; }

        $db->query("DELETE FROM pet_data WHERE owner_uuid = '{$db->real_escape_string($uuid)}'");

        $stmt = $db->prepare(
            'INSERT INTO pet_data (owner_uuid, pet_index, pet_id, custom_name, level, exp, exp_to_next,
                health, max_health, evolution_stage, state, inventory, skin, happiness, hunger, unlocked_skills, total_playtime)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );

        foreach ($this->playerPets[$uuid] as $i => $pet) {
            $inv     = json_encode($pet->getInventory());
            $skills  = json_encode($pet->getUnlockedSkills());
            $petId   = $pet->getPetId();
            $name    = $pet->getCustomName();
            $level   = $pet->getLevel();
            $exp     = $pet->getExp();
            $expNext = $pet->getExpToNext();
            $hp      = $pet->getHealth();
            $maxHp   = $pet->getMaxHealth();
            $stage   = $pet->getEvolutionStage();
            $state   = $pet->getState();
            $skin    = $pet->getSkin();
            $happy   = $pet->getHappiness();
            $hunger  = $pet->getHunger();
            $playtime = $pet->getTotalPlaytime();

            $stmt->bind_param('sississiddisisssi',
                $uuid, $i, $petId, $name, $level, $exp, $expNext,
                $hp, $maxHp, $stage, $state, $inv, $skin, $happy, $hunger, $skills, $playtime
            );
            $stmt->execute();
        }
        $stmt->close();
    }

    private function saveToYAML(string $uuid): void {
        $config = $this->configs[$uuid]
            ?? new Config($this->plugin->getDataFolder() . "player_data/{$uuid}.yml", Config::YAML);

        $data = [];
        foreach ($this->playerPets[$uuid] as $i => $pet) {
            $data["pet_{$i}"] = $pet->toArray();
        }
        $config->setAll($data);
        $config->save();
    }

    public function saveAllPets(): void {
        foreach (array_keys($this->playerPets) as $uuid) {
            $this->savePlayerDataByUUID($uuid);
        }
    }

    // ── 펫 조회 ───────────────────────────────────────────────────────────────

    /** @return PetData[] */
    public function getPlayerPets(Player $player): array {
        return $this->playerPets[$player->getUniqueId()->toString()] ?? [];
    }

    public function getActivePet(Player $player): ?BasePetEntity {
        $uuid   = $player->getUniqueId()->toString();
        $entity = $this->activePets[$uuid] ?? null;
        if ($entity !== null && $entity->isClosed()) {
            unset($this->activePets[$uuid]);
            return null;
        }
        return $entity;
    }

    public function hasActivePet(Player $player): bool {
        return $this->getActivePet($player) !== null;
    }

    public function getMaxPets(Player $player): int {
        if ($player->hasPermission("petsystem.maxpets.5")) return 5;
        if ($player->hasPermission("petsystem.maxpets.3")) return 3;
        return $this->plugin->getPetConfig()->getMaxPetsDefault();
    }

    // ── RPG 레벨 보너스 계산 ─────────────────────────────────────────────────

    private function getRPGMaxHealthBonus(Player $player): float {
        if (!class_exists(\anaf2197\advancedlevel\AdvancedLevel::class)) return 0.0;
        $levelData = \anaf2197\advancedlevel\AdvancedLevel::getInstance()->getPlayerLevel($player);
        if (!($levelData instanceof \anaf2197\advancedlevel\PlayerLevel)) return 0.0;
        $level = $levelData->getLevel();
        return match(true) {
            $level >= 50 => 30.0,
            $level >= 30 => 20.0,
            $level >= 20 => 10.0,
            $level >= 10 => 5.0,
            default      => 0.0,
        };
    }

    // ── 펫 지급 ───────────────────────────────────────────────────────────────

    public function givePet(Player $player, string $petId, string $name = ""): bool {
        $def = $this->getDefinition($petId);
        if ($def === null) return false;

        $uuid = $player->getUniqueId()->toString();
        $this->playerPets[$uuid] ??= [];

        if (count($this->playerPets[$uuid]) >= $this->getMaxPets($player)) {
            $player->sendMessage("§c이미 최대 펫 수에 도달했습니다.");
            return false;
        }

        $petName = $name !== "" ? $name : $def->getDisplayName();
        $petData = new PetData(
            petId:      $petId,
            ownerUUID:  $uuid,
            customName: $petName,
            health:     $def->getBaseHealth(),
            maxHealth:  $def->getBaseHealth(),
        );

        $this->playerPets[$uuid][] = $petData;
        $this->savePlayerDataByUUID($uuid);
        $player->sendMessage("§a§e{$petName} §a펫을 획득했습니다!");
        return true;
    }

    // ── 펫 소환 ───────────────────────────────────────────────────────────────

    public function summonPet(Player $player, int $petIndex = 0): bool {
        $uuid = $player->getUniqueId()->toString();
        $pets = $this->playerPets[$uuid] ?? [];

        if (!isset($pets[$petIndex])) {
            $player->sendMessage("§c해당 인덱스의 펫이 없습니다.");
            return false;
        }

        if ($this->hasActivePet($player)) {
            $this->despawnPet($player);
        }

        $petData = $pets[$petIndex];
        $def     = $this->getDefinition($petData->getPetId());
        if ($def === null) return false;

        if (!$player->hasPermission($def->getPermission())) {
            $player->sendMessage("§c이 펫을 소환할 권한이 없습니다.");
            return false;
        }

        // RPG 보너스 적용
        $rpgBonus = $this->getRPGMaxHealthBonus($player);
        if ($rpgBonus > 0) {
            $newMax = $petData->getMaxHealth() + $rpgBonus;
            $petData->setMaxHealth($newMax);
            if ($petData->getHealth() < $newMax) {
                $petData->setHealth(min($petData->getHealth() + $rpgBonus, $newMax));
            }
        }

        $entityClass = PetEntityRegistry::getEntityClass($petData->getPetId());
        $loc         = Location::fromObject($player->getPosition()->add(1, 0, 1), $player->getWorld());

        /** @var BasePetEntity $entity */
        $entity = new $entityClass($loc, new CompoundTag(), $petData, $def);
        $entity->setOwner($player);
        $entity->spawnToAll();

        $this->activePets[$uuid] = $entity;

        $msg = "§a§e" . $petData->getCustomName() . " §a이(가) 소환되었습니다!";
        if ($rpgBonus > 0) {
            $msg .= " §8(RPG 보너스 §a+{$rpgBonus}HP§8)";
        }
        $player->sendMessage($msg);
        return true;
    }

    // ── 펫 소환 해제 ──────────────────────────────────────────────────────────

    public function despawnPet(Player $player): bool {
        $uuid   = $player->getUniqueId()->toString();
        $entity = $this->activePets[$uuid] ?? null;
        if ($entity === null) return false;

        if (!$entity->isClosed()) {
            $entity->getPetData()->setHealth($entity->getHealth());
            $entity->close();
        }

        unset($this->activePets[$uuid]);
        $this->savePlayerDataByUUID($uuid);
        $player->sendMessage("§8펫이 인벤토리로 돌아갔습니다.");
        return true;
    }

    public function despawnAllPets(): void {
        foreach ($this->activePets as $entity) {
            if (!$entity->isClosed()) {
                $entity->getPetData()->setHealth($entity->getHealth());
                $entity->close();
            }
        }
        $this->activePets = [];
    }

    // ── GUI 열기 ──────────────────────────────────────────────────────────────

    public function openPetGui(Player $player, BasePetEntity $entity): void {
        PetFormUI::openMainMenu($player, $this->plugin);
    }

    // ── 이름 변경 ─────────────────────────────────────────────────────────────

    public function renamePet(Player $player, int $petIndex, string $newName): bool {
        $uuid = $player->getUniqueId()->toString();
        if (!isset($this->playerPets[$uuid][$petIndex])) return false;

        $this->playerPets[$uuid][$petIndex]->setCustomName($newName);
        $this->getActivePet($player)?->updateNameTag();

        $this->savePlayerDataByUUID($uuid);
        $player->sendMessage("§a펫 이름이 §e{$newName} §a(으)로 변경되었습니다.");
        return true;
    }

    // ── 펫 해방 ───────────────────────────────────────────────────────────────

    public function releasePet(Player $player, int $petIndex): bool {
        $uuid = $player->getUniqueId()->toString();
        if (!isset($this->playerPets[$uuid][$petIndex])) return false;

        $petName = $this->playerPets[$uuid][$petIndex]->getCustomName();

        $active = $this->getActivePet($player);
        if ($active !== null && $active->getPetData() === $this->playerPets[$uuid][$petIndex]) {
            if (!$active->isClosed()) $active->close();
            unset($this->activePets[$uuid]);
        }

        array_splice($this->playerPets[$uuid], $petIndex, 1);
        $this->savePlayerDataByUUID($uuid);
        $player->sendMessage("§8{$petName} §f을(를) 자연으로 돌려보냈습니다.");
        return true;
    }

    // ── 앉기 / 가드 토글 ──────────────────────────────────────────────────────

    public function toggleSit(Player $player): bool {
        $active = $this->getActivePet($player);
        if ($active === null) {
            $player->sendMessage("§c소환된 펫이 없습니다.");
            return false;
        }

        $data = $active->getPetData();
        if ($data->getState() === PetData::STATE_SITTING) {
            $data->setState(PetData::STATE_FOLLOWING);
            $player->sendMessage("§a" . $data->getCustomName() . " §f이(가) 일어났습니다.");
        } else {
            $data->setState(PetData::STATE_SITTING);
            $player->sendMessage("§8" . $data->getCustomName() . " §f이(가) 앉았습니다.");
        }
        return true;
    }

    public function toggleGuard(Player $player): bool {
        $active = $this->getActivePet($player);
        if ($active === null) {
            $player->sendMessage("§c소환된 펫이 없습니다.");
            return false;
        }

        $data = $active->getPetData();
        if ($data->getState() === PetData::STATE_GUARDING) {
            $data->setState(PetData::STATE_FOLLOWING);
            $player->sendMessage("§a" . $data->getCustomName() . " §f이(가) 경호 해제되었습니다.");
        } else {
            $data->setState(PetData::STATE_GUARDING);
            $player->sendMessage("§c" . $data->getCustomName() . " §f이(가) 경호 모드로 전환되었습니다!");
        }
        return true;
    }

    // ── 먹이 주기 ─────────────────────────────────────────────────────────────

    public function feedActivePet(Player $player, string $itemId): bool {
        return $this->getActivePet($player)?->feed($itemId) ?? false;
    }

    // ── 진화 ──────────────────────────────────────────────────────────────────

    public function tryEvolveActivePet(Player $player): bool {
        $active = $this->getActivePet($player);
        if ($active === null) {
            $player->sendMessage("§c소환된 펫이 없습니다.");
            return false;
        }
        if (!$active->tryEvolve()) {
            $req = $active->getPetData()->getRequiredLevelForNextEvolution();
            $player->sendMessage("§c아직 진화할 수 없습니다. 필요 레벨: §e{$req}");
            return false;
        }
        return true;
    }

    // ── 죽음 처리 ─────────────────────────────────────────────────────────────

    public function onPetDie(BasePetEntity $entity): void {
        $owner = $entity->getOwner();
        if ($owner === null) return;

        $uuid = $owner->getUniqueId()->toString();
        unset($this->activePets[$uuid]);

        $data = $entity->getPetData();
        $data->setHappiness(max(0, $data->getHappiness() - 30));
        $data->setHealth(1.0);

        $this->savePlayerDataByUUID($uuid);
        $owner->sendMessage("§c§e" . $data->getCustomName() . " §c이(가) 쓰러졌습니다... 다시 소환하면 회복됩니다.");
    }

    // ── 킬 경험치 ─────────────────────────────────────────────────────────────

    public function grantKillExp(Player $player): void {
        $this->getActivePet($player)?->grantKillExp();
    }

    // ── 플레이어 퇴장 ─────────────────────────────────────────────────────────

    public function onPlayerQuit(Player $player): void {
        $uuid   = $player->getUniqueId()->toString();
        $entity = $this->activePets[$uuid] ?? null;

        if ($entity !== null && !$entity->isClosed()) {
            $entity->getPetData()->setHealth($entity->getHealth());
            $entity->close();
            unset($this->activePets[$uuid]);
        }

        $this->savePlayerDataByUUID($uuid);
        unset($this->playerPets[$uuid], $this->configs[$uuid]);
    }
}
