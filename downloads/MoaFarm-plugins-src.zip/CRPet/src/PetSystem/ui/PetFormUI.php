<?php

declare(strict_types=1);

namespace PetSystem\ui;

use PetSystem\data\PetData;
use PetSystem\Main;
use pocketmine\form\Form;
use pocketmine\player\Player;

class PetFormUI {

    public static function openMainMenu(Player $player, Main $plugin): void {
        $activePet = $plugin->getPetManager()->getActivePet($player);
        $petCount  = count($plugin->getPetManager()->getPlayerPets($player));

        $activeName = $activePet !== null
            ? "§a소환 중: §e" . $activePet->getPetData()->getCustomName()
            : "§8소환된 펫 없음";

        $player->sendForm(new class($plugin, $activePet, $petCount, $activeName) implements Form {
            public function __construct(
                private Main $plugin,
                private mixed $activePet,
                private int $petCount,
                private string $activeName,
            ) {}

            public function jsonSerialize(): mixed {
                return [
                    "type"    => "form",
                    "title"   => "§6펫 시스템 ",
                    "content" => "§f보유 펫: §e{$this->petCount}마리\n{$this->activeName}",
                    "buttons" => [
                        ["text" => "§f펫 목록 보기"],
                        ["text" => "§f현재 펫 상태"],
                        ["text" => "§f펫 인벤토리"],
                        ["text" => "§f스킨 선택"],
                        ["text" => "§f경호 모드 토글"],
                        ["text" => "§f앉기 토글"],
                        ["text" => "§f먹이 주기"],
                        ["text" => "§f진화"],
                        ["text" => "§f닫기"],
                    ]
                ];
            }

            public function handleResponse(Player $player, mixed $data): void {
                if ($data === null) return;
                $pm = $this->plugin->getPetManager();

                match ((int)$data) {
                    0 => PetFormUI::openPetList($player, $this->plugin),
                    1 => $pm->hasActivePet($player)
                        ? PetFormUI::openPetStatus($player, $this->plugin)
                        : $player->sendMessage("§c소환된 펫이 없습니다."),
                    2 => $pm->hasActivePet($player)
                        ? PetFormUI::openPetInventory($player, $this->plugin)
                        : $player->sendMessage("§c소환된 펫이 없습니다."),
                    3 => $pm->hasActivePet($player)
                        ? PetFormUI::openSkinSelector($player, $this->plugin)
                        : $player->sendMessage("§c소환된 펫이 없습니다."),
                    4 => $pm->toggleGuard($player),
                    5 => $pm->toggleSit($player),
                    6 => PetFormUI::openFeedMenu($player, $this->plugin),
                    7 => $pm->tryEvolveActivePet($player),
                    default => null,
                };
            }
        });
    }

    public static function openPetList(Player $player, Main $plugin): void {
        $pets = $plugin->getPetManager()->getPlayerPets($player);

        if (empty($pets)) {
            $player->sendMessage("§c보유한 펫이 없습니다. §e/petadmin give §c로 펫을 획득하세요.");
            return;
        }

        $buttons = [];
        foreach ($pets as $pet) {
            $buttons[] = ["text" => "§e" . $pet->getCustomName() . "\n§8[" . $pet->getStageName() . "] Lv." . $pet->getLevel()];
        }
        $buttons[] = ["text" => "§8← 돌아가기"];

        $player->sendForm(new class($plugin, $pets, $buttons) implements Form {
            public function __construct(
                private Main $plugin,
                private array $pets,
                private array $buttons,
            ) {}

            public function jsonSerialize(): mixed {
                return [
                    "type"    => "form",
                    "title"   => "§e나의 펫 목록",
                    "content" => "§f펫을 선택하면 소환하거나 관리할 수 있습니다.",
                    "buttons" => $this->buttons,
                ];
            }

            public function handleResponse(Player $player, mixed $data): void {
                if ($data === null) return;
                $index = (int)$data;

                if ($index === count($this->pets)) {
                    PetFormUI::openMainMenu($player, $this->plugin);
                    return;
                }

                if (isset($this->pets[$index])) {
                    PetFormUI::openSinglePetMenu($player, $this->plugin, $index);
                }
            }
        });
    }

    public static function openSinglePetMenu(Player $player, Main $plugin, int $petIndex): void {
        $pets = $plugin->getPetManager()->getPlayerPets($player);
        if (!isset($pets[$petIndex])) return;

        $pet        = $pets[$petIndex];
        $active     = $plugin->getPetManager()->getActivePet($player);
        $isSummoned = $active !== null && $active->getPetData() === $pet;
        $summonText = $isSummoned ? "§c소환 해제" : "§a소환하기";

        $player->sendForm(new class($plugin, $petIndex, $pet, $summonText) implements Form {
            public function __construct(
                private Main $plugin,
                private int $petIndex,
                private PetData $pet,
                private string $summonText,
            ) {}

            public function jsonSerialize(): mixed {
                return [
                    "type"    => "form",
                    "title"   => "§e" . $this->pet->getCustomName(),
                    "content" => "§8단계: §f" . $this->pet->getStageName()
                        . "\n§8레벨: §a" . $this->pet->getLevel()
                        . "\n§8경험치: §e" . $this->pet->getExp() . "/" . $this->pet->getExpToNext()
                        . "\n§8체력: §c" . round($this->pet->getHealth(), 1) . "/" . round($this->pet->getMaxHealth(), 1)
                        . "\n§8행복도: §d" . $this->pet->getHappiness() . "/100"
                        . "\n§8배고픔: §6" . $this->pet->getHunger() . "/100",
                    "buttons" => [
                        ["text" => $this->summonText],
                        ["text" => "§b이름 변경"],
                        ["text" => "§c해방 (삭제)"],
                        ["text" => "§8← 돌아가기"],
                    ]
                ];
            }

            public function handleResponse(Player $player, mixed $data): void {
                if ($data === null) return;
                $pm = $this->plugin->getPetManager();

                match ((int)$data) {
                    0 => $pm->hasActivePet($player) && $pm->getActivePet($player)?->getPetData() === $this->pet
                        ? $pm->despawnPet($player)
                        : $pm->summonPet($player, $this->petIndex),
                    1 => PetFormUI::openRenameForm($player, $this->plugin, $this->petIndex),
                    2 => PetFormUI::openConfirmRelease($player, $this->plugin, $this->petIndex),
                    3 => PetFormUI::openPetList($player, $this->plugin),
                    default => null,
                };
            }
        });
    }

    public static function openRenameForm(Player $player, Main $plugin, int $petIndex): void {
        $pets = $plugin->getPetManager()->getPlayerPets($player);
        if (!isset($pets[$petIndex])) return;

        $currentName = $pets[$petIndex]->getCustomName();

        $player->sendForm(new class($plugin, $petIndex, $currentName) implements Form {
            public function __construct(
                private Main $plugin,
                private int $petIndex,
                private string $currentName,
            ) {}

            public function jsonSerialize(): mixed {
                return [
                    "type"    => "custom_form",
                    "title"   => "§b펫 이름 변경",
                    "content" => [
                        [
                            "type"        => "input",
                            "text"        => "새 이름 (최대 16자)",
                            "placeholder" => "이름 입력...",
                            "default"     => $this->currentName,
                        ]
                    ]
                ];
            }

            public function handleResponse(Player $player, mixed $data): void {
                if ($data === null) return;
                $newName = trim($data[0] ?? "");

                if (empty($newName)) {
                    $player->sendMessage("§c이름을 입력해주세요.");
                    return;
                }
                if (mb_strlen($newName) > 16) {
                    $player->sendMessage("§c이름은 최대 16자입니다.");
                    return;
                }

                $this->plugin->getPetManager()->renamePet($player, $this->petIndex, $newName);
            }
        });
    }

    public static function openConfirmRelease(Player $player, Main $plugin, int $petIndex): void {
        $pets = $plugin->getPetManager()->getPlayerPets($player);
        if (!isset($pets[$petIndex])) return;

        $petName = $pets[$petIndex]->getCustomName();

        $player->sendForm(new class($plugin, $petIndex, $petName) implements Form {
            public function __construct(
                private Main $plugin,
                private int $petIndex,
                private string $petName,
            ) {}

            public function jsonSerialize(): mixed {
                return [
                    "type"    => "modal",
                    "title"   => "§c펫 해방",
                    "content" => "§e{$this->petName} §f을(를) 정말 해방시키겠습니까?\n§c이 작업은 되돌릴 수 없습니다!",
                    "button1" => "§c예, 해방합니다",
                    "button2" => "§a아니오",
                ];
            }

            public function handleResponse(Player $player, mixed $data): void {
                if ($data === true) {
                    $this->plugin->getPetManager()->releasePet($player, $this->petIndex);
                }
            }
        });
    }

    public static function openPetStatus(Player $player, Main $plugin): void {
        $active = $plugin->getPetManager()->getActivePet($player);
        if ($active === null) return;

        $data   = $active->getPetData();
        $def    = $active->getPetDefinition();
        $skills = count($data->getUnlockedSkills()) > 0
            ? implode(", ", $data->getUnlockedSkills())
            : "없음";

        $player->sendForm(new class($plugin, $data, $def, $skills) implements Form {
            public function __construct(
                private Main $plugin,
                private PetData $data,
                private mixed $def,
                private string $skills,
            ) {}

            public function jsonSerialize(): mixed {
                return [
                    "type"    => "form",
                    "title"   => "§a" . $this->data->getCustomName() . " 상태",
                    "content" =>
                        "§6━━━━━━━━━━━━━━━━━━━━\n"
                        . "§8종류: §f" . $this->def->getDisplayName() . "\n"
                        . "§8진화 단계: §f" . $this->data->getStageName() . "\n"
                        . "§8레벨: §a" . $this->data->getLevel() . "\n"
                        . "§8경험치: §e" . $this->data->getExp() . " §8/ §e" . $this->data->getExpToNext()
                        . " §8(" . round($this->data->getExpPercent(), 1) . "%)\n"
                        . "§c체력: §f" . round($this->data->getHealth(), 1) . " / " . round($this->data->getMaxHealth(), 1) . "\n"
                        . "§6배고픔: §f" . $this->data->getHunger() . " / 100\n"
                        . "§d행복도: §f" . $this->data->getHappiness() . " / 100\n"
                        . "§b스킬: §f" . $this->skills . "\n"
                        . "§8함께한 시간: §f" . round($this->data->getTotalPlaytime() / 1200, 1) . "분\n"
                        . "§6━━━━━━━━━━━━━━━━━━━━",
                    "buttons" => [
                        ["text" => "§5진화 시도"],
                        ["text" => "§8← 메인 메뉴"],
                    ]
                ];
            }

            public function handleResponse(Player $player, mixed $data): void {
                if ($data === null) return;
                match ((int)$data) {
                    0 => $this->plugin->getPetManager()->tryEvolveActivePet($player),
                    1 => PetFormUI::openMainMenu($player, $this->plugin),
                    default => null,
                };
            }
        });
    }

    public static function openFeedMenu(Player $player, Main $plugin): void {
        $active = $plugin->getPetManager()->getActivePet($player);
        if ($active === null) {
            $player->sendMessage("§c소환된 펫이 없습니다.");
            return;
        }

        $foods   = $active->getPetDefinition()->getFoods();
        $petName = $active->getPetData()->getCustomName();

        $player->sendForm(new class($plugin, $foods, $petName) implements Form {
            public function __construct(
                private Main $plugin,
                private array $foods,
                private string $petName,
            ) {}

            public function jsonSerialize(): mixed {
                $foodList = empty($this->foods)
                    ? "§c이 펫에게 줄 수 있는 먹이가 없습니다."
                    : "§f먹이 목록:\n§8" . implode(", ", $this->foods)
                        . "\n\n§f손에 먹이를 들고 펫을 우클릭하면 먹이를 줄 수 있습니다.";

                return [
                    "type"    => "form",
                    "title"   => "§6" . $this->petName . " 먹이 주기",
                    "content" => $foodList,
                    "buttons" => [["text" => "§8← 돌아가기"]],
                ];
            }

            public function handleResponse(Player $player, mixed $data): void {
                if ($data === null) return;
                PetFormUI::openMainMenu($player, $this->plugin);
            }
        });
    }

    public static function openSkinSelector(Player $player, Main $plugin): void {
        $active = $plugin->getPetManager()->getActivePet($player);
        if ($active === null) return;

        $skins   = ["default", "rare", "legendary"];
        $buttons = array_map(fn($s) => ["text" => "§f" . ucfirst($s)], $skins);
        $buttons[] = ["text" => "§8← 돌아가기"];

        $player->sendForm(new class($plugin, $skins, $buttons) implements Form {
            public function __construct(
                private Main $plugin,
                private array $skins,
                private array $buttons,
            ) {}

            public function jsonSerialize(): mixed {
                return [
                    "type"    => "form",
                    "title"   => "§d스킨 선택",
                    "content" => "§f원하는 스킨을 선택하세요.",
                    "buttons" => $this->buttons,
                ];
            }

            public function handleResponse(Player $player, mixed $data): void {
                if ($data === null) return;
                $index = (int)$data;

                if ($index < count($this->skins)) {
                    $active = $this->plugin->getPetManager()->getActivePet($player);
                    $active?->getPetData()->setSkin($this->skins[$index]);
                    $player->sendMessage("§d스킨이 변경되었습니다: §f" . ucfirst($this->skins[$index]));
                }
                PetFormUI::openMainMenu($player, $this->plugin);
            }
        });
    }

    public static function openPetInventory(Player $player, Main $plugin): void {
        $player->sendForm(new class($plugin) implements Form {
            public function __construct(private Main $plugin) {}

            public function jsonSerialize(): mixed {
                return [
                    "type"    => "form",
                    "title"   => "§b펫 인벤토리",
                    "content" => "§f펫 인벤토리는 InvMenu 라이브러리와 연동 시\n실제 인벤토리 GUI로 표시됩니다.\n\n§8현재 저장된 아이템 수: §e0개",
                    "buttons" => [["text" => "§8← 돌아가기"]],
                ];
            }

            public function handleResponse(Player $player, mixed $data): void {
                PetFormUI::openMainMenu($player, $this->plugin);
            }
        });
    }
}