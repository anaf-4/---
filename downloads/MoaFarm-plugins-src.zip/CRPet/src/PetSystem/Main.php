<?php

declare(strict_types=1);

namespace PetSystem;

use PetSystem\command\PetAdminCommand;
use PetSystem\command\PetCommand;
use PetSystem\config\PetConfig;
use PetSystem\entity\PetEntityRegistry;
use PetSystem\listener\PetListener;
use PetSystem\manager\PetManager;
use PetSystem\task\PetTickTask;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;

class Main extends PluginBase {
    use SingletonTrait;

    private PetManager $petManager;
    private PetConfig  $petConfig;
    private ?\mysqli $db = null;

    public function onLoad(): void {
        self::setInstance($this);
    }

    public function onEnable(): void {
        $this->saveResource("config.yml");
        $this->saveResource("pets.yml");
        $this->saveResource("messages.yml");

        @mkdir($this->getDataFolder() . "player_data/");

        $this->connectDb();

        $this->petConfig  = new PetConfig($this);
        PetEntityRegistry::registerAll();
        $this->petManager = new PetManager($this);

        $this->getServer()->getPluginManager()->registerEvents(
            new PetListener($this), $this
        );

        // 수동 CommandMap 등록 제거 - plugin.yml + onCommand() 방식 사용
        $this->getScheduler()->scheduleRepeatingTask(new PetTickTask($this), 4);

        $this->getLogger()->info("§a[PetSystem] §f펫 시스템이 활성화되었습니다!");
    }

    public function onDisable(): void {
        if (isset($this->petManager)) {
            $this->petManager->saveAllPets();
            $this->petManager->despawnAllPets();
        }
        $this->db?->close();
        $this->getLogger()->info("§c[PetSystem] §f펫 시스템이 비활성화되었습니다.");
    }

    private function connectDb(): void {
        $sharedPath = $this->getServer()->getDataPath() . 'plugins/mysql_shared.yml';
        $cfg = [];
        if (file_exists($sharedPath)) {
            $shared = new \pocketmine\utils\Config($sharedPath);
            $cfg = (array) $shared->get('mysql', []);
        }
        if (empty($cfg)) {
            $cfg = (array) $this->getConfig()->get('mysql', []);
        }
        try {
            $db = new \mysqli(
                (string) ($cfg['host'] ?? '127.0.0.1'),
                (string) ($cfg['user'] ?? 'root'),
                (string) ($cfg['password'] ?? ''),
                (string) ($cfg['database'] ?? 'moafarm'),
                (int) ($cfg['port'] ?? 3306)
            );
            if ($db->connect_error) throw new \RuntimeException($db->connect_error);
            $db->set_charset('utf8mb4');
            $db->query('CREATE TABLE IF NOT EXISTS pet_data (
                id INT AUTO_INCREMENT PRIMARY KEY,
                owner_uuid VARCHAR(36) NOT NULL,
                pet_index INT NOT NULL DEFAULT 0,
                pet_id VARCHAR(100) NOT NULL,
                custom_name VARCHAR(100) NOT NULL DEFAULT \'\',
                level INT NOT NULL DEFAULT 1,
                exp INT NOT NULL DEFAULT 0,
                exp_to_next INT NOT NULL DEFAULT 100,
                health FLOAT NOT NULL DEFAULT 20.0,
                max_health FLOAT NOT NULL DEFAULT 20.0,
                evolution_stage TINYINT NOT NULL DEFAULT 0,
                state VARCHAR(20) NOT NULL DEFAULT \'following\',
                inventory TEXT NOT NULL,
                skin VARCHAR(50) NOT NULL DEFAULT \'default\',
                happiness INT NOT NULL DEFAULT 100,
                hunger INT NOT NULL DEFAULT 100,
                unlocked_skills TEXT NOT NULL,
                total_playtime INT NOT NULL DEFAULT 0,
                UNIQUE KEY unique_owner_pet (owner_uuid, pet_index)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
            $this->db = $db;
            $this->getLogger()->info("§a[PetSystem] §fMySQL 연결 완료.");
        } catch (\Throwable $e) {
            $this->getLogger()->warning("§c[PetSystem] MySQL 연결 실패, YAML 폴백 사용: " . $e->getMessage());
        }
    }

    public function getDb(): ?\mysqli {
        return $this->db;
    }

    public function reconnectDb(): void {
        try { $this->db?->close(); } catch (\Throwable) {}
        $this->db = null;
        $this->connectDb();
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        match($command->getName()) {
            "pet"      => (new PetCommand($this))->run($sender, $label, $args),
            "petadmin" => (new PetAdminCommand($this))->run($sender, $label, $args),
            default    => null,
        };
        return true;
    }

    public function getPetManager(): PetManager {
        return $this->petManager;
    }

    public function getPetConfig(): PetConfig {
        return $this->petConfig;
    }
}