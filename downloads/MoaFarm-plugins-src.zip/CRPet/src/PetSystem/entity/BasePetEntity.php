<?php

declare(strict_types=1);

namespace PetSystem\entity;

use PetSystem\data\PetData;
use PetSystem\data\PetDefinition;
use PetSystem\Main;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\entity\Living;
use pocketmine\entity\Location;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\player\Player;
use pocketmine\world\particle\HeartParticle;
use pocketmine\world\particle\SmokeParticle;

abstract class BasePetEntity extends Living {

    protected ?Player $owner      = null;
    protected PetData $petData;
    protected PetDefinition $petDefinition;

    protected int  $skillCooldown  = 0;
    protected int  $hungerTick     = 0;
    protected bool $isMounted      = false;

    private string $lastNameTag = "";

    protected const FOLLOW_DISTANCE   = 4.0;
    protected const TELEPORT_DISTANCE = 20.0;
    protected const MOVE_SPEED        = 0.28;

    public function __construct(
        Location $location,
        CompoundTag $nbt,
        PetData $petData,
        PetDefinition $petDefinition,
    ) {
        $this->petData       = $petData;
        $this->petDefinition = $petDefinition;
        parent::__construct($location, $nbt);
    }

    // ── 초기화 ────────────────────────────────────────────────────────────────

    protected function initEntity(CompoundTag $nbt): void {
        parent::initEntity($nbt);

        $this->setMaxHealth((int)$this->petData->getMaxHealth());
        $this->setHealth((int)$this->petData->getHealth());
        $this->setNameTagAlwaysVisible(true);
        $this->applyEvolutionScale();
        $this->forceUpdateNameTag();
    }

    // ── 주인 관리 ─────────────────────────────────────────────────────────────

    public function setOwner(Player $player): void {
        $this->owner = $player;
    }

    public function getOwner(): ?Player {
        return $this->owner;
    }

    public function isOwner(Player $player): bool {
        return $this->owner !== null
            && $this->owner->getUniqueId()->toString() === $player->getUniqueId()->toString();
    }

    // ── 네임태그 ─────────────────────────────────────────────────────────────

    public function updateNameTag(): void {
        $name   = $this->petData->getCustomName();
        $level  = $this->petData->getLevel();
        $stage  = $this->petData->getStageName();
        $hp     = (int)$this->petData->getHealth();
        $maxHp  = (int)$this->petData->getMaxHealth();
        $hunger = $this->petData->getHunger();

        $hpBar     = $this->buildBar($hp, $maxHp, "§c");
        $hungerBar = $this->buildBar($hunger, 100, "§6");

        $tag = "§e§b{$name} §e\n"
             . "§8[{$stage}] §aLv.{$level}\n"
             . "§c{$hpBar} §8{$hp}/{$maxHp}\n"
             . "§6{$hungerBar} §8{$hunger}/100";

        if ($tag !== $this->lastNameTag) {
            $this->lastNameTag = $tag;
            $this->setNameTag($tag);
        }
    }

    private function forceUpdateNameTag(): void {
        $this->lastNameTag = "";
        $this->updateNameTag();
    }

    private function buildBar(int $current, int $max, string $color): string {
        $filled = (int)round(($current / max(1, $max)) * 10);
        return $color . str_repeat("█", $filled) . "§8" . str_repeat("█", 10 - $filled);
    }

    // ── 크기 ─────────────────────────────────────────────────────────────────

    protected function applyEvolutionScale(): void {
        $scale = $this->petDefinition->getScaleForStage($this->petData->getEvolutionStage());
        $this->setScale($scale);
    }

    // ── 메인 틱 ──────────────────────────────────────────────────────────────

    public function onUpdate(int $currentTick): bool {
        if ($this->isClosed() || $this->owner === null) return false;

        if (!$this->owner->isOnline() || $this->owner->getWorld() !== $this->getWorld()) {
            $this->despawnFromAll();
            return false;
        }

        $result = parent::onUpdate($currentTick);

        if ($currentTick % 2 === 0) {
            $this->processAI();
        }

        $this->hungerTick++;
        if ($this->hungerTick >= 200) {
            $this->hungerTick = 0;
            $newHunger = max(0, $this->petData->getHunger() - 1);
            $this->petData->setHunger($newHunger);

            if ($newHunger <= 20) {
                $this->petData->setHappiness(max(0, $this->petData->getHappiness() - 2));
            }

            $this->petData->addPlaytime(200);
            $this->updateNameTag();
        }

        return $result;
    }

    // ── AI 처리 ──────────────────────────────────────────────────────────────

    protected function processAI(): void {
        if ($this->isMounted) return;

        $state = $this->petData->getState();

        if ($state === PetData::STATE_SITTING) {
            $this->setMotion(new Vector3(0, $this->getMotion()->y, 0));
            return;
        }

        if ($this->skillCooldown > 0) $this->skillCooldown--;

        if ($state === PetData::STATE_GUARDING) {
            $this->processGuardAI();
        } else {
            $this->processFollowAI();
        }
    }

    protected function processFollowAI(): void {
        if ($this->owner === null) return;

        $ownerPos = $this->owner->getPosition();
        $myPos    = $this->getPosition();
        $distance = $myPos->distance($ownerPos);

        if ($distance > self::TELEPORT_DISTANCE) {
            $this->teleport($ownerPos->add(1, 0, 0));
            $this->spawnParticle("heart");
            return;
        }

        if ($distance < self::FOLLOW_DISTANCE) {
            $this->setMotion(new Vector3(0, $this->getMotion()->y, 0));
            return;
        }

        $dir = $ownerPos->subtractVector($myPos)->normalize()->multiply(self::MOVE_SPEED);
        $this->setMotion(new Vector3($dir->x, $this->getMotion()->y, $dir->z));
        $this->lookAt($ownerPos);
    }

    protected function processGuardAI(): void {
        if ($this->owner === null) return;

        $myPos       = $this->getPosition();
        $closest     = null;
        $closestDist = 8.0;

        foreach ($this->getWorld()->getNearbyEntities($this->getBoundingBox()->expandedCopy(8, 4, 8)) as $entity) {
            if ($entity instanceof Player || $entity === $this) continue;
            $dist = $myPos->distance($entity->getPosition());
            if ($dist < $closestDist) {
                $closestDist = $dist;
                $closest     = $entity;
            }
        }

        if ($closest !== null) {
            $dir = $closest->getPosition()->subtractVector($myPos)->normalize()->multiply(self::MOVE_SPEED * 1.5);
            $this->setMotion(new Vector3($dir->x, $this->getMotion()->y, $dir->z));
            $this->lookAt($closest->getPosition());

            if ($closestDist < 2.0 && $this->skillCooldown <= 0) {
                $damage = 3.0 + ($this->petData->getLevel() * 0.5);
                $closest->attack(new \pocketmine\event\entity\EntityDamageByEntityEvent(
                    $this, $closest,
                    \pocketmine\event\entity\EntityDamageEvent::CAUSE_ENTITY_ATTACK,
                    $damage
                ));
                $this->skillCooldown = 40;
            }
        } else {
            $this->processFollowAI();
        }
    }

    // ── 마운트 ────────────────────────────────────────────────────────────────

    public function mountPlayer(Player $player): bool {
        if (!$this->petDefinition->isMountable()) return false;
        if (!$this->isOwner($player)) return false;

        $this->isMounted = true;
        $pk       = new \pocketmine\network\mcpe\protocol\SetActorLinkPacket();
        $pk->link = new \pocketmine\network\mcpe\protocol\types\entity\EntityLink(
            fromActorUniqueId: $this->getId(),
            toActorUniqueId:   $player->getId(),
            type:              \pocketmine\network\mcpe\protocol\types\entity\EntityLink::TYPE_RIDER,
            immediate:         true,
            riderInitiated:    true,
        );
        $player->getNetworkSession()->sendDataPacket($pk);
        return true;
    }

    public function dismountPlayer(Player $player): void {
        $this->isMounted = false;
        $pk       = new \pocketmine\network\mcpe\protocol\SetActorLinkPacket();
        $pk->link = new \pocketmine\network\mcpe\protocol\types\entity\EntityLink(
            fromActorUniqueId: $this->getId(),
            toActorUniqueId:   $player->getId(),
            type:              \pocketmine\network\mcpe\protocol\types\entity\EntityLink::TYPE_REMOVE,
            immediate:         false,
            riderInitiated:    false,
        );
        $player->getNetworkSession()->sendDataPacket($pk);
    }

    // ── 먹이 주기 ─────────────────────────────────────────────────────────────

    public function feed(string $itemId): bool {
        if (!in_array($itemId, $this->petDefinition->getFoods(), true)) return false;

        $this->petData->setHunger(min(100, $this->petData->getHunger() + 20));
        $this->petData->setHappiness(min(100, $this->petData->getHappiness() + 10));

        $leveled = $this->petData->addExp(15);
        $this->setHealth(min($this->getMaxHealth(), $this->getHealth() + 4));
        $this->petData->setHealth((float)$this->getHealth());

        $this->updateNameTag();
        $this->spawnParticle("heart");

        if ($leveled) $this->onLevelUp();
        return true;
    }

    // ── 경험치 ────────────────────────────────────────────────────────────────

    public function grantKillExp(): void {
        if ($this->petData->addExp($this->petDefinition->getExpPerKill())) {
            $this->onLevelUp();
        }
        $this->updateNameTag();
    }

    protected function onLevelUp(): void {
        $this->owner?->sendMessage(
            "§a§e" . $this->petData->getCustomName()
            . " §a이(가) 레벨 " . $this->petData->getLevel() . " §a이 되었습니다!"
        );

        $pos = $this->getPosition();
        for ($i = 0; $i < 5; $i++) {
            $this->getWorld()->addParticle(
                $pos->add(
                    (mt_rand(-10, 10) / 10),
                    1 + (mt_rand(0, 10) / 10),
                    (mt_rand(-10, 10) / 10)
                ),
                new HeartParticle()
            );
        }

        $this->checkSkillUnlocks();
    }

    protected function checkSkillUnlocks(): void {
        $level = $this->petData->getLevel();
        foreach ($this->petDefinition->getSkills() as $skill) {
            $id       = $skill["id"]             ?? "";
            $required = $skill["required_level"] ?? 99;
            if ($required <= $level && !$this->petData->hasSkill($id)) {
                $this->petData->unlockSkill($id);
                $this->owner?->sendMessage("§d새 스킬 해제: §e" . ($skill["name"] ?? $id));
            }
        }
    }

    // ── 진화 ──────────────────────────────────────────────────────────────────

    public function tryEvolve(): bool {
        if (!$this->petData->canEvolve()) return false;

        $this->petData->evolve();
        $this->applyEvolutionScale();
        $this->setMaxHealth((int)$this->petData->getMaxHealth());
        $this->setHealth((int)$this->petData->getMaxHealth());
        $this->forceUpdateNameTag();
        $this->spawnParticle("heart");

        $this->owner?->sendMessage(
            "§5§e" . $this->petData->getCustomName()
            . " §5이(가) §e" . $this->petData->getStageName() . " §5단계로 진화했습니다!"
        );
        return true;
    }

    // ── 파티클 ────────────────────────────────────────────────────────────────

    protected function spawnParticle(string $type): void {
        $pos      = $this->getPosition()->add(0, 1, 0);
        $particle = match ($type) {
            "smoke"  => new SmokeParticle(),
            default  => new HeartParticle(),
        };
        $this->getWorld()->addParticle($pos, $particle);
    }

    // ── 접근자 ────────────────────────────────────────────────────────────────

    public function getPetData(): PetData {
        return $this->petData;
    }

    public function getPetDefinition(): PetDefinition {
        return $this->petDefinition;
    }

    public function getName(): string {
        return $this->petData->getCustomName();
    }

    public function getInitialSizeInfo(): EntitySizeInfo {
        return new EntitySizeInfo(0.7, 0.6);
    }

    protected function getInitialDragMultiplier(): float { return 0.8; }
    protected function getInitialGravity(): float        { return 0.08; }

    public function kill(): void {
        $this->petData->setHealth(0.0);
        Main::getInstance()->getPetManager()->onPetDie($this);
        parent::kill();
    }
}