<?php

declare(strict_types=1);

namespace PetSystem\entity;

use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\EntityFactory;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\world\World;

class PetEntityRegistry {

    public static function registerAll(): void {
        require_once __DIR__ . "/PetEntities.php";

        $factory = EntityFactory::getInstance();

        $factory->register(CatPetEntity::class, function(World $world, CompoundTag $nbt): CatPetEntity {
            // PetData/PetDefinition은 소환 시 직접 주입하므로 더미 값으로 생성
            throw new \LogicException("PetEntities must be created via PetManager::summonPet()");
        }, ["PetCat"]);

        $factory->register(WolfPetEntity::class, function(World $world, CompoundTag $nbt): WolfPetEntity {
            throw new \LogicException("PetEntities must be created via PetManager::summonPet()");
        }, ["PetWolf"]);

        $factory->register(FoxPetEntity::class, function(World $world, CompoundTag $nbt): FoxPetEntity {
            throw new \LogicException("PetEntities must be created via PetManager::summonPet()");
        }, ["PetFox"]);

        $factory->register(PandaPetEntity::class, function(World $world, CompoundTag $nbt): PandaPetEntity {
            throw new \LogicException("PetEntities must be created via PetManager::summonPet()");
        }, ["PetPanda"]);

        $factory->register(ParrotPetEntity::class, function(World $world, CompoundTag $nbt): ParrotPetEntity {
            throw new \LogicException("PetEntities must be created via PetManager::summonPet()");
        }, ["PetParrot"]);

        $factory->register(DragonPetEntity::class, function(World $world, CompoundTag $nbt): DragonPetEntity {
            throw new \LogicException("PetEntities must be created via PetManager::summonPet()");
        }, ["PetDragon"]);

        $factory->register(PhoenixPetEntity::class, function(World $world, CompoundTag $nbt): PhoenixPetEntity {
            throw new \LogicException("PetEntities must be created via PetManager::summonPet()");
        }, ["PetPhoenix"]);
    }

    public static function getEntityClass(string $petId): string {
        require_once __DIR__ . "/PetEntities.php";

        return match($petId) {
            "cat"     => CatPetEntity::class,
            "wolf"    => WolfPetEntity::class,
            "fox"     => FoxPetEntity::class,
            "panda"   => PandaPetEntity::class,
            "parrot"  => ParrotPetEntity::class,
            "dragon"  => DragonPetEntity::class,
            "phoenix" => PhoenixPetEntity::class,
            default   => CatPetEntity::class,
        };
    }
}