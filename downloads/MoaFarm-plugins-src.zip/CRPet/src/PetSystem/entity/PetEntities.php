<?php

declare(strict_types=1);

namespace PetSystem\entity;

use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\math\Vector3;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;
use pocketmine\player\Player;
use pocketmine\world\particle\FlameParticle;
use pocketmine\world\particle\HeartParticle;

// ─────────────────────────────────────────────────────────────────────────────
// 고양이 펫
// ─────────────────────────────────────────────────────────────────────────────
class CatPetEntity extends BasePetEntity {

    public static function getNetworkTypeId(): string {
        return EntityIds::CAT;
    }

    public function getInitialSizeInfo(): EntitySizeInfo {
        return new EntitySizeInfo(0.7, 0.6);
    }

    public function getName(): string {
        return $this->petData->getCustomName();
    }

    protected function processGuardAI(): void {
        parent::processGuardAI();

        // Lv.5 스킬: 야간 투시
        if ($this->petData->hasSkill("night_vision") && $this->owner !== null) {
            if ($this->getWorld()->getTimeOfDay() > 12000) {
                $this->owner->getEffects()->add(new EffectInstance(
                    VanillaEffects::NIGHT_VISION(), 100, 0, false
                ));
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// 늑대 펫
// ─────────────────────────────────────────────────────────────────────────────
class WolfPetEntity extends BasePetEntity {

    public static function getNetworkTypeId(): string {
        return EntityIds::WOLF;
    }

    public function getInitialSizeInfo(): EntitySizeInfo {
        return new EntitySizeInfo(0.85, 0.6);
    }

    public function getName(): string {
        return $this->petData->getCustomName();
    }

    protected function processGuardAI(): void {
        if ($this->owner === null) return;

        $myPos       = $this->getPosition();
        $closest     = null;
        $closestDist = 12.0;

        foreach ($this->getWorld()->getNearbyEntities($this->getBoundingBox()->expandedCopy(12, 4, 12)) as $entity) {
            if ($entity instanceof Player || $entity === $this) continue;
            $dist = $myPos->distance($entity->getPosition());
            if ($dist < $closestDist) {
                $closestDist = $dist;
                $closest     = $entity;
            }
        }

        if ($closest !== null) {
            $dir = $closest->getPosition()->subtractVector($myPos)->normalize()->multiply(0.42);
            $this->setMotion(new Vector3($dir->x, $this->getMotion()->y, $dir->z));
            $this->lookAt($closest->getPosition());

            if ($closestDist < 2.0 && $this->skillCooldown <= 0) {
                $damage = 5.0 + ($this->petData->getLevel() * 1.0);
                $closest->attack(new EntityDamageByEntityEvent(
                    $this, $closest, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $damage
                ));
                $this->skillCooldown = 30;
            }
        } else {
            $this->processFollowAI();
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// 여우 펫 - 아이템 자동 수집
// ─────────────────────────────────────────────────────────────────────────────
class FoxPetEntity extends BasePetEntity {

    public static function getNetworkTypeId(): string {
        return EntityIds::FOX;
    }

    public function getInitialSizeInfo(): EntitySizeInfo {
        return new EntitySizeInfo(0.6, 0.565);
    }

    public function getName(): string {
        return $this->petData->getCustomName();
    }

    protected function processAI(): void {
        parent::processAI();

        // Lv.10 스킬: 주변 아이템 자동 수집
        if (!$this->petData->hasSkill("item_collect") || $this->owner === null) return;

        foreach ($this->getWorld()->getNearbyEntities($this->getBoundingBox()->expandedCopy(4, 2, 4)) as $entity) {
            if (!($entity instanceof \pocketmine\entity\object\ItemEntity)) continue;

            $item = $entity->getItem();
            if ($this->owner->getInventory()->canAddItem($item)) {
                $this->owner->getInventory()->addItem($item);
                $entity->close();
                $this->owner->sendTip("§a" . $this->petData->getCustomName() . " §f이(가) 아이템을 가져왔습니다!");
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// 판다 펫 - 저항 오라
// ─────────────────────────────────────────────────────────────────────────────
class PandaPetEntity extends BasePetEntity {

    public static function getNetworkTypeId(): string {
        return EntityIds::PANDA;
    }

    public function getInitialSizeInfo(): EntitySizeInfo {
        return new EntitySizeInfo(1.25, 1.125);
    }

    public function getName(): string {
        return $this->petData->getCustomName();
    }

    protected function processAI(): void {
        parent::processAI();

        // Lv.15 스킬: 주인에게 저항 효과
        if (!$this->petData->hasSkill("shield_aura") || $this->owner === null) return;

        if ($this->owner->getPosition()->distance($this->getPosition()) < 8.0) {
            $this->owner->getEffects()->add(new EffectInstance(
                VanillaEffects::RESISTANCE(), 40, 0, false
            ));
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// 앵무새 펫 - 플레이어 감지
// ─────────────────────────────────────────────────────────────────────────────
class ParrotPetEntity extends BasePetEntity {

    // static 대신 인스턴스 필드로 변경 (멀티 펫 공유 버그 수정)
    private int $alertCooldown = 0;

    public static function getNetworkTypeId(): string {
        return EntityIds::PARROT;
    }

    public function getInitialSizeInfo(): EntitySizeInfo {
        return new EntitySizeInfo(0.9, 0.5);
    }

    public function getName(): string {
        return $this->petData->getCustomName();
    }

    public function onUpdate(int $currentTick): bool {
        if ($this->alertCooldown > 0) $this->alertCooldown--;
        return parent::onUpdate($currentTick);
    }

    protected function processAI(): void {
        parent::processAI();

        // Lv.8 스킬: 근처 플레이어 감지 (200틱 쿨다운)
        if (!$this->petData->hasSkill("detect_players") || $this->owner === null) return;
        if ($this->alertCooldown > 0) return;

        foreach ($this->getWorld()->getNearbyEntities($this->getBoundingBox()->expandedCopy(20, 10, 20)) as $entity) {
            if ($entity instanceof Player && !$this->isOwner($entity)) {
                $this->owner->sendTip(
                    "§e" . $this->petData->getCustomName()
                    . " §f: 근처에 플레이어가 있습니다! §c(" . $entity->getName() . ")"
                );
                $this->alertCooldown = 200;
                break;
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// 드래곤 펫 - 강력한 공격 + 탑승 가능
// ─────────────────────────────────────────────────────────────────────────────
class DragonPetEntity extends BasePetEntity {

    public static function getNetworkTypeId(): string {
        return EntityIds::PHANTOM;
    }

    public function getInitialSizeInfo(): EntitySizeInfo {
        return new EntitySizeInfo(0.5, 0.9);
    }

    public function getName(): string {
        return $this->petData->getCustomName();
    }

    protected function processGuardAI(): void {
        if ($this->owner === null) return;

        $myPos       = $this->getPosition();
        $closest     = null;
        $closestDist = 15.0;

        foreach ($this->getWorld()->getNearbyEntities($this->getBoundingBox()->expandedCopy(15, 8, 15)) as $entity) {
            if ($entity instanceof Player || $entity === $this) continue;
            $dist = $myPos->distance($entity->getPosition());
            if ($dist < $closestDist) {
                $closestDist = $dist;
                $closest     = $entity;
            }
        }

        if ($closest !== null) {
            $dir = $closest->getPosition()->subtractVector($myPos)->normalize()->multiply(0.5);
            $this->setMotion(new Vector3($dir->x, $this->getMotion()->y, $dir->z));
            $this->lookAt($closest->getPosition());

            if ($closestDist < 3.0 && $this->skillCooldown <= 0) {
                $damage = 10.0 + ($this->petData->getLevel() * 2.0);
                $closest->attack(new EntityDamageByEntityEvent(
                    $this, $closest, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $damage
                ));
                $this->getWorld()->addParticle($closest->getPosition(), new FlameParticle());
                $this->skillCooldown = 60;
            }
        } else {
            $this->processFollowAI();
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// 피닉스 펫 - 부활 스킬 + 자동 재생
// ─────────────────────────────────────────────────────────────────────────────
class PhoenixPetEntity extends BasePetEntity {

    private int $rebirthCooldown = 0;
    private int $regenTick       = 0;

    public static function getNetworkTypeId(): string {
        return EntityIds::BLAZE;
    }

    public function getInitialSizeInfo(): EntitySizeInfo {
        return new EntitySizeInfo(1.8, 0.6);
    }

    public function getName(): string {
        return $this->petData->getCustomName();
    }

    public function onUpdate(int $currentTick): bool {
        if ($this->rebirthCooldown > 0) $this->rebirthCooldown--;

        // HP 자동 재생 (40틱마다 1 회복)
        $this->regenTick++;
        if ($this->regenTick >= 40) {
            $this->regenTick = 0;
            if ($this->getHealth() < $this->getMaxHealth()) {
                $this->setHealth(min($this->getMaxHealth(), $this->getHealth() + 1.0));
            }
        }

        return parent::onUpdate($currentTick);
    }

    protected function processAI(): void {
        parent::processAI();

        // Lv.20 스킬: 주인 HP 위기 시 회복 (2분 쿨다운)
        if (!$this->petData->hasSkill("rebirth") || $this->owner === null) return;
        if ($this->rebirthCooldown > 0) return;

        if ($this->owner->getHealth() <= 4.0) {
            $this->owner->setHealth(10.0);
            $this->rebirthCooldown = 2400;
            $this->owner->sendMessage(
                "§c§e" . $this->petData->getCustomName() . " §c이(가) 당신을 구했습니다!"
            );

            $pos = $this->getPosition();
            for ($i = 0; $i < 5; $i++) {
                $this->getWorld()->addParticle(
                    $pos->add(0, $i * 0.3, 0),
                    new HeartParticle()
                );
            }
        }
    }
}