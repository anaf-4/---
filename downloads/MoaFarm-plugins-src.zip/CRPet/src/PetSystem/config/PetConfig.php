<?php

declare(strict_types=1);

namespace PetSystem\config;

use PetSystem\Main;
use pocketmine\utils\Config;

class PetConfig {

    private Config $config;

    public function __construct(private Main $plugin) {
        $this->config = new Config($plugin->getDataFolder() . "config.yml", Config::YAML);
    }

    public function getMaxPetsDefault(): int {
        return (int)$this->config->get("max-pets-default", 1);
    }

    public function isPetInvincible(): bool {
        return (bool)$this->config->get("pets-invincible", true);
    }

    public function getFollowDistance(): float {
        return (float)$this->config->get("follow-distance", 4.0);
    }

    public function getTeleportDistance(): float {
        return (float)$this->config->get("teleport-distance", 20.0);
    }

    public function isAutoSaveEnabled(): bool {
        return (bool)$this->config->get("auto-save", true);
    }
}