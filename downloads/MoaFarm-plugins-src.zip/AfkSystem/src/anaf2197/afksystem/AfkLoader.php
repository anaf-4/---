<?php
declare(strict_types=1);

namespace anaf2197\afksystem;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use anaf2197\afksystem\listener\AfkListener;

final class AfkLoader extends PluginBase {

    private AfkManager $manager;

    protected function onEnable(): void {
        $this->manager = new AfkManager($this);
        $this->getServer()->getPluginManager()->registerEvents(
            new AfkListener($this->manager),
            $this
        );
        $this->getLogger()->info('잠수 시스템이 활성화되었습니다.');
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if (!$sender instanceof Player) {
            $sender->sendMessage('§c플레이어만 사용 가능합니다.');
            return true;
        }

        match ($command->getName()) {
            '잠수광질' => $this->manager->startMining($sender),
            '잠수낚시' => $this->manager->startFishing($sender),
            '잠수종료' => $this->stopAfk($sender),
            '잠수현황' => $this->manager->sendStatus($sender),
            default    => null,
        };

        return true;
    }

    private function stopAfk(Player $player): void {
        if (!$this->manager->hasSession($player)) {
            $player->sendMessage('§c현재 AFK 활동 중이 아닙니다.');
            return;
        }
        $this->manager->stopSession($player, '§7잠수 활동을 수동으로 종료하였습니다.');
    }
}
