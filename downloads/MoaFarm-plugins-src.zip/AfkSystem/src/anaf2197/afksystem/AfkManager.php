<?php
declare(strict_types=1);

namespace anaf2197\afksystem;

use pocketmine\block\VanillaBlocks;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\item\Pickaxe;
use pocketmine\math\Facing;
use pocketmine\player\Player;
use pocketmine\scheduler\ClosureTask;
use anaf2197\afksystem\session\FishingSession;
use anaf2197\afksystem\session\MiningSession;
use anaf2197\fishing\item\FishingRod;
use anaf2197\upgradetools\function\type\ToolFunction;

final class AfkManager {

    /** @var MiningSession[]|FishingSession[] player UUID → session */
    private array $sessions = [];

    public function __construct(private readonly AfkLoader $plugin) {}

    // ─── 공통 ────────────────────────────────────────────────────

    public function hasSession(Player $player): bool {
        return isset($this->sessions[$player->getUniqueId()->toString()]);
    }

    public function stopSession(Player $player, ?string $message): void {
        $uuid = $player->getUniqueId()->toString();
        if (!isset($this->sessions[$uuid])) return;

        $session = $this->sessions[$uuid];
        $session->getTaskHandler()?->cancel();
        unset($this->sessions[$uuid]);

        // 닉네임 태그 복원
        $player->setScoreTag('');

        if ($message !== null && $player->isConnected()) {
            $player->sendMessage($message);
        }
    }

    // ─── 잠수광질 ─────────────────────────────────────────────────

    public function startMining(Player $player): void {
        if ($this->hasSession($player)) {
            $player->sendMessage('§c이미 AFK 활동 중입니다. 먼저 §l/잠수종료§r§c를 입력하세요.');
            return;
        }

        // 활성화 조건: 곡괭이 장착
        if (!($player->getInventory()->getItemInHand() instanceof Pickaxe)) {
            $player->sendMessage('§c곡괭이를 손에 들고 있어야 잠수광질을 시작할 수 있습니다.');
            return;
        }

        // 활성화 조건: 정면 블록이 Stone
        if (!$this->isFacingStone($player)) {
            $player->sendMessage('§c정면에 §l돌(Stone)§r§c 블록이 있어야 잠수광질을 시작할 수 있습니다.');
            return;
        }

        // ── 곡괭이 능력 읽기 ──────────────────────────────────────
        $pickaxe    = $player->getInventory()->getItemInHand();
        $effLevel   = $pickaxe->getEnchantmentLevel(VanillaEnchantments::EFFICIENCY());
        $luckyLevel = $pickaxe->getNamedTag()
            ->getCompoundTag(ToolFunction::TAG_FUNCTION)
            ?->getInt('행운', 0) ?? 0;

        // 효율 레벨당 3초 단축, 최소 8초
        $intervalSec = max(8, MiningSession::BASE_INTERVAL_SEC - ($effLevel * 3));

        if ($effLevel > 0 || $luckyLevel > 0) {
            $player->sendMessage(
                "§7[잠수광질] 효율 §f{$effLevel}Lv §7→ §f{$intervalSec}초§7 주기  |  행운 §f{$luckyLevel}Lv §7적용"
            );
        }

        $session = new MiningSession($player->getName(), $luckyLevel, $intervalSec);
        $uuid    = $player->getUniqueId()->toString();
        $this->sessions[$uuid] = $session;

        $player->setScoreTag('§eAFK광질중');
        $player->sendMessage('§a잠수광질을 시작합니다. 이동하면 자동으로 종료됩니다.');

        $intervalTicks = $intervalSec * 20;
        $handler = $this->plugin->getScheduler()->scheduleRepeatingTask(
            new ClosureTask(function () use ($player, $session, $uuid): void {
                if (!$player->isConnected() || !isset($this->sessions[$uuid])) return;

                if ($session->isTimeExpired()) {
                    $this->stopSession($player, '§e잠수광질 최대 시간(4시간)에 도달하여 종료되었습니다.');
                    return;
                }

                $gained = $session->tick($player);
                if (!empty($gained)) {
                    $items = implode('§8, ', array_map(
                        fn($name, $cnt) => "{$name} §8×§f{$cnt}",
                        array_keys($gained), $gained
                    ));
                    $player->sendTip("§a광물 획득: {$items}");
                }
            }),
            $intervalTicks
        );

        $session->setTaskHandler($handler);
    }

    private function isFacingStone(Player $player): bool {
        $yaw = fmod($player->getLocation()->yaw, 360.0);
        if ($yaw < 0) $yaw += 360.0;

        $facing = match(true) {
            $yaw < 45 || $yaw >= 315 => Facing::SOUTH,
            $yaw < 135               => Facing::WEST,
            $yaw < 225               => Facing::NORTH,
            default                  => Facing::EAST,
        };

        $offset  = Facing::OFFSET[$facing];
        $pos     = $player->getPosition();
        $world   = $player->getWorld();
        $stoneId = VanillaBlocks::STONE()->getTypeId();

        // 플레이어 몸통과 눈높이 두 곳 모두 확인
        foreach ([0, 1] as $dy) {
            $block = $world->getBlock($pos->add($offset[0], $dy, $offset[2]));
            if ($block->getTypeId() === $stoneId) return true;
        }

        return false;
    }

    // ─── 잠수낚시 ─────────────────────────────────────────────────

    public function startFishing(Player $player): void {
        if ($this->hasSession($player)) {
            $player->sendMessage('§c이미 AFK 활동 중입니다. 먼저 §l/잠수종료§r§c를 입력하세요.');
            return;
        }

        // 활성화 조건: 낚싯대 장착
        if (!($player->getInventory()->getItemInHand() instanceof FishingRod)) {
            $player->sendMessage('§c낚싯대를 손에 들고 있어야 잠수낚시를 시작할 수 있습니다.');
            return;
        }

        if (!$this->isNearWater($player)) {
            $player->sendMessage('§c주변 1칸 이내에 §l물§r§c이 있어야 잠수낚시를 시작할 수 있습니다.');
            return;
        }

        // ── 낚싯대 Fortune 인챈트 읽기 (Fisherman과 동일) ───────────
        $rod          = $player->getInventory()->getItemInHand();
        $fortuneLevel = $rod->getEnchantmentLevel(VanillaEnchantments::FORTUNE());

        if ($fortuneLevel > 0) {
            $player->sendMessage("§7[잠수낚시] 낚싯대 강화 §f{$fortuneLevel}Lv §7적용");
        }

        $session = new FishingSession($player->getName(), $fortuneLevel);
        $uuid    = $player->getUniqueId()->toString();
        $this->sessions[$uuid] = $session;

        $player->setScoreTag('§bAFK낚시중');
        $player->sendMessage('§b잠수낚시를 시작합니다. 이동하면 자동으로 종료됩니다.');

        $intervalTicks = FishingSession::INTERVAL_SEC * 20;
        $handler = $this->plugin->getScheduler()->scheduleRepeatingTask(
            new ClosureTask(function () use ($player, $session, $uuid): void {
                if (!$player->isConnected() || !isset($this->sessions[$uuid])) return;

                if ($session->isTimeExpired()) {
                    $this->stopSession($player, '§e잠수낚시 최대 시간(4시간)에 도달하여 종료되었습니다.');
                    return;
                }

                $result = $session->tick($player);
                if ($result !== null) {
                    $tierColor = match ($result['tier']) {
                        'l'     => '§6',
                        'a'     => '§a',
                        'b'     => '§b',
                        'c'     => '§3',
                        default => '§7',
                    };
                    $tier = strtoupper($result['tier']);
                    $name = $result['name'];
                    $player->sendTip("§b{$tierColor}[{$tier}] {$name} §8획득!");
                }
            }),
            $intervalTicks
        );

        $session->setTaskHandler($handler);
    }

    private function isNearWater(Player $player): bool {
        $pos   = $player->getPosition()->floor();
        $world = $player->getWorld();
        $waterId = VanillaBlocks::WATER()->getTypeId();

        for ($dx = -1; $dx <= 1; $dx++) {
            for ($dz = -1; $dz <= 1; $dz++) {
                for ($dy = -1; $dy <= 1; $dy++) {
                    $block = $world->getBlock($pos->add($dx, $dy, $dz));
                    if ($block->getTypeId() === $waterId) return true;
                }
            }
        }
        return false;
    }

    // ─── 현황 ─────────────────────────────────────────────────────

    public function sendStatus(Player $player): void {
        $uuid = $player->getUniqueId()->toString();
        if (!isset($this->sessions[$uuid])) {
            $player->sendMessage('§c현재 AFK 활동 중이 아닙니다.');
            return;
        }
        $player->sendMessage($this->sessions[$uuid]->getSummary());
    }
}
