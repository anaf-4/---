<?php
declare(strict_types=1);

namespace anaf2197\afksystem\session;

use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\scheduler\TaskHandler;

final class MiningSession {

    public const BASE_INTERVAL_SEC = 30;
    public const MAX_TIME          = 4 * 60 * 60;

    private const MAX_COMMON  = 200;
    private const MAX_RARE    = 50;
    private const MAX_DIAMOND = 10;
    private const MAX_LEGEND  = 3;

    // 행운 레벨별 추가 드롭 확률 (%)
    private const LUCKY_CHANCE = [1 => 30, 2 => 50, 3 => 70];

    private int $cycleCount  = 0;
    private int $elapsedSec  = 0;

    private int $iron     = 0;
    private int $coal     = 0;
    private int $gold     = 0;
    private int $redstone = 0;
    private int $diamond  = 0;
    private int $legend   = 0;

    private ?TaskHandler $taskHandler = null;

    /**
     * @param int $luckyLevel  곡괭이 행운(Lucky) 스킬 레벨 (0 = 없음)
     * @param int $intervalSec 효율(Efficiency) 적용 후 실제 주기
     */
    public function __construct(
        private readonly string $playerName,
        private readonly int $luckyLevel   = 0,
        private readonly int $intervalSec  = self::BASE_INTERVAL_SEC
    ) {}

    public function setTaskHandler(TaskHandler $handler): void { $this->taskHandler = $handler; }
    public function getTaskHandler(): ?TaskHandler            { return $this->taskHandler; }
    public function getPlayerName(): string                   { return $this->playerName; }
    public function getElapsedSec(): int                      { return $this->elapsedSec; }
    public function getIntervalSec(): int                     { return $this->intervalSec; }
    public function isTimeExpired(): bool                     { return $this->elapsedSec >= self::MAX_TIME; }

    /**
     * @return array<string, int> 이번 사이클에 획득한 아이템 목록
     */
    public function tick(Player $player): array {
        $this->elapsedSec += $this->intervalSec;
        $this->cycleCount++;
        $gained = [];

        $this->give($player, $gained, '§f철 주괴',   fn() => VanillaItems::IRON_INGOT(),   $this->iron,     self::MAX_COMMON,  1);
        $this->give($player, $gained, '§8석탄',      fn() => VanillaItems::COAL(),          $this->coal,     self::MAX_COMMON,  1);

        // 금/레드스톤: 2분 주기 (base 30s 기준 4사이클, 실제론 120s / intervalSec 사이클)
        if ($this->cycleCount % $this->cyclesFor(120) === 0) {
            $this->give($player, $gained, '§6금 주괴',    fn() => VanillaItems::GOLD_INGOT(),   $this->gold,     self::MAX_RARE, 1);
            $this->give($player, $gained, '§c레드스톤',   fn() => VanillaItems::REDSTONE_DUST(), $this->redstone, self::MAX_RARE, 1);
        }

        // 다이아몬드: 10분 주기
        if ($this->cycleCount % $this->cyclesFor(600) === 0) {
            $this->give($player, $gained, '§b다이아몬드', fn() => VanillaItems::DIAMOND(),       $this->diamond,  self::MAX_DIAMOND, 1);
        }

        // 전설 광물: 30분 주기
        if ($this->cycleCount % $this->cyclesFor(1800) === 0) {
            $this->give($player, $gained, '§d네더의 별',  fn() => VanillaItems::NETHER_STAR(),  $this->legend,   self::MAX_LEGEND, 1);
        }

        return $gained;
    }

    /**
     * 아이템 지급 + 행운 보너스 적용
     */
    private function give(Player $player, array &$gained, string $label, \Closure $itemFactory, int &$count, int $max, int $base): void {
        if ($count >= $max) return;

        $amount = $base;

        // 행운 스킬: 레벨별 확률로 +1
        $luckyChance = self::LUCKY_CHANCE[$this->luckyLevel] ?? 0;
        if ($luckyChance > 0 && mt_rand(1, 100) <= $luckyChance) {
            $amount++;
        }

        $amount = min($amount, $max - $count);
        $item   = $itemFactory()->setCount($amount);
        $player->getInventory()->addItem($item);
        $count       += $amount;
        $gained[$label] = ($gained[$label] ?? 0) + $amount;
    }

    /** 특정 시간(초)이 몇 사이클인지 계산 */
    private function cyclesFor(int $seconds): int {
        return max(1, (int) round($seconds / $this->intervalSec));
    }

    public function getSummary(): string {
        $elapsed  = $this->formatTime($this->elapsedSec);
        $interval = $this->intervalSec;
        $lucky    = $this->luckyLevel > 0 ? "§a행운 {$this->luckyLevel}Lv" : '§7없음';
        return implode("\n", [
            "§8━━━━━━━━━━ §a잠수광질 현황 §8━━━━━━━━━━",
            "§7경과 시간:  §f{$elapsed}",
            "§7적립 주기:  §f{$interval}초  §7행운: {$lucky}",
            "§7철 주괴:    §f{$this->iron}§7/§f" . self::MAX_COMMON,
            "§7석탄:       §f{$this->coal}§7/§f" . self::MAX_COMMON,
            "§7금 주괴:    §f{$this->gold}§7/§f" . self::MAX_RARE,
            "§7레드스톤:   §f{$this->redstone}§7/§f" . self::MAX_RARE,
            "§7다이아몬드: §f{$this->diamond}§7/§f" . self::MAX_DIAMOND,
            "§7네더의 별:  §f{$this->legend}§7/§f" . self::MAX_LEGEND,
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
        ]);
    }

    private function formatTime(int $sec): string {
        $h = intdiv($sec, 3600);
        $m = intdiv($sec % 3600, 60);
        $s = $sec % 60;
        return ($h > 0 ? "{$h}시간 " : "") . ($m > 0 ? "{$m}분 " : "") . "{$s}초";
    }
}
