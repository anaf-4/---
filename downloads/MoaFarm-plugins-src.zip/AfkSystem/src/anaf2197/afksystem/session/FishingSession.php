<?php
declare(strict_types=1);

namespace anaf2197\afksystem\session;

use pocketmine\player\Player;
use pocketmine\scheduler\TaskHandler;
use anaf2197\fishing\Fish;
use anaf2197\fishing\FishingLoader;
use anaf2197\fishing\event\FishingEvent;

final class FishingSession {

    public const MAX_TIME     = 4 * 60 * 60;
    public const INTERVAL_SEC = 30;

    private int $elapsedSec = 0;
    private int $cntL = 0;
    private int $cntA = 0;
    private int $cntB = 0;
    private int $cntC = 0;
    private int $cntD = 0;

    private ?TaskHandler $taskHandler = null;

    /**
     * @param int $fortuneLevel 낚싯대 Fortune 인챈트 레벨 (Fisherman과 동일 방식)
     */
    public function __construct(
        private readonly string $playerName,
        private readonly int $fortuneLevel = 0
    ) {}

    public function setTaskHandler(TaskHandler $handler): void { $this->taskHandler = $handler; }
    public function getTaskHandler(): ?TaskHandler            { return $this->taskHandler; }
    public function getPlayerName(): string                   { return $this->playerName; }
    public function getElapsedSec(): int                      { return $this->elapsedSec; }
    public function isTimeExpired(): bool                     { return $this->elapsedSec >= self::MAX_TIME; }

    /**
     * @return array{name: string, tier: string}|null
     */
    public function tick(Player $player): ?array {
        $this->elapsedSec += self::INTERVAL_SEC;

        $fishingManager = FishingLoader::getInstance()->getFishingManager();

        // ── 티어 결정 (실제 낚시와 동일한 TIER_LIST 확률표) ────────
        $rand = mt_rand(1, 100);
        $tier = Fish::TIER_D;
        foreach (FishingLoader::TIER_LIST as $key => $chance) {
            if ($rand <= $chance) {
                $tier = $key;
                break;
            }
        }

        // ── Fortune 인챈트 보너스 (Fisherman.getEnchantmentLevel()과 동일) ──
        // L등급은 업그레이드 제외
        if ($tier !== Fish::TIER_L && $this->fortuneLevel > 0) {
            $upgradeChance = $this->fortuneLevel * 2;
            if (mt_rand(1, 100) <= $upgradeChance) {
                $tier = match ($tier) {
                    Fish::TIER_D => Fish::TIER_C,
                    Fish::TIER_C => Fish::TIER_B,
                    Fish::TIER_B => Fish::TIER_A,
                    Fish::TIER_A => Fish::TIER_L,
                    default      => $tier,
                };
            }
        }

        // ── 활성 물고기 풀에서 선택 ────────────────────────────────
        $isSpecial = ($tier === Fish::TIER_L);
        $pool = array_values($fishingManager->getActiveFishes($isSpecial));

        if (empty($pool)) return null;

        /** @var Fish $fish */
        $fish = $pool[mt_rand(0, count($pool) - 1)];
        $item = $fish->asItem($tier);

        // ── FishingEvent 발동 ───────────────────────────────────────
        $event = new FishingEvent($player, $item);
        $event->call();
        $player->getInventory()->addItem($event->getItem());

        // ── 업적 연동 ───────────────────────────────────────────────
        if ($tier === Fish::TIER_L && class_exists(\anaf2197\achievement\AchievementLoader::class)) {
            \anaf2197\achievement\AchievementLoader::getInstance()
                ->addProgress($player, \anaf2197\achievement\Achievement::TYPE_FISHING_RARE);
        }

        // ── 포획 카운트 ─────────────────────────────────────────────
        match ($tier) {
            Fish::TIER_L => $this->cntL++,
            Fish::TIER_A => $this->cntA++,
            Fish::TIER_B => $this->cntB++,
            Fish::TIER_C => $this->cntC++,
            default      => $this->cntD++,
        };

        return ['name' => $fish->getName(), 'tier' => $tier];
    }

    public function getSummary(): string {
        $elapsed = $this->formatTime($this->elapsedSec);
        $total   = $this->cntL + $this->cntA + $this->cntB + $this->cntC + $this->cntD;
        $fortune = $this->fortuneLevel > 0 ? "§a강화 {$this->fortuneLevel}Lv" : '§7없음';
        return implode("\n", [
            "§8━━━━━━━━━━ §b잠수낚시 현황 §8━━━━━━━━━━",
            "§7경과 시간: §f{$elapsed}  §7낚싯대 강화: {$fortune}",
            "§7총 포획수: §f{$total}마리",
            "§6[L] §f{$this->cntL}마리  §a[A] §f{$this->cntA}마리  §b[B] §f{$this->cntB}마리",
            "§3[C] §f{$this->cntC}마리  §7[D] §f{$this->cntD}마리",
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
        ]);
    }

    private function formatTime(int $sec): string {
        $h = intdiv($sec, 3600);
        $m = intdiv($sec % 3600, 60);
        $s = $sec % 60;
        return ($h > 0 ? "{$h}시간 " : "") . ($m > 0 ? "{$m}분 " : "") . "{$s}초";
    }
}
