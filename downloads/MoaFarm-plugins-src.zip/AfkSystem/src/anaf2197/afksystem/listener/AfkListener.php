<?php
declare(strict_types=1);

namespace anaf2197\afksystem\listener;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerQuitEvent;
use anaf2197\afksystem\AfkManager;

final class AfkListener implements Listener {

    public function __construct(private readonly AfkManager $manager) {}

    public function onPlayerMove(PlayerMoveEvent $event): void {
        $from = $event->getFrom();
        $to   = $event->getTo();

        // 실제 위치 변경 없이 시선만 돌렸을 때는 무시
        if ($from->floor()->equals($to->floor())) return;

        $player = $event->getPlayer();
        if ($this->manager->hasSession($player)) {
            $this->manager->stopSession($player, '§c이동이 감지되어 AFK가 종료되었습니다.');
        }
    }

    public function onPlayerQuit(PlayerQuitEvent $event): void {
        $player = $event->getPlayer();
        if ($this->manager->hasSession($player)) {
            $this->manager->stopSession($player, null); // 메시지 없이 종료
        }
    }
}
