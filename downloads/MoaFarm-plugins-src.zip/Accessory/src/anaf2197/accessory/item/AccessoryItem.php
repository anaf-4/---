<?php

declare(strict_types=1);

namespace anaf2197\accessory\item;

use pocketmine\item\Item;
use pocketmine\nbt\tag\CompoundTag;

/**
 * 악세사리 NBT 태그 상수 및 유틸
 *
 * TAG_TYPE:   ring | necklace
 * TAG_HP:     최대 HP 추가 (정수)
 * TAG_ATK:    공격력 추가 (정수)
 * TAG_HP_REGEN_FLAT:   초당 고정 HP 회복
 * TAG_HP_REGEN_PCT:    초당 % HP 회복 (0.0~1.0)
 */
final class AccessoryItem {

    public const TAG_ACCESSORY      = 'accessory';
    public const TAG_TYPE           = 'acc_type';        // ring | necklace
    public const TAG_HP             = 'acc_hp';
    public const TAG_ATK            = 'acc_atk';
    public const TAG_HP_REGEN_FLAT  = 'acc_regen_flat';
    public const TAG_HP_REGEN_PCT   = 'acc_regen_pct';

    // ── 악세사리 강화 태그 ──────────────────────────────────
    public const TAG_ENHANCE_LEVEL = 'acc_enh_level';
    public const TAG_BASE_HP       = 'acc_base_hp';
    public const TAG_BASE_ATK      = 'acc_base_atk';
    public const TAG_BASE_FLAT     = 'acc_base_flat';
    public const TAG_BASE_PCT      = 'acc_base_pct';

    public const MAX_ENHANCE = 10;

    /** 레벨별 성공 확률 (0→1강 ~ 9→10강) */
    public const ENHANCE_RATES = [100, 90, 75, 60, 45, 35, 25, 18, 12, 7];

    /** 레벨별 강화석 소모량 */
    public const ENHANCE_STONE_COUNTS = [1, 2, 3, 5, 8, 10, 15, 20, 25, 30];

    /** 강화 레벨당 기본 스탯의 증가율 (10% per level) */
    public const ENHANCE_STAT_BONUS_RATE = 0.10;

    public const SLOT_RING1    = 'ring1';
    public const SLOT_RING2    = 'ring2';
    public const SLOT_NECKLACE = 'necklace';

    public const SLOTS = [self::SLOT_RING1, self::SLOT_RING2, self::SLOT_NECKLACE];

    public static function isAccessory(Item $item): bool {
        return $item->getNamedTag()->getByte(self::TAG_ACCESSORY, 0) === 1;
    }

    public static function getType(Item $item): string {
        return $item->getNamedTag()->getString(self::TAG_TYPE, '');
    }

    public static function isRing(Item $item): bool {
        return self::getType($item) === 'ring';
    }

    public static function isNecklace(Item $item): bool {
        return self::getType($item) === 'necklace';
    }

    public static function getHp(Item $item): int {
        return $item->getNamedTag()->getInt(self::TAG_HP, 0);
    }

    public static function getAtk(Item $item): int {
        return $item->getNamedTag()->getInt(self::TAG_ATK, 0);
    }

    public static function getRegenFlat(Item $item): int {
        return $item->getNamedTag()->getInt(self::TAG_HP_REGEN_FLAT, 0);
    }

    public static function getRegenPct(Item $item): float {
        return $item->getNamedTag()->getFloat(self::TAG_HP_REGEN_PCT, 0.0);
    }

    /**
     * 관리자가 악세사리 아이템 생성 시 사용
     */
    public static function apply(Item $item, string $type, int $hp = 0, int $atk = 0, int $regenFlat = 0, float $regenPct = 0.0): Item {
        $nbt = $item->getNamedTag();
        $nbt->setByte(self::TAG_ACCESSORY, 1);
        $nbt->setString(self::TAG_TYPE, $type);
        if ($hp > 0)        $nbt->setInt(self::TAG_HP, $hp);
        if ($atk > 0)       $nbt->setInt(self::TAG_ATK, $atk);
        if ($regenFlat > 0) $nbt->setInt(self::TAG_HP_REGEN_FLAT, $regenFlat);
        if ($regenPct > 0)  $nbt->setFloat(self::TAG_HP_REGEN_PCT, $regenPct);
        $item->setNamedTag($nbt);

        // 로어 자동 생성
        $lore = ['§r§8[ ' . ($type === 'ring' ? '반지' : '목걸이') . ' ]', ' '];
        if ($hp > 0)        $lore[] = '§r§c체력 +' . $hp;
        if ($atk > 0)       $lore[] = '§r§c공격력 +' . $atk;
        if ($regenFlat > 0) $lore[] = '§r§a초당 체력 회복 +' . $regenFlat;
        if ($regenPct > 0)  $lore[] = '§r§a초당 체력 회복 +' . round($regenPct * 100, 1) . '%';
        $item->setLore(array_merge($item->getLore(), $lore));

        return $item;
    }

    // ── 강화 관련 ──────────────────────────────────────────

    public static function getEnhanceLevel(Item $item): int {
        return $item->getNamedTag()->getInt(self::TAG_ENHANCE_LEVEL, 0);
    }

    /**
     * 악세사리 강화 적용
     * 첫 강화 시 기본 스탯을 TAG_BASE_*에 저장하고, 레벨당 +10%씩 스탯 증가
     */
    public static function applyEnhance(Item $item): Item {
        $nbt   = $item->getNamedTag();
        $level = $nbt->getInt(self::TAG_ENHANCE_LEVEL, 0);

        // 기본 스탯 최초 저장
        if ($level === 0) {
            $nbt->setInt(self::TAG_BASE_HP,    self::getHp($item));
            $nbt->setInt(self::TAG_BASE_ATK,   self::getAtk($item));
            $nbt->setInt(self::TAG_BASE_FLAT,  self::getRegenFlat($item));
            $nbt->setFloat(self::TAG_BASE_PCT, self::getRegenPct($item));
        }

        $newLevel = $level + 1;
        $nbt->setInt(self::TAG_ENHANCE_LEVEL, $newLevel);

        // 증가량 = floor(base * rate * newLevel)
        $baseHp   = $nbt->getInt(self::TAG_BASE_HP,    0);
        $baseAtk  = $nbt->getInt(self::TAG_BASE_ATK,   0);
        $baseFlat = $nbt->getInt(self::TAG_BASE_FLAT,  0);
        $basePct  = $nbt->getFloat(self::TAG_BASE_PCT, 0.0);
        $r        = self::ENHANCE_STAT_BONUS_RATE * $newLevel;

        if ($baseHp > 0)   $nbt->setInt(self::TAG_HP, $baseHp + (int)floor($baseHp * $r));
        if ($baseAtk > 0)  $nbt->setInt(self::TAG_ATK, $baseAtk + (int)floor($baseAtk * $r));
        if ($baseFlat > 0) $nbt->setInt(self::TAG_HP_REGEN_FLAT, $baseFlat + (int)floor($baseFlat * $r));
        if ($basePct > 0)  $nbt->setFloat(self::TAG_HP_REGEN_PCT, $basePct + $basePct * $r);

        $item->setNamedTag($nbt);
        self::refreshLore($item, $newLevel);
        return $item;
    }

    /** 로어를 현재 스탯으로 갱신 */
    private static function refreshLore(Item $item, int $enhanceLevel): void {
        $type = self::getType($item);
        $typeName = $type === 'ring' ? '반지' : '목걸이';
        $enhStr = $enhanceLevel > 0 ? " §e+{$enhanceLevel}" : '';

        $lore = ["§r§8[ {$typeName}{$enhStr} ]", ' '];
        if (($v = self::getHp($item)) > 0)        $lore[] = '§r§c체력 +' . $v;
        if (($v = self::getAtk($item)) > 0)       $lore[] = '§r§c공격력 +' . $v;
        if (($v = self::getRegenFlat($item)) > 0) $lore[] = '§r§a초당 체력 회복 +' . $v;
        if (($v = self::getRegenPct($item)) > 0)  $lore[] = '§r§a초당 체력 회복 +' . round($v * 100, 1) . '%';
        if ($enhanceLevel > 0) {
            $next = $enhanceLevel < self::MAX_ENHANCE
                ? ' §8→ 다음 강화: §e' . self::ENHANCE_STONE_COUNTS[$enhanceLevel] . '개 §8/ §e' . self::ENHANCE_RATES[$enhanceLevel] . '%'
                : ' §a[최대 강화]';
            $lore[] = "§r§8강화: §e+{$enhanceLevel}§8/{$next}";
        }
        $item->setLore($lore);
    }

    public static function getStatSummary(Item $item): string {
        $parts = [];
        if (($v = self::getHp($item)) > 0)        $parts[] = '§c+' . $v;
        if (($v = self::getAtk($item)) > 0)       $parts[] = '§c+' . $v;
        if (($v = self::getRegenFlat($item)) > 0) $parts[] = '§a+' . $v;
        if (($v = self::getRegenPct($item)) > 0)  $parts[] = '§a+' . round($v * 100, 1) . '%';
        return empty($parts) ? '§8(스탯 없음)' : implode(' ', $parts);
    }
}
