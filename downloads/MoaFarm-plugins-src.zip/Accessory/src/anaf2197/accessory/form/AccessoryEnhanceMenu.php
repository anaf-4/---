<?php

declare(strict_types=1);

namespace anaf2197\accessory\form;

use muqsit\invmenu\InvMenu;
use muqsit\invmenu\transaction\InvMenuTransaction;
use muqsit\invmenu\transaction\InvMenuTransactionResult;
use muqsit\invmenu\type\InvMenuTypeIds;
use pocketmine\block\utils\DyeColor;
use pocketmine\block\VanillaBlocks;
use pocketmine\item\Item;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use anaf2197\accessory\AccessoryLoader;
use anaf2197\accessory\item\AccessoryItem;

/**
 * /악세강화 — InvMenu로 악세사리 강화
 *
 * 레이아웃 (더블 체스트 54칸):
 *   [ 4] 정보 표시 (현재 레벨·성공률·필요 강화석)
 *   [13] 악세사리 배치 슬롯
 *   [15] 강화석 배치 슬롯
 *   [22] 강화 버튼
 *   [40] 취소
 */
final class AccessoryEnhanceMenu
{
    public static function open(Player $player): void
    {
        $invMenu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
        $invMenu->setName('§l악세사리 강화');

        $inv     = $invMenu->getInventory();
        $barrier = VanillaBlocks::BARRIER()->asItem()->setCustomName('§r ');

        for ($i = 0; $i < 54; $i++) {
            $inv->setItem($i, $barrier);
        }
        $inv->setItem(13, VanillaItems::AIR()); // 악세사리 슬롯
        $inv->setItem(15, VanillaItems::AIR()); // 강화석 슬롯

        // 취소 버튼
        $inv->setItem(40, VanillaBlocks::STAINED_GLASS()->setColor(DyeColor::RED())->asItem()
            ->setCustomName('§r§l§c취소'));

        self::refreshInfo($inv, null);

        $invMenu->setListener(function (InvMenuTransaction $transaction) use ($invMenu): InvMenuTransactionResult {
            $slot   = $transaction->getAction()->getSlot();
            $player = $transaction->getPlayer();
            $inv    = $transaction->getAction()->getInventory();

            // 악세사리·강화석 슬롯만 아이템 출입 허용
            if ($slot === 13 || $slot === 15) {
                // 아이템 변경 후 정보 갱신 (다음 틱)
                AccessoryLoader::getInstance()->getScheduler()->scheduleDelayedTask(
                    new \pocketmine\scheduler\ClosureTask(function () use ($inv): void {
                        $acc = $inv->getItem(13);
                        self::refreshInfo($inv, AccessoryItem::isAccessory($acc) ? $acc : null);
                    }),
                    1
                );
                return $transaction->continue();
            }

            // 강화 버튼
            if ($slot === 22) {
                $acc   = $inv->getItem(13);
                $stone = $inv->getItem(15);

                if (!AccessoryItem::isAccessory($acc)) {
                    $player->sendMessage(AccessoryLoader::$prefix . '§c슬롯(왼쪽)에 악세사리를 배치하세요.');
                    return $transaction->discard();
                }

                $level = AccessoryItem::getEnhanceLevel($acc);
                $max   = AccessoryItem::MAX_ENHANCE;

                if ($level >= $max) {
                    $player->sendMessage(AccessoryLoader::$prefix . '§c이미 최대 강화 레벨입니다.');
                    return $transaction->discard();
                }

                $need      = AccessoryItem::ENHANCE_STONE_COUNTS[$level];
                $stoneBase = AccessoryLoader::getInstance()->getEnhanceStone();

                // equalsExact 대신 커스텀 이름만 비교 (NBT 세부 차이로 불일치 방지)
                $isValidStone = !$stone->isNull()
                    && $stone->getTypeId() === $stoneBase->getTypeId()
                    && $stone->getCustomName() === $stoneBase->getCustomName()
                    && $stone->getCount() >= $need;

                if (!$isValidStone) {
                    $player->sendMessage(AccessoryLoader::$prefix . "§c강화석이 부족합니다. (필요: §e{$need}개§c)");
                    return $transaction->discard();
                }

                // 강화석 차감
                $stone->setCount($stone->getCount() - $need);
                $inv->setItem(15, $stone->getCount() <= 0 ? VanillaItems::AIR() : $stone);

                // 성공 판정
                $rate = AccessoryItem::ENHANCE_RATES[$level];
                if (rand(1, 100) <= $rate) {
                    $result = AccessoryItem::applyEnhance(clone $acc);
                    $inv->setItem(13, $result);
                    self::refreshInfo($inv, $result);
                    $player->sendMessage(AccessoryLoader::$prefix
                        . "§a강화 성공! §8(§e+" . AccessoryItem::getEnhanceLevel($result) . "강§8 | 확률: §e{$rate}%§8)");
                } else {
                    $player->sendMessage(AccessoryLoader::$prefix
                        . "§c강화 실패. §8(확률: §e{$rate}%§8 | 레벨 유지)");
                }
                return $transaction->discard();
            }

            // 취소
            if ($slot === 40) {
                $player->removeCurrentWindow();
                return $transaction->discard();
            }

            return $transaction->discard();
        });

        $invMenu->setInventoryCloseListener(function (Player $player, \pocketmine\inventory\Inventory $inv): void {
            // 창 닫힐 때 슬롯 아이템 반환
            foreach ([13, 15] as $slot) {
                $item = $inv->getItem($slot);
                if (!$item->isNull()) {
                    $player->getInventory()->addItem($item);
                }
            }
        });

        $invMenu->send($player);
    }

    private static function refreshInfo(\pocketmine\inventory\Inventory $inv, ?Item $acc): void
    {
        if ($acc === null || !AccessoryItem::isAccessory($acc)) {
            $info = VanillaBlocks::STAINED_GLASS()->setColor(DyeColor::GRAY())->asItem()
                ->setCustomName('§r§l§8[강화 정보]')
                ->setLore([
                    '§r§8왼쪽 슬롯에 악세사리를',
                    '§r§8오른쪽 슬롯에 강화석을 배치하세요.',
                ]);
            $inv->setItem(4, $info);

            $enhBtn = VanillaBlocks::STAINED_GLASS()->setColor(DyeColor::GRAY())->asItem()
                ->setCustomName('§r§l§8강화');
            $inv->setItem(22, $enhBtn);
            return;
        }

        $level = AccessoryItem::getEnhanceLevel($acc);
        $max   = AccessoryItem::MAX_ENHANCE;

        if ($level >= $max) {
            $info = VanillaBlocks::STAINED_GLASS()->setColor(DyeColor::GOLD())->asItem()
                ->setCustomName('§r§l§e[최대 강화]')
                ->setLore(['§r§a이미 최대 강화 레벨입니다.']);
            $inv->setItem(4, $info);

            $inv->setItem(22, VanillaBlocks::STAINED_GLASS()->setColor(DyeColor::GRAY())->asItem()
                ->setCustomName('§r§l§8강화 불가 (최대)'));
            return;
        }

        $rate  = AccessoryItem::ENHANCE_RATES[$level];
        $need  = AccessoryItem::ENHANCE_STONE_COUNTS[$level];

        $info = VanillaBlocks::STAINED_GLASS()->setColor(DyeColor::BLUE())->asItem()
            ->setCustomName('§r§l§f[강화 정보]')
            ->setLore([
                "§r§f현재 강화: §e+{$level}강 §8/ §8{$max}강",
                "§r§f성공 확률: §a{$rate}%",
                "§r§f필요 강화석: §e{$need}개",
                ' ',
                '§r§8실패해도 레벨은 유지됩니다.',
            ]);
        $inv->setItem(4, $info);

        $enhBtn = VanillaBlocks::STAINED_GLASS()->setColor(DyeColor::GREEN())->asItem()
            ->setCustomName('§r§l§a강화')
            ->setLore(["§r§8+{$level}강 → +".($level+1)."강 시도 (§a{$rate}%§8)"]);
        $inv->setItem(22, $enhBtn);
    }
}
