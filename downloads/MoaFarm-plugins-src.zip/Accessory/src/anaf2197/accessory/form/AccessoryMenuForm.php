<?php

declare(strict_types=1);

namespace anaf2197\accessory\form;

use pocketmine\form\Form;
use pocketmine\item\Item;
use pocketmine\item\VanillaItems;
use pocketmine\nbt\BigEndianNbtSerializer;
use pocketmine\nbt\TreeRoot;
use pocketmine\player\Player;
use anaf2197\accessory\AccessoryLoader;
use anaf2197\accessory\item\AccessoryItem;

/**
 * 악세사리 장착/해제 UI
 * 슬롯: ring1, ring2, necklace
 */
final class AccessoryMenuForm implements Form {

    private array $slotLabels = [
        AccessoryItem::SLOT_RING1    => '반지 슬롯 1',
        AccessoryItem::SLOT_RING2    => '반지 슬롯 2',
        AccessoryItem::SLOT_NECKLACE => '목걸이 슬롯',
    ];

    /** @var array [slot => Item|null] */
    private array $equipped;
    private array $buttons = [];

    public function __construct(private readonly Player $player) {
        $this->equipped = AccessoryLoader::getInstance()->getEquipped($player);
    }

    public function jsonSerialize(): array {
        // 합산 스탯 계산
        $totalHp = $totalAtk = $totalFlat = 0;
        $totalPct = 0.0;
        foreach ($this->equipped as $item) {
            if (!$item instanceof Item || $item->isNull()) continue;
            $totalHp   += AccessoryItem::getHp($item);
            $totalAtk  += AccessoryItem::getAtk($item);
            $totalFlat += AccessoryItem::getRegenFlat($item);
            $totalPct  += AccessoryItem::getRegenPct($item);
        }

        $statParts = [];
        if ($totalHp > 0)    $statParts[] = '§c+' . $totalHp;
        if ($totalAtk > 0)   $statParts[] = '§c+' . $totalAtk;
        if ($totalFlat > 0)  $statParts[] = '§a+' . $totalFlat;
        if ($totalPct > 0.0) $statParts[] = '§a+' . round($totalPct * 100, 1) . '%';
        $totalLine = empty($statParts) ? '§8(장착 없음)' : implode('  ', $statParts);

        $content = [
            ' ',
            '§f손에 악세사리를 들고 슬롯을 터치하면 장착됩니다.',
            '§f슬롯을 터치하면 해제됩니다.',
            ' ',
            '§8합산 스탯: ' . $totalLine,
            ' ',
        ];

        foreach ($this->slotLabels as $slot => $label) {
            $item = $this->equipped[$slot] ?? null;
            if ($item instanceof Item && !$item->isNull()) {
                $text = "§a[장착] §f{$label}\n§8" . $item->getName() . ' | ' . AccessoryItem::getStatSummary($item);
                $action = 'unequip';
            } else {
                $text = "§8[비어있음] §f{$label}\n§8손에 악세사리를 들고 터치";
                $action = 'equip';
            }
            $this->buttons[] = ['slot' => $slot, 'action' => $action, 'text' => $text];
        }

        return [
            'type'    => 'form',
            'title'   => '§l§0 악세사리',
            'content' => implode("\n", $content),
            'buttons' => array_map(fn($b) => ['text' => $b['text']], $this->buttons)
        ];
    }

    public function handleResponse(Player $player, $data): void {
        if (!is_numeric($data)) return;

        $btn    = $this->buttons[(int)$data] ?? null;
        if ($btn === null) return;

        $slot   = $btn['slot'];
        $action = $btn['action'];

        if ($action === 'equip') {
            $hand = $player->getInventory()->getItemInHand();
            if ($hand->isNull() || !AccessoryItem::isAccessory($hand)) {
                $player->sendMessage(AccessoryLoader::$prefix . '손에 악세사리를 들고 슬롯을 선택해주세요.');
                $player->sendForm(new self($player));
                return;
            }
            // 타입 체크
            $isRing     = AccessoryItem::isRing($hand);
            $isNecklace = AccessoryItem::isNecklace($hand);
            if ($slot === AccessoryItem::SLOT_NECKLACE && !$isNecklace) {
                $player->sendMessage(AccessoryLoader::$prefix . '목걸이 슬롯에는 목걸이만 장착 가능합니다.');
                $player->sendForm(new self($player));
                return;
            }
            if (in_array($slot, [AccessoryItem::SLOT_RING1, AccessoryItem::SLOT_RING2]) && !$isRing) {
                $player->sendMessage(AccessoryLoader::$prefix . '반지 슬롯에는 반지만 장착 가능합니다.');
                $player->sendForm(new self($player));
                return;
            }
            AccessoryLoader::getInstance()->equip($player, $slot, $hand);
            $player->getInventory()->setItemInHand(VanillaItems::AIR());
            $player->sendMessage(AccessoryLoader::$prefix . $hand->getName() . '을 §f[' . ($this->slotLabels[$slot] ?? $slot) . ']§8에 장착했습니다.');

        } else {
            // 해제: 인벤토리에 돌려줌
            $item = $this->equipped[$slot] ?? null;
            if ($item instanceof Item && !$item->isNull()) {
                if ($player->getInventory()->canAddItem($item)) {
                    $player->getInventory()->addItem(clone $item);
                    AccessoryLoader::getInstance()->unequip($player, $slot);
                    $player->sendMessage(AccessoryLoader::$prefix . $item->getName() . '을 해제했습니다.');
                } else {
                    $player->sendMessage(AccessoryLoader::$prefix . '인벤토리 공간이 부족합니다.');
                }
            }
        }

        $player->sendForm(new self($player));
    }
}
