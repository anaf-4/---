<?php

declare(strict_types=1);

namespace anaf2197\accessory\form;

use pocketmine\form\Form;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use anaf2197\accessory\AccessoryLoader;
use anaf2197\accessory\item\AccessoryItem;

/**
 * /악세관리 — 손에 든 아이템을 악세사리로 지정하는 관리자 GUI
 *
 * 설정 항목:
 *   - 아이템 이름 (커스텀 이름)
 *   - 종류 (ring | necklace)
 *   - 체력 (HP)
 *   - 공격력 (ATK)
 *   - 초당 고정 회복 (regen_flat)
 *   - 초당 % 회복   (regen_pct, 0~100 입력 → 0.0~1.0 저장)
 */
final class AccessoryManageForm implements Form
{
    private string $currentName;

    public function __construct(private readonly Player $player)
    {
        $hand = $player->getInventory()->getItemInHand();
        $this->currentName = $hand->isNull() ? '' : $hand->getName();
    }

    public function jsonSerialize(): array
    {
        $hand = $this->player->getInventory()->getItemInHand();

        // 이미 악세사리면 기존 수치 미리 채우기
        $isAcc     = !$hand->isNull() && AccessoryItem::isAccessory($hand);
        $defType   = $isAcc ? (AccessoryItem::isRing($hand) ? 0 : 1) : 0;
        $defHp     = $isAcc ? AccessoryItem::getHp($hand) : 0;
        $defAtk    = $isAcc ? AccessoryItem::getAtk($hand) : 0;
        $defFlat   = $isAcc ? AccessoryItem::getRegenFlat($hand) : 0;
        $defPct    = $isAcc ? round(AccessoryItem::getRegenPct($hand) * 100, 1) : 0;

        return [
            'type'    => 'custom_form',
            'title'   => '§l악세사리 지정',
            'content' => [
                [
                    'type' => 'label',
                    'text' => implode("\n", [
                        ' ',
                        '§f손에 든 아이템: §e' . ($hand->isNull() ? '(없음)' : $hand->getName()),
                        '§8손에 아이템을 들고 수치를 설정하면 악세사리로 지정됩니다.',
                        ' ',
                    ])
                ],
                [
                    'type'        => 'input',
                    'text'        => '§f아이템 이름',
                    'placeholder' => '예: 별빛의 반지',
                    'default'     => $this->currentName,
                ],
                [
                    'type'    => 'dropdown',
                    'text'    => '§f종류',
                    'options' => ['반지 (ring)', '목걸이 (necklace)'],
                    'default' => $defType,
                ],
                [
                    'type'        => 'input',
                    'text'        => '§f체력 (HP)',
                    'placeholder' => '0',
                    'default'     => (string)$defHp,
                ],
                [
                    'type'        => 'input',
                    'text'        => '§f공격력 (ATK)',
                    'placeholder' => '0',
                    'default'     => (string)$defAtk,
                ],
                [
                    'type'        => 'input',
                    'text'        => '§f초당 고정 체력 회복',
                    'placeholder' => '0',
                    'default'     => (string)$defFlat,
                ],
                [
                    'type'        => 'input',
                    'text'        => '§f초당 % 체력 회복 (0~100)',
                    'placeholder' => '0',
                    'default'     => (string)$defPct,
                ],
            ],
        ];
    }

    public function handleResponse(Player $player, $data): void
    {
        if (!is_array($data)) return;

        $hand = $player->getInventory()->getItemInHand();
        if ($hand->isNull()) {
            $player->sendMessage(AccessoryLoader::$prefix . '§c손에 아이템을 들고 사용해주세요.');
            return;
        }

        $name      = trim((string)($data[1] ?? ''));
        $typeIdx   = (int)($data[2] ?? 0);
        $hp        = max(0, (int)($data[3] ?? 0));
        $atk       = max(0, (int)($data[4] ?? 0));
        $regenFlat = max(0, (int)($data[5] ?? 0));
        $regenPct  = max(0.0, min(100.0, (float)($data[6] ?? 0))) / 100.0;
        $type      = $typeIdx === 0 ? 'ring' : 'necklace';

        if ($name !== '') {
            $hand->setCustomName('§r' . $name);
        }

        // 기존 악세사리 NBT 초기화 후 재지정
        $nbt = $hand->getNamedTag();
        foreach ([
            AccessoryItem::TAG_ACCESSORY,
            AccessoryItem::TAG_TYPE,
            AccessoryItem::TAG_HP,
            AccessoryItem::TAG_ATK,
            AccessoryItem::TAG_HP_REGEN_FLAT,
            AccessoryItem::TAG_HP_REGEN_PCT,
        ] as $tag) {
            $nbt->removeTag($tag);
        }
        $hand->setNamedTag($nbt);

        $result = AccessoryItem::apply($hand, $type, $hp, $atk, $regenFlat, $regenPct);
        $player->getInventory()->setItemInHand($result);

        $typeName = $type === 'ring' ? '반지' : '목걸이';
        $player->sendMessage(AccessoryLoader::$prefix
            . "§a{$result->getName()}§8을 §f{$typeName}§8 악세사리로 지정했습니다. "
            . AccessoryItem::getStatSummary($result));
    }
}
