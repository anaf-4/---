<?php

declare(strict_types=1);

namespace anaf2197\accessory\db;

use mysqli;
use RuntimeException;

final class Database {

    private mysqli $db;

    public function __construct(
        private string $host,
        private int    $port,
        private string $user,
        private string $pass,
        private string $dbName
    ) {
        $this->connect();
        $this->initTables();
    }

    private function connect(): void {
        $this->db = new mysqli($this->host, $this->user, $this->pass, $this->dbName, $this->port);
        if ($this->db->connect_errno) {
            throw new RuntimeException('Accessory DB 연결 실패: ' . $this->db->connect_error);
        }
        $this->db->set_charset('utf8mb4');
    }

    private function reconnectIfNeeded(): void {
        try {
            $this->db->query('SELECT 1');
        } catch (\mysqli_sql_exception $e) {
            if ($e->getCode() === 2006 || $e->getCode() === 2013) {
                $this->connect();
            } else {
                throw $e;
            }
        }
    }

    private function initTables(): void {
        // 플레이어 악세사리 장착 현황
        $this->db->query("
            CREATE TABLE IF NOT EXISTS accessory_equipped (
                player_name VARCHAR(64)  NOT NULL,
                slot        VARCHAR(16)  NOT NULL COMMENT 'ring1, ring2, necklace',
                item_data   MEDIUMBLOB   NOT NULL,
                PRIMARY KEY (player_name, slot)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
    }

    /** 플레이어의 장착 악세사리 전체 로드 → [slot => item_data] */
    public function loadEquipped(string $player): array {
        $this->reconnectIfNeeded();
        $stmt = $this->db->prepare("SELECT slot, item_data FROM accessory_equipped WHERE player_name=?");
        if ($stmt === false) return [];
        $stmt->bind_param('s', $player);
        $stmt->execute();
        $result = $stmt->get_result();
        $data   = [];
        while ($row = $result->fetch_assoc()) {
            $data[$row['slot']] = $row['item_data'];
        }
        $result->free();
        $stmt->close();
        return $data;
    }

    /** 악세사리 장착/교체 */
    public function setEquipped(string $player, string $slot, string $itemData): void {
        $this->reconnectIfNeeded();
        $stmt = $this->db->prepare("
            INSERT INTO accessory_equipped (player_name, slot, item_data)
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE item_data=VALUES(item_data)
        ");
        if ($stmt === false) throw new RuntimeException($this->db->error);
        $stmt->bind_param('sss', $player, $slot, $itemData);
        $stmt->execute();
        $stmt->close();
    }

    /** 악세사리 해제 */
    public function removeEquipped(string $player, string $slot): void {
        $this->reconnectIfNeeded();
        $stmt = $this->db->prepare("DELETE FROM accessory_equipped WHERE player_name=? AND slot=?");
        if ($stmt === false) throw new RuntimeException($this->db->error);
        $stmt->bind_param('ss', $player, $slot);
        $stmt->execute();
        $stmt->close();
    }

    public function close(): void {
        $this->db->close();
    }
}
