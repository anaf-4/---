<?php

declare(strict_types=1);

namespace anaf2197\accessory;

use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\EventPriority;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\item\Item;
use pocketmine\nbt\BigEndianNbtSerializer;
use pocketmine\nbt\TreeRoot;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\scheduler\ClosureTask;
use pocketmine\utils\SingletonTrait;
use anaf2197\accessory\db\Database;
use anaf2197\accessory\form\AccessoryEnhanceMenu;
use anaf2197\accessory\form\AccessoryManageForm;
use anaf2197\accessory\form\AccessoryMenuForm;
use anaf2197\accessory\item\AccessoryItem;
use anaf2197\lib\color\ServerColor;

final class AccessoryLoader extends PluginBase {

    use SingletonTrait;

    public static string $prefix;

    private ?Database $database = null;

    /** [playerName => [slot => Item]] */
    private array $cache = [];

    protected function onLoad(): void {
        self::setInstance($this);
        ServerColor::setPrefix($this, '악세사리');
    }

    protected function onEnable(): void {
        $this->saveDefaultConfig();
        $cfg = $this->getConfig()->get('database');

        try {
            $this->database = new Database(
                $cfg['host'], (int)$cfg['port'],
                $cfg['username'], $cfg['password'], $cfg['database']
            );
        } catch (\Throwable $e) {
            $this->getLogger()->error('DB 연결 실패: ' . $e->getMessage());
            $this->getServer()->getPluginManager()->disablePlugin($this);
            return;
        }

        // 커맨드 등록
        $this->getServer()->getCommandMap()->register('accessory', new class($this) extends \pocketmine\command\Command {
            public function __construct(private AccessoryLoader $plugin) {
                parent::__construct('악세사리', '악세사리 관리', '/악세사리 [만들기|스펙]');
                $this->setPermission(DefaultPermissions::ROOT_USER);
            }
            public function execute(\pocketmine\command\CommandSender $sender, string $label, array $args): void {
                if (!$sender instanceof Player || !$this->testPermission($sender)) return;
                $sub = $args[0] ?? '';
                if ($sub === '만들기' && $sender->hasPermission(DefaultPermissions::ROOT_OPERATOR)) {
                    // /악세사리 만들기 [ring|necklace] [hp] [atk] [regen_flat] [regen_pct]
                    $type      = $args[1] ?? 'ring';
                    $hp        = (int)($args[2] ?? 0);
                    $atk       = (int)($args[3] ?? 0);
                    $regenFlat = (int)($args[4] ?? 0);
                    $regenPct  = (float)($args[5] ?? 0);
                    $item      = \pocketmine\item\VanillaItems::GOLD_NUGGET()->setCustomName('§r§e' . ($type === 'ring' ? '반지' : '목걸이'));
                    $item      = AccessoryItem::apply($item, $type, $hp, $atk, $regenFlat, $regenPct);
                    $sender->getInventory()->addItem($item);
                    $sender->sendMessage(AccessoryLoader::$prefix . '악세사리를 생성했습니다.');
                } elseif ($sub === '스펙') {
                    $equipped = $this->plugin->getEquipped($sender);
                    $sender->sendMessage('');
                    $sender->sendMessage(AccessoryLoader::$prefix . '§l현재 장착 악세사리');
                    foreach ([AccessoryItem::SLOT_RING1 => '반지1', AccessoryItem::SLOT_RING2 => '반지2', AccessoryItem::SLOT_NECKLACE => '목걸이'] as $slot => $name) {
                        $item = $equipped[$slot] ?? null;
                        if ($item instanceof Item && !$item->isNull()) {
                            $sender->sendMessage("§f[{$name}] §8" . $item->getName() . ' ' . AccessoryItem::getStatSummary($item));
                        } else {
                            $sender->sendMessage("§8[{$name}] 비어있음");
                        }
                    }
                    $stats = $this->plugin->getTotalStats($sender);
                    $sender->sendMessage("§f총합: §c+" . $stats['hp'] . " §c+" . $stats['atk'] . " §a+" . $stats['regen_flat'] . " §a+" . round($stats['regen_pct'] * 100, 1) . "%");
                    $sender->sendMessage('');
                } else {
                    $sender->sendForm(new AccessoryMenuForm($sender));
                }
            }
        });

        // 악세강화 명령어 (일반 플레이어)
        $this->getServer()->getCommandMap()->register('accessory', new class extends \pocketmine\command\Command {
            public function __construct() {
                parent::__construct('악세강화', '악세사리를 강화합니다.', '/악세강화');
                $this->setPermission(DefaultPermissions::ROOT_USER);
            }
            public function execute(\pocketmine\command\CommandSender $sender, string $label, array $args): void {
                if (!$sender instanceof Player || !$this->testPermission($sender)) return;
                AccessoryEnhanceMenu::open($sender);
            }
        });

        // 악세관리 명령어 (OP 전용)
        $this->getServer()->getCommandMap()->register('accessory', new class extends \pocketmine\command\Command {
            public function __construct() {
                parent::__construct('악세관리', '아이템을 악세사리로 지정합니다.', '/악세관리');
                $this->setPermission(DefaultPermissions::ROOT_OPERATOR);
            }
            public function execute(\pocketmine\command\CommandSender $sender, string $label, array $args): void {
                if (!$sender instanceof Player || !$this->testPermission($sender)) return;
                $sender->sendForm(new AccessoryManageForm($sender));
            }
        });

        // 이벤트 리스너
        $pm = $this->getServer()->getPluginManager();

        $pm->registerEvent(PlayerJoinEvent::class, function (PlayerJoinEvent $event): void {
            $this->loadPlayer($event->getPlayer());
        }, EventPriority::NORMAL, $this);

        $pm->registerEvent(PlayerQuitEvent::class, function (PlayerQuitEvent $event): void {
            unset($this->cache[strtolower($event->getPlayer()->getName())]);
        }, EventPriority::NORMAL, $this);

        // HP 회복 스케줄러 (1초마다)
        $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(function (): void {
            foreach ($this->getServer()->getOnlinePlayers() as $player) {
                $this->applyRegen($player);
            }
        }), 20);

        $this->getLogger()->info("악세사리 시스템 활성화");
    }

    protected function onDisable(): void {
        $this->database?->close();
    }

    private function loadPlayer(Player $player): void {
        $name = strtolower($player->getName());
        $raw  = $this->database?->loadEquipped($name) ?? [];
        $this->cache[$name] = [];
        foreach ($raw as $slot => $itemData) {
            try {
                $this->cache[$name][$slot] = $this->deserializeItem($itemData);
            } catch (\Throwable) {}
        }
    }

    /** [slot => Item] */
    public function getEquipped(Player $player): array {
        return $this->cache[strtolower($player->getName())] ?? [];
    }

    public function equip(Player $player, string $slot, Item $item): void {
        $name = strtolower($player->getName());
        $this->cache[$name][$slot] = $item;
        $this->database?->setEquipped($name, $slot, $this->serializeItem($item));
    }

    public function unequip(Player $player, string $slot): void {
        $name = strtolower($player->getName());
        unset($this->cache[$name][$slot]);
        $this->database?->removeEquipped($name, $slot);
    }

    /**
     * 악세사리 강화석 아이템 반환
     * config.yml의 enhance_stone 키에 직렬화된 아이템이 있으면 해당 아이템,
     * 없으면 Gold Ingot을 기본 강화석으로 사용
     */
    public function getEnhanceStone(): Item {
        $data = $this->getConfig()->get('enhance_stone', null);
        if ($data !== null) {
            try { return $this->deserializeItem($data); } catch (\Throwable) {}
        }
        return \pocketmine\item\VanillaItems::GOLD_INGOT()
            ->setCustomName('§r§e악세사리 강화석')
            ->setLore(['§r§8악세사리 강화에 사용합니다.']);
    }

    /** 총합 스탯 계산 */
    public function getTotalStats(Player $player): array {
        $hp = $atk = $regenFlat = 0;
        $regenPct = 0.0;
        foreach ($this->getEquipped($player) as $item) {
            if (!$item instanceof Item) continue;
            $hp       += AccessoryItem::getHp($item);
            $atk      += AccessoryItem::getAtk($item);
            $regenFlat += AccessoryItem::getRegenFlat($item);
            $regenPct  += AccessoryItem::getRegenPct($item);
        }
        return compact('hp', 'atk', 'regenFlat', 'regenPct');
    }

    private function applyRegen(Player $player): void {
        if (!$player->isAlive()) return;
        $stats = $this->getTotalStats($player);

        $flat = $stats['regenFlat'];
        $pct  = $stats['regenPct'];
        if ($flat <= 0 && $pct <= 0.0) return;

        $maxHp  = $player->getMaxHealth();
        $curHp  = $player->getHealth();
        $regen  = $flat + ($maxHp * $pct);
        $newHp  = min($maxHp, $curHp + $regen);
        if ($newHp > $curHp) {
            $player->setHealth($newHp);
        }
    }

    private function serializeItem(Item $item): string {
        return base64_encode((new BigEndianNbtSerializer())->write(new TreeRoot($item->nbtSerialize())));
    }

    private function deserializeItem(string $data): Item {
        return Item::nbtDeserialize((new BigEndianNbtSerializer())->read(base64_decode($data))->mustGetCompoundTag());
    }
}
