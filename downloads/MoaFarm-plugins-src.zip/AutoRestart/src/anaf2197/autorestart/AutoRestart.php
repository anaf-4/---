<?php
declare(strict_types=1);

namespace anaf2197\autorestart;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\plugin\PluginBase;
use pocketmine\scheduler\ClosureTask;
use pocketmine\scheduler\TaskHandler;
use pocketmine\utils\SingletonTrait;

final class AutoRestart extends PluginBase {

    use SingletonTrait;

    private ?TaskHandler $scheduledHandler = null;
    /** @var int[] 다음 재시작까지 남은 초 (카운트다운 체크용) */
    private array $sentWarnings = [];

    protected function onLoad(): void {
        self::setInstance($this);
    }

    protected function onEnable(): void {
        $this->saveDefaultConfig();
        // 1분마다 시간 확인
        $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(function (): void {
            $this->checkScheduledRestarts();
        }), 20 * 60);

        // 첫 실행 즉시 한 번 체크
        $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function (): void {
            $this->checkScheduledRestarts();
        }), 20);

        $this->getLogger()->info('AutoRestart 활성화');
    }

    private function checkScheduledRestarts(): void {
        $now          = time();
        $restartTimes = (array) $this->getConfig()->get('restart_times', ['06:00', '12:00', '18:00', '00:00']);
        $warnings     = (array) $this->getConfig()->get('countdown_warnings', [10, 5, 3, 1]);
        sort($warnings);

        foreach ($restartTimes as $timeStr) {
            [$h, $m] = explode(':', $timeStr);
            $targetTs = mktime((int)$h, (int)$m, 0, (int)date('n'), (int)date('j'), (int)date('Y'));
            if ($targetTs < $now) {
                $targetTs += 86400; // 내일로
            }
            $secsLeft = $targetTs - $now;
            $minsLeft = (int) ceil($secsLeft / 60);

            foreach ($warnings as $warnMin) {
                $key = $timeStr . '_' . $warnMin;
                if ($minsLeft <= $warnMin && !isset($this->sentWarnings[$key])) {
                    $this->sentWarnings[$key] = true;
                    $msg = str_replace('{minutes}', (string)$minsLeft,
                        (string)$this->getConfig()->get('warning_message', '§c[서버] §f{minutes}분 후 서버가 재시작됩니다.')
                    );
                    $this->getServer()->broadcastMessage($msg);

                    // 30분 후 경고 플래그 리셋 (다음 주기에 다시 쓸 수 있도록)
                    $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function () use ($key): void {
                        unset($this->sentWarnings[$key]);
                    }), 20 * 1800);
                }
            }

            // 실제 재시작 (30초 이내)
            if ($secsLeft <= 30 && $secsLeft > 0) {
                $restartKey = 'restart_' . $timeStr;
                if (!isset($this->sentWarnings[$restartKey])) {
                    $this->sentWarnings[$restartKey] = true;
                    $msg = (string) $this->getConfig()->get('restart_message', '§c[서버] 서버가 재시작됩니다.');
                    $this->getServer()->broadcastMessage($msg);
                    $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function (): void {
                        $this->getServer()->shutdown();
                    }), (int)($secsLeft * 20));
                }
            }
        }
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        switch ($command->getName()) {
            case '재시작예약':
                if (empty($args[0]) || !is_numeric($args[0]) || (int)$args[0] <= 0) {
                    $sender->sendMessage('§c사용법: /재시작예약 [분]');
                    return true;
                }
                $minutes = (int) $args[0];
                $this->scheduleManualRestart($minutes, $sender->getName());
                $sender->sendMessage("§a[재시작] {$minutes}분 후 재시작이 예약됐습니다.");
                return true;

            case '재시작취소':
                if ($this->scheduledHandler !== null && !$this->scheduledHandler->isCancelled()) {
                    $this->scheduledHandler->cancel();
                    $this->scheduledHandler = null;
                    $this->getServer()->broadcastMessage('§e[서버] 예약된 재시작이 취소됐습니다.');
                } else {
                    $sender->sendMessage('§8예약된 재시작이 없습니다.');
                }
                return true;
        }
        return false;
    }

    private function scheduleManualRestart(int $minutes, string $by): void {
        if ($this->scheduledHandler !== null && !$this->scheduledHandler->isCancelled()) {
            $this->scheduledHandler->cancel();
        }

        $warnings     = (array) $this->getConfig()->get('countdown_warnings', [10, 5, 3, 1]);
        $totalSeconds = $minutes * 60;

        foreach ($warnings as $warnMin) {
            $warnSeconds = $warnMin * 60;
            if ($totalSeconds > $warnSeconds) {
                $delayTicks = ($totalSeconds - $warnSeconds) * 20;
                $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function () use ($warnMin): void {
                    $msg = str_replace('{minutes}', (string)$warnMin,
                        (string)$this->getConfig()->get('warning_message', '§c[서버] §f{minutes}분 후 서버가 재시작됩니다.')
                    );
                    $this->getServer()->broadcastMessage($msg);
                }), (int)$delayTicks);
            }
        }

        $this->getServer()->broadcastMessage("§c[서버] §f{$by}§c 님이 §f{$minutes}분 후 §c재시작을 예약했습니다.");
        $msg = (string) $this->getConfig()->get('restart_message', '§c[서버] 서버가 재시작됩니다.');

        $this->scheduledHandler = $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function () use ($msg): void {
            $this->getServer()->broadcastMessage($msg);
            $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function (): void {
                $this->getServer()->shutdown();
            }), 60);
        }), $totalSeconds * 20);
    }
}
