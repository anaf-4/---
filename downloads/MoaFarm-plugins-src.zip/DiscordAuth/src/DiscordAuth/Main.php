<?php
declare(strict_types=1);

namespace DiscordAuth;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class Main extends PluginBase implements Listener {

    private \mysqli $db;
    private int $codeExpireMinutes;
    private int $maxAttempts;
    private int $lockoutSeconds;

    /** @var array<string, array{count: int, lastAttempt: int}> */
    private array $failedAttempts = [];

    public function onEnable(): void {
        $this->saveDefaultConfig();
        $cfg = $this->getConfig();

        $db = $cfg->get('database', []);
        $this->codeExpireMinutes = (int) $cfg->get('code_expire_minutes', 5);
        $this->maxAttempts       = (int) $cfg->get('max_attempts', 5);
        $this->lockoutSeconds    = (int) $cfg->get('lockout_seconds', 300);

        $this->db = new \mysqli(
            $db['host']     ?? 'localhost',
            $db['username'] ?? 'root',
            $db['password'] ?? '',
            $db['database'] ?? 'discordauth_bot',
            (int) ($db['port'] ?? 3306)
        );

        if ($this->db->connect_error) {
            $this->getLogger()->error("MySQL 연결 실패: " . $this->db->connect_error);
            $this->getServer()->getPluginManager()->disablePlugin($this);
            return;
        }

        $this->getLogger()->info("MySQL 연결 성공!");
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function onDisable(): void {
        if (isset($this->db)) {
            $this->db->close();
        }
    }

    public function onCommand(
        CommandSender $sender,
        Command $command,
        string $label,
        array $args
    ): bool {

        if ($command->getName() !== "인증번호") {
            return false;
        }

        if (!$sender instanceof Player) {
            $sender->sendMessage("§c이 명령어는 플레이어만 사용할 수 있습니다.");
            return true;
        }

        if (empty($args[0])) {
            $sender->sendMessage("§c사용법: /인증번호 [4자리 코드]");
            $sender->sendMessage("§8디스코드 봇에서 /인증번호 를 입력해 코드를 받으세요.");
            return true;
        }

        $inputCode  = trim($args[0]);
        $playerName = $sender->getName();

        if (!preg_match('/^\d{4}$/', $inputCode)) {
            $sender->sendMessage("§c인증번호는 숫자 4자리여야 합니다.");
            return true;
        }

        // 브루트포스 잠금 확인
        if ($this->isLockedOut($playerName)) {
            $sender->sendMessage("§c인증 시도 횟수를 초과했습니다. 잠시 후 다시 시도해주세요.");
            return true;
        }

        // 원자적 UPDATE: verified=0 인 레코드만 한 번에 처리하여 중복 인증 방지
        $stmt = $this->db->prepare("
            UPDATE auth
            SET verified = 1
            WHERE code = ?
              AND verified = 0
              AND created_at >= NOW() - INTERVAL ? MINUTE
        ");
        $stmt->bind_param("si", $inputCode, $this->codeExpireMinutes);
        $stmt->execute();
        $affectedRows = $stmt->affected_rows;
        $stmt->close();

        if ($affectedRows === 0) {
            $this->recordFailedAttempt($playerName);
            $remaining = $this->maxAttempts - ($this->failedAttempts[$playerName]['count'] ?? 0);
            $remaining = max(0, $remaining);
            $sender->sendMessage("§c유효하지 않거나 만료된 인증번호예요. (남은 시도: {$remaining}회)");
            $sender->sendMessage("§8디스코드 봇에서 /인증번호 를 다시 입력해 새 코드를 받으세요.");
            return true;
        }

        // 인증 성공 후 discord_id 조회
        $stmt2 = $this->db->prepare("SELECT discord_id FROM auth WHERE code = ? LIMIT 1");
        $stmt2->bind_param("s", $inputCode);
        $stmt2->execute();
        $result = $stmt2->get_result()->fetch_assoc();
        $stmt2->close();

        if ($result === null) {
            $sender->sendMessage("§c인증 처리 중 오류가 발생했습니다. 관리자에게 문의해주세요.");
            return true;
        }

        $discordId = $result["discord_id"];
        $this->clearFailedAttempts($playerName);

        // 봇에 역할 부여 요청
        $success = $this->requestRoleGrant($discordId, $playerName);

        if ($success) {
            $sender->sendMessage("§a[인증] 디스코드 인증이 완료되었습니다! 인증 역할이 부여됐어요.");
        } else {
            $sender->sendMessage("§e[인증] 인증은 완료됐지만 역할 부여에 실패했어요.");
            $sender->sendMessage("§e관리자에게 문의해주세요. (Discord ID: " . $discordId . ")");
            $this->getLogger()->warning("역할 부여 실패 - Discord ID: {$discordId}, Player: {$playerName}");
        }

        return true;
    }

    private function isLockedOut(string $playerName): bool {
        if (!isset($this->failedAttempts[$playerName])) {
            return false;
        }
        $data = $this->failedAttempts[$playerName];
        if ($data['count'] < $this->maxAttempts) {
            return false;
        }
        if ((time() - $data['lastAttempt']) >= $this->lockoutSeconds) {
            $this->clearFailedAttempts($playerName);
            return false;
        }
        return true;
    }

    private function recordFailedAttempt(string $playerName): void {
        $this->failedAttempts[$playerName] = [
            'count'       => ($this->failedAttempts[$playerName]['count'] ?? 0) + 1,
            'lastAttempt' => time(),
        ];
    }

    private function clearFailedAttempts(string $playerName): void {
        unset($this->failedAttempts[$playerName]);
    }

    private function requestRoleGrant(string $discordId, string $playerName): bool {
        $botUrl = (string) $this->getConfig()->get('bot_url', 'http://127.0.0.1:8765/verify');
        $body   = json_encode(["discord_id" => $discordId, "player" => $playerName]);

        $ch = curl_init($botUrl);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $body,
            CURLOPT_HTTPHEADER     => ["Content-Type: application/json"],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 5,
            CURLOPT_CONNECTTIMEOUT => 3,
        ]);

        $response  = curl_exec($ch);
        $httpCode  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($curlError) {
            $this->getLogger()->error("cURL 오류: {$curlError}");
            return false;
        }

        if ($httpCode !== 200) {
            $this->getLogger()->error("봇 HTTP 응답 코드: {$httpCode}");
            return false;
        }

        $data = json_decode($response, true);
        return isset($data["success"]) && $data["success"] === true;
    }
}
