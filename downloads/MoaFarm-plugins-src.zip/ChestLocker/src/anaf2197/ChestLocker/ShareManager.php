<?php

declare(strict_types=1);

namespace anaf2197\ChestLocker;

use pocketmine\utils\SingletonTrait;
use Symfony\Component\Filesystem\Path;

class ShareManager{

    use SingletonTrait;

    /** @var array */
    private array $shareData = [];

    public static function init(){
        self::$instance = new self();
    }

    private function __construct(){
        $dataPath = Path::join(ChestLocker::getInstance()->getDataFolder(), "shareList.json");
        if(!is_file($dataPath)){
            $this->save();
        }
        $this->shareData = json_decode(file_get_contents($dataPath), true);
    }

    public function save() : void{
        file_put_contents(Path::join(ChestLocker::getInstance()->getDataFolder(), "shareList.json"), json_encode($this->shareData, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    }

    /**
     * @param string $owner
     *
     * @return boolean
     */
    public function isIssetShareData(string $owner) : bool{
        return isset($this->shareData[$owner]);
    }

    /**
     * @param string $owner
     *
     * @param string $player
     */
    public function addSharePlayer(string $owner, string $player) : void{
        $player = strtolower($player);
        if(!$this->isIssetShareData($owner)){
            $this->shareData[$owner] = [$player];
        }else{
            if(!in_array($player, $this->shareData[$owner])){
                $this->shareData[$owner][] = $player;
            }
        }
    }

    /**
     * @param string $owner
     *
     * @param string $player
     */
    public function removeSharePlayer(string $owner, string $player) : void{
        if(!$this->isIssetShareData($owner)){
            return;
        }
        $player = strtolower($player);
        $key = array_search($player, $this->shareData[$owner]);
        if($key === false){
            return;
        }
        unset($this->shareData[$owner][$key]);
        if(count($this->shareData[$owner]) < 1){
            unset($this->shareData[$owner]);
        }
    }

    /**
     * @param string $owner
     *
     * @return array
     */
    public function getShareList(string $owner) : array{
        if(!$this->isIssetShareData($owner)){
            return [];
        }
        return $this->shareData[$owner];
    }

    /**
     * @param string $owner
     *
     * @param string $player
     *
     * @return boolean
     */
    public function isSharePlayer(string $owner, string $player) : bool{
        $player = strtolower($player);
        if(!$this->isIssetShareData($owner)){
            return false;
        }
        if(!in_array($player, $this->shareData[$owner])){
            return false;
        }
        return true;
    }
}