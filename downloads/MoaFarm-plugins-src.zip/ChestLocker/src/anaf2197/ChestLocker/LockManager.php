<?php

declare(strict_types=1);

namespace anaf2197\ChestLocker;

use pocketmine\block\BaseSign;
use pocketmine\block\Chest;
use pocketmine\block\tile\Chest as TileChest;
use pocketmine\block\WallSign;
use pocketmine\utils\SingletonTrait;

class LockManager{

    use SingletonTrait;

    public static function init(){
        self::$instance = new self();
    }

    public function isLockedChest(Chest $chest) : bool{
        $world = $chest->getPosition()->getWorld();
        //연결 상자 확인
        $tileChest = $world->getTile($chest->getPosition());
        if($tileChest instanceof TileChest){ //상자 타일인지 확인
            if($tileChest->isPaired()){ //연결 상자가 있는지 확인
                $pairChest = $world->getBlock($tileChest->getPair()->getPosition());
                if($pairChest instanceof Chest){ //연결 상자 블럭이 상자 블럭인지 확인
                    $pairSign = $pairChest->getSide($pairChest->getFacing());
                    if($pairSign instanceof WallSign){ //표지판 존재여부 확인
                        if($pairSign->getText()->getLine(0) === ChestLocker::getInstance()->getLockSign()){ //표지판 내용 확인
                            return true;
                        }
                    }
                }
            }
        }
        //상자 확인
        $sign = $chest->getSide($chest->getFacing());
        if($sign instanceof WallSign){ //표지판 존재여부 확인
            if($sign->getText()->getLine(0) === ChestLocker::getInstance()->getLockSign()){ //표지판 내용 확인
                return true;
            }
        }
        return false;
    }

    public function getOwnerLockedChest(Chest $chest): ?string {
        $world = $chest->getPosition()->getWorld();

        // Check paired chest
        $tileChest = $world->getTile($chest->getPosition());
        if ($tileChest instanceof TileChest) {
            if ($tileChest->isPaired()) {
                $pairTile = $tileChest->getPair();
                if ($pairTile !== null) {
                    $pairPosition = $pairTile->getPosition();
                    $pairBlock = $world->getBlock($pairPosition);
                    if ($pairBlock instanceof Chest) {
                        $pairFacing = $pairBlock->getFacing();
                        $pairSign = $world->getBlock($pairPosition->getSide($pairFacing));
                        if ($pairSign instanceof WallSign) {
                            if ($pairSign->getText()->getLine(0) === ChestLocker::getInstance()->getLockSign()) {
                                return $this->getOwnerFromSign($pairSign);
                            }
                        }
                    }
                }
            }
        }

        // Check current chest
        $facing = $chest->getFacing();
        $sign = $world->getBlock($chest->getPosition()->getSide($facing));
        if ($sign instanceof WallSign) {
            if ($sign->getText()->getLine(0) === ChestLocker::getInstance()->getLockSign()) {
                return $this->getOwnerFromSign($sign);
            }
        }

        return null;
    }

    public function getOwnerFromSign(BaseSign $sign) : string{
        return str_replace("§r§f", "", $sign->getText()->getLine(1));
    }
}