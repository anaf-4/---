<?php

declare(strict_types=1);

namespace anaf2197\ChestLocker;

use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;
use anaf2197\ChestLocker\command\AddShareChestCommand;
use anaf2197\ChestLocker\command\GetDisableLockToolCommand;
use anaf2197\ChestLocker\command\ListShareChestCommand;
use anaf2197\ChestLocker\command\RemoveShareChestCommand;
use anaf2197\lib\color\ServerColor;

class ChestLocker extends PluginBase{

    public static string $prefix;

    use SingletonTrait;

    //수정 시 수정 이전에 보호 설정한 상자들의 보호가 풀리게 됨
    public String $lockSign = "§a( 상자 보호 )";

    public function onLoad() : void{
        self::$instance = $this;
        ServerColor::setPrefix($this, '상자보호');
    }

    public function onEnable() : void{
        ShareManager::init();
        LockManager::init();
        $this->getServer()->getPluginManager()->registerEvents(new EventListener(), $this);
        $this->getServer()->getCommandMap()->registerAll("ChestLocker", [
            new AddShareChestCommand(),
            new RemoveShareChestCommand(),
            new ListShareChestCommand()
        ]);
    }

    /**
     * @return String
     */
    public function getLockSign() : string{
        return $this->lockSign;
    }

    public function onDisable() : void{
        ShareManager::getInstance()->save();
    }
}