<?php

declare(strict_types=1);

namespace anaf2197\ChestLocker\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use anaf2197\ChestLocker\ChestLocker;
use anaf2197\ChestLocker\ShareManager;

class AddShareChestCommand extends Command{
    public function __construct(){
        parent::__construct("상자공유", "잠긴 상자를 다른 사람과 공유합니다.");
        $this->setPermission("add-share-chest");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args){
        if(!$sender instanceof Player){
            return;
        }
        if(empty($args[0])){
            $sender->sendMessage(ChestLocker::$prefix . '/상자공유 [닉네임]');
            return;
        }
        $args[0] = strtolower($args[0]);
        if(strtolower($sender->getName()) === $args[0]){
            $sender->sendMessage(ChestLocker::$prefix . '자기 자신에게 상자를 공유할 수 없습니다.');
            return;
        }
        if(ShareManager::getInstance()->isSharePlayer($sender->getName(), $args[0])){
            $sender->sendMessage(ChestLocker::$prefix . '이미 공유받은 닉네임입니다.');
            return;
        }
        ShareManager::getInstance()->addSharePlayer($sender->getName(), $args[0]);
        $sender->sendMessage(ChestLocker::$prefix . '성공적으로 상자를 공유했습니다.');
    }
}