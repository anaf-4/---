<?php

declare(strict_types=1);

namespace anaf2197\ChestLocker\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use anaf2197\ChestLocker\ChestLocker;
use anaf2197\ChestLocker\ShareManager;

class ListShareChestCommand extends Command{
    public function __construct(){
        parent::__construct("상자공유목록", "상자를 공유받은 닉네임 목록을 확인합니다.");
        $this->setPermission("list-share-chest");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args){
        if(!$sender instanceof Player){
            return;
        }

        $list = ShareManager::getInstance()->getShareList($sender->getName());
        if(count($list) < 1){
            $sender->sendMessage(ChestLocker::$prefix . '상자를 공유받은 플레이어가 없습니다.');
            return;
        }
        $sender->sendMessage(ChestLocker::$prefix . '공유받은 닉네임 목록: ' . implode(', ', $list));
    }
}