<?php

declare(strict_types=1);

namespace anaf2197\ChestLocker\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use anaf2197\ChestLocker\ChestLocker;
use anaf2197\ChestLocker\ShareManager;

class RemoveShareChestCommand extends Command{
    public function __construct(){
        parent::__construct("상자공유해제", "잠긴 상자 공유를 해제합니다.");
        $this->setPermission("remove-share-chest");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args){
        if(!$sender instanceof Player){
            return;
        }
        if(empty($args[0])){
            $sender->sendMessage(ChestLocker::$prefix . '/상자공유해제 [닉네임]');
            return;
        }
        $args[0] = strtolower($args[0]);
        if(strtolower($sender->getName()) === $args[0]){
            $sender->sendMessage(ChestLocker::$prefix . '자기 자신에게 공유를 해제할 수 없습니다.');
            return;
        }
        if(!ShareManager::getInstance()->isSharePlayer($sender->getName(), $args[0])){
            $sender->sendMessage(ChestLocker::$prefix . '공유되지 않은 닉네임입니다.');
            return;
        }
        ShareManager::getInstance()->removeSharePlayer($sender->getName(), $args[0]);
        $sender->sendMessage(ChestLocker::$prefix . '성공적으로 공유를 해제했습니다.');
    }
}