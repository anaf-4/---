<?php

declare(strict_types=1);

namespace anaf2197\ChestLocker;

use pocketmine\block\Chest;
use pocketmine\block\utils\SignText;
use pocketmine\block\WallSign;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockBurnEvent;
use pocketmine\event\block\SignChangeEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\math\Facing;
use anaf2197\islandloader\IslandLoader;

class EventListener implements Listener {
    public function onSignChange(SignChangeEvent $event): void {
        //잠금 식별 문자열 걸러냄
        if ($event->getNewText()->getLine(0) === ChestLocker::getInstance()->getLockSign()) {
            $event->setNewText(new SignText());
            return;
        }
        //표지판 내용 체크
        if ($event->getNewText()->getLine(0) !== "(보호)") {
            return;
        }
        $player = $event->getPlayer();
        $world = $event->getBlock()->getPosition()->getWorld();

        //섬 존재 여부 체크
        $island = IslandLoader::getInstance()->getIslandByWorld($world);
        if (is_null($island)) {
            return;
        }

        //섬 권한체크
        if (!$player->hasPermission("manage-chest-lock") && $island->getOwner() !== strtolower($player->getName()) && !$island->isResident($player->getName())) {
            return;
        }
        $sign = $event->getSign();

        //벽 표지판 체크
        if ($sign instanceof WallSign) {
            //상자가 벽인지 체크
            $chest = $sign->getSide(Facing::opposite($sign->getFacing()));
            if ($chest instanceof Chest) {
                if ($chest->getFacing() !== $sign->getFacing()) {
                    return;
                }
                if (LockManager::getInstance()->isLockedChest($chest)) {
                    $player->sendMessage(ChestLocker::$prefix . '이미 잠겨있는 상자입니다.');
                    return;
                }
                //상자 보호 시작
                $signText = new SignText([
                    ChestLocker::getInstance()->getLockSign(),
                    "§r§f" . $player->getName()
                ], null, true);
                $event->setNewText($signText);
                $player->sendMessage(ChestLocker::$prefix . '상자 보호가 시작됐습니다 (상자 공유법: /상자공유 [닉네임])');
            }
        }
    }

    public function onBreak(BlockBreakEvent $event): void {
        //상자 부수기 방지
        $block = $event->getBlock();
        if ($block instanceof Chest) {
            if (!is_null(($owner = LockManager::getInstance()->getOwnerLockedChest($block)))) {
                if ($event->getPlayer()->getName() !== $owner && !$event->getPlayer()->hasPermission("manage-chest-lock")) {
                    $event->getPlayer()->sendMessage(ChestLocker::$prefix . '잠겨있는 상자입니다.');
                    $event->cancel();
                } else {
                    $event->getPlayer()->sendMessage(ChestLocker::$prefix . '상자 보호를 해제했습니다.');
                }
            }
        } elseif ($block instanceof WallSign) { //표지판 부수기 방지
            $chest = $block->getSide(Facing::opposite($block->getFacing()));
            if ($chest instanceof Chest) {
                if ($block->getText()->getLine(0) === ChestLocker::getInstance()->getLockSign()) {
                    if ($event->getPlayer()->getName() !== LockManager::getInstance()->getOwnerFromSign($block) && !$event->getPlayer()->hasPermission("manage-chest-lock") && $event->getPlayer()->getInventory()->getItemInHand()->getNamedTag()->getInt("isDisableLockTool", 0) !== 1) {
                        $event->getPlayer()->sendMessage(ChestLocker::$prefix . '상자 보호 표지판을 부술 수 없습니다.');
                        $event->cancel();
                    } else {
                        $event->getPlayer()->sendMessage(ChestLocker::$prefix . '상자 보호를 해제했습니다.');
                    }
                }
            }
        }
    }

    public function onInteract(PlayerInteractEvent $event): void {
        $block = $event->getBlock();
        if ($block instanceof Chest) {
            if (!is_null(($owner = LockManager::getInstance()->getOwnerLockedChest($block)))) {
                if ($event->getPlayer()->getName() !== $owner && !$event->getPlayer()->hasPermission("manage-chest-lock") && !ShareManager::getInstance()->isSharePlayer($owner, $event->getPlayer()->getName())) {
                    $event->getPlayer()->sendMessage(ChestLocker::$prefix . '잠겨있는 상자입니다.');
                    $event->cancel();
                }
            }
        }
        if ($block instanceof WallSign) {
            if ($block->getText()->getLine(0) === ChestLocker::getInstance()->getLockSign()) {
                $event->cancel();
            }
        }
    }

    public function onBlockBurn(BlockBurnEvent $event): void {
        //상자 탐 방지
        $block = $event->getBlock();
        if ($block instanceof Chest) {
            if (LockManager::getInstance()->isLockedChest($block)) {
                $event->cancel();
            }
        } elseif ($block instanceof WallSign) { //표지판 탐 방지
            $chest = $block->getSide(Facing::opposite($block->getFacing()));
            if ($chest instanceof Chest) {
                if ($block->getText()->getLine(0) === ChestLocker::getInstance()->getLockSign()) {
                    $event->cancel();
                }
            }
        }
    }
}