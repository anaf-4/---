<?php

namespace anaf2197\check\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\check\CheckLoader;
use anaf2197\economyapi\EconomyAPI;

final class CheckCommand extends Command {

    public function __construct() {
        parent::__construct('수표', '돈을 수표로 변경합니다.');
        $this->setPermission(DefaultPermissions::ROOT_OPERATOR);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if ($sender instanceof Player) {
            if ($this->testPermission($sender)) {
                $amount = array_shift($args);
                if (trim((string)$amount) !== '') {
                    if (is_numeric($amount)) {
                        $amount = abs((int)$amount);
                        if ($amount >= 100) {
                            $economyData = EconomyAPI::getInstance()->getEconomyData($sender);
                            if ($economyData->getMoney() >= $amount) {
                                $economyData->reduceMoney($amount);
                                $sender->getInventory()->addItem(CheckLoader::getInstance()->getCheck($amount));
                                $sender->sendMessage(CheckLoader::$prefix . EconomyAPI::koreanWonFormat($amount) . ' 수표를 발행했습니다.');
                            } else {
                                $sender->sendMessage(CheckLoader::$prefix . '소지금이 부족합니다.');
                            }
                        } else {
                            $sender->sendMessage(CheckLoader::$prefix . '수표 금액은 100원 이상이어야 합니다.');
                        }
                    } else {
                        $sender->sendMessage(CheckLoader::$prefix . '금액은 숫자로 입력해 주세요.');
                    }
                } else {
                    $sender->sendMessage(CheckLoader::$prefix . '/수표 [금액] - 돈을 수표로 변경합니다.');
                }
            }
        }
    }
}