<?php

namespace anaf2197\check\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\Server;
use anaf2197\check\CheckLoader;

final class GiveCheckCommand extends Command {

    public function __construct() {
        parent::__construct('수표지급', '플레이어에게 수표를 지급합니다.', '/수표지급 [플레이어] [금액]', ['givecheck']);
        $this->setPermission(DefaultPermissions::ROOT_OPERATOR);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if (!$this->testPermission($sender)) return;

        $playerName = $args[0] ?? null;
        $amount     = isset($args[1]) ? (int) $args[1] : 0;

        if ($playerName === null || $amount < 100) {
            $sender->sendMessage(CheckLoader::$prefix . '/수표지급 [플레이어] [금액] — 금액은 100원 이상');
            return;
        }

        $player = Server::getInstance()->getPlayerByPrefix($playerName);
        if ($player === null) {
            $sender->sendMessage(CheckLoader::$prefix . '§c온라인 상태인 플레이어를 찾을 수 없습니다: ' . $playerName);
            return;
        }

        $check = CheckLoader::getInstance()->getCheck($amount);
        $player->getInventory()->addItem($check);
        $player->sendMessage(CheckLoader::$prefix . '§a수표 §e' . number_format($amount) . '원§a이 지급되었습니다!');
        $sender->sendMessage(CheckLoader::$prefix . $player->getName() . '님에게 ' . number_format($amount) . '원 수표 지급 완료.');
    }
}
