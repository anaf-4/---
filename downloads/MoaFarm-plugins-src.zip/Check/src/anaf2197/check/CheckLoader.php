<?php

namespace anaf2197\check;

use pocketmine\event\EventPriority;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\item\Item;
use pocketmine\nbt\tag\IntTag;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;
use anaf2197\check\command\CheckCommand;
use anaf2197\check\command\GiveCheckCommand;
use anaf2197\economyapi\EconomyAPI;
use anaf2197\lib\color\ServerColor;
use anaf2197\servercore\item\ItemDesign;
use anaf2197\servercore\item\ItemTypes;
use anaf2197\servercore\item\ServerItems;

final class CheckLoader extends PluginBase {

    public const TAG_CHECK = 'tag.check';

    use SingletonTrait;

    public static string $prefix;

    /** @var array<string, float> */
    private array $useCooldown = [];

    protected function onEnable(): void {
        $this->getServer()->getCommandMap()->register(strtolower($this->getName()), new CheckCommand());
        $this->getServer()->getCommandMap()->register(strtolower($this->getName()), new GiveCheckCommand());
        $this->getServer()->getPluginManager()->registerEvent(PlayerItemUseEvent::class, function (PlayerItemUseEvent $event): void {
            $item = $event->getItem();
            if (!($item->getNamedTag()->getTag(self::TAG_CHECK) instanceof IntTag)) return;
            $player = $event->getPlayer();
            $name = strtolower($player->getName());
            $now = microtime(true);
            if (isset($this->useCooldown[$name]) && $now - $this->useCooldown[$name] < 0.5) return;
            $this->useCooldown[$name] = $now;
            $this->processCheck($player, $item);
        }, EventPriority::MONITOR, $this);
        $this->getServer()->getPluginManager()->registerEvent(PlayerInteractEvent::class, function (PlayerInteractEvent $event): void {
            if ($event->getAction() === PlayerInteractEvent::LEFT_CLICK_BLOCK) return;
            $item = $event->getItem();
            if (!($item->getNamedTag()->getTag(self::TAG_CHECK) instanceof IntTag)) return;
            $player = $event->getPlayer();
            $name = strtolower($player->getName());
            $now = microtime(true);
            if (isset($this->useCooldown[$name]) && $now - $this->useCooldown[$name] < 0.5) return;
            $this->useCooldown[$name] = $now;
            $event->cancel();
            $this->processCheck($player, $item);
        }, EventPriority::HIGHEST, $this, true);
    }

    private function processCheck(\pocketmine\player\Player $player, Item $item): void {
        $tag = $item->getNamedTag()->getTag(self::TAG_CHECK);
        if (!($tag instanceof IntTag)) return;
        $amount = $tag->getValue();
        $count = 1;
        if ($player->isSneaking()) {
            $count = $item->getCount();
            $amount *= $count;
        }
        EconomyAPI::getInstance()->addMoney($player, $amount);
        $player->sendMessage(self::$prefix . '수표를 §l§a' . $count . '§r§8개 사용했습니다.');
        $player->sendMessage(self::$prefix . '획득한 금액: ' . EconomyAPI::koreanWonFormat($amount));
        $player->getInventory()->removeItem($item->setCount($count));
    }

    protected function onLoad(): void {
        self::setInstance($this);
        ServerColor::setPrefix($this, '수표');
    }

    public function getCheck(int $amount): Item {
        $item = match (true) {
            $amount < 50000 => ServerItems::BRONZE(),
            50000 <= $amount and $amount < 300000 => ServerItems::SILVER(),
            300000 <= $amount => ServerItems::GOLD()
        };
        ItemDesign::setItemDesign($item, ItemTypes::WEALTH, '수표', [
            '금액: ' . EconomyAPI::koreanWonFormat($amount)
        ], '터치, 전체 사용: 웅크리기 + 터치');
        $item->getNamedTag()->setInt(self::TAG_CHECK, $amount);
        return $item;
    }
}