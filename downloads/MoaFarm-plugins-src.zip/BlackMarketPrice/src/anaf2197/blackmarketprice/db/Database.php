<?php

declare(strict_types=1);

namespace anaf2197\blackmarketprice\db;

use mysqli;
use RuntimeException;

final class Database {

    private mysqli $db;

    private string $host;
    private int $port;
    private string $user;
    private string $pass;
    private string $dbName;

    public function __construct(string $host, int $port, string $user, string $pass, string $dbName) {
        $this->host   = $host;
        $this->port   = $port;
        $this->user   = $user;
        $this->pass   = $pass;
        $this->dbName = $dbName;
        $this->connect();
        $this->initTables();
    }

    private function connect(): void {
        $this->db = new mysqli($this->host, $this->user, $this->pass, $this->dbName, $this->port);
        if ($this->db->connect_errno) {
            throw new RuntimeException('BlackMarketPrice DB 연결 실패: ' . $this->db->connect_error);
        }
        $this->db->set_charset('utf8mb4');
    }

    private function initTables(): void {
        $this->db->query("
            CREATE TABLE IF NOT EXISTS blackmarket_prices (
                item_key   VARCHAR(512) NOT NULL,
                item_name  VARCHAR(255) NOT NULL DEFAULT '',
                buy_base   INT          NOT NULL DEFAULT -1,
                sell_base  INT          NOT NULL DEFAULT -1,
                buy_now    INT          NOT NULL DEFAULT -1,
                sell_now   INT          NOT NULL DEFAULT -1,
                PRIMARY KEY (item_key)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
    }

    /** DB 데이터 수 반환 */
    public function count(): int {

        $result = $this->db->query("SELECT COUNT(*) as cnt FROM blackmarket_prices");
        if ($result === false) return 0;
        $row = $result->fetch_assoc();
        $result->free();
        return (int)($row['cnt'] ?? 0);
    }

    /** 전체 가격 데이터 로드 */
    public function loadAll(): array {

        $result = $this->db->query("SELECT item_key, item_name, buy_base, sell_base, buy_now, sell_now FROM blackmarket_prices");
        if ($result === false) return [];

        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[$row['item_key']] = [
                'itemName' => $row['item_name'],
                'buyBase'  => (int) $row['buy_base'],
                'sellBase' => (int) $row['sell_base'],
                'buyNow'   => (int) $row['buy_now'],
                'sellNow'  => (int) $row['sell_now'],
            ];
        }
        $result->free();
        return $data;
    }

    /** 아이템 하나 UPSERT */
    public function upsert(string $itemKey, string $itemName, int $buyBase, int $sellBase, int $buyNow, int $sellNow): void {

        $stmt = $this->db->prepare("
            INSERT INTO blackmarket_prices (item_key, item_name, buy_base, sell_base, buy_now, sell_now)
            VALUES (?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                item_name = VALUES(item_name),
                buy_base  = VALUES(buy_base),
                sell_base = VALUES(sell_base),
                buy_now   = VALUES(buy_now),
                sell_now  = VALUES(sell_now)
        ");
        if ($stmt === false) throw new RuntimeException($this->db->error);
        $stmt->bind_param('ssiiii', $itemKey, $itemName, $buyBase, $sellBase, $buyNow, $sellNow);
        $stmt->execute();
        $stmt->close();
    }

    /** 아이템 현재가만 업데이트 */
    public function updateNowPrice(string $itemKey, int $buyNow, int $sellNow): void {

        $stmt = $this->db->prepare("UPDATE blackmarket_prices SET buy_now=?, sell_now=? WHERE item_key=?");
        if ($stmt === false) throw new RuntimeException($this->db->error);
        $stmt->bind_param('iis', $buyNow, $sellNow, $itemKey);
        $stmt->execute();
        $stmt->close();
    }

    /** 아이템 삭제 */
    public function delete(string $itemKey): void {

        $stmt = $this->db->prepare("DELETE FROM blackmarket_prices WHERE item_key=?");
        if ($stmt === false) throw new RuntimeException($this->db->error);
        $stmt->bind_param('s', $itemKey);
        $stmt->execute();
        $stmt->close();
    }

    /** 전체 현재가 일괄 업데이트 — INSERT … ON DUPLICATE KEY UPDATE 단일 쿼리로 처리 */
    public function bulkUpdateNowPrices(array $updates): void {
        if (empty($updates)) return;

        // VALUES (?, ?, ?) 플레이스홀더 생성
        $placeholders = implode(', ', array_fill(0, count($updates), '(?, ?, ?)'));
        $sql = "INSERT INTO blackmarket_prices (item_key, buy_now, sell_now)
                VALUES {$placeholders}
                ON DUPLICATE KEY UPDATE buy_now = VALUES(buy_now), sell_now = VALUES(sell_now)";

        $stmt = $this->db->prepare($sql);
        if ($stmt === false) throw new RuntimeException($this->db->error);

        $types = str_repeat('sii', count($updates));
        $params = [];
        foreach ($updates as $itemKey => [$buyNow, $sellNow]) {
            $params[] = $itemKey;
            $params[] = $buyNow;
            $params[] = $sellNow;
        }
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $stmt->close();
    }

    public function close(): void {
        $this->db->close();
    }
}
