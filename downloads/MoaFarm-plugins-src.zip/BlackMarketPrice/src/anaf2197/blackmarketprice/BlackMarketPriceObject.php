<?php

declare(strict_types=1);

namespace anaf2197\blackmarketprice;

use pocketmine\item\Item;
use pocketmine\world\format\io\GlobalItemDataHandlers;
use anaf2197\blackmarketprice\db\Database;

/**
 * 암상인 가격 데이터 (메모리 캐시 + DB write-through)
 *
 * item_key: GlobalItemDataHandlers::getSerializer()->serializeType() 기반 정규화 키
 * → 같은 종류의 아이템은 NBT(이름/로어/인챈트) 무관하게 동일 키로 인식
 */
final class BlackMarketPriceObject {

    public function __construct(private array $items = [], private ?Database $db = null) {}

    private function itemKey(Item $item): string {
        try {
            $data = GlobalItemDataHandlers::getSerializer()->serializeType($item);
            $key = $data->getName();
            if ($data->getMeta() !== 0) {
                $key .= ':' . $data->getMeta();
            }
            return $key;
        } catch (\Throwable) {
            $cloned = clone $item;
            $cloned->setCount(1);
            return 'raw:' . $item->getTypeId() . ':' . $item->getMeta();
        }
    }

    // ── 기준가 ───────────────────────────────────────────────

    public function setBasePrice(Item $item, int $buyBase, int $sellBase): void {
        $key = $this->itemKey($item);
        $existing = $this->items[$key] ?? [];
        $this->items[$key] = [
            'itemName' => $item->getName(),
            'buyBase'  => $buyBase,
            'sellBase' => $sellBase,
            'buyNow'   => $existing['buyNow']  ?? $buyBase,
            'sellNow'  => $existing['sellNow'] ?? $sellBase,
        ];
        $this->db?->upsert($key, $item->getName(), $buyBase, $sellBase,
            $this->items[$key]['buyNow'], $this->items[$key]['sellNow']);
    }

    public function getBuyBase(Item $item): int {
        return $this->items[$this->itemKey($item)]['buyBase'] ?? -1;
    }

    public function getSellBase(Item $item): int {
        return $this->items[$this->itemKey($item)]['sellBase'] ?? -1;
    }

    // ── 현재가 ───────────────────────────────────────────────

    public function setNowPrice(Item $item, int $buyNow, int $sellNow): void {
        $key = $this->itemKey($item);
        if (!isset($this->items[$key])) return;
        $this->items[$key]['buyNow']  = $buyNow;
        $this->items[$key]['sellNow'] = $sellNow;
        $this->db?->updateNowPrice($key, $buyNow, $sellNow);
    }

    public function getBuyNow(Item $item): int {
        return $this->items[$this->itemKey($item)]['buyNow'] ?? -1;
    }

    public function getSellNow(Item $item): int {
        return $this->items[$this->itemKey($item)]['sellNow'] ?? -1;
    }

    // ── 현재가 일괄 갱신 ────────────────────────────────────

    public function refreshNowPrices(callable $fn): void {
        $updates = [];
        foreach ($this->items as $key => &$data) {
            $data['buyNow']  = $fn($data['buyBase']  ?? -1);
            $data['sellNow'] = $fn($data['sellBase'] ?? -1);
            $updates[$key] = [$data['buyNow'], $data['sellNow']];
        }
        unset($data);
        $this->db?->bulkUpdateNowPrices($updates);
    }

    // ── 존재 여부 ────────────────────────────────────────────

    public function hasItem(Item $item): bool {
        return isset($this->items[$this->itemKey($item)]);
    }

    public function removeItem(Item $item): void {
        $key = $this->itemKey($item);
        unset($this->items[$key]);
        $this->db?->delete($key);
    }

    // ── 전체 조회 ────────────────────────────────────────────

    public function getAll(): array {
        return $this->items;
    }

    public function count(): int {
        return count($this->items);
    }

    // ── DB에서 로드한 데이터로 복원 ─────────────────────────

    public static function fromDB(array $data, Database $db): self {
        return new self($data, $db);
    }
}
