<?php

declare(strict_types=1);

namespace anaf2197\blackmarketprice;

use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;
use anaf2197\blackmarketprice\command\BlackMarketBasePriceCommand;
use anaf2197\blackmarketprice\command\BlackMarketPriceDeleteCommand;
use anaf2197\blackmarketprice\command\BlackMarketPriceListCommand;
use anaf2197\blackmarketprice\db\Database;
use anaf2197\lib\color\ServerColor;

final class BlackMarketPrice extends PluginBase {

    use SingletonTrait {
        getInstance as _getInstance;
    }

    public static string $prefix = '§l§5[암시세] §r§8';

    private BlackMarketPriceObject $priceObject;
    private Database $database;

    protected function onLoad(): void {
        self::setInstance($this);
        ServerColor::setPrefix($this, '암시세');
    }

    protected function onEnable(): void {
        $this->saveDefaultConfig();
        $cfg = $this->getConfig()->get('database');

        try {
            $this->database = new Database(
                $cfg['host'],
                (int) $cfg['port'],
                $cfg['username'],
                $cfg['password'],
                $cfg['database']
            );
        } catch (\Throwable $e) {
            $this->getLogger()->error('DB 연결 실패 - 플러그인을 비활성화합니다: ' . $e->getMessage());
            $this->getServer()->getPluginManager()->disablePlugin($this);
            return;
        }

        $this->migrateFromJson();
        $this->priceObject = BlackMarketPriceObject::fromDB($this->database->loadAll(), $this->database);
        $this->getLogger()->info("=== 암상인 가격 데이터 로드 완료 (DB): {$this->priceObject->count()}개 ===");

        $this->getServer()->getCommandMap()->registerAll(strtolower($this->getName()), [
            new BlackMarketBasePriceCommand(),
            new BlackMarketPriceDeleteCommand(),
            new BlackMarketPriceListCommand(),
        ]);
    }

    private function migrateFromJson(): void {
        $file = $this->getDataFolder() . 'blackmarket_prices.json';
        if (!file_exists($file)) return;
        // 기존 JSON의 아이템 키 형식(__toString)과 새 키 형식(serializeType 네임스페이스)이 달라
        // 마이그레이션된 데이터는 조회 불가 → 백업만 하고 스킵
        $backup = $file . '.legacy_' . date('Ymd_His');
        rename($file, $backup);
        $this->getLogger()->warning("기존 blackmarket_prices.json은 키 형식이 달라 자동 마이그레이션 불가.");
        $this->getLogger()->warning("백업 파일: " . basename($backup));
        $this->getLogger()->warning("암상인 가격은 /암상인기준가 명령어로 다시 설정해주세요.");
    }

    protected function onDisable(): void {
        $this->database?->close();
        $this->getLogger()->info("=== DB 연결 종료 ===");
    }

    public static function getInstance(): self {
        return self::_getInstance();
    }

    public function getPriceObject(): BlackMarketPriceObject {
        return $this->priceObject;
    }
}
