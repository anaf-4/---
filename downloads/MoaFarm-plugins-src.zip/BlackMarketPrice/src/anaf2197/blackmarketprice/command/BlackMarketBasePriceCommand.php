<?php

namespace anaf2197\blackmarketprice\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\blackmarketprice\BlackMarketPrice;

/**
 * /암상인기준가 [구매가] [판매가]
 * 손에 든 아이템의 기준가를 설정합니다.
 * -1 입력 시 해당 거래 비활성화
 */
final class BlackMarketBasePriceCommand extends Command {

    public function __construct() {
        parent::__construct('암상인기준가', '손에 든 아이템의 암상인 기준가를 설정합니다.', null, ['blackmarketprice', '암시기준가']);
        $this->setPermission(DefaultPermissions::ROOT_OPERATOR);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if (!$sender instanceof Player) return;
        if (!$this->testPermission($sender)) return;

        $buyBase  = array_shift($args);
        $sellBase = array_shift($args);

        if (!is_numeric($buyBase) || !is_numeric($sellBase)) {
            $sender->sendMessage(BlackMarketPrice::$prefix . '/암상인기준가 [구매가] [판매가] - 손에 든 아이템의 기준가를 설정합니다. (-1 = 비활성)');
            return;
        }

        $item = $sender->getInventory()->getItemInHand();
        if ($item->isNull()) {
            $sender->sendMessage(BlackMarketPrice::$prefix . '공기의 가격은 설정할 수 없습니다.');
            return;
        }

        $buyBase  = (int)$buyBase;
        $sellBase = (int)$sellBase;

        BlackMarketPrice::getInstance()->getPriceObject()->setBasePrice($item, $buyBase, $sellBase);

        $buyStr  = $buyBase  > -1 ? $buyBase . '원'  : '§c비활성';
        $sellStr = $sellBase > -1 ? $sellBase . '원' : '§c비활성';
        $sender->sendMessage(BlackMarketPrice::$prefix . $item->getName() . '§r§8 기준가 설정 완료');
        $sender->sendMessage(BlackMarketPrice::$prefix . '구매: §f' . $buyStr . ' §8| 판매: §f' . $sellStr);
    }
}