<?php

namespace anaf2197\blackmarketprice\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use anaf2197\blackmarketprice\BlackMarketPrice;

/**
 * /암상인가격제거
 * 손에 든 아이템의 가격 데이터를 삭제합니다.
 */
final class BlackMarketPriceDeleteCommand extends Command {

    public function __construct() {
        parent::__construct('암상인가격제거', '손에 든 아이템의 암상인 가격 데이터를 삭제합니다.', null, ['blackmarketpricedelete', '암시가격제거']);
        $this->setPermission(DefaultPermissions::ROOT_OPERATOR);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if (!$sender instanceof Player) return;
        if (!$this->testPermission($sender)) return;

        $item = $sender->getInventory()->getItemInHand();
        if ($item->isNull()) {
            $sender->sendMessage(BlackMarketPrice::$prefix . '공기는 삭제할 데이터가 없습니다.');
            return;
        }

        $priceObject = BlackMarketPrice::getInstance()->getPriceObject();
        if (!$priceObject->hasItem($item)) {
            $sender->sendMessage(BlackMarketPrice::$prefix . $item->getName() . '§r§8 의 가격 데이터가 없습니다.');
            return;
        }

        $priceObject->removeItem($item);
        BlackMarketPrice::getInstance()->savePrices();
        $sender->sendMessage(BlackMarketPrice::$prefix . $item->getName() . '§r§8 의 가격 데이터를 삭제했습니다.');
    }
}