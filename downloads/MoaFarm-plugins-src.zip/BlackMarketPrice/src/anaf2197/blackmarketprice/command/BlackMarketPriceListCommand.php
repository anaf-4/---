<?php

namespace anaf2197\blackmarketprice\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use anaf2197\blackmarketprice\BlackMarketPrice;

/**
 * /암상인가격목록
 * 등록된 모든 아이템의 기준가/현재가를 출력합니다.
 */
final class BlackMarketPriceListCommand extends Command {

    public function __construct() {
        parent::__construct('암상인가격목록', '암상인에 등록된 아이템 가격 목록을 확인합니다.', null, ['blackmarketpricelist', '암시가격목록']);
        $this->setPermission(DefaultPermissions::ROOT_OPERATOR);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if (!$this->testPermission($sender)) return;

        $priceObject = BlackMarketPrice::getInstance()->getPriceObject();
        $all         = $priceObject->getAll();

        if (empty($all)) {
            $sender->sendMessage(BlackMarketPrice::$prefix . '등록된 아이템이 없습니다.');
            return;
        }

        $sender->sendMessage(BlackMarketPrice::$prefix . '등록된 아이템: §d' . count($all) . '§8개');
        $sender->sendMessage('§8' . str_repeat('─', 40));

        foreach ($all as $key => $data) {
            $name     = $data['itemName']  ?? '???';
            $id       = $data['itemId']    ?? '???';
            $buyBase  = $data['buyBase']   ?? -1;
            $sellBase = $data['sellBase']  ?? -1;
            $buyNow   = $data['buyNow']    ?? -1;
            $sellNow  = $data['sellNow']   ?? -1;

            $buyBaseStr  = $buyBase  > -1 ? $buyBase . '원'  : '§c비활성§8';
            $sellBaseStr = $sellBase > -1 ? $sellBase . '원' : '§c비활성§8';
            $buyNowStr   = $buyNow   > -1 ? '§f' . $buyNow . '원§8'  : '§c비활성§8';
            $sellNowStr  = $sellNow  > -1 ? '§f' . $sellNow . '원§8' : '§c비활성§8';

            $sender->sendMessage("§5{$name} §8({$id})");
            $sender->sendMessage("  §8기준가 - 구매: §f{$buyBaseStr} §8/ 판매: §f{$sellBaseStr}");
            $sender->sendMessage("  §8현재가 - 구매: {$buyNowStr} / 판매: {$sellNowStr}");
        }

        $sender->sendMessage('§8' . str_repeat('─', 40));
    }
}