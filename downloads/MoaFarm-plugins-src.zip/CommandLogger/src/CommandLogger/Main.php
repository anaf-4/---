<?php

namespace CommandLogger;

use pocketmine\event\Listener;
use pocketmine\event\server\CommandEvent;
use pocketmine\plugin\PluginBase;
use pocketmine\command\PluginCommand;

class Main extends PluginBase implements Listener {

    public function onEnable(): void {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getLogger()->info("CommandLogger 활성화!");
    }

    /**
     * @priority MONITOR
     * @ignoreCancelled true
     */
    public function onCommandExecute(CommandEvent $event): void {
        $commandLine = $event->getCommand();
        $sender = $event->getSender();
        
        // 명령어 파싱 (첫 단어만 추출)
        $args = explode(" ", $commandLine);
        $commandName = array_shift($args);
        
        // 명령어 객체 가져오기
        $command = $this->getServer()->getCommandMap()->getCommand($commandName);
        
        if ($command !== null) {
            $pluginInfo = "§c알 수 없음";
            $fileLocation = "§c알 수 없음";
            
            if ($command instanceof PluginCommand) {
                $plugin = $command->getOwningPlugin();
                $pluginInfo = "§b" . $plugin->getName();
                
                // 플러그인 파일 위치
                $reflection = new \ReflectionClass($plugin);
                $fileLocation = "§e" . $reflection->getFileName();
            } else {
                // 내장 명령어
                $reflection = new \ReflectionClass($command);
                $fileLocation = "§e" . $reflection->getFileName();
                $pluginInfo = "§6PocketMine (내장)";
            }
            
            // 로그 출력
            $this->getLogger()->info("§a━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
            $this->getLogger()->info("§e[명령어 실행]");
            $this->getLogger()->info("§f플레이어: §b" . $sender->getName());
            $this->getLogger()->info("§f명령어: §a/" . $commandLine);
            $this->getLogger()->info("§f소유 플러그인: " . $pluginInfo);
            $this->getLogger()->info("§f파일 위치: " . $fileLocation);
            $this->getLogger()->info("§a━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        } else {
            $this->getLogger()->info("§e[명령어] §f" . $sender->getName() . " §8: §c/" . $commandLine . " §8(명령어 없음)");
        }
    }
}