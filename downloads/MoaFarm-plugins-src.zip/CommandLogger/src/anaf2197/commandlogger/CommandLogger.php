<?php
declare(strict_types=1);

namespace anaf2197\commandlogger;

use pocketmine\command\PluginCommand;
use pocketmine\event\Listener;
use pocketmine\event\server\CommandEvent;
use pocketmine\plugin\PluginBase;
use pocketmine\player\Player;

/**
 * CommandLogger v2.1
 */
final class CommandLogger extends PluginBase implements Listener {

    private array $reflectionCache = [];
    private bool $enabled = true;

    protected function onEnable(): void {
        $this->saveDefaultConfig();
        $this->enabled = $this->getConfig()->get('enabled', true);

        $this->getServer()->getPluginManager()->registerEvents($this, $this);

        $cmd = new class('cmdlog', '명령어 로거 토글') extends \pocketmine\command\Command {
            public function execute(\pocketmine\command\CommandSender $sender, string $label, array $args): void {
                if (!$sender->hasPermission('commandlogger.admin')) return;
                /** @var CommandLogger $plugin */
                $plugin = \pocketmine\Server::getInstance()
                    ->getPluginManager()->getPlugin('CommandLogger');
                if ($plugin === null) return;
                $plugin->toggle();
                $sender->sendMessage('§e[CommandLogger] ' . ($plugin->isEnabled2() ? '§a활성화' : '§c비활성화'));
            }
        };
        $cmd->setPermission('commandlogger.admin');
        $this->getServer()->getCommandMap()->register('commandlogger', $cmd);

        $this->getLogger()->info('CommandLogger 활성화!');
    }

    public function toggle(): void {
        $this->enabled = !$this->enabled;
    }

    public function isEnabled2(): bool {
        return $this->enabled;
    }

    /**
     * @priority MONITOR
     * @ignoreCancelled true
     */
    public function onCommandExecute(CommandEvent $event): void {
        if (!$this->enabled) return;

        $sender      = $event->getSender();
        $commandLine = $event->getCommand();

        if ($this->getConfig()->get('skip-dispatch', true) && !($sender instanceof Player)) {
            return;
        }

        $args        = explode(' ', $commandLine);
        $commandName = array_shift($args);
        $command     = $this->getServer()->getCommandMap()->getCommand($commandName);

        if ($command === null) {
            $this->getLogger()->info(
                "§e[명령어] §f{$sender->getName()} §8: §c/{$commandLine} §8(없는 명령어)"
            );
            return;
        }

        $pluginInfo   = '§6PocketMine (내장)';
        $fileLocation = '§c알 수 없음';

        if ($command instanceof PluginCommand) {
            $plugin     = $command->getOwningPlugin();
            $pluginInfo = '§b' . $plugin->getName();

            $className = get_class($plugin);
            if (!isset($this->reflectionCache[$className])) {
                $this->reflectionCache[$className] = (new \ReflectionClass($plugin))->getFileName();
            }
            $fileLocation = '§e' . $this->reflectionCache[$className];
        }

        $this->getLogger()->info("§a━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        $this->getLogger()->info("§e[명령어 실행]");
        $this->getLogger()->info("§f플레이어: §b{$sender->getName()}");
        $this->getLogger()->info("§f명령어: §a/{$commandLine}");
        $this->getLogger()->info("§f소유 플러그인: {$pluginInfo}");
        $this->getLogger()->info("§f파일 위치: {$fileLocation}");
        $this->getLogger()->info("§a━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    }
}