'use strict';
/* ---------- online rooms (db) ---------- */
const Net={ready:false,db:null,uid:null,code:'',ref:null,chatRef:null,unsub:null,chatUnsub:null,poll:0,beat:0,room:null,chat:{c1:[],c2:[]},lastChat:0,chatInit:false,pending:false,pushQueued:false,chain:Promise.resolve(),myReq:0,me:null,oppId:'',oppRt:1000,retry:0};
const wq=fn=>{Net.chain=Net.chain.then(fn).catch(e=>{toast(netMessage(e));});return Net.chain;};
async function netInit(){
  try{
    if(window.claude&&claude.use){
      const [db,user]=await Promise.all([claude.use('db'),claude.use('user')]);
      const uid=user?await user.id():null;
      if(db&&uid){Net.db=db;Net.uid=uid;Net.ready=true;}
    }
  }catch(e){}
  updateOnlineUI();
  if(Net.ready){await loadMe();checkResume();}
}
function updateOnlineUI(){
  for(const id of ['createRoom','joinRoom','roomCodeIn','quickBtn','roomsBtn','pubRoom']) $('#'+id).disabled=!Net.ready;
  if(!Net.ready){$('#onlineMsg').textContent='온라인 대전은 Claude에서 로그인한 상태로 이 페이지를 열어야 사용할 수 있습니다.';$('#onlineMsg').dataset.k='nologin';}
  else if($('#onlineMsg').dataset.k==='nologin'){$('#onlineMsg').textContent='';$('#onlineMsg').dataset.k='';}
}
function netMessage(e){
  const c=e&&e.code;
  if(c==='invalid_argument') return '이 페이지에 기록할 권한이 없습니다. 페이지 주인에게 기여자(Contributor) 이상으로 초대해 달라고 하세요.';
  if(c==='quota_exceeded') return '저장 공간이 가득 찼습니다. 페이지 주인에게 문의해 주세요.';
  if(c==='resource_exhausted') return '요청이 너무 많습니다. 잠시 후 다시 시도해 주세요.';
  if(c==='revoked') return '이 페이지에 대한 접근 권한이 사라졌습니다.';
  return '연결에 문제가 생겼습니다. 잠시 후 다시 시도해 주세요.';
}
const CODE_CHARS='ABCDEFGHJKMNPQRSTUVWXYZ23456789';
const genCode=()=>{let s='';for(let i=0;i<6;i++) s+=CODE_CHARS[Math.floor(Math.random()*CODE_CHARS.length)];return s;};

/* ratings (Elo, stored per player in players/<id>) */
async function loadMe(){
  try{
    const s=await Net.db.doc('players/'+Net.uid).get();
    if(s.exists){const d=s.data();Net.me={rating:+d.rating||1000,w:+d.w||0,l:+d.l||0,d:+d.d||0};}
    else Net.me={rating:(getProfile()?getProfile().rating:START_RATING),w:0,l:0,d:0};
  }catch(e){Net.me={rating:(getProfile()?getProfile().rating:START_RATING),w:0,l:0,d:0};}
  syncProfileRating();
}
async function saveMe(){
  if(!Net.ready||!Net.me) return;
  syncProfileRating();
  try{await Net.db.doc('players/'+Net.uid).set({id:Net.uid,name:getNick('플레이어'),rating:Net.me.rating,w:Net.me.w,l:Net.me.l,d:Net.me.d,t:Date.now()});}catch(e){}
}
function rateGame(L){
  if(mode!=='online'||role===0||L.rated||!Net.me||L.moves.length<6) return;
  L.rated=true;
  const sc=L.result.winner===0?.5:L.result.winner===role?1:0;
  const exp=1/(1+Math.pow(10,((Net.oppRt||1000)-Net.me.rating)/400));
  const dl=Math.round(32*(sc-exp));
  Net.me.rating=Math.max(100,Net.me.rating+dl);
  if(sc===1) Net.me.w++;else if(sc===0) Net.me.l++;else Net.me.d++;
  L.rd=dl;
  saveMe();
}
async function refreshOpp(force){
  const d=Net.room;if(!d||role===0||!Net.ready) return;
  const opp=role===1?d.guest:d.host;
  if(!opp||!opp.id||(!force&&Net.oppId===opp.id)) return;
  Net.oppId=opp.id;
  try{const s=await Net.db.doc('players/'+opp.id).get();Net.oppRt=s.exists?(+s.data().rating||1000):1000;}catch(e){Net.oppRt=1000;}
}

/* creating and joining */
async function makeRoom(pub){
  const name=getNick('플레이어');
  for(let t=0;t<6;t++){
    const code=genCode(),ref=Net.db.doc('rooms/'+code);
    const s=await ref.get();
    if(s.exists) continue;
    const now=Date.now();
    await ref.set({code,host:{id:Net.uid,name,rt:Net.me?Net.me.rating:1000},guest:null,moves:[],gen:0,rev:0,resigned:0,timeout:0,drawn:0,req:null,ans:null,open:!!pub,limit:SET.limit||0,created:now,beat:now});
    try{await Net.db.doc('chats/'+code).set({c1:[],c2:[]});}catch(e){}
    await enterRoom(code);return true;
  }
  return false;
}
async function createRoom(){
  const msg=$('#onlineMsg');msg.textContent='';
  if(!Net.ready) return;
  $('#createRoom').disabled=true;
  try{if(!(await makeRoom($('#pubRoom').checked))) msg.textContent='방 코드를 만들지 못했습니다. 다시 시도해 주세요.';}
  catch(e){msg.textContent=netMessage(e);}
  finally{$('#createRoom').disabled=!Net.ready;}
}
/* returns 'ok' | 'none' | 'full' */
async function tryJoin(code,needPlayer){
  const ref=Net.db.doc('rooms/'+code),s=await ref.get();
  if(!s.exists) return 'none';
  const d=s.data(),isHost=d.host.id===Net.uid,isGuest=!!(d.guest&&d.guest.id===Net.uid);
  if(!isHost&&!isGuest&&!d.guest){
    await ref.update({guest:{id:Net.uid,name:getNick('플레이어'),rt:Net.me?Net.me.rating:1000}});
    if(needPlayer){
      const d2=(await ref.get()).data();
      if(!d2||!d2.guest||d2.guest.id!==Net.uid) return 'full';
    }
  }else if(needPlayer&&!isHost&&!isGuest) return 'full';
  await enterRoom(code);return 'ok';
}
async function joinRoom(){
  const msg=$('#onlineMsg');msg.textContent='';
  if(!Net.ready) return;
  const code=$('#roomCodeIn').value.toUpperCase().replace(/[^A-Z0-9]/g,'');
  if(code.length!==6){msg.textContent='방 코드는 6자리입니다.';return;}
  $('#joinRoom').disabled=true;
  try{if(await tryJoin(code,false)==='none') msg.textContent='방을 찾을 수 없습니다. 코드를 확인해 주세요.';}
  catch(e){msg.textContent=netMessage(e);}
  finally{$('#joinRoom').disabled=!Net.ready;}
}
async function fetchOpenRooms(){
  const q=await Net.db.collection('rooms').where('open','==',true).limit(60).get();
  const now=Date.now(),out=[];
  for(const x of q.docs){
    const d=x.data();
    if(!d||!d.host||d.guest) continue;
    const age=now-(d.beat||d.created||0);
    if(d.host.id===Net.uid){ if(age>90000){Net.db.doc('rooms/'+d.code).delete().catch(()=>{});} continue; }
    if(age<75000) out.push(d);
  }
  return out.sort((a,b)=>(b.beat||b.created)-(a.beat||a.created));
}
async function quickMatch(){
  const msg=$('#onlineMsg');msg.textContent='';
  if(!Net.ready) return;
  $('#quickBtn').disabled=true;
  try{
    msg.textContent='상대를 찾는 중…';msg.dataset.k='finding';
    for(const d of await fetchOpenRooms()){ if(await tryJoin(d.code,true)==='ok') return; }
    if(!(await makeRoom(true))) msg.textContent='방을 만들지 못했습니다. 다시 시도해 주세요.';
  }catch(e){msg.textContent=netMessage(e);}
  finally{$('#quickBtn').disabled=!Net.ready;if(msg.dataset.k==='finding'){msg.textContent='';msg.dataset.k='';}}
}
async function loadRooms(){
  const ul=$('#roomsList'),msg=$('#roomsMsg');
  msg.textContent='';ul.textContent='';
  if(!Net.ready){msg.textContent='온라인 대전은 Claude에서 로그인한 상태로 이 페이지를 열어야 사용할 수 있습니다.';return;}
  try{
    const list=await fetchOpenRooms();
    if(!list.length){const li=document.createElement('li');li.className='note';li.textContent='지금 열려 있는 공개방이 없습니다. 방을 만들거나 빠른 매칭을 눌러 보세요.';ul.appendChild(li);return;}
    for(const d of list){
      const li=document.createElement('li'),b=document.createElement('button');b.type='button';b.className='gitem';
      const t=document.createElement('b');t.textContent=(d.host.name||'플레이어')+'님의 방';
      const sm=document.createElement('small');sm.textContent='레이팅 '+(d.host.rt||1000)+' · 제한 시간 '+(d.limit?d.limit+'초':'없음');
      b.append(t,sm);
      b.addEventListener('click',async()=>{
        try{const r=await tryJoin(d.code,true);if(r!=='ok'){msg.textContent=r==='full'?'방이 이미 가득 찼습니다.':'방을 찾을 수 없습니다.';loadRooms();}}
        catch(e){msg.textContent=netMessage(e);}
      });
      li.appendChild(b);ul.appendChild(li);
    }
  }catch(e){msg.textContent=netMessage(e);}
}

/* resume after a reload or a dropped connection */
async function checkResume(){
  const ses=store.get('dama.session',null),btn=$('#resumeBtn');
  btn.hidden=true;
  if(!ses||!ses.code||!Net.ready) return;
  try{
    const s=await Net.db.doc('rooms/'+ses.code).get();
    if(!s.exists){store.set('dama.session',null);return;}
    const d=s.data(),host=d.host.id===Net.uid;
    if(!host&&!(d.guest&&d.guest.id===Net.uid)){store.set('dama.session',null);return;}
    $('#resumeSmall').textContent='방 '+ses.code+' · 상대: '+(host?(d.guest?d.guest.name:'아직 없음'):d.host.name);
    btn.hidden=false;
  }catch(e){}
}
async function resumeRoom(){
  const ses=store.get('dama.session',null);
  if(!ses||!ses.code||!Net.ready) return;
  try{await enterRoom(ses.code);}catch(e){toast('방에 다시 들어가지 못했습니다.');store.set('dama.session',null);checkResume();}
}

function subscribeRoom(code){
  if(Net.unsub){try{Net.unsub();}catch(e){}Net.unsub=null;}
  if(!Net.ref) return;
  Net.unsub=Net.ref.onSnapshot(snap=>{Net.retry=0;onRoom(snap);},e=>{
    toast(netMessage(e));
    if(Net.retry++<5) setTimeout(()=>{if(mode==='online'&&Net.ref&&Net.code===code) subscribeRoom(code);},3000);
  });
}
async function enterRoom(code){
  const ref=Net.db.doc('rooms/'+code),s=await ref.get();
  if(!s.exists) throw {code:'unavailable'};
  const d=s.data();
  leaveRoom();
  clearTimeout(aiTimer);clearTimeout(resTimer);
  mode='online';
  role=d.host.id===Net.uid?1:(d.guest&&d.guest.id===Net.uid)?2:0;
  flip=role===2;
  Net.code=code;Net.ref=ref;Net.chatRef=Net.db.doc('chats/'+code);Net.room=null;Net.pending=false;Net.pushQueued=false;
  Net.myReq=0;Net.oppId='';Net.oppRt=1000;Net.retry=0;Net.chat={c1:[],c2:[]};Net.chatInit=false;
  aiBusy=false;animBusy=false;sel=-1;REPLAY=null;hist=[];hideOverlays();
  LIVE=G=freshState({1:'플레이어 1',2:'대기 중'});
  LIVE.gen=d.gen||0;LIVE.rev=d.rev||0;LIVE.limit=d.limit||0;LIVE.waiting=!d.guest;
  show('game');chromeUI();
  $('#roomCode').textContent=code;$('#waitCode').textContent=code;
  renderChat();
  if(role) store.set('dama.session',{code,t:Date.now()});
  subscribeRoom(code);
  Net.chatUnsub=Net.chatRef.onSnapshot(sn=>{if(sn.exists) onChat(sn.data());},()=>{});
  Net.poll=setInterval(async()=>{
    if(!Net.ref||document.hidden||animBusy) return;
    const L=LIVE;
    if(L&&!L.waiting&&!L.result&&isHuman(L.turn)) return;
    try{onRoom(await Net.ref.get());}catch(e){}
  },5000);
  Net.beat=setInterval(()=>{
    const r=Net.room;
    if(Net.ref&&role===1&&r&&r.open&&!r.guest&&!document.hidden) wq(()=>Net.ref?Net.ref.update({beat:Date.now()}):0);
  },25000);
  onRoom(s);
}
function leaveRoom(){
  clearInterval(Net.poll);Net.poll=0;clearInterval(Net.beat);Net.beat=0;
  if(Net.unsub){try{Net.unsub();}catch(e){}Net.unsub=null;}
  if(Net.chatUnsub){try{Net.chatUnsub();}catch(e){}Net.chatUnsub=null;}
  const ref=Net.ref,r=Net.room,cref=Net.chatRef;
  Net.ref=null;Net.room=null;Net.chatRef=null;Net.pending=false;
  if(ref&&role===1&&r&&!r.guest){
    ref.delete().catch(()=>{});
    if(cref) cref.delete().catch(()=>{});
    store.set('dama.session',null);
  }
}
function onRoom(snap){
  if(mode!=='online'||!LIVE) return;
  if(!snap.exists){toast('방이 닫혔습니다.');store.set('dama.session',null);toMenu();return;}
  Net.room=snap.data();syncRoom();
}
function rebuildFrom(L,recs){
  const b=newBoard(),ids=freshIds(b);let noprog=0,result=null,turn=1;const fr=newFr();
  const ok=[];
  for(const r of recs){
    if(result||r.p!==turn) break;
    applyRecBoth(b,ids,r);ok.push(r);
    noprog=stepProgress(r,fr)?0:noprog+1;result=judge(b,r.p,noprog);turn=3-turn;
  }
  L.b=b;L.ids=ids;L.moves=ok;L.noprog=noprog;L.fr=fr;L.result=result;L.turn=turn;L.chain=-1;L.path=null;L.capList=[];sel=-1;
}
function syncRoom(){
  const d=Net.room,L=LIVE;
  if(!d||!L||mode!=='online'||animBusy) return;
  L.names={1:d.host.name||'플레이어 1',2:d.guest?(d.guest.name||'플레이어 2'):'대기 중'};
  L.waiting=!d.guest;L.limit=d.limit||0;
  if((d.gen||0)===L.gen&&(d.rev||0)<L.rev) return;
  if((d.gen||0)!==L.gen){
    L.gen=d.gen||0;L.rev=d.rev||0;L.saved=false;L.pendingResult=false;L.rated=false;L.reward=0;L.rd=null;L.tOut=false;
    rebuildFrom(L,[]);hideOverlays();refreshOpp(true);
  }
  const rm=(d.moves||[]).map(dec);
  if((d.rev||0)!==L.rev){
    L.rev=d.rev||0;rebuildFrom(L,rm);hideOverlays();
  }else if(rm.length>L.moves.length){
    const fresh=rm.slice(L.moves.length);
    if(fresh.length===1&&fresh[0].p===L.turn&&!L.result&&!REPLAY&&!document.hidden){
      const rec=fresh[0];
      playRecord(rec,()=>{finishMove(rec);syncRoom();});
      return;
    }
    rebuildFrom(L,rm);
    if(L.result) finish();
  }
  if(d.drawn&&!L.result){L.result={winner:0,why:'agree'};finish();}
  if(d.timeout&&!L.result){L.result={winner:3-d.timeout,why:'time'};finish();}
  if(d.resigned&&!L.result){L.result={winner:3-d.resigned,why:'resign'};finish();}
  if(d.ans&&Net.myReq&&d.ans.id===Net.myReq){Net.myReq=0;toast(d.ans.ok?'요청이 수락되었습니다.':'상대가 요청을 거절했습니다.');}
  refreshOpp();
  refresh();
}
function netPush(){
  Net.pending=true;
  if(Net.pushQueued) return;
  Net.pushQueued=true;
  wq(async()=>{
    Net.pushQueued=false;
    if(!Net.ref||!LIVE) return;
    try{await Net.ref.update({moves:LIVE.moves.map(enc)});}finally{Net.pending=false;}
  });
}
let resignArm=0;
async function resign(){
  const L=LIVE;
  if(!L||L.result||role===0||!Net.ref) return;
  const btn=$('#resign');
  if(!resignArm){
    btn.textContent='정말 기권?';
    resignArm=setTimeout(()=>{resignArm=0;btn.textContent='기권';},3000);return;
  }
  clearTimeout(resignArm);resignArm=0;btn.textContent='기권';
  L.result={winner:3-role,why:'resign'};
  wq(()=>Net.ref?Net.ref.update({resigned:role}):0);
  finish();
}
async function rematch(){
  const d=Net.room;
  if(!d||!Net.ref) return;
  wq(()=>Net.ref?Net.ref.update({gen:(d.gen||0)+1,moves:[],resigned:0,timeout:0,drawn:0,req:null,ans:null}):0);
}
async function copyCode(){
  try{await navigator.clipboard.writeText(Net.code);toast('방 코드를 복사했습니다.');}
  catch(e){toast('코드를 길게 눌러 복사하세요: '+Net.code);}
}

/* chat */
const EMOJIS=['👍','👏','😮','😂','😢','🔥','GG','굿!'];
function chatItems(){
  const out=[];
  for(const r of [1,2]) for(const m of (Net.chat['c'+r]||[])) out.push({r,t:String(m.t||'').slice(0,60),n:+m.n||0});
  return out.sort((a,b)=>a.n-b.n).slice(-30);
}
function renderChat(){
  const ul=$('#chatLog');ul.textContent='';
  const items=chatItems(),d=Net.room;
  if(!items.length){const li=document.createElement('li');li.className='empty';li.textContent='아직 메시지가 없습니다.';ul.appendChild(li);return;}
  for(const m of items){
    const li=document.createElement('li'),b=document.createElement('b');
    b.className='c'+m.r;
    const nmn=d?(m.r===1?d.host.name:(d.guest&&d.guest.name)):'';
    b.textContent=(nmn||('플레이어 '+m.r))+': ';
    li.append(b,document.createTextNode(m.t));ul.appendChild(li);
  }
  ul.scrollTop=ul.scrollHeight;
}
function bubble(r,text){
  const el=$('#bub'+r);if(!el) return;
  el.textContent=text.slice(0,12);el.hidden=false;
  clearTimeout(el._t);el._t=setTimeout(()=>{el.hidden=true;},3500);
}
function onChat(data){
  Net.chat={c1:data.c1||[],c2:data.c2||[]};
  const items=chatItems();
  if(!Net.chatInit){Net.chatInit=true;Net.lastChat=items.length?items[items.length-1].n:0;}
  else for(const m of items) if(m.n>Net.lastChat){Net.lastChat=m.n;if(m.r!==role) bubble(m.r,m.t);}
  renderChat();
}
let lastSend=0;
function sendChat(text){
  text=String(text||'').replace(/[\u0000-\u001f<>]/g,'').trim().slice(0,60);
  if(!text||mode!=='online'||role===0||!Net.chatRef) return;
  const now=Date.now();
  if(now-lastSend<700) return;
  lastSend=now;
  const key='c'+role,items=(Net.chat[key]||[]).concat({t:text,n:now}).slice(-15);
  Net.chat=Object.assign({},Net.chat,{[key]:items});
  Net.lastChat=Math.max(Net.lastChat,now);
  renderChat();bubble(role,text);
  const ref=Net.chatRef;
  wq(async()=>{
    try{await ref.update({[key]:items});}
    catch(e){if(e&&e.code==='invalid_argument') await ref.set({c1:Net.chat.c1||[],c2:Net.chat.c2||[]});else throw e;}
  });
}


function syncProfileRating(){updateCoinUI();}
