'use strict';
/* ---------- move review (최선 / 우수함 / 놓침) ---------- */
const QL={best:['최선','엔진이 고른 가장 좋은 수입니다.'],excellent:['우수함','최선에 거의 가까운 강한 수입니다.'],miss:['놓침','이득을 볼 수 있는 기회를 놓쳤습니다.'],mistake:['실수','분명한 손해를 본 수입니다.'],blunder:['블런더','말을 잃을 정도로 치명적인 수입니다.']};
const QI={
  best:'<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="11" fill="var(--q-best)"/><path d="M12 5.2l1.9 4.1 4.5.5-3.3 3 .9 4.4L12 15l-4 2.2.9-4.4-3.3-3 4.5-.5z" fill="#fff"/></svg>',
  excellent:'<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="11" fill="var(--q-exc)"/><path d="M7 12.6l3.4 3.4L17 9.2" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  miss:'<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="10" fill="var(--surface,#fff)" stroke="var(--q-miss)" stroke-width="2.4"/><path d="M12 6.6v6.2" stroke="var(--q-miss)" stroke-width="2.6" stroke-linecap="round"/><circle cx="12" cy="17" r="1.5" fill="var(--q-miss)"/></svg>',
  mistake:'<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="11" fill="var(--q-mistake)"/><text x="12" y="17.4" text-anchor="middle" font-size="16" font-weight="800" fill="#fff" font-family="sans-serif">?</text></svg>',
  blunder:'<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="11" fill="var(--q-blunder)"/><text x="12" y="16.8" text-anchor="middle" font-size="13" font-weight="800" fill="#fff" font-family="sans-serif">??</text></svg>'
};
const QC=new Map();let qVer=0,qTimer=0,lastJ='';
function qKey(b,rec){return b.join('')+'|'+enc(rec);}
function qScan(moves,fn){
  const b=newBoard(),ids=freshIds(b);
  for(let i=0;i<moves.length;i++){fn(i,b);applyRecBoth(b,ids,moves[i]);}
}
/* cached verdict per move: {k:'best'|'excellent'|'miss'|'mistake'|'blunder'|0, e:eval from Blue's view, bm:engine's move or null}, undefined while not analysed yet */
function qList(moves){
  const out=[];
  qScan(moves,(i,b)=>{out.push(QC.get(qKey(b,moves[i])));});
  return out;
}
function qPump(){
  if(qTimer) return;
  let job=null;
  const look=(moves,rev)=>{
    if(job||!moves||!moves.length) return;
    const bs=[];qScan(moves,(i,b)=>{bs[i]=b.slice();});
    for(let n=0;n<moves.length;n++){
      const i=rev?moves.length-1-n:n,key=qKey(bs[i],moves[i]);
      if(!QC.has(key)){job={b:bs[i],rec:moves[i],key};return;}
    }
  };
  look(LIVE&&LIVE.moves,true);
  look(REPLAY&&REPLAY.moves,false);
  if(!job) return;
  qTimer=setTimeout(()=>{
    qTimer=0;
    let val={k:0,e:0,bm:null,info:null,delta:0};
    try{const a=analyze(job.b,job.rec.p,job.rec,ANALYSIS_DEPTH);val={k:a.kind||0,e:a.e||0,bm:a.bm||null,info:a.info||null,delta:a.delta||0};}catch(e){}
    QC.set(job.key,val);qVer++;
    if(QC.size>4000) QC.delete(QC.keys().next().value);
    if(G) renderAll();
    qPump();
  },25);
}
/* Plain-language advice for a move, built from the facts the analyser found. Shown in replays only. */
function coachText(rec,q){
  if(!q||!q.k) return '';
  const a=q.info,bm=q.bm;
  if(q.k==='best') return a&&a.pcaps>0?'좋은 수! 상대 말 '+a.pcaps+'개를 잡았어요.':'';
  if(q.k==='excellent') return '최선에 아주 가까운 수예요.';
  if(!a||!bm) return '';
  const out=[],better='더 좋은 수: ‘'+notation(bm)+'’';
  if(q.k==='miss'){
    out.push(better+(a.bcaps>0?' — 상대 말 '+a.bcaps+'개를 잡을 수 있었어요.':' — 훨씬 유리해지는 수였어요.'));
    out.push('잡을 수 있는 말이 있는지 매 수 먼저 확인해 보세요. 포획은 선택이지만 이득이 큰 경우가 많아요.');
    return out.join('\n');
  }
  if(a.lost>0) out.push('이 수를 두면 상대가 ‘'+notation(a.reply)+'’로 말 '+a.lost+'개를 잡아요.');
  else if(a.soonN>0&&a.soonMove) out.push('이 수 뒤 몇 수 안에 상대가 ‘'+notation(a.soonMove)+'’ 같은 수로 말을 '+a.soonN+'개 잡는 흐름이 돼요.');
  else out.push('이 수 뒤에 형세가 불리해져요.');
  let why;
  if(a.bcaps>0) why=' — 먼저 상대 말 '+a.bcaps+'개를 잡을 수 있었어요.';
  else if(a.lost>0&&a.bLost===0) why=' — 말을 잃지 않고 넘어갈 수 있었어요.';
  else if(a.lost>a.bLost) why=' — 잃는 말을 '+a.bLost+'개로 줄일 수 있었어요.';
  else why=' — 형세가 말 '+(Math.max(1,Math.round(q.delta/100*10)/10))+'개 분쯤 더 좋아져요.';
  out.push(better+why);
  if(a.lost>0&&a.pcaps===0) out.push('팁: 상대 말 바로 앞이고 내 말 뒤가 비어 있으면 뛰어넘겨 잡혀요. 나가기 전에 뒤 칸을 확인하세요.');
  return out.join('\n');
}
function renderJudge(Q,idx){
  const el=$('#judge'),rec=idx>=0?(REPLAY?REPLAY.moves:G.moves)[idx]:null,q=rec&&Q[idx],kind=q&&q.k;
  if(!kind){el.hidden=true;qb.hidden=true;lastJ='';return;}
  const sig=idx+kind+(REPLAY?'r':'g')+G.moves.length;
  el.hidden=false;el.dataset.k=kind;
  $('#jic').innerHTML=QI[kind];
  $('#jt').textContent=QL[kind][0];
  $('#jd').textContent=nm(rec.p)+'  '+notation(rec)+' · '+QL[kind][1]+(q.bm?'  추천 수: '+notation(q.bm):'');
  const jc=$('#jc'),coach=REPLAY?coachText(rec,q):'';
  jc.textContent=coach;jc.hidden=!coach;
  const e=rec.path[rec.path.length-1],d=flip?63-e:e;
  qb.hidden=false;qb.style.setProperty('--r',d>>3);qb.style.setProperty('--c',d&7);
  qb.innerHTML=QI[kind];
  if(sig!==lastJ){lastJ=sig;qb.classList.remove('pop');void qb.offsetWidth;qb.classList.add('pop');}
}

