'use strict';
/* ---------- play with coach / bot battles screens ---------- */
let pickColor=String(store.get('dama.color','1')),coachLv=Math.max(0,Math.min(9,+store.get('dama.coachLv',3)||0)),botView={v:'cats',cat:null,bot:null};
const STYLE_NOTE={balanced:'균형 잡힌 스타일',rush:'공격적으로 전진해요',wall:'수비를 단단히 해요',swap:'말 교환을 즐겨요'};
function buildColorPick(box){
  box.querySelectorAll('button').forEach(b=>b.remove());
  for(const [v,label,html] of [['1','파랑 (선공)','<span class="cdisc p1"></span>'],['0','무작위','<span class="cq">?</span>'],['2','빨강 (후공)','<span class="cdisc p2"></span>']]){
    const b=document.createElement('button');b.type='button';b.className='cpick';b.dataset.c=v;b.setAttribute('role','radio');b.setAttribute('aria-label',label);b.title=label;
    b.setAttribute('aria-checked',String(pickColor===v));b.innerHTML=html;
    b.addEventListener('click',()=>{pickColor=v;store.set('dama.color',v);document.querySelectorAll('.colorpick').forEach(buildColorPick);});
    box.appendChild(b);
  }
  rovingInit(box);
}
function resolveSide(){return pickColor==='0'?(Math.random()<.5?1:2):+pickColor;}
const HINT_MODES=[['inf','무제한'],['3','3회'],['0','없음']];
let hintMode=String(store.get('dama.hintMode','inf'));
const hintCount=()=>hintMode==='inf'?Infinity:+hintMode;
function buildHintPick(){
  const box=$('#hintPick');box.textContent='';
  for(const [v,l] of HINT_MODES){
    const b=document.createElement('button');b.type='button';b.className='hpick';b.setAttribute('role','radio');b.setAttribute('aria-checked',String(hintMode===v));b.textContent=l;b.dataset.v=v;
    b.addEventListener('click',()=>{hintMode=v;store.set('dama.hintMode',v);buildHintPick();});
    box.appendChild(b);
  }
  rovingInit(box);
}
function launchBot(bot){
  const me=resolveSide(),opp=3-me,names={};
  names[me]=getNick('플레이어');names[opp]=bot.name+' ('+botRating(bot)+')';
  startGame('cpu',names,0,{bot,me,hints:bot.kind==='coach'?hintCount():0});
}
/* ----- coach screen ----- */
function coachBot(i){const l=COACH_LEVELS[i];return {id:'coach'+i,kind:'coach',name:'컴퓨터',p:{r:l.r,d:l.d,rnd:l.rnd||0,ms:l.ms||0},av:{robot:true,bg:'#3a4a4f'}};}
function renderCoachLevels(){
  const ul=$('#lvList');ul.textContent='';
  COACH_LEVELS.forEach((l,i)=>{
    const b=document.createElement('button');
    b.type='button';b.setAttribute('role','radio');b.setAttribute('aria-checked',String(i===coachLv));
    b.className='lvitem'+(i===coachLv?' on':'');b.textContent=l.n+' ('+l.r+')';
    b.addEventListener('click',()=>{coachLv=i;store.set('dama.coachLv',i);renderCoachLevels();setLvOpen(false);});
    ul.appendChild(b);
  });
  rovingInit(ul);
  const l=COACH_LEVELS[coachLv];$('#lvSelName').textContent=l.n+' ('+l.r+')';
}
function setLvOpen(o){$('#lvList').hidden=!o;$('#lvSel').setAttribute('aria-expanded',String(o));$('#lvSel .chev').textContent=o?'⌃':'⌄';}
function openCoach(){
  $('#coachHeroAv').innerHTML=avatarSvg(COACH_AV);
  buildColorPick($('#coachColor'));buildHintPick();renderCoachLevels();setLvOpen(true);show('scr-coach');
}
/* ----- bots screen ----- */
function botRow(av,name,sub,right,onClick){
  const b=document.createElement('button');b.type='button';b.className='botrow';
  const a=document.createElement('span');a.className='pav md';a.innerHTML=avatarSvg(av);
  const n=document.createElement('span');n.className='bn';const t=document.createElement('b');t.textContent=name;n.appendChild(t);
  if(sub){const s=document.createElement('small');s.textContent=sub;n.appendChild(s);}
  const r=document.createElement('span');r.className='br';r.textContent=right||'';
  b.append(a,n,r);b.addEventListener('click',onClick);return b;
}
function renderBots(){
  const body=$('#botsBody');body.textContent='';
  const {v,cat,bot}=botView;
  $('#botsTitle').textContent=v==='cats'?'봇과 플레이':v==='list'?cat.name:bot.name;
  if(v==='cats'){
    const ul=document.createElement('div');ul.className='botlist';
    for(const c of BOT_CATS) ul.appendChild(botRow(c.bots[0].av,c.name,catProgress(c)+' / '+c.bots.length+' 격파','봇 '+c.bots.length+'개',()=>{botView={v:'list',cat:c,bot:null};renderBots();}));
    body.appendChild(ul);
  }else if(v==='list'){
    const ul=document.createElement('div');ul.className='botlist';
    for(const b of cat.bots){const rc=botRec()[b.id]||[0,0,0];ul.appendChild(botRow(b.av,b.name,(b.adaptive?'내 실력에 맞춰 변해요':STYLE_LABEL[b.st||'balanced'])+(rc[0]+rc[1]+rc[2]?' · '+rc[0]+'승 '+rc[1]+'패 '+rc[2]+'무':''),String(botRating(b))+(rc[0]?' ✓':''),()=>{botView={v:'detail',cat,bot:b};renderBots();}));}
    body.appendChild(ul);
  }else{
    const p=botParams(bot),wrap=document.createElement('div');wrap.className='botdetail';
    const hero=document.createElement('div');hero.className='pscoach';
    hero.innerHTML='<span class="pav big">'+avatarSvg(bot.av)+'</span>';
    const bub=document.createElement('div');bub.className='pbubble';bub.textContent=bot.q;hero.appendChild(bub);
    const panel=document.createElement('div');panel.className='pspanel';
    const info=document.createElement('p');info.className='botinfo';
    info.innerHTML='<b>'+bot.name+'</b> · 레이팅 '+p.r+(bot.adaptive?' (현재)':'')+'<br><small>'+STYLE_NOTE[p.st]+' · 탐색 '+p.d+'수'+(p.rnd?' · 가끔 실수':'')+'</small>';
    const row=document.createElement('div');row.className='psrow';
    const pick=document.createElement('div');pick.className='colorpick';pick.setAttribute('role','radiogroup');pick.setAttribute('aria-label','당신의 색상');pick.innerHTML='<span>당신의 색상</span>';
    buildColorPick(pick);row.appendChild(pick);
    const go=document.createElement('button');go.type='button';go.className='psstart';go.textContent='시작하기';go.addEventListener('click',()=>launchBot(bot));
    panel.append(info,row,go);wrap.append(hero,panel);body.appendChild(wrap);
  }
}
function openBots(reset){
  if(reset!==false) botView={v:'cats',cat:null,bot:null};
  renderBots();show('scr-bots');
  const f=$('#botsBody button');if(f) f.focus({preventScroll:true});
}
function botsBack(){
  if(botView.v==='detail'){botView={v:'list',cat:botView.cat,bot:null};renderBots();}
  else if(botView.v==='list'){botView={v:'cats',cat:null,bot:null};renderBots();}
  else{panel('solo');show('scr-menu');}
}
/* opponent avatar next to the name in the game HUD */
function renderOppAvatar(){
  const opp=3-meSide;
  for(const s of [1,2]){
    const el=$('#av'+s),on=mode==='cpu'&&!!CFG.bot&&s===opp;
    el.hidden=!on;
    if(on&&el.dataset.k!==CFG.bot.id){el.dataset.k=CFG.bot.id;el.innerHTML=avatarSvg(CFG.bot.av);}
  }
}
$('#coachBtn').addEventListener('click',openCoach);
$('#botsBtn').addEventListener('click',()=>openBots());
$('#coachBack').addEventListener('click',()=>{panel('solo');show('scr-menu');});
$('#botsBack').addEventListener('click',botsBack);
$('#lvSel').addEventListener('click',()=>setLvOpen($('#lvList').hidden));
$('#coachStart').addEventListener('click',()=>launchBot(coachBot(coachLv)));
$('#coachUndo').addEventListener('click',()=>undo());
document.addEventListener('keydown',e=>{
  if(e.key!=='Escape') return;
  if(!$('#scr-coach').hidden) $('#coachBack').click();
  else if(!$('#scr-bots').hidden) botsBack();
});

/* ---------- first run: tutorial -> nickname -> starting rating ---------- */
function openOnboard(){
  $('#obStep1').hidden=false;$('#obStep2').hidden=true;$('#obErr').textContent='';
  $('#obNick').value=clean(nickEl.value);$('#obOk').disabled=!clean($('#obNick').value);
  $('#onboard').hidden=false;$('#obNick').focus();
}
function submitNick(){
  const n=clean($('#obNick').value);
  if(!n){$('#obErr').textContent='닉네임을 입력해 주세요.';return;}
  nickEl.value=n;store.set('dama.nick',n);
  store.set('dama.profile',{rating:START_RATING,since:Date.now()});
  $('#obWelcome').textContent=n+'님, 환영합니다!';$('#obRate').textContent=START_RATING;
  $('#obStep1').hidden=true;$('#obStep2').hidden=false;$('#obGo').focus();
  updateCoinUI();
}
$('#obNick').addEventListener('input',()=>{$('#obOk').disabled=!clean($('#obNick').value);$('#obErr').textContent='';});
$('#obNick').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();submitNick();}});
$('#obOk').addEventListener('click',submitNick);
$('#obGo').addEventListener('click',()=>{$('#onboard').hidden=true;$('#soloBtn').focus();});

