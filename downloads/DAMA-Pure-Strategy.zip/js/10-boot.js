'use strict';
/* ---------- boot: loading -> menu ---------- */
const TIPS=['말은 앞쪽과 좌우로 한 칸, 뒤로도 한 칸 움직일 수 있어요.','뒤로 물러설 수는 있지만 뒤쪽으로 잡을 수는 없어요.','한 판을 마치면 코인을 얻어요. 상점에서 보드와 말 스타일을 꾸며 보세요.','착지한 자리에서 또 뛰어넘을 수 있으면 연속 포획!','상대가 움직일 수 없게 만들어도 승리합니다.','포획은 선택 사항입니다. 때로는 참는 것도 수예요.','끝난 대국은 복기에서 처음부터 다시 볼 수 있어요.'];
(function boot(){
  $('#tip').textContent=TIPS[Math.floor(Math.random()*TIPS.length)];
  applyLook();updateCoinUI();
  setInterval(clockTick,250);
  netInit();
  const fill=$('#barfill'),bar=document.querySelector('.bar');
  const t0=performance.now(),MIN=1500,MAX=3500;
  let fontsReady=false;
  (document.fonts&&document.fonts.ready?document.fonts.ready:Promise.resolve()).then(()=>{fontsReady=true;});
  const tick=now=>{
    const el=now-t0,p=Math.min(el/MIN,1);
    const shown=(fontsReady||el>=MAX)?p:Math.min(p,.9);
    fill.style.width=(shown*100)+'%';bar.setAttribute('aria-valuenow',Math.round(shown*100));
    if(shown>=1){
      $('#scr-load').classList.add('out');
      setTimeout(()=>{panel('main',false);show('scr-menu');$('#soloBtn').focus();if(!SET.tut) openTut();else if(!getProfile()) openOnboard();},matchMedia('(prefers-reduced-motion: reduce)').matches?0:350);
      return;
    }
    requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
})();
