'use strict';
/* ---------- game flow ---------- */
function snapshot(){const L=LIVE;return {b:L.b.slice(),ids:L.ids.slice(),turn:L.turn,noprog:L.noprog,fr:L.fr.slice(),n:L.moves.length};}
function restore(s){
  const L=LIVE;
  L.b=s.b.slice();L.ids=s.ids.slice();L.turn=s.turn;L.noprog=s.noprog;L.fr=s.fr.slice();L.moves.length=s.n;
  L.result=null;L.chain=-1;L.path=null;L.capList=[];sel=-1;G=L;
  snapRender();
}
function snapRender(){
  layer.classList.add('snap');renderAll();
  requestAnimationFrame(()=>requestAnimationFrame(()=>layer.classList.remove('snap')));
}
function hideOverlays(){$('#result').hidden=true;$('#confetti').innerHTML='';}
function newGame(){
  clearTimeout(aiTimer);clearTimeout(resTimer);
  aiBusy=false;animBusy=false;sel=-1;REPLAY=null;
  LIVE=G=freshState(Object.assign({},CFG.names));
  LIVE.limit=SET.limit||0;
  hist=[];hideOverlays();
  beginTurn();snapRender();
}
function beginTurn(){
  const L=LIVE;L.path=null;L.capList=[];
  if(mode==='online') return;
  if(isHuman(L.turn)) hist.push(snapshot());
  else scheduleAI();
}
function hopRaw(from,to,cap){
  const L=LIVE;
  if(sel===from) sel=-1;
  L.b[to]=L.b[from];L.b[from]=0;L.ids[to]=L.ids[from];L.ids[from]=0;
  if(cap>=0){L.b[cap]=0;L.ids[cap]=0;}
}
function refresh(){if(REPLAY) syncReplayWithLive();else renderAll();}
function playRecord(rec,done,instant){
  const n=rec.path.length-1;
  const hop=k=>hopRaw(rec.path[k],rec.path[k+1],rec.caps.length?rec.caps[k]:-1);
  if(instant){for(let k=0;k<n;k++) hop(k);done();return;}
  animBusy=true;let k=0;
  const step=()=>{
    hop(k);k++;refresh();
    if(k<n) aiTimer=setTimeout(step,340);
    else aiTimer=setTimeout(()=>{animBusy=false;done();},260);
  };
  step();
}
function bookkeep(L,rec){
  L.moves.push(rec);
  announceMove(rec,L);
  L.noprog=stepProgress(rec,L.fr)?0:L.noprog+1;
  L.turn=3-rec.p;
  L.result=judge(L.b,rec.p,L.noprog);
  L.chain=-1;L.path=null;L.capList=[];sel=-1;
}
function finishMove(rec,opt){
  const L=LIVE;
  bookkeep(L,rec);
  if(opt&&opt.push) netPush();
  if(L.result){finish();return;}
  beginTurn();refresh();
}
/* coins, stats and rating are credited once per finished game */
function doneKey(L){return mode==='online'&&Net.code?Net.code+':'+L.gen:'';}
function wasDone(L){const k=doneKey(L);return !!k&&store.get('dama.done',[]).includes(k);}
function markDone(L){const k=doneKey(L);if(!k) return;const l=store.get('dama.done',[]);l.push(k);store.set('dama.done',l.slice(-30));}
function awardCoins(L){
  const r=L.result;
  if(!r||L.moves.length<8) return 0;
  let c=0;
  if(mode==='cpu'&&CFG.bot){const res=r.winner===meSide?'w':r.winner===0?'d':'l';c=botReward(botParams(CFG.bot).r,res);if(CFG.bot.kind==='coach') c=Math.round(c*(CFG.hints===0?.9:CFG.hints===Infinity?.6:.75));}
  else if(mode==='cpu'){const lv=+$('#level').value||2;c=r.winner===meSide?[0,10,20,40,70][lv]:r.winner===0?[0,3,6,12,20][lv]:[0,2,3,5,8][lv];}
  else if(mode==='local') c=4;
  else if(role!==0) c=r.winner===role?30:r.winner===0?10:6;
  if(c){W.coins+=c;saveW();updateCoinUI();}
  return c;
}
function recordStats(L){
  const r=L.result,st=store.get('dama.stats',{cpu:{},local:0,online:[0,0,0]});
  if(mode==='cpu'&&CFG.bot){
    const k=CFG.bot.kind==='coach'?'coach':'bot',a=st[k]||[0,0,0];a[r.winner===meSide?0:r.winner===0?2:1]++;st[k]=a;
    botProgress(L);
    if(CFG.bot.adaptive&&r.winner!==0) store.set('dama.adapt',Math.max(0,Math.min(9,adaptIdx()+(r.winner===meSide?1:-1))));
  }
  else if(mode==='cpu'){const lv=+$('#level').value||2,a=st.cpu[lv]||[0,0,0];a[r.winner===meSide?0:r.winner===0?2:1]++;st.cpu[lv]=a;}
  else if(mode==='local') st.local=(st.local||0)+1;
  else if(role!==0) st.online[r.winner===role?0:r.winner===0?2:1]++;
  store.set('dama.stats',st);
}
function finish(){
  const L=LIVE;
  if(!L.saved){
    L.saved=true;
    if(!wasDone(L)){saveGame(L);L.reward=awardCoins(L);recordStats(L);rateGame(L);rateSolo(L);markDone(L);}
  }
  refresh();
  clearTimeout(resTimer);
  resTimer=setTimeout(()=>{
    if(LIVE!==L||!L.result) return;
    if(REPLAY) L.pendingResult=true;else showResult(L);
  },650);
}

function onCell(i){
  const L=LIVE;
  if(!L||REPLAY||L.result||aiBusy||animBusy||!isHuman(L.turn)) return;
  const p=L.turn;
  if(L.chain>=0){
    const j=jumpsFrom(L.b,p,L.chain>>3,L.chain&7).find(o=>o.r*8+o.c===i);
    if(j) humanHop(L.chain,i,j.cr*8+j.cc);
    else if(i===L.chain) endHumanTurn();
    return;
  }
  if(L.b[i]===p){sel=sel===i?-1:i;renderAll();return;}
  if(sel>=0){
    const r=sel>>3,c=sel&7;
    const mv=simpleFrom(L.b,p,r,c).find(o=>o.r*8+o.c===i);
    if(mv){humanHop(sel,i,-1);return;}
    const j=jumpsFrom(L.b,p,r,c).find(o=>o.r*8+o.c===i);
    if(j){humanHop(sel,i,j.cr*8+j.cc);return;}
  }
  sel=-1;renderAll();
}
function humanHop(from,to,cap){
  const L=LIVE;
  if(!L.path){L.path=[from];L.capList=[];}
  hopRaw(from,to,cap);
  L.path.push(to);
  if(cap>=0) L.capList.push(cap);
  if(cap>=0&&jumpsFrom(L.b,L.turn,to>>3,to&7).length){L.chain=to;sel=to;renderAll();return;}
  endHumanTurn();
}
function endHumanTurn(){
  const L=LIVE;
  const rec={p:L.turn,path:L.path.slice(),caps:L.capList.slice()};
  finishMove(rec,{push:mode==='online'});
}

function scheduleAI(){aiBusy=true;aiTimer=setTimeout(runAI,450);}
function runAI(){
  const L=LIVE,p=L.turn,cfg=CFG.bot?botParams(CFG.bot):LV[+$('#level').value]||LV[2];
  const m=pickBotMove(L.b,p,cfg);
  if(!m){aiBusy=false;refresh();return;}
  const rec=fromMove(m,p);
  playRecord(rec,()=>{aiBusy=false;finishMove(rec);});
}
function undo(){
  const L=LIVE;
  if(mode==='online'){sendReq('undo');return;}
  if(!L||REPLAY||L.result||aiBusy) return;
  if(L.chain>=0){restore(hist[hist.length-1]);return;}
  if(hist.length<2) return;
  hist.pop();restore(hist[hist.length-1]);
}

/* ---------- clock (optional per-move time limit) ---------- */
let lastTick=0;
function clockOn(L){
  if(!L||!L.limit||L.result||L.waiting) return false;
  if(mode==='cpu') return L.turn===meSide;
  return true;
}
function clockTick(){
  const L=LIVE,el=$('#clock'),now=Date.now();
  if(!clockOn(L)){el.hidden=true;lastTick=now;if(L) L.ctag='';return;}
  const tag=L.gen+':'+L.rev+':'+L.moves.length;
  if(L.ctag!==tag){L.ctag=tag;L.tStart=now;}
  else if(mode!=='online'&&REPLAY) L.tStart+=now-lastTick;
  lastTick=now;
  const rem=L.limit*1000-(now-L.tStart);
  el.hidden=!!REPLAY;
  el.textContent=Math.max(0,Math.ceil(rem/1000))+'초';
  el.classList.toggle('warn',rem<=10000);
  if(rem<=0) onTimeout(L,rem);
}
function onTimeout(L,rem){
  if(L.result) return;
  const t=L.turn;
  if(mode==='online'){
    if(role===0||L.tOut) return;
    if(role===t||rem<-4000){
      L.tOut=true;L.result={winner:3-t,why:'time'};finish();
      wq(()=>Net.ref?Net.ref.update({timeout:t}):0);
    }
  }else{L.result={winner:3-t,why:'time'};finish();}
}

/* ---------- draw offers and online requests (undo / draw) ---------- */
let drawArm=0;
function onDraw(){
  const L=LIVE;
  if(!L||REPLAY||L.result) return;
  if(mode==='online'){sendReq('draw');return;}
  if(mode==='cpu'){
    if(aiBusy||animBusy||L.moves.length<10){toast('조금 더 진행한 뒤에 제안할 수 있습니다.');return;}
    if(evaluate(L.b,2)<=40){L.result={winner:0,why:'agree'};finish();}
    else toast('컴퓨터가 무승부를 거절했습니다.');
    return;
  }
  const btn=$('#drawBtn');
  if(!drawArm){btn.textContent='상대가 동의하면 한 번 더';drawArm=setTimeout(()=>{drawArm=0;btn.textContent='무승부 제안';},5000);return;}
  clearTimeout(drawArm);drawArm=0;btn.textContent='무승부 제안';
  L.result={winner:0,why:'agree'};finish();
}
function sendReq(type){
  const d=Net.room,L=LIVE;
  if(mode!=='online'||!d||!Net.ref||role===0||!L||L.result||L.waiting||d.req||REPLAY) return;
  const req={id:Date.now(),type,by:role};
  if(type==='undo'){
    let to=-1;for(let i=L.moves.length-1;i>=0;i--) if(L.moves[i].p===role){to=i;break;}
    if(to<0){toast('무를 수 있는 내 수가 없습니다.');return;}
    req.to=to;
  }
  Net.myReq=req.id;Net.room=Object.assign({},d,{req});
  wq(()=>Net.ref?Net.ref.update({req}):0);
  renderAll();
}
function answerReq(ok){
  const d=Net.room,L=LIVE;
  if(!d||!d.req||!Net.ref||role===0) return;
  const rq=d.req;
  if(rq.by===role){Net.myReq=0;Net.room=Object.assign({},d,{req:null});wq(()=>Net.ref?Net.ref.update({req:null}):0);renderAll();return;}
  if(!ok){Net.room=Object.assign({},d,{req:null});wq(()=>Net.ref?Net.ref.update({req:null,ans:{id:rq.id,ok:false}}):0);renderAll();return;}
  if(rq.type==='draw'){
    Net.room=Object.assign({},d,{req:null});
    wq(()=>Net.ref?Net.ref.update({req:null,ans:{id:rq.id,ok:true},drawn:1}):0);
    if(L&&!L.result){L.result={winner:0,why:'agree'};finish();}
  }else{
    const mv=(d.moves||[]).slice(),to=rq.to;
    if(!(to>=0&&to<mv.length)){Net.room=Object.assign({},d,{req:null});wq(()=>Net.ref?Net.ref.update({req:null,ans:{id:rq.id,ok:false}}):0);renderAll();return;}
    Net.room=Object.assign({},d,{req:null});
    wq(()=>Net.ref?Net.ref.update({moves:mv.slice(0,to),rev:(d.rev||0)+1,req:null,ans:{id:rq.id,ok:true}}):0);
  }
}
function renderReq(){
  const box=$('#reqBox'),d=Net.room,L=LIVE;
  if(mode!=='online'||!d||!L||REPLAY||L.result||role===0||!d.req){box.hidden=true;return;}
  const rq=d.req,mine=rq.by===role,undoq=rq.type==='undo';
  box.hidden=false;
  $('#reqText').textContent=mine?(undoq?'무르기':'무승부')+'를 요청했습니다. 상대의 답을 기다리는 중…':nm(rq.by)+'님이 '+(undoq?'무르기를 요청했습니다.':'무승부를 제안했습니다.');
  $('#reqYes').hidden=mine;$('#reqNo').textContent=mine?'취소':'거절';
}

