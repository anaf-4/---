'use strict';
/* ---------- replay ---------- */
function startReplay(rec){
  stopReplayTimer();
  const states=[];let b=newBoard(),ids=freshIds(b);
  states.push({b:b.slice(),ids:ids.slice()});
  for(const r of rec.moves){applyRecBoth(b,ids,r);states.push({b:b.slice(),ids:ids.slice()});}
  REPLAY={moves:rec.moves,names:rec.names,result:rec.result||null,states,k:0,timer:0,live:!!rec.live,me:rec.me||0,gen:rec.gen||0,showBest:false,when:rec.when||0};
  hideOverlays();sel=-1;logKey='';
  replayStep(0);
}
function qAt(moves,i){
  if(i<0||i>=moves.length) return undefined;
  let out;qScan(moves.slice(0,i+1),(j,b)=>{if(j===i) out=QC.get(qKey(b,moves[i]));});
  return out;
}
/* "추천 수 보기": show the position before the move with the engine's move (green) and the played move (grey, dashed) */
function replayView(){
  const R=REPLAY,n=R.moves.length;
  let bm=null;
  if(R.showBest){const q=R.k>0?qAt(R.moves,R.k-1):null;if(q&&q.bm) bm=q.bm;else R.showBest=false;}
  const idx=bm?R.k-1:R.k,st=R.states[idx];
  const turn=idx<n?R.moves[idx].p:(n?3-R.moves[n-1].p:1);
  G={b:st.b,ids:st.ids,turn,noprog:0,moves:R.moves.slice(0,idx),result:null,chain:-1,names:R.names,waiting:false,
     arrows:bm?[{cls:'a-best',path:bm.path},{cls:'a-played',path:R.moves[R.k-1].path}]:null};
}
function replayStep(k){
  const n=REPLAY.moves.length,nk=Math.max(0,Math.min(n,k));
  if(nk!==REPLAY.k) REPLAY.showBest=false;
  REPLAY.k=nk;
  replayView();renderAll();
}
function toggleHint(){
  const R=REPLAY;if(!R) return;
  stopReplayTimer();
  R.showBest=!R.showBest;
  replayView();renderAll();
}
function renderGraph(R,Q){
  const g=$('#rpGraph'),n=R.moves.length;
  g.textContent='';
  g.appendChild(mkSvg('line',{x1:0,y1:40,x2:300,y2:40,class:'mid'}));
  if(!n) return;
  const X=i=>i/n*300,Y=e=>40-Math.max(-400,Math.min(400,e))/400*34;
  const pts=['0,40'];let last=0;
  for(let i=1;i<=n;i++){const q=Q[i-1];if(q) last=q.e;pts.push(X(i).toFixed(1)+','+Y(last).toFixed(1));}
  g.appendChild(mkSvg('polyline',{points:pts.join(' '),class:'ln'}));
  for(let i=1;i<=n;i++){const q=Q[i-1];if(q&&(q.k==='blunder'||q.k==='mistake'||q.k==='miss')) g.appendChild(mkSvg('circle',{cx:X(i).toFixed(1),cy:Y(q.e).toFixed(1),r:3.4,fill:'var(--q-'+q.k+')'}));}
  g.appendChild(mkSvg('line',{x1:X(R.k).toFixed(1),y1:0,x2:X(R.k).toFixed(1),y2:80,class:'cur'}));
}
{
  const gEl=$('#rpGraph');let drag=false;
  const seek=e=>{if(!REPLAY) return;const r=gEl.getBoundingClientRect();stopReplayTimer();replayStep(Math.round(Math.max(0,Math.min(1,(e.clientX-r.left)/r.width))*REPLAY.moves.length));};
  gEl.addEventListener('pointerdown',e=>{drag=true;try{gEl.setPointerCapture(e.pointerId);}catch(x){}seek(e);});
  gEl.addEventListener('pointermove',e=>{if(drag) seek(e);});
  gEl.addEventListener('pointerup',()=>{drag=false;});
  gEl.addEventListener('pointercancel',()=>{drag=false;});
}
function renderReplayPanel(){
  const R=REPLAY,n=R.moves.length;
  $('#rpSlider').max=n;$('#rpSlider').value=R.k;
  $('#rpInfo').textContent=R.k+' / '+n+'수 · '+resultLine(R.result||null,R.names);
  $('#rpFirst').disabled=$('#rpPrev').disabled=R.k===0;
  $('#rpNext').disabled=$('#rpLast').disabled=R.k===n;
  $('#rpPlay').textContent=R.timer?'정지':'재생';
  $('#rpPlay').disabled=n===0;
  const an=$('#rpAn'),Q=qList(R.moves),dn=Q.filter(x=>x!==undefined).length;
  an.hidden=dn>=n;an.textContent='수 평가 분석 중… '+dn+' / '+n;
  renderGraph(R,Q);
  renderKeyMoments(R,Q,dn>=n&&n>0);
  {
    const sm=$('#rpSum');
    if(dn<n||!n){sm.hidden=true;}
    else{
      sm.hidden=false;sm.textContent='';
      for(const side of [1,2]){
        const c={best:0,excellent:0,miss:0,mistake:0,blunder:0};
        R.moves.forEach((m,i)=>{if(m.p===side&&Q[i]&&Q[i].k) c[Q[i].k]++;});
        const tot=c.best+c.excellent+c.miss+c.mistake+c.blunder;
        const row=document.createElement('div');
        const nmEl=document.createElement('b');nmEl.textContent=R.names[side];
        row.append(nmEl,' · '+(tot?'정확도 '+Math.round((c.best+c.excellent)/tot*100)+'%':'평가 없음')+' · 최선 '+c.best+' · 우수 '+c.excellent+' · 놓침 '+c.miss+' · 실수 '+c.mistake+' · 블런더 '+c.blunder);
        sm.appendChild(row);
      }
    }
  }
  const cq=R.k>0?Q[R.k-1]:null;
  $('#rpHint').disabled=!(cq&&cq.bm);
  $('#rpHint').textContent=R.showBest?'실제 수 보기':'추천 수 보기';
  $('#rpExport').disabled=n===0;
  $('#rpExit').textContent=replayFrom==='menu'?'목록으로':R.live?'대국으로 돌아가기':'복기 끝내기';
  const lv=$('#rpLive'),L=LIVE;
  if(R.live&&L){
    lv.hidden=false;
    lv.textContent=L.result?'대국은 이미 끝났습니다.':(mode==='online'&&L.waiting)?'대국 진행 중 · 상대를 기다리는 중':'대국 진행 중 · '+(L.names[L.turn]||'')+'의 차례';
  }else lv.hidden=true;
}
/* A replay opened mid-game keeps following the live game: new moves are appended, the position you are looking at stays put. */
function syncReplayWithLive(){
  const R=REPLAY,L=LIVE;
  if(!R||!R.live||!L){if(R) renderAll();return;}
  const n=R.moves.length;
  if(L.moves.length>n&&L.gen===R.gen){
    const b=R.states[n].b.slice(),ids=R.states[n].ids.slice();
    for(let i=n;i<L.moves.length;i++){
      const r=L.moves[i];
      R.moves.push(r);applyRecBoth(b,ids,r);R.states.push({b:b.slice(),ids:ids.slice()});
    }
  }
  renderAll();
}
function stopReplayTimer(){if(REPLAY&&REPLAY.timer){clearInterval(REPLAY.timer);REPLAY.timer=0;}}
function togglePlay(){
  const R=REPLAY;if(!R) return;
  if(R.timer){stopReplayTimer();}
  else{
    if(R.k>=R.moves.length) R.k=0;
    R.timer=setInterval(()=>{
      replayStep(R.k+1);
      if(R.k>=R.moves.length){stopReplayTimer();renderReplayPanel();}
    },900);
    replayStep(R.k);
  }
  renderReplayPanel();
}
function exitReplay(){
  stopReplayTimer();REPLAY=null;logKey='';
  if(replayFrom==='menu'||!LIVE){toMenu('games');return;}
  G=LIVE;
  if(LIVE.chain>=0) sel=LIVE.chain;
  if(LIVE.pendingResult){LIVE.pendingResult=false;showResult(LIVE);}
  renderAll();
}
function startReplayFromGame(){
  const L=LIVE;
  if(!L||!L.moves.length) return;
  replayFrom='game';
  startReplay({moves:L.moves.slice(),names:Object.assign({},L.names),result:L.result,live:true,gen:L.gen,me:mode==='cpu'?meSide:0});
}

/* ---------- export ---------- */
function exportText(moves,names,result,when){
  const lines=['[DAMA 기보]','파랑: '+names[1],'빨강: '+names[2],'결과: '+(result?resultLine(result,names):'진행 중'),'일시: '+new Date(when||Date.now()).toLocaleString(LANG==='en'?'en-US':'ko-KR'),''];
  for(let i=0;i<moves.length;i+=2) lines.push((i/2+1)+'. '+notation(moves[i])+(moves[i+1]?'   '+notation(moves[i+1]):''));
  lines.push('','코드: DAMA1:'+moves.map(enc).join(';'));
  return lines.map(l=>T(l)).join('\n');
}
function openExport(){
  let t;
  if(REPLAY) t=exportText(REPLAY.moves,REPLAY.names,REPLAY.result,REPLAY.when);
  else if(LIVE&&LIVE.moves.length) t=exportText(LIVE.moves,LIVE.names,LIVE.result,Date.now());
  else return;
  $('#exText').value=t;$('#exportModal').hidden=false;$('#exCopy').focus();
}
async function copyExport(){
  const ta=$('#exText');
  try{await navigator.clipboard.writeText(ta.value);toast('기보를 복사했습니다.');}
  catch(e){ta.focus();ta.select();toast('전체 선택했습니다. Ctrl+C(⌘C)로 복사하세요.');}
}

/* ---------- tutorial ---------- */
const TUT=[
  {t:'게임의 목표',x:'파랑과 빨강이 번갈아 한 수씩 둡니다. 상대의 말을 모두 잡거나, 상대가 움직일 수 없게 만들면 승리합니다.',g:['RRRRR','.....','.....','.....','BBBBB']},
  {t:'이동',x:'말은 앞쪽과 좌우로 한 칸, 그리고 바로 뒤로 한 칸 움직일 수 있어요. 초록 점은 앞·옆, 속이 빈 초록 고리는 뒤로 가는 칸입니다. 대각선은 안 돼요.',g:['.....','..g..','.gSg.','..u..','.....']},
  {t:'뛰어넘어 잡기',x:'앞이나 옆에 상대 말이 붙어 있고 그 너머가 비어 있으면 뛰어넘어 잡아요. 노란 고리가 착지 칸입니다. 뒤쪽으로는 잡을 수 없어요.',g:['..y..','..x..','..S..','.....','.....']},
  {t:'연속 포획',x:'착지한 자리에서 또 뛰어넘을 수 있으면 이어서 잡을 수 있어요. 멈추고 싶으면 ‘여기서 멈추기’를 누르세요.',g:['.....','.....','.yxy.','.x...','.S...']},
  {t:'승리와 무승부',x:'전멸시키거나 봉쇄(위 그림의 빨강처럼 움직일 수 없게)하면 승리! 포획도 새로운 전진도 없이 40수가 지나면 무승부이고, 앞뒤로 왔다 갔다 하는 건 전진이 아니에요.',g:['RBB..','B....','B....','.....','.....']},
  {t:'수 평가와 코인',x:'수를 둘 때마다 엔진이 평가해 줘요. 한 판을 마치면 코인을 얻고, 상점에서 보드 테마와 말 스타일을 살 수 있어요. 방향키와 Enter로 키보드 조작도 가능합니다.',badges:['best','excellent','miss','mistake','blunder']}
];
let tutI=0;
function renderTut(){
  const p=TUT[tutI],b=$('#tutBoard');
  $('#tutTitle').textContent=p.t;$('#tutText').textContent=p.x;
  b.textContent='';
  if(p.g){
    b.className='mini5';
    for(const row of p.g) for(const ch of row){const c=document.createElement('span');if(ch!=='.'){c.className=ch;c.appendChild(document.createElement('i'));}b.appendChild(c);}
  }else{
    b.className='badgestrip';
    for(const k of p.badges){const sp=document.createElement('span');sp.innerHTML=QI[k];sp.append(QL[k][0]);b.appendChild(sp);}
  }
  const d=$('#tutDots');d.textContent='';
  TUT.forEach((_,i)=>{const e=document.createElement('i');if(i===tutI) e.className='on';d.appendChild(e);});
  $('#tutPrev').disabled=tutI===0;
  $('#tutNext').textContent=tutI===TUT.length-1?'시작하기':'다음';
}
function openTut(){tutI=0;renderTut();$('#tutorial').hidden=false;$('#tutNext').focus();}
function closeTut(){$('#tutorial').hidden=true;if(!SET.tut){SET.tut=true;saveSet();}if(!getProfile()) openOnboard();}

