'use strict';
/*CORE-START*/
const LIMIT=40;
const FWD={1:-1,2:1};
const inb=(r,c)=>r>=0&&r<8&&c>=0&&c<8;
function newBoard(){
  const b=new Int8Array(64);
  for(let c=0;c<8;c++){b[8+c]=2;b[16+c]=2;b[40+c]=1;b[48+c]=1;}
  return b;
}
function steps(p){return [[FWD[p],0],[0,-1],[0,1]];}
/* Quiet moves: forward or sideways 1 step, plus 1 step straight back. Jumps never go backward. */
function simpleFrom(b,p,r,c){
  const out=[];
  for(const [dr,dc] of steps(p)){
    const nr=r+dr,nc=c+dc;
    if(inb(nr,nc)&&b[nr*8+nc]===0) out.push({r:nr,c:nc,fwd:dr!==0,back:false});
  }
  const br=r-FWD[p];
  if(inb(br,c)&&b[br*8+c]===0) out.push({r:br,c,fwd:false,back:true});
  return out;
}
function jumpsFrom(b,p,r,c){
  const out=[],o=3-p;
  for(const [dr,dc] of steps(p)){
    const mr=r+dr,mc=c+dc,lr=r+2*dr,lc=c+2*dc;
    if(inb(lr,lc)&&b[mr*8+mc]===o&&b[lr*8+lc]===0) out.push({r:lr,c:lc,cr:mr,cc:mc});
  }
  return out;
}
function hasMoves(b,p){
  for(let i=0;i<64;i++){
    if(b[i]!==p) continue;
    const r=i>>3,c=i&7;
    if(simpleFrom(b,p,r,c).length||jumpsFrom(b,p,r,c).length) return true;
  }
  return false;
}
function genMoves(b,p){
  const out=[];
  for(let i=0;i<64;i++){
    if(b[i]!==p) continue;
    const r=i>>3,c=i&7;
    for(const m of simpleFrom(b,p,r,c)) out.push({path:[[r,c],[m.r,m.c]],caps:[],fwd:m.fwd,back:m.back});
    const dfs=(bb,cr,cc,path,caps)=>{
      for(const j of jumpsFrom(bb,p,cr,cc)){
        const nb=bb.slice();
        nb[cr*8+cc]=0;nb[j.cr*8+j.cc]=0;nb[j.r*8+j.c]=p;
        const np=[...path,[j.r,j.c]],nc=[...caps,j.cr*8+j.cc];
        out.push({path:np,caps:nc,fwd:false});
        dfs(nb,j.r,j.c,np,nc);
      }
    };
    dfs(b,r,c,[[r,c]],[]);
  }
  return out;
}
function applyMove(b,p,m){
  const nb=b.slice();
  const [sr,sc]=m.path[0];nb[sr*8+sc]=0;
  for(const k of m.caps) nb[k]=0;
  const [er,ec]=m.path[m.path.length-1];nb[er*8+ec]=p;
  return nb;
}
function evaluate(b,p){
  let s=0;
  for(let i=0;i<64;i++){
    const v=b[i];if(!v) continue;
    const r=i>>3,adv=v===1?6-r:r-1;
    s+=(v===p?1:-1)*(100+adv*4);
  }
  return s;
}
/* The CPU searches with its own, more aggressive evaluation (pushes forward, trades down when ahead).
   Move review keeps using the plain evaluate() above so its thresholds stay stable. */
const AIW={adv:8,trade:1.5};
function evalAI(b,p){
  let s=0,mine=0,theirs=0;
  for(let i=0;i<64;i++){
    const v=b[i];if(!v) continue;
    const r=i>>3,adv=v===1?6-r:r-1;
    if(v===p){mine++;s+=100+adv*AIW.adv;}else{theirs++;s-=100+adv*AIW.adv;}
  }
  return s+(mine-theirs)*(32-mine-theirs)*AIW.trade;
}
let DL=0,NODES=0,EV=null;
function negamax(b,p,d,alpha,beta){
  if(DL&&((++NODES)&255)===0&&Date.now()>DL) throw 'T';
  const ms=genMoves(b,p);
  if(ms.length===0) return -10000-d;
  if(d===0) return EV?EV(b,p):evaluate(b,p);
  ms.sort((x,y)=>y.caps.length-x.caps.length);
  let best=-Infinity;
  for(const m of ms){
    const v=-negamax(applyMove(b,p,m),3-p,d-1,-beta,-alpha);
    if(v>best) best=v;
    if(best>alpha) alpha=best;
    if(alpha>=beta) break;
  }
  return best;
}
function chooseMove(b,p,depth,rnd){
  const ms=genMoves(b,p);
  if(!ms.length) return null;
  if(rnd>0&&Math.random()<rnd) return ms[Math.floor(Math.random()*ms.length)];
  for(let i=ms.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[ms[i],ms[j]]=[ms[j],ms[i]];}
  ms.sort((x,y)=>y.caps.length-x.caps.length);
  let best=-Infinity,bm=ms[0];
  EV=evalAI;
  try{
    for(const m of ms){
      const v=-negamax(applyMove(b,p,m),3-p,depth-1,-Infinity,-best);
      if(v>best){best=v;bm=m;}
    }
  }finally{EV=null;}
  return bm;
}
/* Iterative deepening with a time budget: the last fully searched depth decides. */
function chooseTimed(b,p,maxD,ms){
  const root=genMoves(b,p);
  if(!root.length) return null;
  if(root.length===1) return root[0];
  for(let i=root.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[root[i],root[j]]=[root[j],root[i]];}
  root.sort((x,y)=>y.caps.length-x.caps.length);
  let best=root[0];
  DL=Date.now()+ms;NODES=0;EV=evalAI;
  try{
    for(let d=1;d<=maxD;d++){
      let bv=-Infinity,bm=null;
      for(const m of root){
        const v=-negamax(applyMove(b,p,m),3-p,d-1,-Infinity,-bv);
        if(v>bv){bv=v;bm=m;}
      }
      best=bm;
      root.splice(root.indexOf(bm),1);root.unshift(bm);
      if(bv>9000||bv<-9000) break;
    }
  }catch(e){if(e!=='T') throw e;}
  finally{DL=0;EV=null;}
  return best;
}
/* move records: {p, path:[square index...], caps:[square index...]} */
/* Progress = a capture, or a piece reaching a row further than that player has ever reached (the "frontier").
   Stepping forward and back again never counts, so shuffling cannot dodge the 40-ply draw rule. */
const newFr=()=>[0,5,2];
function stepProgress(rec,fr){
  const row=rec.path[rec.path.length-1]>>3;let adv=false;
  if(rec.p===1){if(row<fr[1]){fr[1]=row;adv=true;}}
  else if(row>fr[2]){fr[2]=row;adv=true;}
  return rec.caps.length>0||adv;
}
function enc(rec){return rec.p+'|'+rec.path.join(',')+'|'+rec.caps.join(',');}
function dec(s){const t=String(s).split('|');return {p:+t[0],path:t[1]?t[1].split(',').map(Number):[],caps:t[2]?t[2].split(',').map(Number):[]};}
function fromMove(m,p){return {p,path:m.path.map(([r,c])=>r*8+c),caps:m.caps.slice()};}
function judge(b,mover,noprog){
  const o=3-mover;let n=0;
  for(let i=0;i<64;i++) if(b[i]===o) n++;
  if(n===0) return {winner:mover,why:'wipe'};
  if(!hasMoves(b,o)) return {winner:mover,why:'block'};
  if(noprog>=LIMIT) return {winner:0,why:'stall'};
  return null;
}
function simulate(recs){
  let b=newBoard(),turn=1,noprog=0,result=null,n=0;const fr=newFr();
  for(const rec of recs){
    if(result||rec.p!==turn) return {b,turn,noprog,result,n,bad:true};
    const key=rec.path.join(',')+'/'+rec.caps.join(',');
    const legal=genMoves(b,turn).find(m=>m.path.map(([r,c])=>r*8+c).join(',')+'/'+m.caps.join(',')===key);
    if(!legal) return {b,turn,noprog,result,n,bad:true};
    b=applyMove(b,turn,legal);
    noprog=stepProgress(rec,fr)?0:noprog+1;
    result=judge(b,turn,noprog);
    turn=3-turn;n++;
  }
  return {b,turn,noprog,result,n,bad:false,fr};
}
/* Move review: compare the played move with the engine's best at the same depth.
   best      = no loss against the engine's top choice
   excellent = a small loss (a few rows of advancement at most)
   miss      = a gain of about a piece was available, the played move gave it up (but lost nothing)
   mistake   = a clear loss (more than ~7 rows of advancement, under a piece)
   blunder   = loses about a piece or more compared with the best move
   e = evaluation after the move, from Blue's point of view; bm = engine's preferred move */
const ANALYSIS_DEPTH=4;
const nPieces=(b,p)=>{let n=0;for(let i=0;i<64;i++) if(b[i]===p) n++;return n;};
/* follow best play for a few plies after the played move; how many of my pieces vanish, and the first capture */
function lineLoss(b,p,pm,plies){
  let cur=applyMove(b,p,pm),side=3-p,first=null;
  const start=nPieces(b,p);
  for(let i=0;i<plies;i++){
    const ms=genMoves(cur,side);if(!ms.length) break;
    ms.sort((x,y)=>y.caps.length-x.caps.length);
    let bv=-Infinity,bm2=ms[0];
    for(const m of ms){const v=-negamax(applyMove(cur,side,m),3-side,2,-Infinity,-bv);if(v>bv){bv=v;bm2=m;}}
    if(side!==p&&bm2.caps.length&&!first) first=fromMove(bm2,side);
    cur=applyMove(cur,side,bm2);side=3-side;
  }
  return {n:Math.max(0,start-nPieces(cur,p)),first};
}
const keyOf=m=>m.path.map(([r,c])=>r*8+c).join(',')+'/'+m.caps.join(',');
function analyze(b,p,rec,depth){
  const ms=genMoves(b,p);
  const key=rec.path.join(',')+'/'+rec.caps.join(',');
  const pm=ms.find(m=>keyOf(m)===key);
  if(!pm) return {kind:null,delta:0,gain:0,e:0,bm:null};
  const played=-negamax(applyMove(b,p,pm),3-p,depth-1,-Infinity,Infinity);
  const e=p===1?played:-played;
  if(ms.length<2) return {kind:null,forced:true,delta:0,gain:0,e,bm:null};
  ms.sort((x,y)=>y.caps.length-x.caps.length);
  let best=-Infinity,bm=null;
  for(const m of ms){
    const v=-negamax(applyMove(b,p,m),3-p,depth-1,-Infinity,-best);
    if(v>best){best=v;bm=m;}
  }
  const stat=evaluate(b,p),delta=best-played,gain=best-stat;
  let kind=null;
  if(delta<=0) kind='best';
  else if(delta<=12) kind='excellent';
  else if(delta>=70&&gain>=70&&played>stat-70) kind='miss';
  else if(delta>=100) kind='blunder';
  else if(delta>=28) kind='mistake';
  /* facts for the coaching text: what the opponent can grab after the played move, and what the best move does instead */
  const rp=genMoves(applyMove(b,p,pm),3-p).sort((x,y)=>y.caps.length-x.caps.length)[0];
  const lost=rp?rp.caps.length:0;
  const bLost=genMoves(applyMove(b,p,bm),3-p).reduce((m,x)=>Math.max(m,x.caps.length),0);
  const soon=(kind==='blunder'||kind==='mistake')&&!lost?lineLoss(b,p,pm,4):{n:0,first:null};
  const info={lost,reply:lost?fromMove(rp,3-p):null,soonN:soon.n,soonMove:soon.first,pcaps:pm.caps.length,bcaps:bm.caps.length,bLost};
  return {kind,delta,gain,best,played,e,info,bm:(kind&&kind!=='best'&&kind!=='excellent')?fromMove(bm,p):null};
}
/*CORE-END*/

const $=s=>document.querySelector(s);
const LV={1:{d:2,rnd:.3},2:{d:4,rnd:0},3:{d:8,ms:700},4:{d:14,ms:1800}};
const sq=i=>'abcdefgh'[i&7]+(8-(i>>3));
const notation=rec=>rec.path.map(sq).join(rec.caps.length?'×':'-');
const clean=s=>String(s||'').replace(/[\u0000-\u001f<>]/g,'').replace(/\s+/g,' ').trim().slice(0,12);
const count=(b,p)=>{let n=0;for(let i=0;i<64;i++) if(b[i]===p) n++;return n;};
const store={
  get(k,d){try{const v=localStorage.getItem(k);return v==null?d:JSON.parse(v);}catch(e){return d;}},
  set(k,v){try{localStorage.setItem(k,JSON.stringify(v));}catch(e){}}
};

