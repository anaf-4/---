'use strict';
/* ---------- solo rating, bot progress and rewards ---------- */
const QLV_RATING={1:700,2:1600,3:2400,4:3000};
const oppRating=()=>CFG.bot?botParams(CFG.bot).r:QLV_RATING[+$('#level').value||2];
/* Elo against the bot's rating. Coach games are practice and never change the rating. */
function rateSolo(L){
  if(mode!=='cpu'||!L.result||L.rated) return;
  L.rated=true;
  if(CFG.bot&&CFG.bot.kind==='coach') return;
  if(L.moves.length<6) return;
  const p=getProfile();if(!p) return;
  const sc=L.result.winner===0?.5:L.result.winner===meSide?1:0;
  const exp=1/(1+Math.pow(10,(oppRating()-p.rating)/400));
  const dl=Math.round(32*(sc-exp));
  p.rating=Math.max(100,p.rating+dl);store.set('dama.profile',p);L.srd=dl;updateCoinUI();
}
const botRec=()=>store.get('dama.botrec',{});
function botProgress(L){
  const b=CFG.bot;if(!b||b.kind!=='bot'||!L.result) return;
  const r=L.result,rec=botRec(),a=rec[b.id]||[0,0,0],won=r.winner===meSide;
  const first=won&&a[0]===0;
  a[won?0:r.winner===0?2:1]++;rec[b.id]=a;store.set('dama.botrec',rec);
  const msgs=[];let bonus=0;
  if(first){
    bonus+=botReward(botParams(b).r,'w');msgs.push('첫 승리 보너스');
    const cat=BOT_CATS.find(c=>c.id===b.cat);
    if(cat&&cat.bots.every(x=>(rec[x.id]||[0])[0]>0)){
      const cl=store.get('dama.catclear',[]);
      if(!cl.includes(cat.id)){
        cl.push(cat.id);store.set('dama.catclear',cl);
        bonus+=40+Math.round(cat.bots.reduce((s,x)=>s+botParams(x).r,0)/cat.bots.length/40);msgs.push(cat.name+' 전원 격파!');
        if(cl.length>=BOT_CATS.length){for(const k of ['board:forest','piece:chip']) if(!W.own.includes(k)) W.own.push(k);msgs.push('전체 격파 보상: 숲 보드 · 칩 말 해금');}
      }
    }
  }
  if(bonus){W.coins+=bonus;saveW();updateCoinUI();}
  L.botNote=msgs.length?msgs.join(' · ')+(bonus?' (+'+bonus+' 코인)':''):'';
}
const catProgress=c=>{const rec=botRec();return c.bots.filter(x=>(rec[x.id]||[0])[0]>0).length;};
/* replay: the few moves that mattered most */
function renderKeyMoments(R,Q,ready){
  const box=$('#rpKey');box.textContent='';
  if(!ready){box.hidden=true;return;}
  const items=[];
  R.moves.forEach((m,i)=>{
    const q=Q[i];if(!q||!(q.k==='blunder'||q.k==='mistake'||q.k==='miss')) return;
    if(R.me&&m.p!==R.me) return;
    items.push({i,q,m});
  });
  items.sort((a,b)=>b.q.delta-a.q.delta);
  const top=items.slice(0,3).sort((a,b)=>a.i-b.i);
  box.hidden=false;
  const h=document.createElement('b');h.textContent=top.length?'갈림길 — 승부에 영향을 준 수':'갈림길';box.appendChild(h);
  if(!top.length){const p=document.createElement('p');p.textContent=(R.me?'내가 둔 수에':'이 대국에')+' 큰 실수가 없었어요. 깔끔한 대국이에요!';box.appendChild(p);return;}
  for(const t of top){
    const b=document.createElement('button');b.type='button';b.className='keymv';
    b.innerHTML='<span class="ki">'+QI[t.q.k]+'</span>';
    const s=document.createElement('span');s.className='kt';
    s.textContent=(t.i+1)+'수 '+nm(t.m.p)+' ‘'+notation(t.m)+'’ · '+QL[t.q.k][0]+(t.q.bm?' → 추천 ‘'+notation(t.q.bm)+'’':'');
    b.appendChild(s);
    b.addEventListener('click',()=>{stopReplayTimer();replayStep(t.i+1);if(t.q.bm){R.showBest=true;replayView();renderAll();}});
    box.appendChild(b);
  }
}
