'use strict';
/* ---------- language: Korean (source) / English (translated at display time) ---------- */
let LANG=store.get('dama.lang',null)||((navigator.language||'ko').toLowerCase().startsWith('ko')?'ko':'en');
const HANGUL=/[가-힣]/;
const I18N={exact:new Map(),pats:[]};
(function(){
  for(const [ko,en] of I18N_DATA){
    if(!/\{/.test(ko)){I18N.exact.set(ko,en);continue;}
    const names=[];let re='^';
    for(const p of ko.split(/(\{[^}]+\})/)){
      const m=p.match(/^\{(\w+)(?:=(.+))?\}$/);
      if(m){names.push(m[1]);re+='('+(m[2]||'.+?')+')';}
      else re+=p.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
    }
    I18N.pats.push({re:new RegExp(re+'$'),names,en});
  }
})();
function trFull(c){
  if(I18N.exact.has(c)) return I18N.exact.get(c);
  for(const p of I18N.pats){
    const m=c.match(p.re);if(!m) continue;
    return p.en.replace(/\{(\w+)(?::(\w+))?\}/g,(_,k,f)=>{
      let v=m[p.names.indexOf(k)+1]||'';if(HANGUL.test(v)) v=trCore(v);
      return f==='piece'?v+' '+(parseFloat(v)===1?'piece':'pieces'):v;
    });
  }
  return null;
}
function trCore(c){
  let r=trFull(c);if(r!==null) return r;
  if(c.startsWith('· ')) return '· '+trCore(c.slice(2));
  if(c.includes('\n')) return c.split('\n').map(trCore).join('\n');
  for(const sep of [' — ',' · ']) if(c.includes(sep)) return c.split(sep).map(trCore).join(sep);
  const sents=c.split(/(?<=[.!?…])\s+/);
  if(sents.length>1) return sents.map(trCore).join(' ');
  const m=c.match(/^(.*?)\s*([.!?…·:]+)$/);
  if(m&&m[1]){const r2=trFull(m[1]);if(r2!==null) return r2+(m[2]===':'?': ':m[2]).replace(/ $/,'');}
  return c;
}
function tr(s){
  if(LANG!=='en'||!HANGUL.test(s)) return s;
  const lead=s.match(/^\s*/)[0],trail=s.match(/\s*$/)[0];
  return lead+trCore(s.trim())+trail;
}
const T=tr; /* for strings that never reach the DOM as text (export text) */
/* DOM translation with the original kept so the language can be switched back and forth */
const I18N_ATTRS=['aria-label','title','placeholder','alt'];
const textOrig=new WeakMap(),attrOrig=new WeakMap();
const skip=(n,attr)=>{const e=n.nodeType===1?n:n.parentElement;return !e||!!e.closest(attr?'[data-notr],script,style':'[data-notr],script,style,textarea');};
function doText(n){
  if(skip(n)) return;
  const v=n.nodeValue,rec=textOrig.get(n);
  if(LANG==='en'){
    if(rec&&rec.out===v) return;
    if(!HANGUL.test(v)) return;
    const t=tr(v);textOrig.set(n,{ko:v,out:t});if(t!==v) n.nodeValue=t;
  }else if(rec&&rec.out===v){n.nodeValue=rec.ko;textOrig.delete(n);}
}
function doAttrs(el){
  if(el.nodeType!==1||skip(el,true)) return;
  let rec=attrOrig.get(el);
  for(const a of I18N_ATTRS){
    if(!el.hasAttribute(a)) continue;
    const v=el.getAttribute(a),r=rec&&rec[a];
    if(LANG==='en'){
      if(r&&r.out===v) continue;
      if(!HANGUL.test(v)) continue;
      const t=tr(v);if(!rec){rec={};attrOrig.set(el,rec);}rec[a]={ko:v,out:t};if(t!==v) el.setAttribute(a,t);
    }else if(r&&r.out===v){el.setAttribute(a,r.ko);delete rec[a];}
  }
}
function walk(root){
  if(root.nodeType===3){doText(root);return;}
  if(root.nodeType!==1) return;
  doAttrs(root);
  const w=document.createTreeWalker(root,NodeFilter.SHOW_ELEMENT|NodeFilter.SHOW_TEXT);
  let n;while((n=w.nextNode())){if(n.nodeType===3) doText(n);else doAttrs(n);}
}
function applyLang(){
  document.documentElement.lang=LANG;
  walk(document.body);
  const lb=$('#langBtn');if(lb) lb.textContent=LANG==='en'?'한국어':'English';
  const sl=$('#setLang');if(sl) sl.value=LANG;
}
function setLang(l){
  LANG=l;store.set('dama.lang',l);applyLang();
  /* things rendered from state are refreshed so every string comes from the right source */
  if(G&&!$('#game').hidden) renderAll();
}
new MutationObserver(ms=>{
  for(const m of ms){
    if(m.type==='childList') m.addedNodes.forEach(walk);
    else if(m.type==='characterData') doText(m.target);
    else if(m.type==='attributes') doAttrs(m.target);
  }
}).observe(document.body,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:I18N_ATTRS});
$('#langBtn').addEventListener('click',()=>setLang(LANG==='en'?'ko':'en'));
$('#setLang').addEventListener('change',e=>setLang(e.target.value));
applyLang();
