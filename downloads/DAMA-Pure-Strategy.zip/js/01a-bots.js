'use strict';
/* ---------- bots: procedural avatars, coach levels, roster, search styles ---------- */
/* Avatar spec: {skin,hair,hs:0-5 hair style,beard:0-3,glasses,hat:0-3,phones,shirt,bg,robot} */
function avatarSvg(a){
  const id='a'+Math.random().toString(36).slice(2,7);
  let s='<svg viewBox="0 0 64 64" aria-hidden="true"><defs><clipPath id="'+id+'"><rect width="64" height="64" rx="8"/></clipPath></defs><g clip-path="url(#'+id+')"><rect width="64" height="64" fill="'+(a.bg||'#5b6b63')+'"/>';
  if(a.robot){
    s+='<rect x="14" y="14" width="36" height="36" rx="7" fill="#2e3638" stroke="#9aa6a1" stroke-width="2"/>';
    for(let i=0;i<4;i++){s+='<rect x="'+(19+i*8)+'" y="8" width="3" height="6" fill="#9aa6a1"/><rect x="'+(19+i*8)+'" y="50" width="3" height="6" fill="#9aa6a1"/>';}
    s+='<text x="32" y="40" text-anchor="middle" font-size="22" font-weight="800" fill="#e9ece8" font-family="sans-serif">'+(a.robot===true?'1':a.robot)+'</text></g></svg>';
    return s;
  }
  const skin=a.skin||'#e8b98f',hair=a.hair||'#3b2a20',shirt=a.shirt||'#4a6a8a',hs=a.hs||0;
  /* back hair */
  if(hs===3) s+='<path d="M18 28C16 52 48 52 46 28L46 18 18 18Z" fill="'+hair+'"/>';
  if(hs===4) s+='<circle cx="32" cy="9" r="6" fill="'+hair+'"/>';
  /* body */
  s+='<path d="M6 66C6 50 16 45 32 45S58 50 58 66Z" fill="'+shirt+'"/><path d="M26 45L32 52 38 45Z" fill="rgba(0,0,0,.18)"/>';
  s+='<rect x="27" y="36" width="10" height="11" rx="3" fill="'+skin+'"/><rect x="27" y="42" width="10" height="5" fill="rgba(0,0,0,.12)"/>';
  /* ears and head */
  s+='<ellipse cx="19.5" cy="28" rx="2.6" ry="3.4" fill="'+skin+'"/><ellipse cx="44.5" cy="28" rx="2.6" ry="3.4" fill="'+skin+'"/>';
  s+='<ellipse cx="32" cy="27" rx="12.5" ry="14.5" fill="'+skin+'"/>';
  /* front hair */
  if(hs===1) s+='<path d="M19 26C17 10 47 10 45 26C42 19 36 17 32 17C28 17 22 19 19 26Z" fill="'+hair+'"/>';
  if(hs===2) s+='<path d="M19 28C16 8 48 8 45 26C44 21 40 18 36 17C30 21 24 22 19 28Z" fill="'+hair+'"/>';
  if(hs===3) s+='<path d="M19 30C16 8 48 8 45 30C43 22 38 18 32 18C26 18 21 22 19 30Z" fill="'+hair+'"/>';
  if(hs===4) s+='<path d="M19 26C17 10 47 10 45 26C42 19 36 17 32 17C28 17 22 19 19 26Z" fill="'+hair+'"/>';
  if(hs===5) for(const [x,y,r] of [[22,17,6],[29,13,6.5],[37,13,6.5],[43,18,6],[19,24,4.5],[45,24,4.5]]) s+='<circle cx="'+x+'" cy="'+y+'" r="'+r+'" fill="'+hair+'"/>';
  /* face */
  s+='<ellipse cx="26.5" cy="27" rx="1.8" ry="2.2" fill="#1c1c1c"/><ellipse cx="37.5" cy="27" rx="1.8" ry="2.2" fill="#1c1c1c"/>';
  s+='<path d="M23.5 23.2Q26.5 21.6 29.4 23" stroke="'+hair+'" stroke-width="1.6" fill="none" stroke-linecap="round"/><path d="M34.6 23Q37.5 21.6 40.5 23.2" stroke="'+hair+'" stroke-width="1.6" fill="none" stroke-linecap="round"/>';
  s+='<path d="M32 28.5L30.6 33.2H33.4" stroke="rgba(0,0,0,.25)" stroke-width="1.3" fill="none" stroke-linecap="round" stroke-linejoin="round"/>';
  s+='<path d="M27.5 36.4Q32 39.6 36.5 36.4" stroke="#8a3b3b" stroke-width="1.7" fill="none" stroke-linecap="round"/>';
  /* beard */
  if(a.beard===1) s+='<path d="M20 30C21 42 43 42 44 30C42 38 38 40 32 40C26 40 22 38 20 30Z" fill="'+hair+'" opacity=".35"/>';
  if(a.beard===2) s+='<path d="M19.5 28C19 46 45 46 44.5 28C43 36 39 38.5 32 38.5C25 38.5 21 36 19.5 28Z" fill="'+hair+'"/><path d="M26 34.6Q32 32.6 38 34.6Q32 37.4 26 34.6Z" fill="'+hair+'"/><path d="M27.5 36.4Q32 39 36.5 36.4" stroke="#c98" stroke-width="1.2" fill="none"/>';
  if(a.beard===3) s+='<path d="M28 39Q32 46 36 39Q32 41 28 39Z" fill="'+hair+'"/><path d="M26 34.6Q32 32.8 38 34.6Q32 36.4 26 34.6Z" fill="'+hair+'"/>';
  /* glasses */
  if(a.glasses) s+='<g fill="rgba(255,255,255,.12)" stroke="#222" stroke-width="1.4"><circle cx="26.5" cy="27" r="4.6"/><circle cx="37.5" cy="27" r="4.6"/><path d="M31.1 27H32.9" fill="none"/></g>';
  /* headwear */
  if(a.hat===1) s+='<path d="M18.5 22C18 6 46 6 45.5 22Z" fill="'+(a.hatc||'#c0392b')+'"/><path d="M17 22.5H47" stroke="'+(a.hatc||'#c0392b')+'" stroke-width="4" stroke-linecap="round"/>';
  if(a.hat===2) s+='<path d="M18.5 21C18 5 46 5 45.5 21Z" fill="'+(a.hatc||'#33507a')+'"/><rect x="18" y="18" width="28" height="4.5" rx="2" fill="rgba(255,255,255,.25)"/>';
  if(a.hat===3) s+='<rect x="19" y="15.5" width="26" height="4" rx="2" fill="'+(a.hatc||'#e67e22')+'"/>';
  if(a.phones) s+='<path d="M18.5 28C17 6 47 6 45.5 28" stroke="#222" stroke-width="2.4" fill="none"/><rect x="15.4" y="25" width="5.4" height="9" rx="2.4" fill="#222"/><rect x="43.2" y="25" width="5.4" height="9" rx="2.4" fill="#222"/>';
  return s+'</g></svg>';
}
const SK=['#f1c9a5','#e8b98f','#d09a70','#a8754f','#7a4f35'],HC=['#2b1f18','#4a3224','#7a5230','#b8863f','#d8b25a','#9a9a9a','#1c1c1c','#a33b2a'];
const COACH_AV={skin:SK[1],hair:'#4a3224',hs:1,beard:2,glasses:true,shirt:'#41566b',bg:'#6b7f87'};
/* ten fixed coach levels. rating is an estimate from AI-vs-AI play, not a chess-style Elo */
const COACH_LEVELS=[
  {n:'입문',r:100,d:1,rnd:.85},{n:'초심자',r:400,d:1,rnd:.5},{n:'초심자',r:600,d:2,rnd:.4},{n:'중급',r:900,d:2,rnd:.2},{n:'중급 II',r:1200,d:3,rnd:.1},
  {n:'고급',r:1600,d:4,rnd:0},{n:'전문가',r:2000,d:6,ms:500},{n:'마스터',r:2400,d:8,ms:700},{n:'그랜드마스터',r:2800,d:11,ms:1200},{n:'최대',r:3200,d:14,ms:1800}
];
/* search styles change only how the engine weighs things */
const STYLES={balanced:{adv:8,trade:1.5},rush:{adv:16,trade:3},wall:{adv:3,trade:.6},swap:{adv:6,trade:6}};
const STYLE_LABEL={balanced:'균형형',rush:'돌격형',wall:'수비형',swap:'교환형'};
const BP=(r,d,rnd,ms)=>({r,d,rnd:rnd||0,ms:ms||0});
/* roster: categories -> bots */
const BOT_CATS=[
  {id:'novice',name:'입문자',bots:[
    {id:'momo',name:'모모',q:'말이 어떻게 움직이는지 이제 막 배우고 있어요!',p:BP(100,1,.85),av:{skin:SK[0],hair:HC[3],hs:2,shirt:'#e07a5f',bg:'#7a8f7b'}},
    {id:'haneul',name:'하늘',q:'이겨도 되나요? 진짜로요?',p:BP(250,1,.7),av:{skin:SK[1],hair:HC[1],hs:1,hat:1,shirt:'#5b8def',bg:'#8a7f6b'}},
    {id:'bori',name:'보리',q:'일단 앞으로 가 볼게요.',p:BP(400,1,.5),av:{skin:SK[2],hair:HC[0],hs:5,shirt:'#f2c14e',bg:'#6b8a82'}},
    {id:'duri',name:'두리',q:'잡히기 전에 먼저 잡을 거예요!',p:BP(500,1,.35),av:{skin:SK[0],hair:HC[7],hs:4,shirt:'#6bbf8a',bg:'#7a6b8a'}}]},
  {id:'beginner',name:'초심자',bots:[
    {id:'namu',name:'나무',q:'천천히, 하지만 꾸준히 둬요.',p:BP(600,2,.4),av:{skin:SK[1],hair:HC[2],hs:1,beard:1,shirt:'#3f7d5a',bg:'#8a8a6b'}},
    {id:'haedeun',name:'해든',q:'한 수 앞은 보고 있어요.',p:BP(750,2,.3),av:{skin:SK[3],hair:HC[6],hs:2,shirt:'#b5483a',bg:'#6b7f8a'}},
    {id:'sori',name:'소리',q:'수비가 최고의 공격이죠.',p:BP(900,2,.2),st:'wall',av:{skin:SK[0],hair:HC[1],hs:3,shirt:'#8a6bb5',bg:'#6b8a76'}},
    {id:'jihu',name:'지후',q:'공격 앞으로! 뒤는 몰라요.',p:BP(1000,2,.1),st:'rush',av:{skin:SK[2],hair:HC[0],hs:1,hat:3,shirt:'#d9822b',bg:'#8a6b6b'}}]},
  {id:'mid',name:'중급',bots:[
    {id:'maru',name:'마루',q:'3수 앞까지는 읽어요.',p:BP(1200,3,.1),av:{skin:SK[1],hair:HC[4],hs:2,glasses:true,shirt:'#4a6a8a',bg:'#7a8a6b'}},
    {id:'ian',name:'이안',q:'먼저 치고 나갑니다.',p:BP(1300,3,0),st:'rush',av:{skin:SK[3],hair:HC[6],hs:1,shirt:'#a33b3b',bg:'#6b6b8a'}},
    {id:'seoyun',name:'서윤',q:'빈틈은 보여 주지 않아요.',p:BP(1450,3,0),st:'wall',av:{skin:SK[0],hair:HC[2],hs:3,glasses:true,shirt:'#3a6b6b',bg:'#8a7a6b'}},
    {id:'doyun',name:'도윤',q:'계산은 제 특기예요.',p:BP(1600,4,0),av:{skin:SK[2],hair:HC[1],hs:1,beard:3,shirt:'#5a5a7a',bg:'#6b8a8a'}}]},
  {id:'adv',name:'고급',bots:[
    {id:'hajun',name:'하준',q:'실수는 용서하지 않아요.',p:BP(1800,5,0,400),av:{skin:SK[1],hair:HC[0],hs:1,beard:1,glasses:true,shirt:'#2f4858',bg:'#7b8a6b'}},
    {id:'yuna',name:'유나',q:'깊이 읽으면 길이 보여요.',p:BP(2000,6,0,600),av:{skin:SK[0],hair:HC[7],hs:4,shirt:'#7a3f6b',bg:'#6b7a8a'}},
    {id:'siwoo',name:'시우',q:'교환하면서 몰아붙입니다.',p:BP(2200,7,0,700),st:'swap',av:{skin:SK[3],hair:HC[6],hs:2,beard:2,shirt:'#3b3b3b',bg:'#8a6b7a'}}]},
  {id:'master',name:'마스터',bots:[
    {id:'arin',name:'아린',q:'이 판은 이미 읽었어요.',p:BP(2400,8,0,700),av:{skin:SK[0],hair:HC[5],hs:3,shirt:'#2d4a3e',bg:'#6b8a7a'}},
    {id:'teo',name:'태오',q:'뚫을 수 있으면 뚫어 보세요.',p:BP(2600,10,0,1000),st:'wall',av:{skin:SK[4],hair:HC[6],hs:1,beard:2,glasses:true,shirt:'#1f2d4a',bg:'#8a8a6b'}},
    {id:'raon',name:'라온',q:'최선만 둡니다.',p:BP(2800,12,0,1400),av:{skin:SK[1],hair:HC[5],hs:2,beard:1,shirt:'#4a2d2d',bg:'#6b6b6b'}}]},
  {id:'quirk',name:'성격파',bots:[
    {id:'charge',name:'돌격대장',q:'후퇴는 없다! 전진, 전진!',p:BP(1400,3,.05),st:'rush',av:{skin:SK[2],hair:HC[7],hs:1,hat:1,hatc:'#a33b2a',shirt:'#6b3f2a',bg:'#8a6b5b'}},
    {id:'wall',name:'철벽',q:'한 칸도 내주지 않겠어요.',p:BP(1400,3,.05),st:'wall',av:{skin:SK[3],hair:HC[5],hs:0,beard:2,shirt:'#4a5a6b',bg:'#6b7a7a'}},
    {id:'swap',name:'교환왕',q:'하나 주고 하나 받는 게 제일 재밌어요.',p:BP(1400,3,.05),st:'swap',av:{skin:SK[1],hair:HC[3],hs:5,glasses:true,shirt:'#7a6b2a',bg:'#7a6b8a'}},
    {id:'joker',name:'장난꾸러기',q:'가끔 엉뚱한 수를 두는 게 매력이죠.',p:BP(1500,4,.25),av:{skin:SK[0],hair:HC[4],hs:5,hat:2,hatc:'#8a3fa3',shirt:'#c0568a',bg:'#6b8a6b'}}]},
  {id:'job',name:'직업별',bots:[
    {id:'athlete',name:'한 선수',q:'체력은 자신 있어요. 끝까지 달려요!',p:BP(1100,3,.15),st:'rush',av:{skin:SK[3],hair:HC[6],hs:1,hat:3,hatc:'#e74c3c',shirt:'#c0392b',bg:'#6b7f6b'}},
    {id:'musician',name:'리듬',q:'박자를 맞춰서 한 수 한 수.',p:BP(900,2,.2),av:{skin:SK[1],hair:HC[7],hs:3,phones:true,shirt:'#2b2b4a',bg:'#7a6b8a'}},
    {id:'chef',name:'요리사 정',q:'수 읽기도 요리처럼, 불 조절이 중요해요.',p:BP(1000,2,.1),st:'balanced',av:{skin:SK[0],hair:HC[1],hs:0,beard:3,hat:2,hatc:'#eeeeee',shirt:'#f4f4f4',bg:'#8a7a6b'}},
    {id:'painter',name:'화가 솔',q:'판 위에 그림을 그리듯 둡니다.',p:BP(1300,3,.1),av:{skin:SK[2],hair:HC[2],hs:4,hat:1,hatc:'#3a7a8a',shirt:'#8a5a3a',bg:'#6b8a8a'}},
    {id:'explorer',name:'탐험가 윤',q:'모르는 길로 가 보는 게 좋아요.',p:BP(1700,4,.08),st:'rush',av:{skin:SK[3],hair:HC[0],hs:1,hat:1,hatc:'#7a6b2a',glasses:true,shirt:'#5a6b3a',bg:'#7a8a6b'}}]},
  {id:'adaptive',name:'적응형',bots:[
    {id:'adapt',name:'벗',q:'당신의 실력에 맞춰 강해지거나 약해져요.',adaptive:true,p:BP(900,2,.2),av:{skin:SK[0],hair:HC[4],hs:2,shirt:'#3f7d9a',bg:'#6b8a82'}}]},
  {id:'engine',name:'엔진',bots:[
    {id:'eng',name:'다마 엔진',q:'계산 시작.',p:BP(3000,12,0,1500),av:{robot:true,bg:'#3a4a4f'}},
    {id:'engmax',name:'다마 엔진 MAX',q:'최대 출력으로 둡니다.',p:BP(3200,14,0,1800),av:{robot:'M',bg:'#4a3a3a'}}]}
];
const BOT_BY_ID={};for(const c of BOT_CATS) for(const b of c.bots){b.cat=c.id;b.kind='bot';BOT_BY_ID[b.id]=b;}
const adaptIdx=()=>Math.max(0,Math.min(9,+store.get('dama.adapt',3)||0));
/* the live search settings of a bot (adaptive bots follow the player) */
function botParams(b){
  if(b.adaptive){const l=COACH_LEVELS[adaptIdx()];return {r:l.r,d:l.d,rnd:l.rnd||0,ms:l.ms||0,st:'balanced'};}
  return {r:b.p.r,d:b.p.d,rnd:b.p.rnd,ms:b.p.ms,st:b.st||'balanced'};
}
function botRating(b){return botParams(b).r;}
function pickBotMove(bd,p,cfg){
  const st=STYLES[cfg.st||'balanced']||STYLES.balanced,old=[AIW.adv,AIW.trade];
  AIW.adv=st.adv;AIW.trade=st.trade;
  try{
    if(cfg.rnd>0&&Math.random()<cfg.rnd){const ms=genMoves(bd,p);return ms.length?ms[Math.floor(Math.random()*ms.length)]:null;}
    if((cfg.r||0)>=900||(cfg.r===undefined&&cfg.d>=4)){const bm=bookMove(bd,p);if(bm) return bm;const tm=tbMove(bd,p);if(tm) return tm;}
    return cfg.ms?chooseTimed(bd,p,cfg.d,cfg.ms):chooseMove(bd,p,cfg.d,0);
  }finally{AIW.adv=old[0];AIW.trade=old[1];}
}
const botReward=(r,res)=>res==='w'?Math.round(6+r/45):res==='d'?Math.round(3+r/150):Math.round(2+r/400);
