'use strict';
/* ---------- accessibility helpers ---------- */
const srEl=$('#sr');
function announce(text){srEl.textContent='';setTimeout(()=>{srEl.textContent=text;},30);}
function announceMove(rec,L){
  const n=L.names||{},who=n[rec.p]||('플레이어 '+rec.p),to=rec.path[rec.path.length-1];
  let s=who+' '+sq(rec.path[0])+'에서 '+sq(to)+'로 '+(rec.caps.length?'뛰어서 말 '+rec.caps.length+'개를 잡았습니다.':'이동했습니다.');
  announce(s);
}
/* radio groups: arrow keys move the choice, only the checked one is in the tab order */
function rovingInit(box){
  const rs=[...box.querySelectorAll('[role="radio"]')];
  const on=rs.find(r=>r.getAttribute('aria-checked')==='true')||rs[0];
  rs.forEach(r=>r.tabIndex=r===on?0:-1);
}
document.addEventListener('keydown',e=>{
  const t=e.target;
  if(t&&t.getAttribute&&t.getAttribute('role')==='radio'&&/^Arrow(Left|Right|Up|Down)$/.test(e.key)){
    const grp=t.closest('[role="radiogroup"]');if(!grp) return;
    const rs=[...grp.querySelectorAll('[role="radio"]')],i=rs.indexOf(t),d=/Right|Down/.test(e.key)?1:-1;
    const nx=rs[(i+d+rs.length)%rs.length];
    const gi=[...document.querySelectorAll('[role="radiogroup"]')].indexOf(grp);
    e.preventDefault();nx.click();
    const g2=document.querySelectorAll('[role="radiogroup"]')[gi];
    const f=g2&&(g2.querySelector('[role="radio"][aria-checked="true"]')||g2.querySelector('[role="radio"]'));if(f) f.focus();
    return;
  }
  const open=[...document.querySelectorAll('.modal:not([hidden]),.result:not([hidden])')].pop();
  if(!open) return;
  if(e.key==='Escape'){
    const x=open.querySelector('.x');
    if(x){e.preventDefault();x.click();}
    else if(open.id==='result'){e.preventDefault();$('#viewBoard').click();}
    return;
  }
  if(e.key!=='Tab') return;
  const f=[...open.querySelectorAll('button,input,select,textarea,a[href],[tabindex]')].filter(el=>!el.disabled&&el.tabIndex>=0&&!el.closest('[hidden]'));
  if(!f.length) return;
  const first=f[0],last=f[f.length-1];
  if(!open.contains(document.activeElement)){e.preventDefault();first.focus();}
  else if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}
  else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}
});
/* give focus back to whatever opened a dialog when it closes */
{
  const prev=new WeakMap();
  const mo=new MutationObserver(ms=>{
    for(const m of ms){
      const el=m.target;if(!el.classList||!(el.classList.contains('modal')||el.classList.contains('result'))) continue;
      if(el.hidden){const p=prev.get(el);if(p&&document.contains(p)&&!p.closest('[hidden]')) try{p.focus({preventScroll:true});}catch(e){} prev.delete(el);}
      else if(!prev.has(el)){const a=document.activeElement;if(a&&a!==document.body&&!el.contains(a)) prev.set(el,a);}
    }
  });
  document.querySelectorAll('.modal,.result').forEach(el=>mo.observe(el,{attributes:true,attributeFilter:['hidden']}));
}
$('#skipBoard').addEventListener('click',e=>{e.preventDefault();const c=document.querySelector('.cell[tabindex="0"]')||cells[focusIdx];if(c) c.focus();});
