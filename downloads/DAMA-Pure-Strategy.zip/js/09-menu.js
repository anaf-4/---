'use strict';
/* ---------- screens and menu ---------- */
const SCREENS=['scr-load','scr-menu','scr-coach','scr-bots','game'];
function show(id){
  for(const s of SCREENS){const el=document.getElementById(s);el.hidden=s!==id;el.classList.remove('out');}
  window.scrollTo(0,0);
}
function chromeUI(){
  $('#lvl-wrap').hidden=mode!=='cpu'||!!CFG.bot;
  $('#roomChip').hidden=mode!=='online';
  $('#newgame').hidden=mode==='online';
  $('#undo').hidden=mode==='online'&&role===0;
  $('#drawBtn').hidden=mode==='online'&&role===0;
  $('#chat').hidden=mode!=='online';
  $('#chatRow').hidden=role===0;
  $('#resign').hidden=true;
  applyFlip();
}
function panel(name,focus){
  document.querySelectorAll('#scr-menu .menu').forEach(m=>{m.hidden=m.dataset.panel!==name;});
  if(name==='games') renderGames();
  if(name==='online') updateOnlineUI();
  if(name==='rooms') loadRooms();
  if(name==='shop') renderShop();
  if(name==='stats') renderStats();
  if(name==='settings'){$('#setCb').checked=!!SET.cb;$('#setLimit').value=String(SET.limit||0);$('#setCoach').checked=SET.coach!==false;$('#setFs').value=String(SET.fs||1);$('#setRm').checked=!!SET.rm;$('#setHc').checked=!!SET.hc;}
  if(name==='main'){updateCoinUI();if(store.get('dama.session',null)) checkResume();else $('#resumeBtn').hidden=true;}
  if(focus!==false){const b=document.querySelector('#scr-menu .menu[data-panel="'+name+'"] button');if(b) b.focus();}
}
function startGame(m,names,lv,opts){
  leaveRoom();mode=m;role=0;CFG={names,bot:(opts&&opts.bot)||null,hints:(opts&&opts.hints!=null)?opts.hints:Infinity};meSide=(opts&&opts.me)||1;flip=m==='cpu'&&meSide===2;
  if(lv) $('#level').value=String(lv);
  show('game');chromeUI();newGame();
}
function toMenu(p){
  stopReplayTimer();REPLAY=null;
  if(mode==='online'&&LIVE&&LIVE.result) store.set('dama.session',null);
  clearTimeout(aiTimer);clearTimeout(resTimer);
  aiBusy=false;animBusy=false;
  leaveRoom();
  const back=mode==='cpu'&&CFG.bot?CFG.bot.kind:'';
  LIVE=null;G=null;logKey='';role=0;flip=false;mode='cpu';meSide=1;CFG={names:{1:'플레이어',2:'컴퓨터'},bot:null,hints:Infinity};
  hideOverlays();$('#waiting').hidden=true;
  if(back==='coach'&&typeof p!=='string'){openCoach();return;}
  if(back==='bot'&&typeof p!=='string'){openBots();return;}
  panel(typeof p==='string'?p:'main');show('scr-menu');
}
function renderStats(){
  const st=store.get('dama.stats',{cpu:{},local:0,online:[0,0,0]});
  const box=$('#statBox');box.textContent='';
  const row=(a,v)=>{const d=document.createElement('div');d.append(a+' · ');const e=document.createElement('b');e.textContent=v;d.appendChild(e);box.appendChild(d);};
  const nmz={1:'쉬움',2:'보통',3:'어려움',4:'달인'};
  for(const lv of [1,2,3,4]){const a=(st.cpu||{})[lv]||[0,0,0];row('솔로 '+nmz[lv],a[0]+'승 '+a[1]+'패 '+a[2]+'무');}
  { const c=st.coach||[0,0,0],b=st.bot||[0,0,0];row('코치님과 플레이',c[0]+'승 '+c[1]+'패 '+c[2]+'무');row('봇 대전',b[0]+'승 '+b[1]+'패 '+b[2]+'무'); }
  row('같은 기기 2인',(st.local||0)+'판');
  row('온라인',Net.me?('레이팅 '+Net.me.rating+' ('+Net.me.w+'승 '+Net.me.l+'패 '+Net.me.d+'무)'):'로그인한 상태에서 열면 레이팅이 표시됩니다');
  row('솔로·봇 레이팅',String(myRating()));
  if(Net.me) row('온라인 레이팅',String(Net.me.rating));
  row('보유 코인',String(W.coins));
  loadRank();
}
async function loadRank(){
  const ol=$('#rankList'),msg=$('#rankMsg');
  ol.textContent='';msg.textContent='';
  if(!Net.ready){msg.textContent='온라인 랭킹은 로그인한 상태에서 볼 수 있습니다.';return;}
  try{
    const q=await Net.db.collection('players').orderBy('rating','desc').limit(20).get();
    if(!q.size){msg.textContent='아직 랭킹 기록이 없습니다. 온라인 대전을 마치면 올라갑니다.';return;}
    q.docs.forEach(x=>{
      const d=x.data(),li=document.createElement('li');
      li.textContent=(d.name||'플레이어')+' — '+d.rating+' ('+(d.w||0)+'승 '+(d.l||0)+'패 '+(d.d||0)+'무)';
      if(d.id===Net.uid) li.className='me';
      ol.appendChild(li);
    });
  }catch(e){msg.textContent=netMessage(e);}
}

const nickEl=$('#nick');
nickEl.value=store.get('dama.nick','');
nickEl.addEventListener('input',()=>store.set('dama.nick',clean(nickEl.value)));
const getNick=def=>clean(nickEl.value)||def;

$('#soloBtn').addEventListener('click',()=>panel('solo'));
$('#multiBtn').addEventListener('click',()=>panel('multi'));
$('#gamesBtn').addEventListener('click',()=>panel('games'));
document.querySelectorAll('#scr-menu .back').forEach(b=>b.addEventListener('click',()=>panel(b.dataset.to)));
document.querySelectorAll('#scr-menu [data-lv]').forEach(b=>b.addEventListener('click',()=>startGame('cpu',{1:getNick('플레이어'),2:'컴퓨터'},+b.dataset.lv)));
$('#shopBtn').addEventListener('click',()=>panel('shop'));
$('#coinChip').addEventListener('click',()=>panel('shop'));
$('#statsBtn').addEventListener('click',()=>panel('stats'));
$('#settingsBtn').addEventListener('click',()=>panel('settings'));
$('#tutBtn').addEventListener('click',openTut);
$('#resumeBtn').addEventListener('click',resumeRoom);
$('#quickBtn').addEventListener('click',quickMatch);
$('#roomsBtn').addEventListener('click',()=>panel('rooms'));
$('#roomsRefresh').addEventListener('click',loadRooms);
$('#setCoach').addEventListener('change',e=>{SET.coach=e.target.checked;saveSet();if(G)renderAll();});
$('#coachAsk').addEventListener('click',coachAsk);
$('#setFs').addEventListener('change',e=>{SET.fs=+e.target.value;saveSet();applyLook();});
$('#setRm').addEventListener('change',e=>{SET.rm=e.target.checked;saveSet();applyLook();});
$('#setHc').addEventListener('change',e=>{SET.hc=e.target.checked;saveSet();applyLook();});
$('#setCb').addEventListener('change',e=>{SET.cb=e.target.checked;saveSet();applyLook();});
$('#setLimit').addEventListener('change',e=>{SET.limit=+e.target.value||0;saveSet();});
$('#localBtn').addEventListener('click',()=>panel('local'));
$('#localStart').addEventListener('click',()=>startGame('local',{1:getNick('플레이어 1'),2:clean($('#p2nick').value)||'플레이어 2'}));
$('#onlineBtn').addEventListener('click',()=>panel('online'));
$('#createRoom').addEventListener('click',createRoom);
$('#joinRoom').addEventListener('click',joinRoom);
$('#roomCodeIn').addEventListener('keydown',e=>{if(e.key==='Enter') joinRoom();});

$('#toMenu').addEventListener('click',()=>toMenu());
$('#newgame').addEventListener('click',()=>{if(mode!=='online') newGame();});
$('#again').addEventListener('click',()=>{if(mode==='online') rematch();else newGame();$('#result').hidden=true;});
$('#viewBoard').addEventListener('click',()=>{$('#result').hidden=true;});
$('#resMenu').addEventListener('click',()=>toMenu());
$('#resReplay').addEventListener('click',()=>{$('#result').hidden=true;startReplayFromGame();});
$('#undo').addEventListener('click',undo);
$('#stop').addEventListener('click',()=>{if(LIVE&&LIVE.chain>=0&&!LIVE.result) endHumanTurn();});
$('#replayBtn').addEventListener('click',startReplayFromGame);
$('#resign').addEventListener('click',resign);
$('#drawBtn').addEventListener('click',onDraw);
$('#reqYes').addEventListener('click',()=>answerReq(true));
$('#reqNo').addEventListener('click',()=>answerReq(false));
$('#exportBtn').addEventListener('click',openExport);
$('#rpExport').addEventListener('click',openExport);
$('#rpHint').addEventListener('click',toggleHint);
$('#exportClose').addEventListener('click',()=>{$('#exportModal').hidden=true;});
$('#exCopy').addEventListener('click',copyExport);
$('#exSelect').addEventListener('click',()=>{const t=$('#exText');t.focus();t.select();});
$('#tutClose').addEventListener('click',closeTut);
$('#tutPrev').addEventListener('click',()=>{if(tutI>0){tutI--;renderTut();}});
$('#tutNext').addEventListener('click',()=>{if(tutI<TUT.length-1){tutI++;renderTut();}else closeTut();});
$('#chatSend').addEventListener('click',()=>{sendChat($('#chatIn').value);$('#chatIn').value='';});
$('#chatIn').addEventListener('keydown',e=>{if(e.key==='Enter'){sendChat($('#chatIn').value);$('#chatIn').value='';}});
for(const em of EMOJIS){const b=document.createElement('button');b.type='button';b.textContent=em;b.setAttribute('aria-label','빠른 반응 '+em);b.addEventListener('click',()=>sendChat(em));$('#emo').appendChild(b);}
$('#copyCode').addEventListener('click',copyCode);
$('#waitCopy').addEventListener('click',copyCode);
$('#waitCancel').addEventListener('click',()=>toMenu('online'));

$('#rpFirst').addEventListener('click',()=>{stopReplayTimer();replayStep(0);});
$('#rpPrev').addEventListener('click',()=>{stopReplayTimer();replayStep(REPLAY.k-1);});
$('#rpNext').addEventListener('click',()=>{stopReplayTimer();replayStep(REPLAY.k+1);});
$('#rpLast').addEventListener('click',()=>{stopReplayTimer();replayStep(REPLAY.moves.length);});
$('#rpPlay').addEventListener('click',togglePlay);
$('#rpSlider').addEventListener('input',e=>{stopReplayTimer();replayStep(+e.target.value);});
$('#rpExit').addEventListener('click',exitReplay);

const rules=$('#rules');
let rulesFrom=null;
const openRules=from=>{rulesFrom=from;rules.hidden=false;$('#rulesClose').focus();};
const closeRules=()=>{rules.hidden=true;if(rulesFrom) rulesFrom.focus();};
$('#rulesBtn').addEventListener('click',()=>openRules($('#rulesBtn')));
$('#menuRules').addEventListener('click',()=>openRules($('#menuRules')));
$('#rulesClose').addEventListener('click',closeRules);
rules.addEventListener('click',e=>{if(e.target===rules) closeRules();});
document.addEventListener('keydown',e=>{
  if(e.key==='Escape'&&!$('#tutorial').hidden){closeTut();return;}
  if(e.key==='Escape'&&!$('#exportModal').hidden){$('#exportModal').hidden=true;return;}
  if(e.key==='Escape'&&!rules.hidden){closeRules();return;}
  if(!REPLAY||e.target.matches('input[type=text]')) return;
  if(e.key==='ArrowLeft'){stopReplayTimer();replayStep(REPLAY.k-1);}
  else if(e.key==='ArrowRight'){stopReplayTimer();replayStep(REPLAY.k+1);}
  else if(e.key==='Home'){stopReplayTimer();replayStep(0);}
  else if(e.key==='End'){stopReplayTimer();replayStep(REPLAY.moves.length);}
});

document.addEventListener('visibilitychange',()=>{
  if(!document.hidden&&mode==='online'&&Net.ref){Net.ref.get().then(onRoom).catch(()=>{});}
});
window.addEventListener('online',()=>{if(mode==='online'&&Net.ref){Net.ref.get().then(onRoom).catch(()=>{});}});

const deco=$('#deco');
for(let r=0;r<5;r++)for(let c=0;c<8;c++){
  const s=document.createElement('span');
  if(r<2) s.className='p2';else if(r>2) s.className='p1';
  deco.appendChild(s);
}

