'use strict';
/* ---------- result, saved games ---------- */
function resultLine(res,names){
  if(!res) return '';
  if(res.winner===0) return '무승부';
  const why={wipe:'전멸',block:'봉쇄',resign:'기권',time:'시간 초과',agree:'합의'}[res.why]||'';
  return names[res.winner]+' 승'+(why?' ('+why+')':'');
}
const MODE_LABEL={cpu:'솔로',local:'2인',online:'온라인'};
function saveGame(L){
  const list=store.get('dama.games.v1',[]);
  list.unshift({t:Date.now(),mode,me:mode==='cpu'?meSide:0,names:[L.names[1],L.names[2]],moves:L.moves.map(enc),res:[L.result.winner,L.result.why]});
  store.set('dama.games.v1',list.slice(0,20));
}
function renderGames(){
  const ul=$('#gamesList'),list=store.get('dama.games.v1',[]);
  ul.textContent='';
  if(!list.length){
    const li=document.createElement('li');li.className='note';li.textContent='아직 저장된 대국이 없습니다. 한 판을 끝내면 여기에 쌓입니다.';
    ul.appendChild(li);return;
  }
  list.forEach((g,i)=>{
    const li=document.createElement('li');
    const b=document.createElement('button');b.type='button';b.className='gitem';
    const t=document.createElement('b');t.textContent=g.names[0]+' vs '+g.names[1];
    const s=document.createElement('small');
    const d=new Date(g.t).toLocaleString(LANG==='en'?'en-US':'ko-KR',{month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit'});
    s.textContent=d+' · '+(MODE_LABEL[g.mode]||'')+' · '+g.moves.length+'수 · '+resultLine({winner:g.res[0],why:g.res[1]},{1:g.names[0],2:g.names[1]});
    b.append(t,s);
    b.addEventListener('click',()=>openSaved(g));
    const del=document.createElement('button');del.type='button';del.className='gdel';del.textContent='✕';del.setAttribute('aria-label','삭제');
    del.addEventListener('click',()=>{const l=store.get('dama.games.v1',[]);l.splice(i,1);store.set('dama.games.v1',l);renderGames();});
    li.append(b,del);ul.appendChild(li);
  });
}
function openSaved(g){
  leaveRoom();mode='cpu';role=0;flip=false;LIVE=null;
  replayFrom='menu';
  show('game');chromeUI();$('#lvl-wrap').hidden=true;
  startReplay({moves:g.moves.map(dec),names:{1:g.names[0],2:g.names[1]},result:{winner:g.res[0],why:g.res[1]},when:g.t,me:g.me||0});
}

function showResult(L){
  G=REPLAY?G:L;
  const r=L.result,big=$('#resTitle'),txt=$('#resText'),name=p=>L.names[p]||('플레이어 '+p);
  big.className='big';
  const online=mode==='online';
  {const ex=[];if(L.reward) ex.push('+'+L.reward+' 코인');if(typeof L.rd==='number'&&Net.me) ex.push('레이팅 '+(L.rd>=0?'+':'')+L.rd+' → '+Net.me.rating);if(typeof L.srd==='number'&&getProfile()) ex.push('레이팅 '+(L.srd>=0?'+':'')+L.srd+' → '+getProfile().rating);if(mode==='cpu'&&CFG.bot&&CFG.bot.kind==='coach') ex.push('연습 대국 · 레이팅 변동 없음');if(L.botNote) ex.push(L.botNote);$('#resExtra').textContent=ex.join(' · ');}
  if(r.winner===0){big.textContent='무승부';txt.textContent=r.why==='agree'?'두 플레이어가 무승부에 합의했습니다.':LIMIT+'수 동안 포획도 새로운 전진도 없어 승부가 나지 않았습니다.';}
  else{
    big.textContent=name(r.winner)+' 승리!';big.classList.add('w'+r.winner);
    txt.textContent={wipe:'상대의 말을 모두 잡았습니다.',block:'상대가 더 이상 움직일 수 없습니다.',resign:'상대가 기권했습니다.',time:'상대가 제한 시간 안에 두지 못했습니다.'}[r.why]||'';
    if(mode==='cpu'&&r.winner===3-meSide) txt.textContent+=' 난이도를 낮추거나 다시 도전해 보세요.';
    if(online&&role&&r.winner!==role) txt.textContent+=' 재대결로 다시 겨뤄 보세요.';
  }
  const mine=mode==='cpu'?r.winner===meSide:online?(role===0||r.winner===role):true;
  if(r.winner!==0&&mine) confetti();
  $('#again').textContent=online?'재대결':'다시 하기';
  $('#again').hidden=online&&role===0;
  $('#result').hidden=false;$('#again').hidden?$('#resReplay').focus():$('#again').focus();
}
function confetti(){
  if(matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const box=$('#confetti');box.innerHTML='';
  const cols=['var(--blue)','var(--red)','var(--select)','var(--gold)'];
  for(let k=0;k<64;k++){
    const i=document.createElement('i');
    i.style.cssText='--x:'+(Math.random()*100)+'vw;--dx:'+((Math.random()-.5)*30)+'vw;--d:'+(2.4+Math.random()*2)+'s;--w:'+(6+Math.random()*6)+'px;--rot:'+(Math.random()*720)+'deg;--delay:'+(Math.random()*.6)+'s;background:'+cols[k%4];
    box.appendChild(i);
  }
  setTimeout(()=>{box.innerHTML='';},6500);
}
let toastTimer=0;
function toast(msg){
  const t=$('#toast');t.textContent=msg;t.hidden=false;
  clearTimeout(toastTimer);toastTimer=setTimeout(()=>{t.hidden=true;},3600);
}

