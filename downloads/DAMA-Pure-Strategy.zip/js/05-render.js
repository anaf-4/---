'use strict';
/* ---------- rendering ---------- */
function renderPieces(){
  const pos=new Int16Array(33).fill(-1);
  for(let i=0;i<64;i++){const id=G.ids[i];if(id) pos[id]=i;}
  for(let id=1;id<=32;id++){
    const el=pieceEls[id],i=pos[id];
    if(i<0) el.classList.add('dead');
    else{
      const d=flip?63-i:i;
      el.classList.remove('dead');el.style.setProperty('--r',d>>3);el.style.setProperty('--c',d&7);
    }
  }
}
function renderHints(){
  for(let i=0;i<64;i++){
    const c=cells[i],v=G.b[i];
    c.classList.remove('hm','hc','own','lm');
    c.setAttribute('aria-label',sq(i)+' '+(v===0?'빈 칸':v===1?'파란 말':'붉은 말'));
  }
  for(let id=1;id<=32;id++) pieceEls[id].classList.remove('sel','marked');
  const last=G.moves[G.moves.length-1];
  if(last){cells[last.path[0]].classList.add('lm');cells[last.path[last.path.length-1]].classList.add('lm');}
  if(REPLAY||G.result||aiBusy||animBusy||!isHuman(G.turn)) return;
  const p=G.turn;
  for(let i=0;i<64;i++) if(G.b[i]===p) cells[i].classList.add('own');
  if(sel<0) return;
  const selEl=pieceEls[G.ids[sel]];
  if(!selEl){sel=-1;return;}
  selEl.classList.add('sel');
  const r=sel>>3,c=sel&7;
  if(G.chain<0) for(const m of simpleFrom(G.b,p,r,c)) cells[m.r*8+m.c].classList.add('hm');
  for(const j of jumpsFrom(G.b,p,r,c)){
    cells[j.r*8+j.c].classList.add('hc');
    pieceEls[G.ids[j.cr*8+j.cc]].classList.add('marked');
  }
}
const nm=p=>G.names[p]||('플레이어 '+p);
function renderAll(){
  if(!G) return;
  renderPieces();renderHints();renderArrows();
  const live=!REPLAY,over=live&&!!G.result,turn=G.turn;
  $('#cnt1').textContent=count(G.b,1);$('#cnt2').textContent=count(G.b,2);
  $('#lab1').textContent=nm(1)+(mode==='online'&&role===1?' (나)':'');
  $('#lab2').textContent=nm(2)+(mode==='online'&&role===2?' (나)':'');
  $('#cbox1').classList.toggle('active',live&&!over&&turn===1);
  $('#cbox2').classList.toggle('active',live&&!over&&turn===2);
  $('#hud').dataset.turn=(over||REPLAY)?0:turn;
  $('#turnDot').className='dot p'+(turn===2?2:1);
  let t,h;
  if(REPLAY){
    const k=REPLAY.k,n=REPLAY.moves.length,last=REPLAY.moves[k-1];
    t='복기 · '+k+' / '+n+'수';
    h=last?nm(last.p)+'  '+notation(last):'시작 위치';
  }else if(over){t='게임 종료';h=mode==='online'?'재대결하거나 복기할 수 있습니다.':'‘새 게임’으로 다시 시작할 수 있습니다.';}
  else if(mode==='online'&&G.waiting){t='상대를 기다리는 중';h='방 코드를 상대에게 알려 주세요.';}
  else if(aiBusy){t='컴퓨터가 수를 고르는 중…';h='';}
  else{
    t=nm(turn)+'의 차례';
    if(mode==='online'){
      h=role===0?'관전 중입니다.':turn===role?(G.chain>=0?'이어서 뛰어넘거나 ‘여기서 멈추기’를 누르세요.':sel>=0?'이동할 칸을 선택하세요.':'내 차례입니다. 움직일 말을 선택하세요.'):'상대가 두는 중입니다.';
    }else h=G.chain>=0?'이어서 뛰어넘거나 ‘여기서 멈추기’를 누르세요.':sel>=0?'이동할 칸을 선택하세요.':'움직일 말을 선택하세요.';
  }
  $('#turnText').textContent=t;$('#turnHint').textContent=h;

  $('#controls').hidden=!!REPLAY;
  $('#replayPanel').hidden=!REPLAY;
  if(live){
    const L=LIVE,busy=aiBusy||animBusy;
    if(mode==='online'){
      const d=Net.room,mine=role&&L.moves.some(m=>m.p===role);
      $('#undo').textContent='무르기 요청';
      $('#undo').disabled=!role||!!L.result||L.waiting||!mine||!!(d&&d.req);
      $('#drawBtn').disabled=!role||!!L.result||L.waiting||!!(d&&d.req);
    }else{
      $('#undo').textContent='되돌리기';
      $('#undo').disabled=!!L.result||busy||(L.chain<0&&hist.length<2);
      $('#drawBtn').disabled=!!L.result||(mode==='cpu'&&busy);
    }
    $('#exportBtn').disabled=!L.moves.length;
    $('#stop').hidden=!(L.chain>=0)||!!L.result;
    $('#replayBtn').disabled=!L.moves.length;
    $('#resign').hidden=!(mode==='online'&&role!==0&&!L.result&&!L.waiting);
    $('#waiting').hidden=!(mode==='online'&&L.waiting);
  }else{
    $('#waiting').hidden=true;
    renderReplayPanel();
  }
  renderReq();
  const full=REPLAY?REPLAY.moves:G.moves,Q=qList(full);
  renderJudge(Q,(REPLAY?REPLAY.k:G.moves.length)-1);
  renderCoach(Q);renderOppAvatar();
  renderLog(Q);
  qPump();
}
let logKey='';
function renderLog(Q){
  const box=$('#logbox'),moves=REPLAY?REPLAY.moves:G.moves,cur=REPLAY?REPLAY.k:-1;
  const key=(REPLAY?'r'+REPLAY.k+'/':'g')+moves.length+'/'+qVer;
  $('#logsec').classList.toggle('rv',!!REPLAY);
  if(key!==logKey){
    logKey=key;
    if(!moves.length) box.innerHTML='<p class="empty">아직 둔 수가 없습니다. 파란 말부터 시작합니다.</p>';
    else{
      let h='<ol>';
      for(let i=0;i<moves.length;i+=2){
        h+='<li><span class="n">'+(i/2+1)+'</span>';
        for(let j=i;j<i+2;j++){
          if(j<moves.length) h+='<button type="button" class="mv '+(j%2?'r':'b')+(cur===j+1?' cur':'')+'" data-k="'+(j+1)+'"'+(REPLAY?'':' tabindex="-1"')+(Q[j]&&Q[j].k?' title="'+QL[Q[j].k][0]+'"':'')+'>'+notation(moves[j])+(Q[j]&&Q[j].k?'<span class="q">'+QI[Q[j].k]+'</span>':'')+'</button>';
          else h+='<span></span>';
        }
        h+='</li>';
      }
      box.innerHTML=h+'</ol>';
      const ol=box.querySelector('ol'),c=ol.querySelector('.cur');
      if(c) ol.scrollTop=Math.max(0,c.offsetTop-ol.clientHeight/2);
      else ol.scrollTop=ol.scrollHeight;
    }
  }
  $('#prog').textContent=REPLAY?'':'진전 없는 수 '+G.noprog+' / '+LIMIT;
}
$('#logbox').addEventListener('click',e=>{
  const b=e.target.closest('.mv');
  if(b&&REPLAY) replayStep(+b.dataset.k);
});

