'use strict';
/* ---------- settings, coins, shop ---------- */
const SET=Object.assign({cb:false,limit:0,tut:false,hint:true,coach:true,fs:1,rm:false,hc:false},store.get('dama.set',{}));
const saveSet=()=>store.set('dama.set',SET);
const W={coins:+store.get('dama.coins',0)||0,own:store.get('dama.own',['board:slate','piece:disc']),eq:Object.assign({board:'slate',piece:'disc'},store.get('dama.eq',{}))};
const saveW=()=>{store.set('dama.coins',W.coins);store.set('dama.own',W.own);store.set('dama.eq',W.eq);};
function applyLook(){const de=document.documentElement;de.dataset.motion=SET.rm?'reduce':'';de.dataset.hc=SET.hc?'1':'';de.style.fontSize=(16*(+SET.fs||1))+'px';de.dataset.cb=SET.cb?'1':'0';document.body.dataset.board=W.eq.board;document.body.dataset.piece=W.eq.piece;}
const SHOP={
  board:[{id:'slate',name:'슬레이트',price:0},{id:'wood',name:'우드',price:60},{id:'mint',name:'민트',price:90},{id:'sakura',name:'벚꽃',price:120},{id:'midnight',name:'미드나잇',price:160},{id:'sunset',name:'선셋',price:220},{id:'neon',name:'네온',price:300},{id:'forest',name:'숲',price:0,reward:true}],
  piece:[{id:'disc',name:'기본 돌',price:0},{id:'glass',name:'유리 돌',price:70},{id:'cube',name:'큐브',price:90},{id:'pixel',name:'픽셀',price:110},{id:'metal',name:'메탈',price:140},{id:'gem',name:'보석',price:200},{id:'chip',name:'칩',price:0,reward:true}]
};
const owns=(kind,id)=>W.own.includes(kind+':'+id);
const START_RATING=1000;
const getProfile=()=>store.get('dama.profile',null);
const myRating=()=>getProfile()?getProfile().rating:START_RATING;
function updateCoinUI(){$('#coinNum').textContent=W.coins;const rc=$('#rateChip');if(rc){rc.hidden=!getProfile();$('#rateNum').textContent=myRating();}}
function swatch(kind,it){
  const d=document.createElement('div');d.className='sw';
  d.dataset.board=kind==='board'?it.id:W.eq.board;
  d.dataset.piece=kind==='piece'?it.id:W.eq.piece;
  const pat=['','B','','R','B','','R','','','R','','B','R','','B',''];
  for(let i=0;i<16;i++){
    const c=document.createElement('span');
    if(pat[i]){const pv=document.createElement('span');pv.className='pv p'+(pat[i]==='B'?1:2);pv.innerHTML='<span class="disc"></span>';c.appendChild(pv);}
    d.appendChild(c);
  }
  return d;
}
function renderShop(){
  updateCoinUI();
  for(const [kind,boxId] of [['board','#shopBoards'],['piece','#shopPieces']]){
    const box=$(boxId);box.textContent='';
    for(const it of SHOP[kind]){
      const card=document.createElement('div');card.className='shopitem'+(W.eq[kind]===it.id?' eq':'');
      const nameEl=document.createElement('b');nameEl.textContent=it.name;
      const price=document.createElement('small');
      const btn=document.createElement('button');btn.type='button';btn.className='btn';
      const own=owns(kind,it.id);
      if(W.eq[kind]===it.id){price.textContent='사용 중';btn.textContent='장착됨';btn.disabled=true;}
      else if(own){price.textContent='보유';btn.textContent='장착';btn.onclick=()=>{W.eq[kind]=it.id;saveW();applyLook();renderShop();};}
      else if(it.reward){price.textContent='봇 대전 전체 격파 보상';btn.textContent='잠김';btn.disabled=true;}
      else{price.textContent=it.price+' 코인';btn.textContent='구매';btn.disabled=W.coins<it.price;
        btn.onclick=()=>{if(W.coins<it.price) return;W.coins-=it.price;W.own.push(kind+':'+it.id);W.eq[kind]=it.id;saveW();applyLook();renderShop();toast(it.name+' 구매 완료!');};}
      card.append(swatch(kind,it),nameEl,price,btn);box.appendChild(card);
    }
  }
}

let LIVE=null,G=null,REPLAY=null,CFG={names:{1:'플레이어',2:'컴퓨터'},bot:null,hints:Infinity},meSide=1;
let hist=[],mode='cpu',role=0,flip=false,sel=-1,aiBusy=false,animBusy=false,aiTimer=0,resTimer=0,replayFrom='game';
const isHuman=t=>mode==='cpu'?t===meSide:mode==='local'?true:(role!==0&&t===role);

