'use strict';
/* ---------- board DOM ---------- */
const boardEl=$('#board'),cells=[],pieceEls={};
for(let i=0;i<64;i++){
  const el=document.createElement('button');
  el.type='button';el.className='cell';
  el.addEventListener('click',()=>onCell(i));
  boardEl.appendChild(el);cells.push(el);
}
const NS='http://www.w3.org/2000/svg';
const arrowSvg=document.createElementNS(NS,'svg');arrowSvg.setAttribute('class','arrows');arrowSvg.setAttribute('viewBox','0 0 8 8');arrowSvg.setAttribute('aria-hidden','true');
boardEl.appendChild(arrowSvg);
const mkSvg=(t,a)=>{const e=document.createElementNS(NS,t);for(const k in a) e.setAttribute(k,a[k]);return e;};
function renderArrows(){
  arrowSvg.textContent='';
  const arrows=G&&G.arrows;if(!arrows) return;
  for(const a of arrows){
    const pts=a.path.map(i=>{const d=flip?63-i:i;return [(d&7)+.5,(d>>3)+.5];});
    arrowSvg.appendChild(mkSvg('polyline',{class:a.cls,points:pts.map(q=>q.join(',')).join(' ')}));
    const [x2,y2]=pts[pts.length-1],[x1,y1]=pts[pts.length-2];
    const L=Math.hypot(x2-x1,y2-y1)||1,ux=(x2-x1)/L,uy=(y2-y1)/L,px=-uy,py=ux;
    const bx=x2-ux*.32,by=y2-uy*.32;
    const hp=[[x2+ux*.08,y2+uy*.08],[bx+px*.17,by+py*.17],[bx-px*.17,by-py*.17]];
    arrowSvg.appendChild(mkSvg('polygon',{class:a.cls,points:hp.map(q=>q[0].toFixed(3)+','+q[1].toFixed(3)).join(' ')}));
  }
}
let focusIdx=52;
function setFocus(i){cells[focusIdx].tabIndex=-1;focusIdx=i;cells[i].tabIndex=0;}
cells.forEach((el,i)=>{el.tabIndex=i===focusIdx?0:-1;el.addEventListener('focus',()=>setFocus(i));});
boardEl.addEventListener('keydown',e=>{
  const dir={ArrowUp:[-1,0],ArrowDown:[1,0],ArrowLeft:[0,-1],ArrowRight:[0,1]}[e.key];
  if(dir){
    const i=focusIdx,v=flip?63-i:i,r=Math.max(0,Math.min(7,(v>>3)+dir[0])),c=Math.max(0,Math.min(7,(v&7)+dir[1])),nv=r*8+c;
    cells[flip?63-nv:nv].focus();e.preventDefault();
  }else if(e.key==='Escape'&&LIVE&&!REPLAY&&LIVE.chain<0&&sel>=0){sel=-1;renderAll();}
});
const layer=document.createElement('div');layer.className='pieces';boardEl.appendChild(layer);
const qb=document.createElement('div');qb.className='qb';qb.hidden=true;layer.appendChild(qb);
for(let id=1;id<=32;id++){
  const el=document.createElement('div');
  el.className='piece '+(id<=16?'p1':'p2');
  el.innerHTML='<span class="disc"></span>';
  layer.appendChild(el);pieceEls[id]=el;
}
function applyFlip(){
  for(let i=0;i<64;i++) cells[i].style.order=flip?63-i:i;
  $('#ranks').classList.toggle('rev',flip);
  $('#files').classList.toggle('rev',flip);
}
function freshIds(b){
  const ids=new Int16Array(64);let a=1,c=17;
  for(let i=0;i<64;i++){if(b[i]===1) ids[i]=a++;else if(b[i]===2) ids[i]=c++;}
  return ids;
}
function freshState(names){
  const b=newBoard();
  return {b,ids:freshIds(b),turn:1,noprog:0,fr:newFr(),moves:[],result:null,chain:-1,path:null,capList:[],names,saved:false,gen:0,rev:0,limit:0,ctag:'',tStart:0,tOut:false,rated:false,reward:0,rd:null,waiting:false,pendingResult:false};
}
function applyRecBoth(b,ids,rec){
  const id=ids[rec.path[0]];
  b[rec.path[0]]=0;ids[rec.path[0]]=0;
  for(const c of rec.caps){b[c]=0;ids[c]=0;}
  const e=rec.path[rec.path.length-1];
  b[e]=rec.p;ids[e]=id;
}

