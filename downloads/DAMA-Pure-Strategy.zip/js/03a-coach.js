'use strict';
/* ---------- coach (solo only): comments on your moves, warns about threats, gives hints ---------- */
let coachHint=null; /* {n:moves played when asked, rec, text} */
const COACH_TIPS=[
  '먼저 잡을 수 있는 말이 있는지 확인해 보세요. 뛰어넘기는 연속으로 이어갈 수 있어요.',
  '말은 앞·옆으로 뛰고, 한 칸 뒤로는 걸어서만 물러날 수 있어요.',
  '내 말 바로 뒤 칸이 비어 있으면 상대가 뛰어넘어 잡을 수 있어요.',
  '말을 한 줄로 나란히 세우면 서로 뒤를 막아 줘서 단단해져요.',
  '상대 말이 줄어들면 길이 열려요. 말 수에서 앞서고 있다면 교환을 두려워하지 마세요.',
  '40수 동안 진전이 없으면 무승부예요. 앞서고 있다면 전진해서 끝내 보세요.'
];
const coachKind=()=>CFG.bot?CFG.bot.kind:'quick';
function coachOn(){const k=coachKind();return mode==='cpu'&&(k==='coach'||(k==='quick'&&SET.coach!==false))&&!REPLAY&&!!G&&G===LIVE;}
function coachThreat(b){
  const ms=genMoves(b,3-meSide).sort((x,y)=>y.caps.length-x.caps.length);
  return ms.length&&ms[0].caps.length?ms[0]:null;
}
function coachAsk(){
  const L=LIVE;
  if(!coachOn()||L.result||aiBusy||animBusy||L.turn!==meSide||L.chain>=0||!(CFG.hints>0)) return;
  if(isFinite(CFG.hints)) CFG.hints--;
  const b=L.b,m=chooseTimed(b,meSide,4,700);
  if(!m) return;
  const rec=fromMove(m,meSide),mv='‘'+notation(rec)+'’';
  const reply=genMoves(applyMove(b,meSide,m),3-meSide).reduce((x,y)=>y.caps.length>x.caps.length?y:x,{caps:[]});
  const thr=coachThreat(b);
  let text;
  if(m.caps.length) text='추천 수는 '+mv+'예요. 상대 말 '+m.caps.length+'개를 잡을 수 있어요!'+(reply.caps.length?' 다만 그 뒤 상대가 말 '+reply.caps.length+'개를 되받아칠 수 있으니 주의하세요.':'');
  else if(thr&&!reply.caps.length) text='추천 수는 '+mv+'예요. 상대의 위협을 피하면서 말을 잃지 않는 수예요.';
  else if(!reply.caps.length) text='추천 수는 '+mv+'예요. 말을 잃지 않고 형세를 조금씩 좋게 만드는 수예요.';
  else text='추천 수는 '+mv+'예요. 지금은 이 수가 손해가 가장 적어요.';
  coachHint={n:L.moves.length,rec,text};
  L.arrows=[{cls:'a-best',path:rec.path}];
  renderAll();
}
function coachClear(){
  if(coachHint&&(!G||G.moves.length!==coachHint.n||G!==LIVE)){coachHint=null;if(G){G.arrows=null;renderArrows();}}
}
function renderCoach(Q){
  const box=$('#coach');
  coachClear();
  if(!coachOn()){box.hidden=true;return;}
  box.hidden=false;
  const L=LIVE,mine=L.turn===meSide&&!L.result&&!aiBusy&&!animBusy;
  {const left=CFG.hints,ask=$('#coachAsk');ask.hidden=left===0;ask.disabled=!mine||L.chain>=0;ask.textContent='힌트 받기'+(isFinite(left)&&left>0?' ('+left+'회 남음)':'');}
  if(!box.dataset.av){box.dataset.av=1;$('#coachAv').innerHTML=avatarSvg(COACH_AV);}
  let mood='idle',lines=[];
  if(L.result){
    let bad=0,good=0;
    L.moves.forEach((m,i)=>{if(m.p!==meSide) return;const q=Q[i];if(q&&(q.k==='blunder'||q.k==='mistake'))bad++;if(q&&(q.k==='best'||q.k==='excellent'))good++;});
    const w=L.result.winner,won=w===meSide;
    lines.push(won?'승리 축하해요! ':w===0?'무승부예요. 끝까지 잘 버텼어요. ':'아쉽게 졌지만 좋은 경기였어요. ');
    lines.push('내가 둔 수 중 좋은 수 '+good+'개, 실수·블런더 '+bad+'개였어요. ‘복기’에서 어디가 갈림길이었는지 같이 볼까요?');
    mood=won?'happy':'think';
  }else if(coachHint){
    lines.push(coachHint.text);mood='hint';
  }else{
    let idx=-1;for(let i=L.moves.length-1;i>=0;i--) if(L.moves[i].p===meSide){idx=i;break;}
    const thr=mine&&L.chain<0?coachThreat(L.b):null;
    if(idx>=0&&idx>=L.moves.length-2){
      const q=Q[idx],rec=L.moves[idx];
      if(q===undefined) lines.push('방금 수를 살펴보는 중이에요…');
      else if(q.k){
        const t=coachText(rec,q);
        lines.push('‘'+notation(rec)+'’ — '+QL[q.k][0]+'. '+(t||QL[q.k][1]));
        mood=(q.k==='best'||q.k==='excellent')?'happy':'think';
      }
    }
    if(thr){lines.push('주의: 상대가 ‘'+notation(fromMove(thr,3-meSide))+'’로 말 '+thr.caps.length+'개를 노리고 있어요.');mood='warn';}
    if(!lines.length&&CFG.hints===0) lines.push(L.moves.length<2?'힌트 없이 도전하는 대국이에요. 제가 옆에서 수를 평가해 드릴게요!':COACH_TIPS[Math.floor(L.moves.length/2)%COACH_TIPS.length]);
    if(!lines.length) lines.push(L.moves.length<2?'안녕하세요, 다마 코치예요! 막히면 ‘힌트’를 눌러 보세요.':COACH_TIPS[Math.floor(L.moves.length/2)%COACH_TIPS.length]);
  }
  if(!L.result&&!coachHint&&L.moves.length===0&&coachKind()==='coach') lines=[CFG.hints===0?'환영합니다! 힌트 없이 도전하는 대국이에요. 제가 옆에서 수를 평가해 드릴게요.':'환영합니다! 함께 게임하면서 전략을 가르쳐 드릴게요. 막히면 ‘힌트’를 눌러 보세요.'];
  let canRetry=false;
  if(mine&&!coachHint){const li=L.moves.length-2,q=li>=0&&L.moves[li].p===meSide?Q[li]:null;canRetry=!!(q&&(q.k==='blunder'||q.k==='mistake')&&hist.length>=2);}
  $('#coachUndo').hidden=!canRetry;
  box.dataset.mood=mood;
  $('#coachText').textContent=lines.join('\n');
}
